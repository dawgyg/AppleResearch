# CONFIRMED: kauth_acl_inherit mutable-count reload -> kernel heap OOB WRITE

Verdict: **DYNAMICALLY CONFIRMED KERNEL HEAP OOB WRITE**

Build: macOS 27 beta 4 `26A5388g`, xnu
`13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE`.

Triggering process: `v32select`, `uid=501`, `gid=20`, PID 3890.

This lifts the filing hold on the `kauth_acl_inherit` upgrade. It does not yet
prove standalone exploitation, controlled PC, LPE, or Target Flag. The current
trigger remains DTrace-assisted.

## Decisive panic

Artifact:

```text
/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/
panics/panic-full-2026-07-29-082922.0002.panic
sha256 55181fa799ca171942be7255a355e36eeaba36ef2f41942ec7a44dcd16ecc90a
```

The panic reports:

```text
ESR 0x96000047: WRITE
runtime PC = 0xfffffe0019000df0
FAR        = 0xfffffe2face20008

Probabilistic GZAlloc Report:
  Zone    : data.kalloc.32
  Kind    : out-of-bounds (high confidence)
  Access  : 9 byte(s) past

fault:
  str x16, [x17, #0x10]
```

The generic symbol-span resolver calls this `_kauth_acl_evaluate+0x5d4`.
That label is wrong for this stripped local function. The effective KDK
`__TEXT_EXEC` slide is:

```text
runtime __TEXT_EXEC base  0xfffffe0018a4c000
KDK __TEXT_EXEC vmaddr    0xfffffe00072fc000
effective slide           0x11750000

0xfffffe0019000df0 - 0x11750000
  = 0xfffffe00078b0df0
```

KDK `atos` resolves the exact unslid PC:

```text
kauth_acl_inherit (kern_authorization.c:906)
```

This is the store site independently identified before the run:

```text
0xfffffe00078b0df0  str x16,[x17,#0x10]
0xfffffe00078b0df4  str q0,[x17]
```

## Exact A/B/C identity

The pre-run map contains:

```text
PID 3890
A = fffffe2facd702a0
B = fffffe2facd702c0
C = fffffe2facd702e0
```

The panic has:

```text
x19 = fffffe2facd702c0
```

Therefore `kauth_acl_inherit`'s mutable source ACL is exactly selected slot
`B`, not an unrelated allocation.

## Rule Zero register proof

Source-side operands:

```text
source ACL base = x19 = B
source index    = x11 = 0x559 = 1369
source record   = x1

x1 == x19 + 8 + x11*24
```

Destination-side operands:

```text
destination ACL base = x0
qualifying index      = x10 = 0x1c6 = 454
destination record    = x17

x17 == x0 + 8 + x10*24
FAR == x17 + 0x10
```

The destination was sized from one eligible ACE, so the allocation request was
32 bytes. The mutable source-count reload let the copy loop reach source index
1369 and destination index 454. The first 8-byte record store eventually hit a
GZAlloc guard after writing far beyond the one-record destination.

No instruction bounds the reloaded source count against the original count,
eligible count, `0x80`, source allocation span, or destination allocation
span.

## Attacker-influenced write contents

At the fault:

```text
x16 = 0xffffffff00000041
```

That is the exact little-endian qword at offset `0x10` in the supplied
`ace-everybody-allow-all-dir-inherit` payload:

```text
flags  = 0x00000041
rights = 0xffffffff
packed = 0xffffffff00000041
```

The faulting `str x16,[x17,#0x10]` was therefore attempting to write the
attacker-sprayed ACE flags/rights qword. The following `str q0,[x17]` would
copy the other 16 bytes of the same 24-byte ACE, but the first store hit the
guard page.

This is stronger than a count-only OOB scan: an attacker-influenced 24-byte
record is copied out of groomed source heap into an unbounded linear
destination index.

## Trace change that reached it

Trace:

```text
trace_cross_digest_fixedspray_acl_inherit_beta4_attempt510.d
sha256 b8f49247309209e94e7d5f9331ad0feb8726c42dcb87d0e8d306eecd739277d8
```

The prior entry hold caused NULL digest-info panics. Attempt 510 moved the
499 ms hold to `ccdigest_final_64be:return`, after digest-info/key use and
before the outer digest copy resumed. That allowed:

1. the AES MIC output allocation to map onto helper `A`;
2. natural same-address AES-to-DES3 context replacement;
3. helper `B` to become the 32-byte inheritance source ACL;
4. `kauth_acl_inherit` to allocate a 32-byte destination and pause;
5. the MIC tail to corrupt `B->acl_entrycount`;
6. the inheritance loop to perform repeated 24-byte destination stores.

## Honest boundary

- Dynamic OOB WRITE: proven.
- Exact source object and unprivileged caller: proven.
- Attacker-influenced stored qword: proven.
- Standalone timing: not proven; DTrace widens/rendezvouses the race.
- Exact count control in this run: not proven. The predictor selected `0x2b`,
  but the loop reached at least 1370 records, so the live RPC reply body did
  not match the offline count predictor.
- Arbitrary write / controlled PC / LPE / Target Flag: not yet proven.

## Next work

1. Update the existing Apple case with this panic and register proof now.
2. Fix the live HMAC predictor so the actual count can be constrained to a
   small chosen value such as 2-8.
3. Reduce the digest-return hold while preserving the exact A/B/C sequence.
4. Replace the guard-page destination with a groomed adjacent kernel object
   and measure which fields the first extra 24-byte ACE overwrites.

## Artifact hashes

```text
panic-full-2026-07-29-082922.0002.panic
55181fa799ca171942be7255a355e36eeaba36ef2f41942ec7a44dcd16ecc90a

voucher_selective_inherit_attempt510.map
f04f9755c210324a723e78450d0087857301509b6087378b363fc7bc0be298c3

voucher_selective_inherit_attempt510.setup.log
17c2ec8de05a81914df507cb1c27711cba3e57d591ae4654ab5b9770b96c79cc

cross_digest_acl_inherit_beta4_attempt510.run.log
9207553ca9baf377199521d517ab11892bcc5f7df0b9f68936ae81ebdd45147a

cross_digest_acl_inherit_beta4_attempt510.target.log
aa33c42e036b758f179afe223d695db43e3b4087ce62c9fcfef7c4f1efdfdc16

cross_digest_acl_inherit_beta4_attempt510.wave.log
ae3f0012d742a4548ffd5761f757e4574775fadaa2f2950fd19da025ca5cebc3

voucher32_prearmed_oracle.c
6094282d34db53c22dc8730d406683147f7f0a74af38eeed48fb45380118ac90

run_cross_digest_acl_prestaged_nonmutual_beta4.sh
2cfb64c3f539d4fa9ee1ce702fa40e53c25d57e8a8f6a493c6cb76b650366ddf
```
