#!/usr/sbin/dtrace -s

#pragma D option quiet
#pragma D option dynvarsize=16m
#pragma D option switchrate=1ms

dtrace:::BEGIN
{
	configured_candidate_min_aes_mic = $1;
	configured_mic_hold_ns = (uint64_t)$2;
	configured_target_gss_handle = (uint32_t)$3;
	target_outer = (uintptr_t)0;
	target_nfs_cp = (uintptr_t)0;
	outer_cp_freed = 0;
	candidate_outer = (uintptr_t)0;
	target_mic_buf = (uintptr_t)0;
	target_alloc_cpu = -1;
	neighbor_alloc_caller = (uintptr_t)0;
	neighbor_alloc_request = 0;
	neighbor_alloc_key_derivation = 0;
	acl_neighbor_ptr = (uintptr_t)0;
	acl_neighbor_count_before = 0;
	acl_oob_ace_ptr = (uintptr_t)0;
	acl_ready = 0;
	acl_auth_ready = 0;
	acl_window_vap = (uintptr_t)0;
	acl_window_ptr = (uintptr_t)0;
	acl_window_getattr_return_ts = (uint64_t)0;
	acl_window_authorize_entry_ts = (uint64_t)0;
	inherit_exact_seen = 0;
	inherit_result_seen = 0;
	exact_des3 = 0;
	mic_finished = 0;
	mic_async_notified = 0;
	continue_signal_sent = 0;
	candidate_claimed = 0;
	replacement_make_done = 0;
	staged_replace_cp = (uintptr_t)0;
	staged_replace_outer = (uintptr_t)0;
	staged_replace_cpu = -1;
	replacement_destroy_barrier_done = 0;
	replacement_destroy_barrier_ready = 0;
	selective_stage1_total = 0;
	selected_mic_owner_plus1 = 0;
	selected_mic_slot_plus1 = 0;
	prealloc_barrier_ready = 0;
	early_continue_barrier_ready = 0;
	continue_barrier_ready = 0;
	digest_barrier_ready = 0;
	digest_barrier_start_ts = (uint64_t)0;
	precopy_ready = 0;
	precopy_async_notified = 0;
	precopy_tid = 0;
	precopy_len = 0;
	precopy_sink = (uintptr_t)0;
	precopy_digest = (uintptr_t)0;
	precopy_cctx = (uintptr_t)0;
	precopy_di = (uintptr_t)0;
	precopy_etype = 0;
	repair_barrier_ready = 0;
	repair_signal_sent = 0;
	repair_stop_signal_sent = 0;
	repair_make_done = 0;
	repair_null_seen = 0;
	data_signal_sent = 0;
	target_destroy_count = 0;
	neighbor_freed = 0;
	selected_neighbor_freed = 0;
	voucher_signal_sent = 0;
	printf("%llu trace_begin candidate_min_aes_mic=%d mic_hold_ns=%llu target_gss_handle=0x%x\n",
	    (uint64_t)walltimestamp, configured_candidate_min_aes_mic,
	    configured_mic_hold_ns, configured_target_gss_handle);
}

fbt:mach_kernel:nfs_gss_svc_verf_put:entry
{
	self->verf_cp = *(uintptr_t *)(arg0 + 0x140);
}

fbt:mach_kernel:nfs_gss_svc_verf_put:return
{
	if (self->verf_cp == target_nfs_cp && target_nfs_cp != 0) {
		printf("%llu OUTER_CP_VERF_RETURN tid=%d cp=%p freed=%d\n",
		    (uint64_t)walltimestamp, tid, self->verf_cp,
		    outer_cp_freed);
	}
	self->verf_cp = 0;
}

fbt:mach_kernel:nfs_gss_svc_ctx_init:entry
{
	self->ctx_init_cp = *(uintptr_t *)(arg0 + 0x140);
	this->ctx_init_inner = self->ctx_init_cp == 0 ? 0 :
	    *(uintptr_t *)(self->ctx_init_cp + 0xa0);
	if (self->ctx_init_cp != 0 &&
	    *(uint32_t *)(self->ctx_init_cp + 0x28) == 2 &&
	    this->ctx_init_inner != 0 &&
	    *(uint32_t *)(this->ctx_init_inner + 0x48) == 18 &&
	    *(uint32_t *)(this->ctx_init_inner + 0xc0) == 12) {
		staged_replace_cp = self->ctx_init_cp;
		staged_replace_outer = this->ctx_init_inner;
		staged_replace_cpu = cpu;
		printf("%llu STAGED_REPLACE_CTX_INIT tid=%d cpu=%d cp=%p outer=%p etype=%d digest=%d\n",
		    (uint64_t)walltimestamp, tid, staged_replace_cpu,
		    staged_replace_cp,
		    staged_replace_outer,
		    *(uint32_t *)(staged_replace_outer + 0x48),
		    *(uint32_t *)(staged_replace_outer + 0xc0));
	}
	printf("%llu OUTER_CP_CTX_INIT tid=%d cp=%p target=%d refcnt=%d proc=%d inner=%p\n",
	    (uint64_t)walltimestamp, tid, self->ctx_init_cp,
	    self->ctx_init_cp == target_nfs_cp,
	    self->ctx_init_cp == 0 ? -1 :
	    *(uint32_t *)(self->ctx_init_cp + 0x24),
	    self->ctx_init_cp == 0 ? -1 :
	    *(uint32_t *)(self->ctx_init_cp + 0x28),
	    self->ctx_init_cp == 0 ? 0 :
	    *(uintptr_t *)(self->ctx_init_cp + 0xa0));
}

fbt:mach_kernel:kfree_type_impl_internal:entry
/self->ctx_init_cp != 0 && arg1 == self->ctx_init_cp/
{
	printf("%llu OUTER_CP_FREE tid=%d view=%p cp=%p target=%d refcnt=%d proc=%d inner=%p\n",
	    (uint64_t)walltimestamp, tid, arg0, arg1,
	    arg1 == target_nfs_cp, *(uint32_t *)(arg1 + 0x24),
	    *(uint32_t *)(arg1 + 0x28), *(uintptr_t *)(arg1 + 0xa0));
	if (arg1 == target_nfs_cp) {
		outer_cp_freed = 1;
	}
}

fbt:mach_kernel:nfs_gss_svc_ctx_init:return
{
	printf("%llu OUTER_CP_CTX_INIT_RETURN tid=%d cp=%p target=%d freed=%d retval=%d\n",
	    (uint64_t)walltimestamp, tid, self->ctx_init_cp,
	    self->ctx_init_cp == target_nfs_cp, outer_cp_freed,
	    (int)arg1);
	self->ctx_init_cp = 0;
}

fbt:mach_kernel:nfs_gss_svc_ctx_deref:entry
/target_nfs_cp != 0 && arg0 == target_nfs_cp/
{
	printf("%llu OUTER_CP_DEREF tid=%d cp=%p freed=%d\n",
	    (uint64_t)walltimestamp, tid, arg0, outer_cp_freed);
}

profile:::profile-997
/target_mic_buf != 0 && mic_finished == 0 && mic_async_notified == 0/
{
	mic_async_notified = 1;
	printf("%llu MIC_ALLOC_ASYNC cpu=%d ptr=%p outer=%p\n",
	    (uint64_t)walltimestamp, cpu, target_mic_buf, target_outer);
}

profile:::profile-997
/precopy_ready != 0 && precopy_async_notified == 0/
{
	precopy_async_notified = 1;
	printf("%llu PRE_MEMCPY_ASYNC target_tid=%d observer_cpu=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d exact_des3=%d\n",
	    (uint64_t)walltimestamp, precopy_tid, cpu, precopy_cctx,
	    precopy_di, precopy_sink, precopy_digest, precopy_len,
	    precopy_etype, exact_des3);
}

profile:::profile-997
/target_outer != 0 && target_mic_buf != 0 &&
  mic_finished == 0 && repair_null_seen == 0 &&
  *(uintptr_t *)(target_outer + 0x78) == 0/
{
	repair_null_seen = 1;
	repair_barrier_ready = 1;
	printf("%llu NULL_DI_REPAIR_ARMED observer_cpu=%d outer=%p cctx=%p destroy_count=%d\n",
	    (uint64_t)walltimestamp, cpu, target_outer,
	    target_outer + 0x48, target_destroy_count);
}

syscall::getpid:entry
/execname == "rgssig" &&
  (early_continue_barrier_ready != 0 || continue_barrier_ready != 0) &&
  selected_mic_owner_plus1 != 0 &&
  continue_signal_sent == 0/
{
	continue_signal_sent = 1;
	printf("%llu DTRACE_CONTINUE_SIGNAL pid=%d ptr=%p outer=%p early=%d final=%d\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    early_continue_barrier_ready, continue_barrier_ready);
	raise(30);
}

syscall::access:entry
/execname == "rgssig" &&
  (early_continue_barrier_ready != 0 || continue_barrier_ready != 0) &&
  selected_mic_owner_plus1 != 0 &&
  continue_signal_sent == 0/
{
	continue_signal_sent = 1;
	printf("%llu DTRACE_CONTINUE_SIGNAL pid=%d ptr=%p outer=%p early=%d final=%d syscall=access\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    early_continue_barrier_ready, continue_barrier_ready);
	raise(30);
}

syscall::getpgid:entry
/execname == "rgssig" && repair_barrier_ready != 0 &&
  repair_signal_sent == 0 &&
  arg0 == 0x7b02/
{
	repair_signal_sent = 1;
	printf("%llu DTRACE_REPAIR_CONTINUE_SIGNAL pid=%d ptr=%p outer=%p cctx=%p di=%p destroy_count=%d\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    target_outer + 0x48, *(uintptr_t *)(target_outer + 0x78),
	    target_destroy_count);
	raise(31);
}

syscall::getpgid:entry
/execname == "rgssig" && exact_des3 != 0 &&
  repair_stop_signal_sent == 0 && arg0 == 0x7b03/
{
	repair_stop_signal_sent = 1;
	printf("%llu DTRACE_REPAIR_STOP_SIGNAL pid=%d ptr=%p outer=%p destroy_count=%d repair_make=%d\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    target_destroy_count, repair_make_done);
	raise(14);
}

syscall::getpgid:entry
/execname == "rgssig" && staged_replace_outer != 0 &&
  data_signal_sent == 0 && arg0 == 0x7b04/
{
	data_signal_sent = 1;
	printf("%llu DTRACE_STAGED_DATA_SIGNAL pid=%d phase=ctx_init ptr=%p outer=%p replacement=%p\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    staged_replace_outer);
	raise(30);
}

fbt:mach_kernel:gss_krb5_destroy_context:entry
/staged_replace_outer != 0 && arg0 == staged_replace_outer &&
  replacement_destroy_barrier_done == 0/
{
	replacement_destroy_barrier_done = 1;
	replacement_destroy_barrier_ready = 1;
	printf("%llu REPLACEMENT_DESTROY_BARRIER tid=%d cpu=%d outer=%p cp=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0, staged_replace_cp);
	replacement_destroy_barrier_ready = 0;
	printf("%llu REPLACEMENT_DESTROY_RESUME tid=%d outer=%p target=%p\n",
	    (uint64_t)walltimestamp, tid, arg0, target_outer);
}

fbt:mach_kernel:gss_krb5_destroy_context:entry
/target_outer != 0 && arg0 == target_outer/
{
	self->repair_target_destroy = 1;
	target_destroy_count++;
	printf("%llu TARGET_DESTROY_ENTRY tid=%d cpu=%d outer=%p etype=%d digest=%d di=%p count=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uint32_t *)(arg0 + 0x48), *(uint32_t *)(arg0 + 0xc0),
	    *(uintptr_t *)(arg0 + 0x78), target_destroy_count);
}

fbt:mach_kernel:gss_krb5_destroy_context:return
/self->repair_target_destroy/
{
	repair_barrier_ready = 1;
	printf("%llu TARGET_DESTROY_RETURN_REPAIR_ARMED tid=%d outer=%p count=%d\n",
	    (uint64_t)walltimestamp, tid, target_outer,
	    target_destroy_count);
	self->repair_target_destroy = 0;
}

fbt:mach_kernel:gss_krb5_make_context:return
/target_outer != 0 && arg1 != 0 &&
  self->ctx_init_cp == target_nfs_cp/
{
	printf("%llu MAKE_AFTER_TARGET tid=%d ctx=%p exact_addr=%d etype=%d digest=%d keylen=%d di=%p repair_sent=%d\n",
	    (uint64_t)walltimestamp, tid, arg1, arg1 == target_outer,
	    *(uint32_t *)(arg1 + 0x48), *(uint32_t *)(arg1 + 0xc0),
	    *(uint32_t *)(arg1 + 0xc4), *(uintptr_t *)(arg1 + 0x78),
	    repair_signal_sent);
	if (arg1 == target_outer &&
	    *(uint32_t *)(arg1 + 0x48) == 16 &&
	    *(uint32_t *)(arg1 + 0xc0) == 20 &&
	    *(uint32_t *)(arg1 + 0xc4) == 24 &&
	    *(uintptr_t *)(arg1 + 0x78) != 0) {
		exact_des3 = 1;
		repair_make_done = 1;
		digest_barrier_ready = 1;
		repair_barrier_ready = 0;
		printf("%llu EXACT_DES3_REPAIR_READY tid=%d outer=%p di=%p destroy_count=%d\n",
		    (uint64_t)walltimestamp, tid, arg1,
		    *(uintptr_t *)(arg1 + 0x78), target_destroy_count);
	}
}

syscall::getpid:entry
/execname == "v32select" && prealloc_barrier_ready != 0 &&
  target_alloc_cpu >= 0 && selective_stage1_total < 32 &&
  selective_stage1_signal_sent[pid] == 0/
{
	selective_stage1_total++;
	selective_stage1_signal_sent[pid] = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE1_SIGNAL pid=%d target_cpu=%d helper_cpu=%d\n",
	    (uint64_t)walltimestamp, pid, target_alloc_cpu, cpu);
	raise(30);
}

syscall::getpgid:entry
/execname == "v32select" && target_mic_buf != 0 &&
  mic_finished == 0 &&
  target_outer != 0 &&
  *(uint32_t *)(target_outer + 0x48) == 16 &&
  *(uint32_t *)(target_outer + 0xc0) == 20 &&
  selected_mic_owner_plus1 != 0 &&
  selected_mic_slot_plus1 > 0 &&
  selected_mic_slot_plus1 <= 16 &&
  pid + 1 == selected_mic_owner_plus1 &&
  arg0 == 0x6a00 + selected_mic_slot_plus1 &&
  selective_stage2_signal_sent[pid] == 0/
{
	exact_des3 = 1;
	digest_barrier_ready = 1;
	repair_barrier_ready = 1;
	selective_stage2_signal_sent[pid] = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE2_PROBE pid=%d slot=%d marker=0x%x target_cpu=%d helper_cpu=%d\n",
	    (uint64_t)walltimestamp, pid, selected_mic_slot_plus1 - 1,
	    (int)arg0, target_alloc_cpu, cpu);
	raise(31);
}

syscall::getpid:entry
/execname == "v32select" && target_mic_buf != 0 &&
  selected_mic_owner_plus1 != 0 &&
  pid + 1 != selected_mic_owner_plus1 &&
  selective_nonowner_stopped[pid] == 0/
{
	selective_nonowner_stopped[pid] = 1;
	raise(17);
}

syscall::getpid:entry
/execname == "aclbridge" && selected_neighbor_freed != 0 &&
  exact_des3 != 0 &&
  acl_signal_sent[pid] == 0/
{
	acl_signal_sent[pid] = 1;
	raise(30);
}

syscall::getpid:entry
/execname == "v32oracle" && acl_ready != 0 &&
  target_alloc_cpu >= 0 && cpu == target_alloc_cpu &&
  voucher_signal_sent == 0/
{
	voucher_signal_sent = 1;
	printf("%llu DTRACE_VOUCHER_SIGNAL pid=%d acl=%p oob_ace=%p\n",
	    (uint64_t)walltimestamp, pid, acl_neighbor_ptr,
	    acl_neighbor_ptr + 32);
	raise(30);
}

fbt:mach_kernel:vnode_getattr:entry
/(execname == "aclsig" || execname == "v32select") &&
  target_mic_buf != 0 &&
  mic_finished == 0 && arg1 != 0/
{
	self->window_vap = arg1;
}

fbt:mach_kernel:vnode_getattr:return
/self->window_vap != 0/
{
	this->window_acl = *(uintptr_t *)(self->window_vap + 0x58);
	if (target_mic_buf != 0 && mic_finished == 0 &&
	    this->window_acl == target_mic_buf + 32) {
		acl_window_vap = self->window_vap;
		acl_window_ptr = this->window_acl;
		acl_window_getattr_return_ts = timestamp;
		acl_window_authorize_entry_ts = (uint64_t)0;
		printf("%llu EXACT_ACL_WINDOW_GETATTR_RETURN tid=%d vap=%p ptr=%p count=0x%x mono_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, acl_window_vap,
		    acl_window_ptr, *(uint32_t *)acl_window_ptr,
		    acl_window_getattr_return_ts);
	}
	self->window_vap = (uintptr_t)0;
}

fbt:mach_kernel:vfs_attr_pack_ext:entry
/(execname == "aclsig" || execname == "v32select") &&
  target_mic_buf != 0 &&
  mic_finished == 0 && arg5 != 0 &&
  *(uintptr_t *)(arg5 + 0x58) == target_mic_buf + 32/
{
	acl_neighbor_ptr = *(uintptr_t *)(arg5 + 0x58);
	acl_neighbor_count_before = *(uint32_t *)acl_neighbor_ptr;
	acl_ready = 1;
	printf("%llu EXACT_ACL32_PACK_ENTRY tid=%d vap=%p ptr=%p count_before=%u holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, arg5, acl_neighbor_ptr,
	    acl_neighbor_count_before);
	printf("%llu EXACT_ACL32_PACK_RESUME tid=%d ptr=%p count_after=0x%x exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, acl_neighbor_ptr,
	    *(uint32_t *)acl_neighbor_ptr, exact_des3);
}

fbt:mach_kernel:vnode_attr_authorize_internal:entry
/(execname == "aclsig" || execname == "v32select") &&
  target_mic_buf != 0 &&
  mic_finished == 0 && acl_ready == 0 && arg0 != 0 &&
  *(uintptr_t *)(arg0 + 8) != 0 &&
  *(uintptr_t *)(*(uintptr_t *)(arg0 + 8) + 0x58) ==
    target_mic_buf + 32/
{
	this->vap = *(uintptr_t *)(arg0 + 8);
	acl_neighbor_ptr = *(uintptr_t *)(this->vap + 0x58);
	acl_neighbor_count_before = *(uint32_t *)acl_neighbor_ptr;
	acl_oob_ace_ptr = acl_neighbor_ptr + 32;
	acl_ready = 1;
	acl_auth_ready = 1;
	self->exact_auth = 1;
	if (acl_window_getattr_return_ts != 0 &&
	    this->vap == acl_window_vap &&
	    acl_neighbor_ptr == acl_window_ptr) {
		acl_window_authorize_entry_ts = timestamp;
		printf("%llu EXACT_ACL_WINDOW_AUTHORIZE_ENTRY tid=%d vap=%p ptr=%p count=0x%x mono_ns=%llu delta_getattr_return_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, this->vap,
		    acl_neighbor_ptr, *(uint32_t *)acl_neighbor_ptr,
		    acl_window_authorize_entry_ts,
		    acl_window_authorize_entry_ts -
		    acl_window_getattr_return_ts);
	}
	printf("%llu EXACT_ACL32_AUTH_ENTRY tid=%d vcp=%p vap=%p ptr=%p count_before=%u oob_ace=%p guid_q0=0x%llx guid_q1=0x%llx flags=0x%x rights=0x%x holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, arg0, this->vap,
	    acl_neighbor_ptr, acl_neighbor_count_before, acl_oob_ace_ptr,
	    *(uint64_t *)acl_oob_ace_ptr,
	    *(uint64_t *)(acl_oob_ace_ptr + 8),
	    *(uint32_t *)(acl_oob_ace_ptr + 16),
	    *(uint32_t *)(acl_oob_ace_ptr + 20));
	printf("%llu EXACT_ACL32_AUTH_RESUME tid=%d ptr=%p count_after=0x%x exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, acl_neighbor_ptr,
	    *(uint32_t *)acl_neighbor_ptr, exact_des3);
}

/*
 * kauth_acl_inherit sizes a separate destination from the first source scan,
 * then reloads the source count for its copy loop. Hold only after the exact
 * 32-byte destination allocation, once vnode_getattr has returned the MIC
 * neighbor as the source. The MIC thread can then change source count 1 to a
 * predictor-selected value in [2,128] while the destination remains sized for
 * one inheritable ACE.
 */
fbt:mach_kernel:kauth_acl_inherit:entry
/execname == "v32select" && target_mic_buf != 0 && mic_finished == 0/
{
	self->in_inherit = 1;
	self->inherit_start = timestamp;
	self->inherit_initial = (uintptr_t)arg1;
	self->inherit_productp = (uintptr_t)arg2;
	self->inherit_isdir = (uint32_t)arg3;
	self->inherit_getattr = 0;
	self->inherit_source = (uintptr_t)0;
	self->inherit_source_count_before = 0;
	self->inherit_source_count_after = 0;
	self->inherit_source_exact = 0;
	self->inherit_dst_alloc = 0;
	self->inherit_dst_seen = 0;
	self->inherit_dst = (uintptr_t)0;
	printf("%llu ACL_INHERIT_ENTRY tid=%d dvp=%p initial=%p productp=%p isdir=%u\n",
	    (uint64_t)walltimestamp, tid, arg0, arg1, arg2, (uint32_t)arg3);
}

fbt:mach_kernel:vnode_getattr:entry
/self->in_inherit && arg1 != 0/
{
	self->inherit_getattr = 1;
	self->inherit_vap = (uintptr_t)arg1;
}

fbt:mach_kernel:vnode_getattr:return
/self->inherit_getattr/
{
	this->inherit_acl = *(uintptr_t *)(self->inherit_vap + 0x58);
	self->inherit_source = this->inherit_acl;
	self->inherit_source_count_before = this->inherit_acl == 0 ? 0 :
	    *(uint32_t *)this->inherit_acl;
	if (this->inherit_acl == target_mic_buf + 32 &&
	    self->inherit_source_count_before == 1) {
		self->inherit_source_exact = 1;
		inherit_exact_seen = 1;
		printf("%llu EXACT_INHERIT_SOURCE tid=%d vap=%p source=%p count_before=%u oob_ace=%p flags=0x%x rights=0x%x getattr_error=%d\n",
		    (uint64_t)walltimestamp, tid, self->inherit_vap,
		    this->inherit_acl,
		    (uint32_t)self->inherit_source_count_before,
		    this->inherit_acl + 32,
		    *(uint32_t *)(this->inherit_acl + 48),
		    *(uint32_t *)(this->inherit_acl + 52), (int)arg1);
	}
	self->inherit_getattr = 0;
}

fbt:mach_kernel:kalloc_ext:entry
/self->in_inherit && self->inherit_source_exact &&
  self->inherit_dst_seen == 0 && arg1 == 32/
{
	self->inherit_dst_alloc = 1;
	self->inherit_dst_seen = 1;
	self->inherit_dst_request = (uint64_t)arg1;
	self->inherit_dst_caller = (uintptr_t)caller;
	printf("%llu EXACT_INHERIT_DST_ALLOC_ENTRY tid=%d source=%p count=%u request=%llu caller=%a\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source,
	    (uint32_t)self->inherit_source_count_before, (uint64_t)arg1, caller);
}

fbt:mach_kernel:kalloc_ext:return
/self->inherit_dst_alloc/
{
	self->inherit_dst = (uintptr_t)arg1;
	printf("%llu EXACT_INHERIT_DST_ALLOC_RETURN tid=%d source=%p dst=%p request=%llu caller=%a count_before=%u flags=0x%x mic_finished=%d holding_ms=499\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source, arg1,
	    (uint64_t)self->inherit_dst_request, self->inherit_dst_caller,
	    (uint32_t)self->inherit_source_count_before,
	    *(uint32_t *)(self->inherit_source + 48), mic_finished);
	chill(499000000);
	self->inherit_source_count_after =
	    *(uint32_t *)self->inherit_source;
	printf("%llu EXACT_INHERIT_DST_ALLOC_RESUME tid=%d source=%p dst=%p count_after=0x%x flags=0x%x rights=0x%x exact_des3=%d mic_finished=%d\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source,
	    self->inherit_dst, (uint32_t)self->inherit_source_count_after,
	    *(uint32_t *)(self->inherit_source + 48),
	    *(uint32_t *)(self->inherit_source + 52), exact_des3, mic_finished);
	self->inherit_dst_alloc = 0;
}

fbt:mach_kernel:kauth_acl_inherit:return
/self->in_inherit/
{
	this->inherit_product = self->inherit_productp == 0 ?
	    (uintptr_t)0 : *(uintptr_t *)self->inherit_productp;
	this->inherit_product_count = this->inherit_product == 0 ? 0 :
	    *(uint32_t *)this->inherit_product;
	printf("%llu EXACT_INHERIT_RETURN tid=%d error=%d source=%p count_before=%u count_after=0x%x dst=%p product=%p product_count=%u isdir=%u total_ns=%llu overflow_proven=%d\n",
	    (uint64_t)walltimestamp, tid, (int)arg1, self->inherit_source,
	    (uint32_t)self->inherit_source_count_before,
	    (uint32_t)self->inherit_source_count_after, self->inherit_dst,
	    this->inherit_product, (uint32_t)this->inherit_product_count,
	    (uint32_t)self->inherit_isdir,
	    (uint64_t)(timestamp - self->inherit_start),
	    self->inherit_dst_request == 32 &&
	    this->inherit_product_count >= 2);
	inherit_result_seen = 1;
	self->in_inherit = 0;
	self->inherit_getattr = 0;
	self->inherit_source_exact = 0;
	self->inherit_dst_alloc = 0;
}

fbt:mach_kernel:kauth_acl_evaluate:entry
/self->exact_auth && arg1 != 0/
{
	self->exact_acl_eval = 1;
	self->exact_eval_ptr = arg1;
	this->acl = *(uintptr_t *)arg1 - 8;
	this->oob_ace = this->acl + 32;
	if (acl_window_getattr_return_ts != 0 &&
	    this->acl == acl_window_ptr) {
		printf("%llu EXACT_ACL_WINDOW_EVAL_ENTRY tid=%d acl=%p ae_count=0x%x acl_entrycount=0x%x mono_ns=%llu delta_getattr_return_ns=%llu delta_authorize_entry_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, this->acl,
		    *(uint32_t *)(arg1 + 8), *(uint32_t *)this->acl,
		    (uint64_t)timestamp,
		    (uint64_t)timestamp -
		    acl_window_getattr_return_ts,
		    acl_window_authorize_entry_ts == 0 ?
		    (uint64_t)0 :
		    (uint64_t)timestamp -
		    acl_window_authorize_entry_ts);
	}
	printf("%llu EXACT_ACL_EVAL_ENTRY tid=%d eval=%p ae_acl=%p ae_count=0x%x ae_requested=0x%x ae_residual=0x%x ae_result=0x%x ae_options=0x%x acl=%p acl_entrycount=0x%x expected_ae_acl=%p oob_ace=%p guid_q0=0x%llx guid_q1=0x%llx flags=0x%x rights=0x%x\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    *(uintptr_t *)arg1, *(uint32_t *)(arg1 + 8),
	    *(uint32_t *)(arg1 + 12), *(uint32_t *)(arg1 + 16),
	    *(uint32_t *)(arg1 + 20), *(uint32_t *)(arg1 + 28),
	    this->acl, *(uint32_t *)this->acl,
	    target_mic_buf + 40, this->oob_ace,
	    *(uint64_t *)this->oob_ace,
	    *(uint64_t *)(this->oob_ace + 8),
	    *(uint32_t *)(this->oob_ace + 16),
	    *(uint32_t *)(this->oob_ace + 20));
}

fbt:mach_kernel:kauth_acl_evaluate:return
/self->exact_acl_eval/
{
	printf("%llu EXACT_ACL_EVAL_RETURN tid=%d function_result=%d eval=%p ae_count=0x%x ae_requested=0x%x ae_residual=0x%x ae_result=0x%x found_deny=0x%x\n",
	    (uint64_t)walltimestamp, tid, arg1, self->exact_eval_ptr,
	    *(uint32_t *)(self->exact_eval_ptr + 8),
	    *(uint32_t *)(self->exact_eval_ptr + 12),
	    *(uint32_t *)(self->exact_eval_ptr + 16),
	    *(uint32_t *)(self->exact_eval_ptr + 20),
	    *(uint32_t *)(self->exact_eval_ptr + 24));
	self->exact_acl_eval = 0;
	self->exact_eval_ptr = (uintptr_t)0;
}

fbt:mach_kernel:vnode_attr_authorize_internal:return
/self->exact_auth/
{
	printf("%llu EXACT_ACL_AUTH_RETURN tid=%d result=%d acl=%p count_now=0x%x\n",
	    (uint64_t)walltimestamp, tid, arg1, acl_neighbor_ptr,
	    acl_neighbor_ptr == 0 ? 0 : *(uint32_t *)acl_neighbor_ptr);
	self->exact_auth = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/* This trace starts after setup, so the raced DATA verifier is #1. */
/ *(uint32_t *)(arg1 + 0xc0) == 12 /
{
	aes_mic_seen++;
	self->any_aes_cfx = 1;
	printf("%llu aes_mic_seen count=%d outer=%p\n",
	    (uint64_t)walltimestamp, aes_mic_seen, arg1);
}

fbt:mach_kernel:krb5_key_derivation:entry
{
	self->in_key_derivation = 1;
}

fbt:mach_kernel:krb5_key_derivation:return
/self->in_key_derivation/
{
	self->in_key_derivation = 0;
}

fbt:mach_kernel:user_data_release_value:entry
/execname == "v32select" && digest_barrier_ready == 0/
{
	self->selective_a_release = 1;
	selective_stage1_signal_sent[pid] = 1;
}

fbt:mach_kernel:kfree_ext:entry
/self->selective_a_release && arg1 != 0 && arg2 == 32/
{
	selective_a_owner[(uintptr_t)arg1] = pid + 1;
	selective_a_release_count[pid]++;
	selective_a_slot_plus1[(uintptr_t)arg1] =
	    selective_a_release_count[pid];
}

fbt:mach_kernel:user_data_release_value:return
/self->selective_a_release/
{
	self->selective_a_release = 0;
}

fbt:mach_kernel:user_data_release_value:entry
/execname == "v32select" && target_mic_buf != 0 &&
  selected_mic_owner_plus1 != 0 &&
  pid + 1 == selected_mic_owner_plus1 &&
  selective_stage2_signal_sent[pid] != 0/
{
	self->selected_b_release = 1;
}

fbt:mach_kernel:kfree_ext:entry
/self->selected_b_release && arg1 != 0 && arg2 == 32 &&
  (uintptr_t)arg1 == target_mic_buf + 32/
{
	self->selected_b_exact = 1;
	printf("%llu EXACT_SELECTED_B_FREE_ENTRY pid=%d cpu=%d slot=%d ptr=%p mic=%p\n",
	    (uint64_t)walltimestamp, pid, cpu,
	    selected_mic_slot_plus1 - 1, arg1, target_mic_buf);
}

fbt:mach_kernel:kfree_ext:return
/self->selected_b_exact/
{
	selected_neighbor_freed = 1;
	self->selected_b_exact = 0;
	printf("%llu EXACT_SELECTED_B_FREED pid=%d ptr=%p\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf + 32);
}

fbt:mach_kernel:user_data_release_value:return
/self->selected_b_release/
{
	self->selected_b_release = 0;
}

fbt:mach_kernel:kalloc_ext:entry
/self->any_aes_cfx && arg1 == 28/
{
	data_heap = arg0;
}

fbt:mach_kernel:kalloc_ext:entry
/target_mic_buf != 0 && mic_finished == 0 && data_heap != 0 &&
  arg0 == data_heap && arg1 > 16 && arg1 <= 32/
{
	self->track32_caller = caller;
	self->track32_request = arg1;
	self->track32_key_derivation = self->in_key_derivation;
}

fbt:mach_kernel:kalloc_ext:return
/self->track32_caller != 0 && arg1 != 0/
{
	if (target_mic_buf != 0 &&
	    (uintptr_t)arg1 == target_mic_buf + 32) {
		neighbor_alloc_caller = self->track32_caller;
		neighbor_alloc_request = self->track32_request;
		neighbor_alloc_key_derivation =
		    self->track32_key_derivation;
		printf("%llu EXACT_32_NEIGHBOR_ALLOC ptr=%p request=%d caller=%a key_derivation=%d\n",
		    (uint64_t)walltimestamp, arg1,
		    (int)self->track32_request,
		    self->track32_caller,
		    self->track32_key_derivation);
	}

	self->track32_caller = 0;
	self->track32_request = 0;
	self->track32_key_derivation = 0;
}

fbt:mach_kernel:kalloc_ext:return
/self->track32_caller != 0 && arg1 == 0/
{
	self->track32_caller = 0;
	self->track32_request = 0;
	self->track32_key_derivation = 0;
}

fbt:mach_kernel:kfree_ext:entry
/target_mic_buf != 0 && mic_finished == 0 && data_heap != 0 &&
  arg0 == data_heap && arg2 > 16 && arg2 <= 32 &&
  (uintptr_t)arg1 == target_mic_buf + 32/
{
	self->exact_neighbor_free_request = neighbor_alloc_request;
	self->exact_neighbor_free =
	    neighbor_alloc_request == 24 &&
	    neighbor_alloc_key_derivation != 0 &&
	    neighbor_alloc_caller != 0;
	printf("%llu EXACT_32_NEIGHBOR_FREE ptr=%p request=%d alloc_request=%d alloc_caller=%a key_derivation=%d free_caller=%a\n",
	    (uint64_t)walltimestamp, arg1,
	    (int)arg2, (int)neighbor_alloc_request,
	    neighbor_alloc_caller, neighbor_alloc_key_derivation, caller);
	neighbor_alloc_caller = (uintptr_t)0;
	neighbor_alloc_request = 0;
	neighbor_alloc_key_derivation = 0;
}

fbt:mach_kernel:kfree_ext:return
/self->exact_neighbor_free/
{
	neighbor_freed = 1;
	printf("%llu EXACT_32_NEIGHBOR_FREED ptr=%p alloc_request=%d acl_ready=%d acl_ptr=%p\n",
	    (uint64_t)walltimestamp, target_mic_buf + 32,
	    (int)self->exact_neighbor_free_request, acl_ready,
	    acl_neighbor_ptr);
	self->exact_neighbor_free = 0;
	self->exact_neighbor_free_request = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/target_outer == 0 && candidate_claimed == 0 &&
  staged_replace_outer != 0 &&
  *(uint32_t *)(arg1 + 0xc0) == 12 &&
  aes_mic_seen >= configured_candidate_min_aes_mic/
{
	candidate_claimed = 1;
	candidate_outer = arg1;
	target_nfs_cp = self->verf_cp;
	self->candidate = 1;
	self->outer = arg1;
	self->mic_desc = arg4;
	target_alloc_cpu = cpu;
	target_outer = arg1;
	printf("%llu get_mic_candidate tid=%d cpu=%d outer=%p nfs_cp=%p refcnt=%d etype=%d digest=%d prealloc_hold_ms=0\n",
	    (uint64_t)walltimestamp, tid, target_alloc_cpu, arg1,
	    target_nfs_cp,
	    target_nfs_cp == 0 ? -1 :
	    *(uint32_t *)(target_nfs_cp + 0x24),
	    *(uint32_t *)(arg1 + 0x48),
	    *(uint32_t *)(arg1 + 0xc0));
	prealloc_barrier_ready = 1;
	prealloc_barrier_ready = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/candidate_claimed != 0 && self->candidate == 0 &&
  arg1 == candidate_outer/
{
	printf("%llu get_mic_bystander_hold tid=%d cpu=%d outer=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1);
	printf("%llu get_mic_bystander_resume tid=%d outer=%p etype=%d digest=%d\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    *(uint32_t *)(arg1 + 0x48), *(uint32_t *)(arg1 + 0xc0));
}

fbt:mach_kernel:krb5_mic:entry
/candidate_outer != 0 && self->candidate == 0 &&
  arg0 == candidate_outer + 0x48 && exact_des3 != 0/
{
	printf("%llu krb5_mic_bystander_hold tid=%d cpu=%d cctx=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0);
	printf("%llu krb5_mic_bystander_resume tid=%d cctx=%p digest=%d\n",
	    (uint64_t)walltimestamp, tid, arg0,
	    *(uint32_t *)(arg0 + 0x78));
}

fbt:mach_kernel:kalloc_ext:entry
/self->candidate && !self->in_krb5/
{
	self->outer_alloc_size = arg1;
}

fbt:mach_kernel:kalloc_ext:return
/self->candidate && !self->in_krb5 && self->outer_alloc_size != 0/
{
	self->mic_buf = arg1;
	target_outer = self->outer;
	target_mic_buf = arg1;
	target_alloc_cpu = cpu;
	selected_mic_owner_plus1 =
	    selective_a_owner[(uintptr_t)target_mic_buf];
	selected_mic_slot_plus1 =
	    selective_a_slot_plus1[(uintptr_t)target_mic_buf];
	this->neighbor = (uintptr_t)arg1 + 32;
	printf("%llu mic_alloc tid=%d cpu=%d ptr=%p request=%d heap=%p neighbor=%p outer=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, target_alloc_cpu, arg1,
	    (int)self->outer_alloc_size, data_heap,
	    this->neighbor, target_outer);
	printf("%llu SELECTIVE_MIC_OWNER ptr=%p owner_pid=%d slot=%d exact=%d\n",
	    (uint64_t)walltimestamp, target_mic_buf,
	    selected_mic_owner_plus1 == 0 ?
	    -1 : selected_mic_owner_plus1 - 1,
	    selected_mic_slot_plus1 == 0 ?
	    -1 : selected_mic_slot_plus1 - 1,
	    selected_mic_owner_plus1 != 0);
	self->outer_alloc_size = 0;
}

fbt:mach_kernel:kalloc_ext:entry
/execname == "v32oracle" && arg1 == 32/
{
	self->voucher_alloc = 1;
}

fbt:mach_kernel:kalloc_ext:return
/self->voucher_alloc/
{
	if (arg1 == target_mic_buf + 32) {
		printf("%llu EXACT_VOUCHER32_NEIGHBOR tid=%d ptr=%p mic=%p\n",
		    (uint64_t)walltimestamp, tid, arg1, target_mic_buf);
		stack(8);
	}
	if (arg1 == target_mic_buf + 64) {
		printf("%llu EXACT_VOUCHER32_OOB_ACE tid=%d ptr=%p mic=%p\n",
		    (uint64_t)walltimestamp, tid, arg1, target_mic_buf);
		stack(8);
	}
	self->voucher_alloc = 0;
}

fbt:mach_kernel:krb5_mic:entry
/self->candidate/
{
	printf("%llu krb5_mic_target_entry tid=%d cpu=%d cctx=%p holding_ns=0\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0);
	self->in_krb5 = 1;
	self->cctx = arg0;
	self->sink = arg4;
	self->bp = arg2;
	self->trailer = arg3;
	printf("%llu krb5_mic_entry_resume tid=%d cctx=%p outer=%p etype=%d digest=%d di=%p repair_sent=%d repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, arg0, target_outer,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(arg0 + 0x78), *(uintptr_t *)(arg0 + 0x30),
	    repair_signal_sent, repair_make_done, target_destroy_count);
	self->digest_info = *(uintptr_t *)(arg0 + 0x30);
	self->context_key = *(uintptr_t *)(arg0 + 0x28);
	self->context_key_len = *(uint32_t *)(arg0 + 0x7c);
	self->checksum_key = *(uintptr_t *)(arg0 + 0x80);
	self->checksum_key_len = *(uint32_t *)(arg0 + 0x88);
	printf("%llu krb5_mic_enter tid=%d cctx=%p sink=%p digest=%d mic_buf=%p expected_sink=%p\n",
	    (uint64_t)walltimestamp, tid, arg0, arg4,
	    *(uint32_t *)(arg0 + 0x78), self->mic_buf,
	    self->mic_buf + 16);
	if (self->digest_info != 0) {
		printf("%llu krb5_mic_digest_callback tid=%d digest_info=%p callback=%a\n",
		    (uint64_t)walltimestamp, tid, self->digest_info,
		    *(uintptr_t *)(self->digest_info + 0x38));
	} else {
		printf("%llu REPAIR_MISSED_NULL_DI tid=%d outer=%p repair_sent=%d repair_make=%d destroy_count=%d\n",
		    (uint64_t)walltimestamp, tid, target_outer,
		    repair_signal_sent, repair_make_done, target_destroy_count);
	}
	printf("%llu krb5_mic_keys tid=%d context_key=%p context_len=%d checksum_key=%p checksum_len=%d\n",
	    (uint64_t)walltimestamp, tid, self->context_key,
	    (int)self->context_key_len, self->checksum_key,
	    (int)self->checksum_key_len);
	if (self->context_key_len == 16) {
		printf("%llu context_key_bytes tid=%d q0=0x%llx q1=0x%llx\n",
		    (uint64_t)walltimestamp, tid,
		    *(uint64_t *)self->context_key,
		    *(uint64_t *)(self->context_key + 8));
	}
	if (self->context_key_len == 32) {
		printf("%llu context_key_bytes tid=%d q0=0x%llx q1=0x%llx q2=0x%llx q3=0x%llx\n",
		    (uint64_t)walltimestamp, tid,
		    *(uint64_t *)self->context_key,
		    *(uint64_t *)(self->context_key + 8),
		    *(uint64_t *)(self->context_key + 16),
		    *(uint64_t *)(self->context_key + 24));
	}
	if (self->checksum_key_len == 16) {
		printf("%llu checksum_key_bytes tid=%d q0=0x%llx q1=0x%llx\n",
		    (uint64_t)walltimestamp, tid,
		    *(uint64_t *)self->checksum_key,
		    *(uint64_t *)(self->checksum_key + 8));
	}
	if (self->checksum_key_len == 32) {
		printf("%llu checksum_key_bytes tid=%d q0=0x%llx q1=0x%llx q2=0x%llx q3=0x%llx\n",
		    (uint64_t)walltimestamp, tid,
		    *(uint64_t *)self->checksum_key,
		    *(uint64_t *)(self->checksum_key + 8),
		    *(uint64_t *)(self->checksum_key + 16),
		    *(uint64_t *)(self->checksum_key + 24));
	}
	printf("%llu hmac_input tid=%d bp_len=%llu bp_ptr=%p bp_u32=0x%x trailer_len=%llu trailer_ptr=%p trailer_q0=0x%llx trailer_q1=0x%llx\n",
	    (uint64_t)walltimestamp, tid,
	    *(uint64_t *)arg2, *(uintptr_t *)(arg2 + 8),
	    *(uint32_t *)(*(uintptr_t *)(arg2 + 8)),
	    *(uint64_t *)arg3, *(uintptr_t *)(arg3 + 8),
	    *(uint64_t *)(*(uintptr_t *)(arg3 + 8)),
	    *(uint64_t *)(*(uintptr_t *)(arg3 + 8) + 8));
}

fbt:mach_kernel:kalloc_ext:entry
/self->in_krb5 && !self->digest_barrier_done &&
  self->digest_alloc_size == 0 && arg1 == 20/
{
	self->digest_alloc_size = arg1;
	printf("%llu digest_alloc_entry_observed tid=%d request=%d outer=%p etype=%d digest=%d holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, (int)arg1, target_outer,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0));
}

fbt:mach_kernel:kalloc_ext:return
/self->in_krb5 && !self->digest_barrier_done &&
  self->digest_alloc_size == 20/
{
	self->digest_ptr = arg1;
	printf("%llu digest_alloc_observed tid=%d ptr=%p request=%d outer=%p exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    (int)self->digest_alloc_size, target_outer, exact_des3);
	self->digest_alloc_size = 0;
}

fbt:com.apple.kec.corecrypto:ccdigest_final_64be:entry
/self->in_krb5 && !self->digest_barrier_done/
{
	self->digest_final_target = 1;
	printf("%llu final_copy_rendezvous tid=%d cpu=%d outer=%p signal_sent=%d destroy_seen=%d exact_des3=%d holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, cpu, target_outer,
	    continue_signal_sent, replacement_destroy_barrier_done,
	    exact_des3);
	continue_barrier_ready = 0;
	if (exact_des3 != 0) {
		digest_barrier_ready = 0;
	}
	printf("%llu final_copy_resume tid=%d outer=%p exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, target_outer, exact_des3);
}

fbt:com.apple.kec.corecrypto:ccdigest_final_64be:return
/self->digest_final_target/
{
	precopy_tid = tid;
	precopy_len = *(uint32_t *)(self->cctx + 0x78);
	precopy_sink = self->sink;
	precopy_digest = self->digest_ptr;
	precopy_cctx = self->cctx;
	precopy_di = *(uintptr_t *)(self->cctx + 0x30);
	precopy_etype = *(uint32_t *)(target_outer + 0x48);
	precopy_ready = 1;
	printf("%llu DIGEST_RETURN_HOLD tid=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d exact_des3=%d holding_ns=%llu\n",
	    (uint64_t)walltimestamp, tid, precopy_cctx, precopy_di,
	    precopy_sink, precopy_digest, precopy_len, precopy_etype,
	    exact_des3, configured_mic_hold_ns);
	chill(configured_mic_hold_ns);
	precopy_ready = 0;
	printf("%llu DIGEST_RETURN_RESUME tid=%d cctx=%p di_before=%p di_live=%p sink=%p digest=%p len_before=%d len_live=%d etype_before=%d etype_live=%d exact_des3=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, precopy_cctx, precopy_di,
	    *(uintptr_t *)(precopy_cctx + 0x30), precopy_sink,
	    precopy_digest, precopy_len,
	    *(uint32_t *)(precopy_cctx + 0x78), precopy_etype,
	    *(uint32_t *)(target_outer + 0x48), exact_des3,
	    target_destroy_count);
	if (exact_des3 != 0 && selected_mic_owner_plus1 != 0) {
		printf("%llu digest_callback_repair_rendezvous tid=%d outer=%p exact_des3=%d acl_auth_ready=%d owner_pid=%d slot=%d holding_ms=0\n",
		    (uint64_t)walltimestamp, tid, target_outer,
		    exact_des3, acl_auth_ready,
		    selected_mic_owner_plus1 - 1,
		    selected_mic_slot_plus1 - 1);
		repair_barrier_ready = 0;
		printf("%llu digest_callback_repair_resume tid=%d outer=%p exact_des3=%d acl_auth_ready=%d di_live=%p repair_sent=%d repair_make=%d destroy_count=%d\n",
		    (uint64_t)walltimestamp, tid, target_outer,
		    exact_des3, acl_auth_ready,
		    *(uintptr_t *)(self->cctx + 0x30), repair_signal_sent,
		    repair_make_done, target_destroy_count);
	}
	printf("%llu digest_callback_return tid=%d outer=%p exact_des3=%d etype=%d digest=%d\n",
	    (uint64_t)walltimestamp, tid, target_outer, exact_des3,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0));
	self->digest_final_target = 0;
	self->digest_barrier_done = 1;
}

fbt:com.apple.kec.corecrypto:cchmac_final:entry
/self->in_krb5 && self->digest_ptr != 0 && arg2 == self->digest_ptr/
{
	self->target_cchmac_final = 1;
}

fbt:com.apple.kec.corecrypto:cchmac_final:return
/self->target_cchmac_final/
{
	precopy_tid = tid;
	precopy_len = *(uint32_t *)(self->cctx + 0x78);
	precopy_sink = self->sink;
	precopy_digest = self->digest_ptr;
	precopy_cctx = self->cctx;
	precopy_di = *(uintptr_t *)(self->cctx + 0x30);
	precopy_etype = *(uint32_t *)(target_outer + 0x48);
	precopy_ready = 1;
	printf("%llu PRE_MEMCPY_RENDEZVOUS tid=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d exact_des3=%d holding_ns=0\n",
	    (uint64_t)walltimestamp, tid, precopy_cctx, precopy_di,
	    precopy_sink, precopy_digest, precopy_len, precopy_etype,
	    exact_des3);
	precopy_ready = 0;
	printf("%llu PRE_MEMCPY_RESUME tid=%d cctx=%p di_before=%p di_live=%p sink=%p digest=%p len_before=%d len_live=%d etype_before=%d etype_live=%d exact_des3=%d repair_sent=%d repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, precopy_cctx, precopy_di,
	    *(uintptr_t *)(precopy_cctx + 0x30), precopy_sink,
	    precopy_digest, precopy_len,
	    *(uint32_t *)(precopy_cctx + 0x78), precopy_etype,
	    *(uint32_t *)(target_outer + 0x48), exact_des3,
	    repair_signal_sent, repair_make_done, target_destroy_count);
	self->target_cchmac_final = 0;
}

fbt:mach_kernel:krb5_mic:return
/self->in_krb5/
{
	self->return_rawkey = *(uintptr_t *)(self->cctx + 0x28);
	self->return_ckey = *(uintptr_t *)(self->cctx + 0x80);
	printf("%llu return_context_key tid=%d ptr=%p keylen=%d key_q0=0x%llx key_q1=0x%llx key_q2=0x%llx\n",
	    (uint64_t)walltimestamp, tid, self->return_rawkey,
	    *(uint32_t *)(self->cctx + 0x7c),
	    *(uint64_t *)self->return_rawkey,
	    *(uint64_t *)(self->return_rawkey + 8),
	    *(uint64_t *)(self->return_rawkey + 16));
	printf("%llu return_checksum_key tid=%d ptr=%p keylen=%llu key_q0=0x%llx key_q1=0x%llx key_q2=0x%llx\n",
	    (uint64_t)walltimestamp, tid, self->return_ckey,
	    *(uint64_t *)(self->cctx + 0x88),
	    *(uint64_t *)self->return_ckey,
	    *(uint64_t *)(self->return_ckey + 8),
	    *(uint64_t *)(self->return_ckey + 16));
	printf("%llu krb5_mic_return tid=%d outer=%p exact_des3=%d etype=%d digest=%d mic_buf=%p neighbor=%p overflow_dword=0x%x alloc_request=%d alloc_caller=%a\n",
	    (uint64_t)walltimestamp, tid, target_outer, exact_des3,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0),
	    self->mic_buf, self->mic_buf + 32,
	    *(uint32_t *)(self->mic_buf + 32),
	    (int)neighbor_alloc_request, neighbor_alloc_caller);
	this->return_neighbor = (uintptr_t)self->mic_buf + 32;
	printf("%llu neighbor_return ptr=%p alloc_request=%d alloc_caller=%a\n",
	    (uint64_t)walltimestamp, this->return_neighbor,
	    (int)neighbor_alloc_request, neighbor_alloc_caller);
	if (acl_ready && acl_neighbor_ptr != 0) {
		printf("%llu acl_at_mic_return ptr=%p count_before=%u count_after=0x%x exact_des3=%d\n",
		    (uint64_t)walltimestamp, acl_neighbor_ptr,
		    acl_neighbor_count_before,
		    *(uint32_t *)acl_neighbor_ptr, exact_des3);
	}
	self->in_krb5 = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:return
/self->candidate/
{
	printf("%llu get_mic_return tid=%d outer=%p exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, target_outer, exact_des3);
	mic_finished = 1;
	self->candidate = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:return
/self->any_aes_cfx/
{
	self->any_aes_cfx = 0;
}

tick-10sec
{
	printf("%llu trace_end target=%p nfs_cp=%p outer_cp_freed=%d exact_des3=%d acl_ready=%d acl_ptr=%p inherit_exact=%d inherit_result=%d\n",
	    (uint64_t)walltimestamp, target_outer, target_nfs_cp,
	    outer_cp_freed, exact_des3, acl_ready, acl_neighbor_ptr,
	    inherit_exact_seen, inherit_result_seen);
	exit(0);
}
