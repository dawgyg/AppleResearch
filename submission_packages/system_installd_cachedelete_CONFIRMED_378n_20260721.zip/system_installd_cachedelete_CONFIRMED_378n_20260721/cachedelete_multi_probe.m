// Safe query-only probe of multiple CacheDelete services (servicePurgeable, NON-destructive).
#import <Foundation/Foundation.h>
@protocol CDProto
- (void)servicePurgeable:(int)priority info:(NSDictionary*)info replyBlock:(void(^)(NSDictionary*))reply;
@end
int main(int argc,const char**argv){ @autoreleasepool {
  for (int i=1;i<argc;i++){
    NSString *svc = [NSString stringWithUTF8String:argv[i]];
    fprintf(stderr,"\n[svc=%s] uid=%d\n", argv[i], getuid());
    NSXPCConnection *c=[[NSXPCConnection alloc] initWithMachServiceName:svc options:NSXPCConnectionPrivileged];
    c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(CDProto)];
    c.invalidationHandler=^{ fprintf(stderr,"  INVALIDATED (rejected)\n"); };
    [c resume];
    dispatch_semaphore_t s=dispatch_semaphore_create(0);
    id p=[c remoteObjectProxyWithErrorHandler:^(NSError*e){ fprintf(stderr,"  err: %s\n",e.localizedDescription.UTF8String); dispatch_semaphore_signal(s);}];
    [p servicePurgeable:3 info:@{} replyBlock:^(NSDictionary*r){ fprintf(stderr,"  *** REPLY servicePurgeable=%s -> UNAUTH SERVICED ***\n", r.description.UTF8String); dispatch_semaphore_signal(s);}];
    dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC));
    [c invalidate];
  }
  return 0;
}}
