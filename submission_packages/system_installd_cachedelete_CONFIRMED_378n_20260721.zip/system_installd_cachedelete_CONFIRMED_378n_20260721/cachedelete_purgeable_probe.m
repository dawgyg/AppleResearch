#import <Foundation/Foundation.h>

@protocol CacheDeleteServiceProtocol
- (void)serviceCallback:(id)info replyBlock:(void (^)(NSDictionary *reply))reply;
- (void)serviceNotify:(id)info replyBlock:(void (^)(NSDictionary *reply))reply;
- (void)serviceCancelPurge:(void (^)(NSDictionary *reply))reply;
- (void)servicePurge:(int)priority
                info:(NSDictionary *)info
          replyBlock:(void (^)(NSDictionary *reply))reply;
- (void)serviceCancelPurgeImmediate:(void (^)(NSDictionary *reply))reply;
- (void)servicePurgeable:(int)priority
                    info:(NSDictionary *)info
              replyBlock:(void (^)(NSDictionary *reply))reply;
- (void)servicePing:(void (^)(NSDictionary *reply))reply;
- (void)servicePeriodic:(int)priority
                   info:(NSDictionary *)info
             replyBlock:(void (^)(NSDictionary *reply))reply;
@end

int main(int argc, const char *argv[])
{
    @autoreleasepool {
        BOOL doPurge = NO;
        int64_t amount = 0;
        if (argc > 1 && strcmp(argv[1], "--purge") == 0) {
            doPurge = YES;
            amount = argc > 2 ? strtoll(argv[2], NULL, 0) : 0;
        }

        NSXPCConnection *conn = [[NSXPCConnection alloc]
            initWithMachServiceName:@"com.apple.system_installd.CacheDelete"
                            options:NSXPCConnectionPrivileged];
        conn.remoteObjectInterface = [NSXPCInterface
            interfaceWithProtocol:@protocol(CacheDeleteServiceProtocol)];

        dispatch_semaphore_t sema = dispatch_semaphore_create(0);
        __block BOOL gotReply = NO;

        conn.invalidationHandler = ^{
            fprintf(stderr, "connection invalidated\n");
            dispatch_semaphore_signal(sema);
        };
        conn.interruptionHandler = ^{
            fprintf(stderr, "connection interrupted\n");
            dispatch_semaphore_signal(sema);
        };

        [conn resume];

        id proxy = [conn remoteObjectProxyWithErrorHandler:^(NSError *error) {
            fprintf(stderr, "remote proxy error: %s\n",
                    error.description.UTF8String ?: "(null)");
            dispatch_semaphore_signal(sema);
        }];

        NSMutableDictionary *info = [@{ @"CACHE_DELETE_VOLUME": @"/" } mutableCopy];
        if (doPurge) {
            info[@"CACHE_DELETE_AMOUNT"] = @(amount);
            fprintf(stderr, "calling servicePurge priority=3 amount=%lld\n",
                    (long long)amount);
            [proxy servicePurge:3 info:info replyBlock:^(NSDictionary *reply) {
                gotReply = YES;
                fprintf(stderr, "reply: %s\n",
                        reply.description.UTF8String ?: "(null)");
                dispatch_semaphore_signal(sema);
            }];
        } else {
            fprintf(stderr, "calling servicePurgeable priority=3\n");
            [proxy servicePurgeable:3 info:info replyBlock:^(NSDictionary *reply) {
                gotReply = YES;
                fprintf(stderr, "reply: %s\n",
                        reply.description.UTF8String ?: "(null)");
                dispatch_semaphore_signal(sema);
            }];
        }

        dispatch_time_t deadline = dispatch_time(DISPATCH_TIME_NOW, 15 * NSEC_PER_SEC);
        long waitResult = dispatch_semaphore_wait(sema, deadline);
        [conn invalidate];

        if (waitResult != 0) {
            fprintf(stderr, "timeout waiting for reply\n");
            return 2;
        }
        return gotReply ? 0 : 1;
    }
}
