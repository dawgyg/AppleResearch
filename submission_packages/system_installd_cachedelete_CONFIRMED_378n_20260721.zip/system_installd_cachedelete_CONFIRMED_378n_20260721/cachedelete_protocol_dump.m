#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <dlfcn.h>

static void dump_methods(Protocol *proto, BOOL required, BOOL instance)
{
    unsigned int count = 0;
    struct objc_method_description *methods =
        protocol_copyMethodDescriptionList(proto, required, instance, &count);
    printf("required=%d instance=%d count=%u\n", required, instance, count);
    for (unsigned int i = 0; i < count; i++) {
        printf("  %s :: %s\n",
               sel_getName(methods[i].name),
               methods[i].types ? methods[i].types : "(null)");
    }
    free(methods);
}

int main(void)
{
    @autoreleasepool {
        void *h = dlopen("/System/Library/PrivateFrameworks/CacheDelete.framework/CacheDelete",
                         RTLD_NOW | RTLD_LOCAL);
        printf("dlopen=%p err=%s\n", h, dlerror() ?: "(none)");
        Protocol *proto = NSProtocolFromString(@"CacheDeleteServiceProtocol");
        printf("proto=%p\n", proto);
        if (!proto) {
            return 1;
        }
        dump_methods(proto, YES, YES);
        dump_methods(proto, NO, YES);
        return 0;
    }
}
