# Technical analysis

## Target

- OS: macOS 27 beta `26A5378n`.
- Binary: `/usr/sbin/smbd`, arm64e UUID
  `39778c76-324c-3174-a550-e4ead047ebc9`.
- Extracted arm64e SHA-256:
  `b2a2e45f49a01e6832a3e0cadaa82b12aa9838af7f651fe8c47b706eead61e7b`.

## Request extraction

`smb2::extract(set_info_request)` at preferred `0x100048774` validates the
outer `BufferOffset` and `BufferLength` against the SMB2 frame at
`0x100048824..0x10004884c`. That protects the source pointer but does not size
the separate native destination correctly.

For `InfoType=3`, `smb2_dispatch_set_file_information`:

1. Loads attacker input length into `w23` at `0x10002bb3c`.
2. Calls `platform::heap_buffer::grow_atleast(input_len)` at
   `0x10002bb50..0x10002bb64`. The helper rounds the requested allocation to a
   page boundary.
3. Loads the heap pointer into `x2` at `0x10002bb68` and reloads the same input
   length into `x1` at `0x10002bb6c`.
4. Copies `x1` to `x3` at `0x10002bbb8`, then calls the converter at
   `0x10002bbbc`.

The effective call is:

```text
ConvertWireSecurityDescriptorToSecurityDescriptor(
    wire, input_len, output_heap, input_len)
```

## Destination-size mismatch

`ConvertWireSecurityDescriptorToSecurityDescriptor` at `0x10003ffc4`:

- checks only `x3 >= x1` at `0x100040014..0x100040018`;
- computes `x23 = 40*x3` at `0x10004001c..0x100040020`;
- treats `output_heap + 40*input_len` as the destination end;
- initializes the fixed 40-byte native descriptor at
  `0x100040078..0x100040084`.

The actual caller allocation is only the page-rounded `input_len`. All nested
destination checks therefore compare against an end up to 40 times beyond the
real allocation.

The same mismatch is present in the x86_64 slice. At preferred
`0x10003a743..0x10003a74f`, it computes `40*x3`; at
`0x10003a756..0x10003a75e`, it only checks `x3 >= input_len`; and at
`0x10003a7b5..0x10003a7c7`, it clears and initializes the 40-byte native
descriptor. This is not arm64e-only code generation.

## Aliased ACL expansion

The proof input is exactly `0x4000` bytes:

- 20-byte self-relative descriptor;
- control `0x8014` (`SELF_RELATIVE | SACL_PRESENT | DACL_PRESENT`);
- both SACL and DACL offsets are `20`;
- one 8-byte ACL header at offset 20;
- ACL revision `2`, `AclSize=0x3fec`, `AceCount=0`;
- zero padding to the declared ACL end.

Each offset is independently less than the global input length, so both pass.
No check requires the two source components to be disjoint and no check limits
total native output to the caller's allocation.

For each ACL, `InitializeAclFromWire` validates `AclSize` against the remaining
global source at `0x100040368..0x10004037c`, then compares destination space
against the inflated converter end at `0x100040380..0x10004039c`. It calls
`InitializeAcl` at `0x1000403f0`.

`InitializeAcl` executes `bzero(destination, AclSize)` at
`0x10003d5f4..0x10003d5f8`. The first ACL begins at native offset `0x28`; the
second begins after the first declared ACL span. The second zeroing operation
therefore runs outside the true output allocation.

## Rule Zero operand map

Sink: `bzero(x0=destination, x1=AclSize)` at `0x10003d5f8`.

- `AclSize`: attacker u16 from wire ACL offset `+2`.
  Source-side bound: `cmp remaining, AclSize` at `0x100040378`, branch reject
  `b.lt` at `0x10004037c`.
- ACL source offset: attacker u32 SACL/DACL field.
  Lower and upper bound: `cmp offset,input_len`, reject `b.hs` at
  `0x100040324..0x100040328`; nested extractor also checks eight header bytes.
- Destination base: caller heap pointer plus a 40-byte native header and prior
  converted components.
- Destination upper bound: `cmp output_end-current, AclSize+10` at
  `0x100040394..0x10004039c`.
- Gap: `output_end` is formed as `heap_ptr + 40*input_len`, while the real heap
  allocation is page-rounded `input_len`. There is no comparison against the
  actual heap-buffer capacity.
- Sibling gap: SACL and DACL offsets are checked independently against the
  global input span, but their combined destination expansion is not bounded;
  both may alias the same source ACL.

## Dynamic evidence

The included `.ips` report records:

- process `smbd`, PID 43941, root launch daemon;
- `EXC_BAD_ACCESS / KERN_INVALID_ADDRESS` at `0x70221f8000`;
- ESR: `Data Abort byte write Translation fault`;
- `x21=0x3fec`, exactly the attacker ACL size;
- `x24=0x8014`, exactly the attacker descriptor control flags;
- current memset destination `x0=0x70221f4028`;
- first unmapped byte `far=0x70221f8000`;
- VM map: preceding `Malloc Small` region ends at the fault address.

Faulting stack:

```text
_platform_memset
InitializeAcl(_ACL*, unsigned long, unsigned int) + 68
InitializeAclFromWire(...) + 260
ConvertWireSecurityDescriptorToSecurityDescriptor(...) + 364
smb2_dispatch_set_file_information(...) + 632
smb2_dispatch_compound(...) + 1932
```

The client received a connection-read error during the `SET_INFO`, and the
daemon exited with `SIGSEGV`.

## Suggested fix

Treat the fourth converter argument as a byte capacity throughout. Compute the
destination end as `output_heap + output_capacity`, require at least 40 bytes
before the fixed native descriptor stores, and account for the sum of all
converted owner, group, SACL, and DACL components. Source offsets should be
validated against their component-local declared spans; independently valid
overlapping offsets must not allow cumulative destination output to exceed the
real heap-buffer capacity.
