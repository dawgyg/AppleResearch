# Package map

- `REPORT.md`: concise technical report for the attempt-1233 controlled write.
- `PORTAL_FIELDS.txt`: portal-ready fields with bounded impact claims.
- `evidence/`: complete attempt-1233 logs, map, DTrace source, panic, and
  symbolication.
- `base_reproducer/`: the earlier submission-ready archive that reproduces the
  underlying RPCSEC_GSS context UAF without the advanced placement harness.
- `diagnostic_harness/`: exact source, binaries, and coordinators used for the
  deterministic selected-write experiment.

Start with `REPORT.md`. The advanced harness is intentionally included for
auditability, but it is tied to the disposable VM lab and is not represented
as a standalone one-command PoC.

