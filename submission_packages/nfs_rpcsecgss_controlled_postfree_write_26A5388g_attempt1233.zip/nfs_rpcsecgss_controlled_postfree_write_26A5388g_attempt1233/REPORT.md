# Remote NFS RPCSEC_GSS race writes attacker-selected dword after free

## Verdict

On macOS 27 beta 4 build `26A5388g`, an authenticated uid 501 NFS client
caused the kernel RPCSEC_GSS verifier to write the attacker-selected value
`0x00000009` at offset zero of a deliberately adjacent, already-freed
`data.kalloc.32` object.

The release kernel allocator independently detected the post-free write:

```text
[data.kalloc.32]: element modified after free
(off:0, val:0x0000000000000009, sz:32, ptr:0xfffffe30b8e6fb80)
```

This is stronger than a crash-only UAF: the client selects the four-byte value,
the diagnostic harness selects and records the source allocation, and the
allocator verifies the exact value at the exact adjacent destination.

This is not claimed as an arbitrary-address write, privilege escalation,
remote code execution, control-flow hijack, or Apple Target Flag capture.

## Affected configuration

- macOS 27.0 beta 4 `26A5388g`
- Darwin `xnu-13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE`
- NFS server export configured with `sec=krb5`
- Remote client has a valid Kerberos credential for the NFS service
- Triggering client runs as uid 501

## Root cause

The NFS server accepts RPCSEC_GSS `CONTINUE_INIT` for an already-complete
context. Concurrent DATA and CONTINUE_INIT workers access and replace the same
kernel GSS crypto-context pointer without one lock covering the object's
lifetime and all of its fields.

The controlled-write path exploits a check/use mismatch across the shared
crypto context:

1. The DATA worker begins MIC generation with an AES context whose digest size
   is 12 bytes.
2. The kernel allocates `16 + 12 = 28` bytes for the MIC. That request occupies
   one 32-byte data-zone element.
3. The HMAC calculation completes using the authenticated client's predictable
   input and key material.
4. A concurrent valid `CONTINUE_INIT` replaces the shared context with DES3,
   whose digest size is 20 bytes.
5. The stale DATA worker reloads the live digest size as 20 for the final copy
   into `mic_buffer + 16`.
6. The 20-byte copy reaches byte 35. Bytes 28 through 31 consume allocator
   slack; bytes 32 through 35 overwrite offset zero of the next
   `data.kalloc.32` object.

No validation ties the final 20-byte copy length to the original 28-byte
allocation request. Each digest size is valid in isolation; the bug is the gap
between the AES size used for allocation and the DES3 size reloaded for use.

## Attacker-selected value

The client exports its own lucid Kerberos context and therefore knows the key
and MIC input. `aes_kernel_mic_predict` searches valid RPCSEC_GSS sequence
numbers for a requested four-byte HMAC tail before releasing the DATA record.

Attempt 1233 selected:

```text
selected_sequence=2014130201
selected_overwrite=0x00000009
hmac_sha1=3afa2e0bc8d97b1a195ad02da8be96cf09000000
```

The final four bytes are `09 00 00 00`, which become little-endian dword
`0x00000009` at the adjacent object's offset zero.

## Exact placement proof

The diagnostic harness preallocated pairs of adjacent 32-byte objects. It
released selected A objects, then recorded this exact reclaim:

```text
SELECTIVE_A_FREE_EDGE pid=1338 cpu=0 ptr=fffffe30b8e6fb60 slot=0
mic_alloc ... ptr=fffffe30b8e6fb60 request=28 ...
    neighbor=fffffe30b8e6fb80
SELECTIVE_MIC_OWNER ptr=fffffe30b8e6fb60 owner_pid=1338 slot=0 exact=1
```

Therefore:

```text
MIC/A                 0xfffffe30b8e6fb60
next 32-byte object B 0xfffffe30b8e6fb80
selected dword        0x00000009
allocator report B    0xfffffe30b8e6fb80, offset 0, value 9
```

The DTrace transcript and panic report independently agree on both the
destination and value.

## Reproduction

The attached `base_reproducer` archive is the submission-ready, comparatively
self-contained reproducer for the underlying remotely reachable RPCSEC_GSS
context UAF. It does not require the attempt-1233 placement harness.

The `diagnostic_harness` directory contains the exact advanced instrumentation
used to turn that UAF into the selected adjacent write. It is lab-specific:
its coordinator currently contains the test VM address and expects the
Kerberos/NFS lab, helper processes, DTrace symbols, and setup files described
by its scripts. It should be treated as corroborating diagnostic material, not
as a one-command standalone reproducer.

Attempt 1233 used:

```text
VOUCHER32_SETUP_TIGHT_DRAIN_COUNT=96
VOUCHER32_SETUP_TIGHT_SACRIFICE_COUNT=0
RPC_GSS_PREFORK_PREDICTOR_MIN_DWORD=1
RPC_GSS_PREFORK_PREDICTOR_MAX_DWORD=128
RPC_GSS_PREFORK_REPAIR_ON_FDFLAGS_EXACT=0
race DATA count=1
```

The complete run transcript, placement map, DTrace program, panic, extracted
panic string, and symbolication are in `evidence/`.

## Environment and claim boundary

Attempt 1233 ran in a disposable VM on a release kernel. SIP was disabled and
DTrace timing holds were used to make allocation and race ordering
deterministic. Boot arguments were:

```text
keepsyms=1 amfi_get_out_of_my_way=1
```

`-zp` and KASAN were not active. The panic is the release allocator's
use-after-free modification check, not a KASAN diagnostic.

Confirmed:

- authenticated remote uid501 reachability;
- shared RPCSEC_GSS crypto-context race;
- digest-size allocation/use mismatch;
- exact reclaim of the selected 28-byte MIC allocation;
- deliberate adjacency to a selected 32-byte object;
- attacker selection and prediction of dword `9`;
- post-free write of dword `9` at that object's offset zero;
- independent allocator detection of the same pointer and value.

Not demonstrated:

- arbitrary choice of a 64-bit destination address;
- arbitrary 32-bit value without search cost;
- victim-object replacement in this specific panic;
- privilege escalation, remote code execution, or control-flow hijack;
- Apple Target Flag capture.

