# Diagnostic harness

This directory preserves the exact attempt-1233 orchestration materials.

Core components:

- `rpc_gss_crypto_race_prearmed_gate.c`: authenticated RPCSEC_GSS client and
  synchronized DATA/CONTINUE sender.
- `aes_kernel_mic_predict.c`: predicts valid sequence numbers whose HMAC tail
  matches a selected dword.
- `voucher32_prearmed_oracle.c`: constructs and controls adjacent 32-byte
  allocation pairs.
- `run_prefork_fdflags_repair_attempt.sh`: top-level lab coordinator.
- `run_cross_digest_acl_fdflags_beta4.sh`: race and predictor coordinator.
- `setup_voucher32_fdflags_beta4.sh`: helper-cohort setup.
- `run_des3_dtrace_supervisor_fdflags_beta4.sh`: DTrace supervisor.
- `parallel_des3_exact_scan.sh`: parallel predictor driver.

The coordinator has lab-specific host paths and the disposable VM address
`192.168.64.84`. It expects the NFS/Kerberos lab and supporting helper files
already installed. The exact attempt transcript and DTrace program are under
`../evidence/`.

The binaries were built and ad-hoc signed for Apple Silicon. Rebuild the C
sources when validating on another SDK or architecture.

