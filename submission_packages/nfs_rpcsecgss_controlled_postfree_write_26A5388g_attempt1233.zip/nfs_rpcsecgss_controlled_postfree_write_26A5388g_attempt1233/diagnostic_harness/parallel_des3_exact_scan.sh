#!/bin/zsh

set -u

if (( $# < 4 || $# > 6 )); then
	print -u2 "usage: $0 KEY HEADER MIN_VALUE MAX_VALUE [WORKERS [dword|rpcseq]]"
	exit 2
fi

key=$1
header=$2
min_dword=$3
max_dword=$4
workers=${5:-8}
scan_mode=${6:-dword}
if [[ "${scan_mode}" != dword && "${scan_mode}" != rpcseq ]]; then
	print -u2 "invalid scan mode: ${scan_mode}"
	exit 2
fi
scan_option=--scan-${scan_mode}
binary=${RPC_GSS_PREDICTOR_BINARY:-/Users/dawgyg/codex_lanes/nfs_rpcsecgss_poc/des3_kernel_mic_predict}
scan_dir=$(mktemp -d /tmp/fdflags_exact_scan.XXXXXX) || exit 1
max_sequence=${RPC_GSS_PREDICTOR_MAX_SEQUENCE:-4294967295}
if [[ "${max_sequence}" != <-> ||
    "${max_sequence}" -lt 1 ||
    "${max_sequence}" -gt 4294967295 ]]; then
	print -u2 "invalid predictor max sequence: ${max_sequence}"
	exit 2
fi
typeset -a pids
typeset -a active

print "scan_dir=${scan_dir}"
for worker in $(seq 1 "${workers}"); do
	start=$((max_sequence * (worker - 1) / workers + 1))
	end=$((max_sequence * worker / workers))
	if (( worker == workers )); then
		end=${max_sequence}
	fi
	"${binary}" "${scan_option}" "${key}" "${header}" \
	    "${min_dword}" "${max_dword}" "${start}" "${end}" \
	    >"${scan_dir}/out.${worker}" 2>"${scan_dir}/err.${worker}" &
	worker_pid=$!
	pids[$worker]="${worker_pid}"
	active[$worker]=1
	print "worker=$((worker - 1)) pid=${worker_pid} start=${start} end=${end}"
done

while true; do
	active_count=0
	for worker in $(seq 1 "${workers}"); do
		if [[ ${active[$worker]:-0} != 1 ]]; then
			continue
		fi
		active_count=$((active_count + 1))
		if kill -0 "${pids[$worker]}" 2>/dev/null; then
			continue
		fi
		wait "${pids[$worker]}"
		exit_status=$?
		active[$worker]=0
		if (( exit_status == 0 )); then
			print "winner=$((worker - 1))"
			cat "${scan_dir}/out.${worker}"
			for other in $(seq 1 "${workers}"); do
				if [[ ${active[$other]:-0} == 1 ]]; then
					kill -TERM "${pids[$other]}" 2>/dev/null || true
				fi
			done
			for other in $(seq 1 "${workers}"); do
				if [[ ${active[$other]:-0} == 1 ]]; then
					wait "${pids[$other]}" 2>/dev/null || true
				fi
			done
			exit 0
		fi
	done
	if (( active_count == 0 )); then
		print -u2 "no match in full sequence space"
		exit 1
	fi
	sleep 1
done
