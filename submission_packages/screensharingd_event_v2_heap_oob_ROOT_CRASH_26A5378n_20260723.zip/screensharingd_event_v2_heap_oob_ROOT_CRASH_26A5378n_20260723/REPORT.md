# Authenticated RFB EventMessage2 causes a root screensharingd heap OOB read/write

## Verdict

On macOS 27 beta build `26A5378n`, an authenticated Screen Sharing client can
send one 20-byte RFB message that causes root `screensharingd` to read and
write 16 bytes immediately after a 16-byte heap allocation.

The parser accepts a 16-byte event-type-3 body, but event version 2 activates
an additional 16-byte in-place byte-order conversion at body offset `0x10`,
followed by two 8-byte reads from the same adjacent address. The type-3 size
arm does not include that version-dependent tail. The sibling type-5 size arm
does.

The package contains four crash reports covering both the exact fault and
Apple's normal account-authentication path:

1. Probabilistic Guard Malloc faults at the exact first OOB instruction. Its
   high-confidence report identifies an allocated 16-byte object ending at the
   fault address.
2. The ordinary allocator later raises a pointer-authentication trap in
   `mfm_free` after one trigger frame, showing downstream heap-integrity impact.
3. A separate ordinary-allocator run authenticates as the regular uid-501 test
   account with Apple RFB security type 30, sends the same one frame, and
   produces the same root `mfm_free` PAC trap.
4. A second type-30 run authenticates as an explicitly authorized standard
   account that is not a member of `admin` and produces the same root
   `mfm_free` PAC trap.

The currently proven primitive is an adjacent 16-byte heap OOB read followed
by a deterministic 16-byte byte-order transform/write in a root network
daemon. This report does not claim arbitrary write, code execution, or
privilege escalation.

## Affected target

- Product: macOS 27.0 beta
- Build: `26A5378n`
- Component: `com.apple.screensharing.daemon`
- Binary: `screensharingd` 3.9.8, build 756.33
- Binary UUID: `332FB24B-1BD5-33C6-BEF8-3F53449C7032`
- Universal binary SHA-256:
  `cf4b4de7d192ec51710666ba013fb0ef068a8815ee4d289900da1879b4870549`
- Crashed service user: root (`userID=0`)

## Trigger

After a successful RFB authentication and `ServerInit`, the client sends:

```text
17 00 00 10  00 02 00 03  00 00 00 00  00 00 00 00  00 00 00 00
```

The framing is:

```text
offset  size  value       meaning
0x00    u8    0x17        EventMessage2 outer message type
0x01    u8    0x00        flags
0x02    be16  0x0010      declared body size
0x04    be16  0x0002      event version 2
0x06    be16  0x0003      event type 3
0x08    12    zeroes      remaining base event fields
```

Two bounded clients are supplied:

- `rfb_event_v2_ard_probe.c` uses Apple RFB security type 30 and ordinary
  Screen Sharing account credentials, then sends this one frame.
- `rfb_event_v2_probe.c` uses legacy VNC security type 2. It is retained
  because that run produced the exact-site PGM report.

Both clients target `127.0.0.1:5900`. Account-authenticated runs used
`testtest` (uid 501) and `rfbstd` (uid 502). The latter was a standard account
explicitly granted Remote Management access and control privileges.

## Root cause

The parser function is associated with `HandleEventMessage2` in
`RFBServer/ViewerMessages.m`. File addresses below refer to the current arm64e
slice whose UUID is listed above.

### Exact allocation

The outer parser:

```text
0x100039b7c  loads global maximum 50001
0x100039b80  cmp declared_body_size, 50001
0x100039b84  b.lo accepts the frame
0x10003a538  computes declared_body_size + 4
0x10003a54c  requires the complete frame to be buffered
0x10003bdb8  loads declared_body_size
0x10003bdc8  calloc(1, declared_body_size)
0x10003bddc  removes exactly declared_body_size bytes into the allocation
```

With the supplied frame, the logical and PGM-observed allocation size is
exactly 16 bytes.

### Incomplete type-3 bound

For event type 3, the size-table arm is:

```asm
0x10003f484  add w11, w11, #0xc
```

With flags clear, `w11` starts at 4, so the required body size becomes 16.
The only per-event body check is:

```asm
0x10003f4b0  ldrh w12, [sp, #0xda]   ; declared body size
0x10003f4b4  cmp   w12, w11
0x10003f4b8  b.hs  0x10003f554
```

The declared size of 16 therefore passes.

The type-3 consumer first transforms fields within offsets `0x04..0x0f`.
It then checks the independently supplied event version:

```asm
0x10003f750  cmp   w8, #2
0x10003f754  b.lo  0x10003f9a0
0x10003f758  ldr   q0, [x20, #0x10]
0x10003f75c  rev64.16b v0, v0
0x10003f760  str   q0, [x20, #0x10]
0x10003f780  ldr   x8, [x20, #0x10]  ; conditional logging path
0x10003f7c0  ldr   x8, [x20, #0x10]  ; unconditional consumer
```

For version 2, the load and store operate on body bytes `0x10..0x1f`, all
outside the 16-byte allocation. The later loads read bytes `0x10..0x17`, also
outside it.

### Two-sided operand audit

For all four adjacent-memory sinks:

1. Base `x20` is the exact `calloc` result.
2. Offset `0x10` is fixed by the instructions.
3. Access width is 16 bytes for `q0` at `0x10003f758/760` and 8 bytes for
   `x8` at `0x10003f780/7c0`.
4. The required spans are therefore `0x20` and `0x18` bytes respectively.
5. The check at `0x10003f4b4` only establishes
   `declared_body_size >= 0x10` for type 3.
6. The version check at `0x10003f750` selects the extra access but performs no
   size comparison.
7. The global `< 50001` check only caps the body and does not establish the
   per-event minimum.

No instruction establishes either `declared_body_size >= 0x18` or
`declared_body_size >= 0x20` before the version-2 type-3 sinks.

The sibling type-5 arm does account for its analogous version-dependent tail:

```asm
0x10003f48c  computes the base or extended minimum
0x10003f494  cmp  w12, #0x100
0x10003f498  csel w11, w13, w11, ne
```

Type 3 lacks this adjustment. The vulnerability is therefore a missing sibling
bound, not an absence of all size validation.

The complete 12-type event-family audit is in `STATIC_ANALYSIS.md`. For types
1, 2, and 4 through 12, the per-type minimum matches the largest reachable
fixed-offset access. Type 12's optional 8-byte tail is also paired with the
same flag that expands its minimum from 22 to 30 bytes. Type 3 version 2 is the
only physical span mismatch found in this family.

## Allocator free-list corruption

A follow-up normal-allocator debugger run identified the immediate neighbor
when the 16-byte body is served by Apple's MFM early allocator:

```text
x20 = 0x7b010403a0
malloc_size(x20)        = 16
malloc_size(x20 + 0x10) = 0
```

The 16 bytes at `x20+0x10` were a free MFM block's linked-list node:

```text
before:
0x0110000000000000 0x01760c0021a007db

after the three vulnerable instructions:
0x0000000000001001 0xdb07a021000c7601
```

Current Apple open-source `libmalloc` defines an MFM free block as a 16-byte
`mfmb_next`/`mfmb_prev` pair. `mfmb_next` is a process-dependent
pointer-authenticated value, while `mfmb_prev` is a raw arena offset. During
coalescing, `mfm_free` removes the adjacent free block and authenticates
`mfmb_next` before updating the list.

The vulnerable SIMD sequence byte-reverses both link qwords. This directly
explains the attached ordinary-allocator pointer-authentication trap in
`mfm_free`: the parser corrupts the next free-list node, then freeing the
message attempts to unlink that corrupted node.

This strengthens the demonstrated impact from generic adjacent bytes to
allocator free-list corruption. PAC rejects the corrupted next link in the
captured run, so this report still does not claim a successful unsafe unlink
or arbitrary write. See `HEAP_IMPACT.md` for the source mapping and exact
dynamic values.

## Exact-site crash

Primary report:

`screensharingd-2026-07-23-082305.ips`

SHA-256:

`635aa73e3edc99eb18a9010b5903ead97b7142562d180daf8e350b430a764c37`

Crash facts:

```text
incident: 829C5912-1072-46AC-BEC6-FDD9A357585B
pid: 1487
userID: 0
exception: EXC_BAD_ACCESS / SIGBUS
subtype: KERN_PROTECTION_FAILURE at 0x11c704000
ESR: Data Abort, byte read Translation fault
triggered image offset: 0x3f758
```

Relevant registers:

```text
x10 = 3
x11 = 16
x12 = 16
x20 = 0x11c703ff0
FAR = 0x11c704000
```

Thus `FAR == x20 + 0x10`. The report's `probGuardReport` says:

```text
errorType: out-of-bounds
confidence: high
nearestAllocation: 0x11c703ff0
allocationSize: 16
allocationState: allocated
```

The triggered image offset `0x3f758` is exactly:

```asm
ldr q0, [x20, #0x10]
```

This is the first OOB instruction.

## Ordinary-allocator crash

Secondary report:

`screensharingd-2026-07-23-082031.ips`

SHA-256:

`fb8d3f6bfc32567c1daf1efdd9dda48ef63a7f60ce69d0bf17b82acee2651006`

Crash facts:

```text
incident: 76670CD6-3E71-4563-815A-FCF9A473562C
pid: 1330
userID: 0
exception: EXC_BREAKPOINT
termination namespace: PAC_EXCEPTION
ESR: pointer authentication trap DB
fault: mfm_free + 868
caller: screensharingd + 0x3ec30
receive loop: screensharingd + 0x2ee00
```

At image offset `0x3ec30`, the immediately preceding instruction is the return
from `free(x23)`. This run used a fresh daemon and one trigger frame without
PGM. A later ordinary-allocator repeat did not crash, so this secondary crash
is allocation-layout dependent. The PGM report is the deterministic root-cause
evidence.

### Apple account-authentication repeat

The same ordinary-allocator crash was independently reproduced through Apple
RFB security type 30:

`screensharingd-2026-07-23-085516.ips`

SHA-256:

`72059bed4e5f3756cec60ce2cf52d625a30487807a2c03b79e8a5ebe979288e2`

Crash facts:

```text
incident: 3680D25C-E0C0-4632-97B4-F7288A172134
userID: 0
exception: EXC_BREAKPOINT
termination namespace: PAC_EXCEPTION
ESR: pointer authentication trap DB
fault: mfm_free + 868
caller: screensharingd + 0x3ec30
```

The client log recorded selection of security scheme 30 and successful VNC
authentication before the single EventMessage2 frame was sent. The client
process ran as the regular test account (`uid 501`). No legacy VNC password was
used in this run.

The same path was then repeated with credentials for `rfbstd` (uid 502), a
standard account that was not a member of `admin` but had been explicitly
granted Remote Management access and control privileges:

`screensharingd-2026-07-23-093432.ips`

SHA-256:

`c3d892cafba9aed9d60ccad35af0c9aad055e6ae739b2769c01d8580ef7c158c`

Crash facts:

```text
incident: 60A2A915-8688-4F75-BB88-D49F3DD4AB04
userID: 0
exception: EXC_BREAKPOINT
termination namespace: PAC_EXCEPTION
ESR: pointer authentication trap DB
fault: mfm_free + 868
caller: screensharingd + 0x3ec30
```

The probe authenticated through security type 30 and sent one frame. This
closes administrator membership as a precondition, while retaining the honest
requirement that the account already be authorized for remote control.

## Reachability

The confirmed path is:

```text
unprivileged client
  -> TCP 5900
  -> successful Apple RFB type-30 authentication as an authorized standard account
  -> ServerInit
  -> one EventMessage2 frame
  -> root screensharingd
```

The vulnerable block is reached when the Screen Sharing session permits
control rather than view-only access. The headless test VM was placed in the
equivalent control-enabled TCC state because command-line Remote Management
activation cannot show the normal System Settings consent UI. This was
test-environment setup, not part of the trigger. No daemon memory or registers
were modified in either attached crash report.

## Reproduction

See `REPRODUCTION.md`. The type-30 client is the preferred natural
authentication proof. The guarded legacy run remains the recommended exact-site
diagnostic because the attached PGM report deterministically faults at the
first OOB access.

## Attachments

- `rfb_event_v2_probe.c`: bounded one-frame reproducer source
- `rfb_event_v2_probe`: arm64 test executable
- `rfb_event_v2_ard_probe.c`: bounded type-30 account-authentication source
- `screensharingd-2026-07-23-082305.ips`: exact-site PGM crash
- `screensharingd-2026-07-23-082031.ips`: ordinary-allocator PAC crash
- `screensharingd-2026-07-23-085516.ips`: type-30 account-authenticated PAC
  crash
- `screensharingd-2026-07-23-093432.ips`: type-30 standard non-admin account
  PAC crash
- `ARD_AUTH_EVIDENCE.md`: account-authentication build and run evidence
- `STATIC_ANALYSIS.md`: detailed parser and sibling-check map
- `DYNAMIC_EVIDENCE.md`: natural control-enabled reachability evidence
- `HEAP_IMPACT.md`: MFM free-list-node corruption and PAC-trap explanation
- `REPRODUCTION.md`: setup, build, trigger, and cleanup steps
- `SHA256SUMS.txt`: attachment integrity
