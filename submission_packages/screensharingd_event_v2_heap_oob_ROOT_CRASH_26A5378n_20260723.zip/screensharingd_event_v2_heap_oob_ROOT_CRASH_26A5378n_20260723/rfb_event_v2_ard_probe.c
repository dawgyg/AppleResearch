#include <rfb/rfbclient.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char *credential_username;
static const char *credential_password;

static rfbCredential *
get_credential(rfbClient *client, int credential_type)
{
    (void)client;

    if (credential_type != rfbCredentialTypeUser) {
        return NULL;
    }

    rfbCredential *credential = calloc(1, sizeof(*credential));
    if (credential == NULL) {
        return NULL;
    }

    credential->userCredential.username = strdup(credential_username);
    credential->userCredential.password = strdup(credential_password);
    if (credential->userCredential.username == NULL ||
        credential->userCredential.password == NULL) {
        free(credential->userCredential.username);
        free(credential->userCredential.password);
        free(credential);
        return NULL;
    }
    return credential;
}

static rfbBool
allocate_framebuffer(rfbClient *client)
{
    size_t bytes_per_pixel = (size_t)client->format.bitsPerPixel / 8;
    size_t width = (size_t)client->width;
    size_t height = (size_t)client->height;

    if (bytes_per_pixel == 0 || width == 0 || height == 0 ||
        width > SIZE_MAX / height ||
        width * height > SIZE_MAX / bytes_per_pixel) {
        return FALSE;
    }

    free(client->frameBuffer);
    client->frameBuffer = calloc(width * height, bytes_per_pixel);
    return client->frameBuffer != NULL;
}

int
main(int argc, char **argv)
{
    static const uint32_t auth_schemes[] = {rfbARD};
    static const unsigned char event_message[] = {
        0x17, 0x00, 0x00, 0x10,
        0x00, 0x02, 0x00, 0x03,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00,
    };

    if (argc != 3) {
        fprintf(stderr, "usage: %s username password\n", argv[0]);
        return 2;
    }
    credential_username = argv[1];
    credential_password = argv[2];

    rfbClient *client = rfbGetClient(8, 3, 4);
    if (client == NULL) {
        return 1;
    }

    client->serverHost = strdup("127.0.0.1");
    client->serverPort = 5900;
    client->GetCredential = get_credential;
    client->MallocFrameBuffer = allocate_framebuffer;
    SetClientAuthSchemes(client, auth_schemes, 1);

    if (!rfbInitClient(client, NULL, NULL)) {
        fprintf(stderr, "ARD authentication failed\n");
        return 1;
    }

    printf("ARD account authentication succeeded\n");
    if (!WriteToRFBServer(client, (const char *)event_message,
            sizeof(event_message))) {
        fprintf(stderr, "failed to send EventMessage2 frame\n");
        rfbClientCleanup(client);
        return 1;
    }

    printf("sent one EventMessage2 frame (%zu bytes)\n",
        sizeof(event_message));
    sleep(2);
    rfbClientCleanup(client);
    return 0;
}
