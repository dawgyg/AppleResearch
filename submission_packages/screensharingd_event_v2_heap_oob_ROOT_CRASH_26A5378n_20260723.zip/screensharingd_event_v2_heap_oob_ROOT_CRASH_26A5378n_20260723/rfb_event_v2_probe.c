#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <unistd.h>

#include <CommonCrypto/CommonCryptor.h>

static int
read_full(int fd, void *buffer, size_t length)
{
    unsigned char *cursor = buffer;

    while (length != 0) {
        ssize_t count = read(fd, cursor, length);
        if (count == 0) {
            return -1;
        }
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        cursor += count;
        length -= (size_t)count;
    }
    return 0;
}

static int
write_full(int fd, const void *buffer, size_t length)
{
    const unsigned char *cursor = buffer;

    while (length != 0) {
        ssize_t count = write(fd, cursor, length);
        if (count < 0) {
            if (errno == EINTR) {
                continue;
            }
            return -1;
        }
        cursor += count;
        length -= (size_t)count;
    }
    return 0;
}

static unsigned char
reverse_bits(unsigned char value)
{
    value = (unsigned char)(((value & 0xaaU) >> 1) | ((value & 0x55U) << 1));
    value = (unsigned char)(((value & 0xccU) >> 2) | ((value & 0x33U) << 2));
    value = (unsigned char)((value >> 4) | (value << 4));
    return value;
}

static int
vnc_authenticate(int fd, const char *password)
{
    unsigned char challenge[16];
    unsigned char response[16];
    unsigned char key[8] = {0};
    size_t password_length = strlen(password);

    if (password_length > sizeof(key)) {
        password_length = sizeof(key);
    }
    for (size_t i = 0; i < password_length; i++) {
        key[i] = reverse_bits((unsigned char)password[i]);
    }
    if (read_full(fd, challenge, sizeof(challenge)) != 0) {
        return -1;
    }
    for (size_t offset = 0; offset < sizeof(challenge); offset += 8) {
        size_t output_length = 0;
        CCCryptorStatus status = CCCrypt(
            kCCEncrypt,
            kCCAlgorithmDES,
            kCCOptionECBMode,
            key,
            sizeof(key),
            NULL,
            challenge + offset,
            8,
            response + offset,
            8,
            &output_length);
        if (status != kCCSuccess || output_length != 8) {
            fprintf(stderr, "DES failed: status=%d output=%zu\n",
                status, output_length);
            return -1;
        }
    }
    return write_full(fd, response, sizeof(response));
}

static int
read_failure_reason(int fd)
{
    uint32_t network_length;

    if (read_full(fd, &network_length, sizeof(network_length)) != 0) {
        return -1;
    }
    uint32_t length = ntohl(network_length);
    if (length > 4096) {
        fprintf(stderr, "failure reason too long: %u\n", length);
        return -1;
    }
    char *reason = calloc((size_t)length + 1, 1);
    if (reason == NULL) {
        return -1;
    }
    if (read_full(fd, reason, length) != 0) {
        free(reason);
        return -1;
    }
    fprintf(stderr, "server failure: %s\n", reason);
    free(reason);
    return 0;
}

static int
rfb_handshake(int fd, const char *password)
{
    char version[13] = {0};
    unsigned char count;
    unsigned char types[255];
    unsigned char selected = 0;
    uint32_t status;

    if (read_full(fd, version, 12) != 0) {
        perror("read version");
        return -1;
    }
    printf("server version: %.12s", version);
    if (memcmp(version, "RFB ", 4) != 0) {
        fprintf(stderr, "unexpected protocol greeting\n");
        return -1;
    }
    if (write_full(fd, "RFB 003.008\n", 12) != 0) {
        perror("write version");
        return -1;
    }
    if (read_full(fd, &count, 1) != 0) {
        perror("read security count");
        return -1;
    }
    if (count == 0) {
        read_failure_reason(fd);
        return -1;
    }
    if (read_full(fd, types, count) != 0) {
        perror("read security types");
        return -1;
    }
    printf("security types:");
    for (unsigned int i = 0; i < count; i++) {
        printf(" %u", types[i]);
        if (types[i] == 2) {
            selected = 2;
        }
    }
    printf("\n");
    if (selected == 0) {
        fprintf(stderr, "VNC authentication is not offered\n");
        return -1;
    }
    if (write_full(fd, &selected, 1) != 0 ||
        vnc_authenticate(fd, password) != 0) {
        perror("VNC authentication exchange");
        return -1;
    }
    if (read_full(fd, &status, sizeof(status)) != 0) {
        perror("read auth status");
        return -1;
    }
    status = ntohl(status);
    printf("auth status: %u\n", status);
    if (status != 0) {
        read_failure_reason(fd);
        return -1;
    }
    return 0;
}

static int
read_server_init(int fd)
{
    unsigned char fixed[24];
    uint32_t network_name_length;

    if (read_full(fd, fixed, sizeof(fixed)) != 0) {
        return -1;
    }
    memcpy(&network_name_length, fixed + 20, sizeof(network_name_length));
    uint32_t name_length = ntohl(network_name_length);
    if (name_length > 4096) {
        fprintf(stderr, "server name too long: %u\n", name_length);
        return -1;
    }
    char *name = calloc((size_t)name_length + 1, 1);
    if (name == NULL) {
        return -1;
    }
    if (read_full(fd, name, name_length) != 0) {
        free(name);
        return -1;
    }
    uint16_t width;
    uint16_t height;
    memcpy(&width, fixed, sizeof(width));
    memcpy(&height, fixed + 2, sizeof(height));
    printf("server init: %ux%u name=%s\n",
        ntohs(width), ntohs(height), name);
    free(name);
    return 0;
}

int
main(int argc, char **argv)
{
    int trigger = argc == 2 && strcmp(argv[1], "--trigger") == 0;
    int hold = argc == 2 && strcmp(argv[1], "--hold") == 0;
    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        perror("socket");
        return 1;
    }

    struct timeval timeout = {.tv_sec = 5, .tv_usec = 0};
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));

    struct sockaddr_in address = {
        .sin_family = AF_INET,
        .sin_port = htons(5900),
    };
    inet_pton(AF_INET, "127.0.0.1", &address.sin_addr);
    if (connect(fd, (struct sockaddr *)&address, sizeof(address)) != 0) {
        perror("connect");
        close(fd);
        return 1;
    }
    if (rfb_handshake(fd, "test") != 0) {
        close(fd);
        return 1;
    }

    unsigned char shared = 1;
    if (write_full(fd, &shared, sizeof(shared)) != 0 ||
        read_server_init(fd) != 0) {
        perror("server init");
        close(fd);
        return 1;
    }

    if (trigger) {
        static const unsigned char message[] = {
            0x17, 0x00, 0x00, 0x10,
            0x00, 0x02, 0x00, 0x03,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
            0x00, 0x00, 0x00, 0x00,
        };
        if (write_full(fd, message, sizeof(message)) != 0) {
            perror("write candidate message");
            close(fd);
            return 1;
        }
        printf("sent one candidate message (%zu bytes)\n", sizeof(message));
        sleep(2);
    } else if (hold) {
        printf("holding initialized connection for debugger attach\n");
        sleep(120);
    }

    close(fd);
    return 0;
}
