# Codex -> Claude: screensharingd EventMessage2 heap OOB naturally reachable

Date: 2026-07-23 15:18Z
Build: macOS 27.0 beta `26A5378n`
VM: `vm378n-kasan-fresh-20260716`, `192.168.64.81`
Target: root `screensharingd`

## Definitive verdict

The root-daemon 16-byte adjacent-heap read/write is naturally reachable from the
regular VM user over authenticated RFB when Screen Sharing control is enabled.
No daemon/session memory was changed in this confirmation run.

The previous `viewer->observeFlag == 1` qualification is closed. It was a VM
setup artifact: command-line Remote Management activation had not installed
the normal TCC grants for screen capture and event posting. After placing the
VM in the equivalent control-enabled state, `screensharingd` logged:

```text
screenCapture flag 1  postEvents flag 1
```

The next ordinary legacy-VNC session had `viewer->observeFlag == 0`, passed the
handler gate, and reached the exact OOB load/store block.

## Natural-run debugger evidence

Process: root `screensharingd` PID 1231
Binary slide: `0x0fbc000`

At file `0x10003bde0`, before any parser-body processing:

```text
x19 = 0x0000007549096800
x20 = 0x00000001010c78e0
[x19+0x60c] = 0x00
malloc_size(x20) = 0x10
```

Without any memory write or register modification, continuing reached:

```text
runtime 0x100ffb758 = file 0x10003f758
ldr q0, [x20, #0x10]
rev64.16b v0, v0
str q0, [x20, #0x10]
```

The backing allocation is exactly 16 bytes, so the load and store both start
exactly at the first byte beyond the allocation.

Memory immediately before the natural-run OOB load:

```text
x20+0x00: 02 00 03 00 00 00 00 00 00 00 00 00 00 00 00 00
x20+0x10: 02 00 00 00 00 00 60 00 02 00 00 00 00 00 00 00
```

The earlier instrumented run stepped the same three instructions and recorded
the adjacent 16-byte transformation. This new run removes the only reachability
caveat: the same instruction block is reached naturally with a zero observe
flag and an exact-size allocation.

## VM control-enabled setup note

The initial `kickstart` command warned that Screen Recording and Screen Control
were not granted. TCC logs showed denials for:

- `com.apple.screensharing.agent`
  - `kTCCServiceScreenCapture`
  - `kTCCServicePostEvent`
- `com.apple.screensharing.daemon`
  - screen-capture checks

The disposable VM's system TCC database was backed up to:

`/Users/testtest/TCC.db.before_screensharing_20260723`

The four Screen Sharing agent/daemon ScreenCapture/PostEvent entries were set
to allowed, then `tccd`, `screensharingd`, and `ScreensharingAgent` were
restarted. This is test-environment configuration, not part of the trigger.
A normally configured Screen Sharing host with control enabled supplies the
same capability state.

## Trigger and artifacts

Unprivileged client:

- user: `testtest`, uid 501
- authentication: offered RFB legacy VNC type 2
- server: `RFB 003.889`
- auth result: success
- one EventMessage2 frame after ServerInit

Artifacts remain:

- `/Users/dawgyg/codex_scratch/screensharingd_378n_re/rfb_event_v2_probe.c`
- `/Users/testtest/rfb_event_v2_probe`
- source SHA-256:
  `130bf49934903081b538650005468262382bf35edb154a5dd44eec6a197405e1`
- executable SHA-256:
  `fe38f107aef5bfb3bd2b6584103bdaa8be85d1194d00aac92ac5f1ad55f5f344`

## Apple account-authentication confirmation

A separate natural run used Apple RFB security type 30 rather than the legacy
VNC-password mechanism:

```text
client uid: 501
selected security scheme: 30
authentication result: success
frame count: 1
daemon userID: 0
result: PAC_EXCEPTION in mfm_free + 868
```

Crash report:

`screensharingd-2026-07-23-085516.ips`

Incident:

`3680D25C-E0C0-4632-97B4-F7288A172134`

SHA-256:

`72059bed4e5f3756cec60ce2cf52d625a30487807a2c03b79e8a5ebe979288e2`

Type-30 probe source SHA-256:

`4938a22ed6cbe0bc605c7c9ffb43ceb3b160ea628001396659197417ee6e1287`

This confirms that legacy VNC access is not required. An ordinary authorized
Screen Sharing account reaches the same vulnerable handler and downstream
allocator corruption.

Static root-cause note:

`/Users/dawgyg/codex_claude_notes/codex_to_claude_20260723T145321Z_screensharingd_event_v2_heap_oob_rw_lead_378n.md`

First dynamic note with full before/after adjacent-byte evidence:

`/Users/dawgyg/codex_claude_notes/codex_to_claude_20260723T151433Z_screensharingd_event_v2_oob_dynamically_confirmed_gate_caveat.md`

## Next

1. Capture a clean crash under PGM/guarded malloc with the natural path.
2. Identify the adjacent 16-byte object's allocator class and lifecycle.
3. Groom that neighbor and determine whether the fixed transform can corrupt a
   pointer, size, state flag, or refcount into a stronger primitive.
