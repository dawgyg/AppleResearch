# Apple RFB type-30 account-authentication evidence

## Purpose

These runs remove the legacy-VNC-password qualification from the finding. The
client authenticated as authorized Screen Sharing accounts through Apple RFB
security type 30, then sent the same single fixed EventMessage2 frame. The
second run used a standard account that was not a member of `admin`.

## Client

Source:

`rfb_event_v2_ard_probe.c`

SHA-256:

`4938a22ed6cbe0bc605c7c9ffb43ceb3b160ea628001396659197417ee6e1287`

The client uses LibVNCClient at:

```text
repository: https://github.com/LibVNC/libvncserver
commit: 42494999e6492aaab9c1db785ecd293ef10b3aed
commit date: 2026-07-06
```

It sets the accepted authentication-scheme list to `{ rfbARD }`, whose
protocol value is 30. Credentials are supplied as command-line arguments. No
legacy VNC password is read or sent.

## First account-authenticated run

The regular client process ran as `testtest`, uid 501. Its authentication log
recorded:

```text
Received security type 30
Selecting security type 30
Selected Security Scheme 30
VNC authentication succeeded
ARD account authentication succeeded
sent one EventMessage2 frame (20 bytes)
```

The service immediately wrote:

`screensharingd-2026-07-23-085516.ips`

SHA-256:

`72059bed4e5f3756cec60ce2cf52d625a30487807a2c03b79e8a5ebe979288e2`

The report records:

```text
incident: 3680D25C-E0C0-4632-97B4-F7288A172134
build: macOS 27.0 (26A5378n)
binary UUID: 332fb24b-1bd5-33c6-bef8-3f53449c7032
userID: 0
exception: EXC_BREAKPOINT
termination: PAC_EXCEPTION
ESR: pointer authentication trap DB
fault: mfm_free + 868
caller: screensharingd + 0x3ec30
```

This is the same allocator-corruption signature as the earlier
ordinary-allocator run reached with security type 2.

## Standard non-admin account repeat

A separate local account, `rfbstd` (uid 502), was created without
administrative membership. Before the trigger:

```text
uid=502(rfbstd) gid=20(staff)
no rfbstd is NOT a member of admin
yes rfbstd is a member of com.apple.access_screensharing
dsAttrTypeNative:naprivs: -1073741569
```

The account was explicitly granted Remote Management access and control
privileges using Apple's supplied `kickstart` tool. The probe itself still ran
as uid 501 and supplied the `rfbstd` credentials to security type 30.

The client recorded:

```text
Selected Security Scheme 30
VNC authentication succeeded
ARD account authentication succeeded
sent one EventMessage2 frame (20 bytes)
```

The service immediately wrote:

`screensharingd-2026-07-23-093432.ips`

SHA-256:

`c3d892cafba9aed9d60ccad35af0c9aad055e6ae739b2769c01d8580ef7c158c`

The report records:

```text
incident: 60A2A915-8688-4F75-BB88-D49F3DD4AB04
build: macOS 27.0 (26A5378n)
binary UUID: 332fb24b-1bd5-33c6-bef8-3f53449c7032
userID: 0
exception: EXC_BREAKPOINT
termination: PAC_EXCEPTION
ESR: pointer authentication trap DB
fault: mfm_free + 868
caller: screensharingd + 0x3ec30
```

This proves that administrator account membership is not required. The
credentials must belong to an account that an administrator has already
authorized for Screen Sharing or Remote Management.

## Boundary

The account must already be authorized for Screen Sharing control. This
evidence proves normal account-authentication reachability for an explicitly
authorized standard account; it does not claim pre-authentication reachability
or an authentication bypass.
