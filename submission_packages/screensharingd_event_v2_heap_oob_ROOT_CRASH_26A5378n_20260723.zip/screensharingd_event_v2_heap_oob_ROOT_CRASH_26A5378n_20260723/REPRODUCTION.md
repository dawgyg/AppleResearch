# Reproduction

Use a disposable macOS 27 beta `26A5378n` system.

## 1. Enable the service

In System Settings, enable Screen Sharing or Remote Management for a test user
and permit that user to control the screen. Legacy VNC access is not required
for the preferred account-authentication reproduction.

The tested service is:

```text
system/com.apple.screensharing
/System/Library/CoreServices/RemoteManagement/screensharingd.bundle/Contents/MacOS/screensharingd
```

## 2. Preferred: Apple account authentication

`rfb_event_v2_ard_probe.c` uses LibVNCClient's Apple Remote Desktop
authentication implementation and restricts selection to RFB security type 30.
The captured run used upstream commit:

```text
https://github.com/LibVNC/libvncserver
42494999e6492aaab9c1db785ecd293ef10b3aed
```

Build LibVNCClient and the probe on the test system:

```sh
git clone https://github.com/LibVNC/libvncserver.git
git -C libvncserver checkout 42494999e6492aaab9c1db785ecd293ef10b3aed
cmake -S libvncserver -B libvncserver/build \
  -DCMAKE_C_FLAGS='-include unistd.h' \
  -DWITH_SDL=OFF -DWITH_GNUTLS=OFF -DWITH_OPENSSL=ON \
  -DWITH_EXAMPLES=OFF -DWITH_TESTS=OFF \
  -DWITH_FFMPEG=OFF -DWITH_JPEG=OFF -DWITH_PNG=OFF -DWITH_ZLIB=OFF
cmake --build libvncserver/build --target vncclient
clang -std=c11 -Wall -Wextra -Werror \
  -Ilibvncserver/include -Ilibvncserver/build/include \
  rfb_event_v2_ard_probe.c \
  -Llibvncserver/build -lvncclient \
  -Wl,-rpath,"$PWD/libvncserver/build" \
  -o rfb_event_v2_ard_probe
```

Run it as the regular authorized test user:

```sh
./rfb_event_v2_ard_probe TEST_USERNAME TEST_PASSWORD
```

The client selects only security type 30, completes account authentication,
sends one fixed 20-byte frame, waits two seconds, and exits. The attached
`screensharingd-2026-07-23-085516.ips` is an ordinary-allocator root-daemon
crash from this path. The separate
`screensharingd-2026-07-23-093432.ips` repeat used credentials for a standard
account that was explicitly granted Remote Management control access and was
not a member of `admin`.

## 3. Exact-site diagnostic client

For the exact-site PGM reproduction, enable legacy VNC access with the test
password `test`, or change the hard-coded test password in
`rfb_event_v2_probe.c`. Build it with:

```sh
clang -Wall -Wextra -O2 rfb_event_v2_probe.c -o rfb_event_v2_probe
```

The supplied executable was built for arm64 and connects only to
`127.0.0.1:5900`. Running it without `--trigger` performs only authentication
and initialization.

## 4. Deterministic exact-site crash

Enable PGM for a fresh launch of only the system service:

```sh
sudo launchctl setenv MallocProbGuard 1
sudo launchctl setenv MallocProbGuardSampleRate 1
sudo launchctl setenv MallocProbGuardLeftAlignPercentage 0
sudo launchctl setenv MallocProbGuardMemoryBudgetInKB 65536
sudo launchctl kill SIGKILL system/com.apple.screensharing 2>/dev/null || true
```

Run the probe as the regular test user:

```sh
./rfb_event_v2_probe --trigger
```

The connection is interrupted when root `screensharingd` faults. The resulting
DiagnosticReports entry should have:

```text
process: screensharingd
userID: 0
exception: EXC_BAD_ACCESS
image offset: 0x3f758
probGuardReport.errorType: out-of-bounds
probGuardReport.allocationSize: 16
```

Immediately remove the diagnostic variables:

```sh
sudo launchctl unsetenv MallocProbGuard
sudo launchctl unsetenv MallocProbGuardSampleRate
sudo launchctl unsetenv MallocProbGuardLeftAlignPercentage
sudo launchctl unsetenv MallocProbGuardMemoryBudgetInKB
```

## 5. Ordinary allocator

With the PGM variables absent, start a fresh service and run the same one-frame
probe:

```sh
sudo launchctl kill SIGKILL system/com.apple.screensharing 2>/dev/null || true
./rfb_event_v2_probe --trigger
```

The OOB transform always executes, but whether the neighboring 16 bytes cause
an immediate downstream crash depends on heap layout. The attached ordinary
run produced a PAC trap in `mfm_free`; the PGM run is the deterministic crash
method.

## Safety

The reproducer sends exactly one fixed malformed frame after successful
authentication and then exits. Run it only on a disposable test system.
