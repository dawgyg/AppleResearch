# MFM free-list corruption

## Dynamic layout

A normal-allocator debugger run stopped immediately before:

```asm
ldr q0, [x20, #0x10]
rev64.16b v0, v0
str q0, [x20, #0x10]
```

The live body was:

```text
x20 = 0x7b010403a0
malloc_size(x20) = 16
```

The next 16-byte-aligned address was not allocated:

```text
malloc_size(x20 + 0x10) = 0
```

Memory before the OOB sequence:

```text
0x7b010403a0: 0x0000000000030002 0x0000000000000000
0x7b010403b0: 0x0110000000000000 0x01760c0021a007db
```

After single-stepping the load, lane reversal, and store:

```text
0x7b010403a0: 0x0000000000030002 0x0000000000000000
0x7b010403b0: 0x0000000000001001 0xdb07a021000c7601
```

Both qwords at `x20+0x10` were byte-reversed exactly.

## Allocator mapping

Apple's current open-source `libmalloc` tree was inspected at:

```text
repository: https://github.com/apple-oss-distributions/libmalloc
commit: c49dafa25f1efe8607701ae6014a663ad2ee437f
release: libmalloc-812.100.31
commit date: 2026-04-17
```

`src/early_malloc.c` defines the 16-byte MFM block:

```c
struct mfm_block {
    void *mfmb_next;
    uint64_t mfmb_prev;
} __attribute__((aligned(MFM_QUANTUM)));
```

On arm64e, `mfmb_next` uses process-dependent data pointer authentication,
address diversity, and the discriminator `mfmb_next`. `mfmb_prev` is a raw
arena-relative block offset.

`__mfm_block_remove` performs:

```text
next = authenticated blk->mfmb_next
prev = blk->mfmb_prev
next_blk = arena->mfm_base[next]
prev_blk = arena->mfm_base[prev]
next_blk->mfmb_prev = prev
prev_blk->mfmb_next = next
```

`mfm_free` coalesces a newly freed allocation with an adjacent free block by
calling `__mfm_block_remove` on that block.

## Crash correlation

The ordinary-allocator report
`screensharingd-2026-07-23-082031.ips` terminates in:

```text
PAC_EXCEPTION
mfm_free + 868
screensharingd + 0x3ec30
screensharingd + 0x2ee00
```

The vulnerable write replaces the neighboring free block's valid signed next
link with its byte-reversed value. When the parser later frees the body,
`mfm_free` attempts to coalesce and authenticate that link, producing the
captured pointer-authentication trap.

The account-authenticated type-30 run independently produced the same
`mfm_free + 868` / `screensharingd + 0x3ec30` signature in
`screensharingd-2026-07-23-085516.ips`.

## Primitive boundary

Proven:

- exact 16-byte live allocation;
- OOB read and write beginning at allocation end;
- corruption of both qwords in an adjacent MFM free-list node;
- downstream PAC failure in `mfm_free` during the ordinary run.

Not proven:

- a valid forged PAC link;
- a successful unsafe unlink;
- attacker-chosen write address or value;
- code execution.
