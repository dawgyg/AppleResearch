#pragma D option quiet
fbt:com.apple.driver.SoftRAID:*Volume18AddVolumePartition*:entry
{
  this->vol = (uintptr_t)arg0;            /* this = the Volume object */
  this->rec = (uintptr_t)arg4;            /* VolumePartitionStatusRec* */
  this->idx = *(uint8_t*)(this->rec + 0x6c);
  this->cnt = *(uint16_t*)(this->rec + 0x6e);
  this->target = this->vol + 0x2d8 + this->idx*8;
  printf("SINK Volume::AddVolumePartition this=0x%llx allocSize=0x538 member_index=0x%x member_count=0x%x\n",
    (uint64_t)this->vol, this->idx, this->cnt);
  printf("  OOB write target = this+0x2d8+idx*8 = 0x%llx  (offset from obj = 0x%llx, alloc=0x538) %s\n",
    (uint64_t)this->target, (uint64_t)(this->target - this->vol),
    (this->target - this->vol) > 0x538 ? "=> OUT-OF-BOUNDS" : "in-bounds");
}
