#pragma D option quiet
fbt:com.apple.driver.SoftRAID:*Volume18AddVolumePartition*:entry
{ self->vol=(uintptr_t)arg0; self->idx=*(uint8_t*)((uintptr_t)arg4+0x6c);
  self->before = *(uint64_t*)(self->vol + 0x2d8 + self->idx*8); }
fbt:com.apple.driver.SoftRAID:*Volume18AddVolumePartition*:return
/self->vol/
{ this->after = *(uint64_t*)(self->vol + 0x2d8 + self->idx*8);
  printf("vol=0x%llx idx=0x%x OOBslot[+0x%x] before=0x%llx after=0x%llx %s\n",
    (uint64_t)self->vol, self->idx, 0x2d8+self->idx*8,
    (uint64_t)self->before, (uint64_t)this->after,
    this->after != self->before ? "=> WRITE EXECUTED OOB (slot past 0x538 alloc modified)" : "(unchanged)");
  self->vol=0; }
