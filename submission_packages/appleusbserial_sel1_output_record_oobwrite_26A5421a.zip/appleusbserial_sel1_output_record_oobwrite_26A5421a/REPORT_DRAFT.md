# AppleUSBSerial selector 1 omits output-record capacity check, enabling an unprivileged controlled kernel-heap overwrite

## Summary

`AppleUSBSerialUserClient::externalMethod` selector 1 accepts two client
scalars, `{acknowledge_length, submit_length}`. The submit length is checked
against available bytes in a user-writable `0x10000` transmit ring, but it is
never checked against the capacity of the selected USB output record. Each
output record has only `PAGE_SIZE` (`0x4000` on Apple silicon) bytes.

An unprivileged uid 501 client can therefore submit `0x8000` bytes. The kernel
copies attacker-controlled bytes from the mapped transmit ring into a
`0x4000`-byte output record and continues for another `0x4000` bytes into the
following kernel allocation.

On macOS 27 build `26A5421a`, I used DTrace only as a placement and
before/after oracle. It identified a selected output record immediately
followed by another live output record. Selector 1 then changed the first
quadwords of that distinct neighbor from zero to
`0x4141414141414141`, and the system continued running. This proves a silent,
attacker-content kernel-heap overwrite rather than only a panic.

The same missing check is present in shipping macOS 26.6 build `25G72` and in
every archived macOS 27 beta checked through `26A5421a`.

## Tested environment

- macOS 27.0, build `26A5421a`
- Darwin 27.0.0, `xnu-13432.1.9~3/RELEASE_ARM64_T6000`
- unprivileged caller: uid 501
- provider: `AppleUSBACMData`, bundle `com.apple.driver.usb.cdc.acm`
- implementation: `com.apple.driver.usb.serial`
- implementation UUID: `90B8D9E2-FEFE-3473-ADE2-F3F9FA7F7E80`
- implementation SHA-256:
  `3530146e10d1718c4a93fd67670e2d86f58ed4db83a3c205e3d99b1cfd87842d`

The silent before/after oracle run used SIP disabled and GZAlloc. The attached
stock preflight performs only unprivileged open/setup/map validation and does
not trigger the overflow. The vulnerable copy and the provider's ordinary
open policy are in the stock kernel image.

## Reachability and argument shape

The client finds `AppleUSBACMData` and opens user-client type 0 as uid 501.
No entitlement or root privilege is required in the tested configuration.

Selector 0 takes two scalar inputs and allocates the receive/transmit
resources. Client-memory type 2 maps the `0x10000` transmit ring read/write into
the caller.

Selector 1 takes exactly two scalar inputs and no structure input or output:

```text
scalarInput[0] = acknowledge_length
scalarInput[1] = submit_length
scalarInputCount = 2
```

## Root cause: Rule Zero operand proof

Current `26A5421a` selector-1 path begins at
`AppleUSBSerialUserClient::externalMethod @ 0xfffffe000a20e304`.

The attacker-controlled submit length is loaded into `w27`:

```text
0xfffffe000a20e3dc  ldr x8, [x20, #0x20]
0xfffffe000a20e3e0  ldr w27, [x8, #0x8]
```

The source-ring check is:

```text
0xfffffe000a20e444  ldp w8, w9, [x26, #0x80]
0xfffffe000a20e448  sub w9, w8, w9
0xfffffe000a20e44c  bic w9, w25, w9
0xfffffe000a20e450  cmp w9, w27
0xfffffe000a20e454  b.lo 0xfffffe000a20e980
```

The first copy chunk is only reduced for transmit-ring wrap:

```text
0xfffffe000a20e458  and w22, w8, w25
0xfffffe000a20e45c  sub w8, w28, w22
0xfffffe000a20e460  cmp w27, w8
0xfffffe000a20e464  csel w21, w27, w8, lo
```

The destination record is selected from the provider's eight-entry pool and
its bytes pointer is returned in `x0`. The source is the mapped transmit ring
at provider offset `+0x120`, plus the ring offset in `w22`. The copy is:

```text
0xfffffe000a20e48c  ldr x9, [x8, #0xe0]
0xfffffe000a20e49c  and x8, x10, #0x7
0xfffffe000a20e4a0  ldr x23, [x9, x8, lsl #3]
0xfffffe000a20e4cc  blraa x8, x16          ; getBytesNoCopy -> x0/dst
0xfffffe000a20e4d0  ldr x8, [x19, #0xd8]
0xfffffe000a20e4d4  ldr x8, [x8, #0x120]
0xfffffe000a20e4d8  add x1, x8, w22, uxtw ; src
0xfffffe000a20e4dc  mov x2, x21            ; length
0xfffffe000a20e4e0  bl _memmove
```

Every sink operand has been traced:

- source and length are bounded against the `0x10000` transmit ring;
- the source offset is reduced modulo that ring;
- the destination is a valid selected output-record bytes pointer;
- **no instruction compares `w27` or `w21` with the destination record's
  `0x4000` capacity before `_memmove`.**

`AppleUSBSerial::allocResources` creates eight output records through
`IOUSBHostInterface::createIOBuffer(options=2, capacity=PAGE_SIZE)`. On the
tested Apple-silicon build, DTrace observed each record capacity as `0x4000`.

## Dynamic proof

The guarded verifier filled the mapped transmit ring with byte `0x41` and used
three in-bounds selector-1 calls to advance the pool index. DTrace then found:

```text
ENTRY index=0 backing=fffffea1eeeec000 adjacent_output=1 neighbor_before=0/0
POOL fffffea1eeeec000 fffffea1eeef0000 fffffea1eeec4000 fffffea1eeee4000 fffffea1eeee8000 fffffea1eeec0000 fffffea1eeecc000 fffffea1eeef4000
```

The selected record began at `0xfffffea1eeeec000`; pool entry 1 began at
`0xfffffea1eeef0000`, exactly `0x4000` bytes later. After submitting `0x8000`:

```text
RETURN index=0 backing=fffffea1eeeec000 adjacent_output=1 neighbor_after=0x4141414141414141/0x4141414141414141
```

The selector returned `0x1` after the write. The system did not panic.

## Reproduction

Attach a USB device that publishes `AppleUSBACMData`, compile the probe, and
run the non-destructive preflight as an ordinary user:

```sh
./collect_stock_preflight.zsh
```

This proves stock venue reachability but does not call selector 1 with an
oversized length.

For the full silent-overwrite mechanism proof, use a disposable research Mac
with kernel DTrace available:

```sh
sudo dtrace -o dtrace.log -s evidence/trace_silent_overflow.d
./appleusbserial_sel1_probe --safe-submit
./appleusbserial_sel1_probe --fire-I-accept-kernel-panic
```

The attached preserved `probe.log` and `dtrace.log` are from the controlled
adjacent-record run. The fire mode can corrupt an arbitrary neighboring kernel
allocation or panic the system and is intentionally guarded by a literal
command-line acknowledgement.

## Persistence

| Build | UUID | `externalMethod` | source check | `_memmove` sink |
|---|---|---:|---:|---:|
| macOS 26.6 `25G72` | `758DCD16-E2E4-3ACA-B181-B749589D63F6` | `0xfffffe0009ec10d8` | `0xfffffe0009ec1200` | `0xfffffe0009ec1294` |
| macOS 27 `26A5378n` | `81A28B1E-18EB-3022-9B6D-1F344CB85D73` | `0xfffffe000a1f4204` | `0xfffffe000a1f4358` | `0xfffffe000a1f43e8` |
| macOS 27 `26A5416b` | `90B8D9E2-FEFE-3473-ADE2-F3F9FA7F7E80` | `0xfffffe000a20cb04` | `0xfffffe000a20cc50` | `0xfffffe000a20cce0` |
| macOS 27 `26A5421a` | `90B8D9E2-FEFE-3473-ADE2-F3F9FA7F7E80` | `0xfffffe000a20e304` | `0xfffffe000a20e450` | `0xfffffe000a20e4e0` |

All four paths bound only source-ring availability and wrap distance. None
checks the same copy length against the output-record capacity.

## Impact

An unprivileged local user can overwrite at least the demonstrated `0x4000`
bytes beyond a live kernel heap allocation with chosen content when an
`AppleUSBACMData` provider is present. The demonstrated outcome is silent
corruption of a distinct live kernel allocation. Depending on adjacent
allocation placement, the same
primitive can corrupt kernel object state or pointers and may enable local
privilege escalation. I have not claimed code execution or a Target Flag.
