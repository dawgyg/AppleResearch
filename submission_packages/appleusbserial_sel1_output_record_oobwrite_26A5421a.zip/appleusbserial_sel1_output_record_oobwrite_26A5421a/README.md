# AppleUSBSerial selector-1 controlled kernel-heap overwrite

`REPORT_DRAFT.md` contains the bounded claim, exact current-build disassembly,
Rule Zero operand trace, dynamic before/after proof, and version span.

Run `./collect_stock_preflight.zsh` as an ordinary user on an unmodified boot
with a USB CDC ACM device attached. It opens the service, allocates the rings,
maps client memory type 2, and stops before the oversized selector-1 call.

The literal `--fire-I-accept-kernel-panic` mode is destructive and must only be
used on a disposable research machine. The preserved `evidence/` directory is
the authoritative silent-overwrite run.

