# diskimagesiod UDIF blkx Data OOB-read

This package contains a proof-of-concept UDIF/DMG that triggers a memory-safety bug in
`/usr/libexec/diskimagesiod` while parsing the `blkx` resource-fork `Data` field.

## Contents

- `poc_udif_blkx_data8.dmg` - malformed UDIF image with a short `blkx` `Data` blob.
- `diskimagesiod_OOB_read_blkx.ips` - crash report from `_diskimagesiod` under guard malloc.
- `udif_blkx_poc.py` - generator/sweep script used to create short-`Data` variants from a seed UDIF.
- `repro_attach.sh` - minimal local trigger for the included DMG.
- `APPLE_REPORT_DRAFT.md` - concise report text.
- `CRASH_SUMMARY.txt` - parsed crash details and static offset mapping.
- `SHA256SUMS.txt` - checksums for package artifacts.

## Minimal Reproduction

Run on a test machine or VM:

```sh
./repro_attach.sh
```

Equivalent trigger:

```sh
diskutil image attach ./poc_udif_blkx_data8.dmg --noMount --nobrowse
```

The included crash was captured with guard malloc loaded into `diskimagesiod`, which turns the
out-of-bounds read into a deterministic `EXC_BAD_ACCESS` at the guard page. Without guard malloc,
the same malformed input may be parsed far enough to fail later or silently read adjacent heap
memory depending on allocator layout.

## Root Cause

`diskimagesiod` copies the `blkx` dictionary's `Data` CFData into a heap buffer using the CFData
length, then passes only the pointer to the block parser. The parser performs fixed reads up to
at least `Data+0xc8` without receiving or checking the copied length. The packaged `Data` length is
8 bytes, so the first fixed reads cross the allocation boundary under guard malloc.
