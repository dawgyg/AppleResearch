# `diskimagesiod` out-of-bounds read parsing malformed UDIF `blkx` Data

## Summary

A malformed UDIF/DMG image can cause the privileged `diskimagesiod` service to read out of bounds
while parsing the resource-fork `blkx` dictionary `Data` field. The daemon copies
attacker-controlled CFData using the provided length, then parses the copied buffer as a fixed-size
UDIF block table without a minimum-length check.

With guard malloc enabled for `diskimagesiod`, the included PoC produces a deterministic
`EXC_BAD_ACCESS` in `/usr/libexec/diskimagesiod` at `diskimagesiod+0x167c5c`.

## Affected Component

- Process: `/usr/libexec/diskimagesiod`
- Context: privileged platform daemon running as `_diskimagesiod` (`userID=271` in the included
  crash report)
- Input: attacker-supplied local DMG/UDIF image
- Trigger route: local image attach/open path, for example `diskutil image attach` or a stock
  disk image open workflow.

## Steps to Reproduce

On a test machine or VM:

```sh
cd diskimagesiod_blkx_oob
./repro_attach.sh
```

Equivalent direct trigger:

```sh
diskutil image attach ./poc_udif_blkx_data8.dmg --noMount --nobrowse
```

The included `.ips` was captured with guard malloc enabled for the daemon to make the OOB read
fault at the allocation boundary.

## Expected Result

`diskimagesiod` rejects the malformed UDIF `blkx` record before reading beyond the provided
`Data` buffer.

## Actual Result

`diskimagesiod` reads beyond the 8-byte copied `blkx` `Data` buffer. Under guard malloc, this
faults in the UDIF block parser:

```text
Exception: EXC_BAD_ACCESS / SIGSEGV / KERN_INVALID_ADDRESS
Process:   /usr/libexec/diskimagesiod
PC:        diskimagesiod+0x167c5c
FAR:       0x338fa0000
x20:       0x338f9fff0
```

The fault address is `x20+0x10`, consistent with a fixed read from a short copied buffer placed
at the end of a guard-malloc page.

## Technical Details

Static reverse engineering of `diskimagesiod` shows:

1. `UDIF_base::generate_blocks(CFArrayRef)` obtains the `blkx` dictionary `Data` value and
   type-checks it as CFData.
2. It allocates exactly `CFDataGetLength(Data)` bytes, zeroes that allocation, and copies
   `CFDataGetBytes(Data, range 0..length)` into it.
3. It calls the block parser with only the copied pointer, not the length.
4. The block parser performs fixed loads from offsets including `+0x0`, `+0x4`, `+0x8`,
   `+0x90`, `+0xb0`, `+0xc0`, and `+0xc8`.

Relevant offsets from the tested build:

```text
generate_blocks:          diskimagesiod+0x165f44
call to block parser:     diskimagesiod+0x1660b4
faulting block parser PC: diskimagesiod+0x167c5c
```

The included PoC uses a `blkx` `Data` length of 8 bytes. The crash report shows `x24=8` and
`x26=8`, matching the copied short `Data` size, while the parser faults reading beyond it.

## Impact

This is a memory-safety issue in a privileged platform daemon reachable by local
attacker-controlled disk image input. The demonstrated impact is an out-of-bounds read and daemon
crash under guard malloc. The bug should be treated as a privileged parser memory-corruption issue
even when stock allocator layout does not always turn the OOB read into a visible crash.
