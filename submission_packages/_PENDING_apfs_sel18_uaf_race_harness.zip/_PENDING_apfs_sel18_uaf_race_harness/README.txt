PENDING STATIC LEAD, NOT A CONFIRMED UAF AND NOT READY TO FILE

Target: AppleAPFSUserClient selector 18 versus selector 1 on macOS 27 build
26A5378n. The static release-before-clear window remains present, but 380
properly targeted dynamic races did not produce a panic or sanitizer report.

Static basis
- selector 18 methodVolumeCryptoOperation @ 0xfffffe000b7ad444
- late raw slot reload @ 0xfffffe000b7ad720, vtable load @ 0xfffffe000b7ad724,
  authenticated call @ 0xfffffe000b7ad754
- selector 1 methodVolumeDelete @ 0xfffffe000b7b0690
- release @ 0xfffffe000b7b08e8..0xfffffe000b7b08fc, then slot clear
  @ 0xfffffe000b7b0900
- full Rule Zero analysis:
  /Users/dawgyg/codex_claude_notes/codex_to_claude_20260721T101439Z_apfs_378n_sel18_and_indexed_store_closure.md

Dynamic disposition on vm378n-kasan-fresh-20260716
- The guest is RELEASE_ARM64_VMAPPLE, not KASAN.
- A disposable 512 MB APFS image was used. The harness now requires an exact
  container UUID and never falls back to the first AppleAPFSContainer.
- selector 18 op 4 query succeeded for volume index 0.
- On an encrypted, unmounted disposable volume, selector 18 op 2 succeeded.
- Selector 1 succeeded with its correct exact 4-byte structure input and
  removed the same volume.
- 100 zero-delay races: selector 18 success 61, no-device 39; delete success
  100; no panic.
- 80 delay-sweep races (1,2,5,10,20,50,100,200 us): 79 selector 18 success,
  one no-device; delete success 80; no panic.
- After reboot with boot-args "-zp keepsyms=1 amfi_get_out_of_my_way=1",
  200 zero-delay races: selector 18 success 121, no-device 79; delete success
  200; no panic and no new panic report.

Current verdict
Both state-changing operations are dynamically reachable on the current build,
but the tested schedules produced only clean before/after outcomes. This does
not prove the static lifetime window safe, and it does not prove a UAF. Resume
only with a genuine KASAN kernel or deterministic kernel-breakpoint timing.

VM-only usage
  clang -Wall -Wextra -O2 -framework IOKit -framework CoreFoundation \
    apfs_sel18_race.c -o apfs_sel18_race
  ./apfs_sel18_race --container-uuid UUID --volume-index 0 --mode probe
  sudo ./apfs_sel18_race --container-uuid UUID --volume-index 0 \
    --mode race --op 2 --threads 1 --delete-delay-us 0

Never run the race mode on a host or a non-disposable APFS container.

