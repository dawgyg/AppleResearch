FSKit msdos VFAT LFN index-255 controlled stack OOB write
=========================================================

Status: CONFIRMED statically and dynamically on macOS 27.0 beta 26A5378n.

WARNING: Do not mount either image on the host. Use a disposable VM. The primary PoC is
msdos_lfn_idx255_stop256_378n.img.

Primary PoC SHA-256:
f1965fb15478d25ddc3917896f5dc34bf85a7779161f777cd1a414ed7bd81d81

Affected binary:
/System/Library/ExtensionKit/Extensions/com.apple.fskit.msdos.appex/Contents/MacOS/com.apple.fskit.msdos
Universal binary SHA-256:
ce4ae4114d0669d606e8360bcd9fb51b0a13f295e76c67fb2aa17a29e3db5ea7
Extracted arm64e slice SHA-256:
2f41fdaa97552271ca1b4a65cb66b1297b99abeaa54ec6e6d6c2a79944a86cd4

Confirmed result
----------------
An unprivileged uid 501 user can mount the crafted FAT16 image through FSKit. Directory
enumeration reaches a root com.apple.fskit.msdos process and performs an
attacker-controlled 16-bit write one element past a fixed unistr255 chars[255] array.

The release-build LLDB trace breaks immediately before the sink, shows w9=0xff and
w8=0x0041, single-steps the strh, and observes the adjacent stack word change from
0x0000 to 0x0041. The primary image stops at exactly 256 UTF-16 code units; ordinary
readdir returns a filename containing 256 'A' characters. The extension remains alive
and no crash report is generated.

Bug mechanics and complete bound accounting
--------------------------------------------
The helper +[MsdosUtilities parseCharacterOfLongNameEntry:charIdxInEntry:
charIdxInName:unistrName:isFirstLongEntryInSet:] begins at unslid 0x100008d70.

1. charIdxInEntry (w3) is independently bounded to 0..12 by:
   0x100008d70 cmp w3, #0xc
   0x100008d74 b.ls 0x100008d80

2. The caller derives charIdxInName (w4) as count*13-13 at 0x10000d654..0x10000d65c.
   The first LFN order byte is masked with 0x3f at 0x10000c170..0x10000c178, but is not
   capped to the 19-entry/255-character capacity of the destination.

3. The sink index is w9=w4+w3. Its only final check is:
   0x100008dbc cmp w9, #0xff
   0x100008dc0 b.hi reject
   This rejects values greater than 255 but permits 255.

4. The destination parameter has ObjC encoding ^{unistr255=S[255S]}: a uint16 length
   followed by uint16 chars[255]. Valid character indices are 0..254. The sink is:
   0x100008dc4 add x10, x5, #2
   0x100008dc8 strh w8, [x10, w9, uxtw #1]

5. The attacker supplies w8 through the VFAT LFN UTF-16 entry. Order 20 gives base
   (20-1)*13=247; slot 8 produces index 255 and writes the chosen halfword at x5+0x200.

The destination payload is stack-resident inside a __block object. Index 255 lands in
the first two bytes of the immediately adjacent byref header. This is a real controlled
two-byte stack OOB write. No control-flow consequence or privilege escalation is claimed.

Reproduction
------------
Run as a normal uid 501 user in a disposable macOS 27 VM:

  hdiutil attach -readonly -nobrowse -noverify -noautofsck \
    msdos_lfn_idx255_stop256_378n.img
  /bin/ls -1 /Volumes/LFNPOC | awk '{ print length($0) }'

Expected PoC output: 256

Verify the mount uses FSKit and is owned by the normal user:

  mount | grep /Volumes/LFNPOC

Observed on 26A5378n:

  /dev/disk6 on /Volumes/LFNPOC (... read-only, ... fskit, mounted by testtest)

The LLDB trace in LLDB_CONTROLLED_OOB_WRITE.txt is the definitive dynamic memory-write
evidence. It includes registers, memory before/after, stack region, queue, and backtrace.

Files
-----
- msdos_lfn_idx255_stop256_378n.img: primary PoC; char 255='A', char 256=NUL.
- msdos_lfn_idx255_oob_378n.img: original all-'A' variant; attempts index 256 after 255.
- make_stop256_variant.c: deterministic transformation from the original to primary PoC.
- LLDB_CONTROLLED_OOB_WRITE.txt: clean debugger transcript from root FSKit process.
- STATIC_RULE_ZERO_EVIDENCE.txt: exact checks, unchecked span, sink, and stack layout.
- DYNAMIC_VM_EVIDENCE.txt: build, identity, reachability, and behavioral result.
- PORTAL_FIELDS_DRAFT.txt: bounded Apple Security Bounty report draft.
- SHA256SUMS.txt: package file hashes.
