#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>

enum {
    kImageSize = 8 * 1024 * 1024,
    kOrder20EntryOffset = 0x8200,
    kGlobal256CodeUnitOffset = kOrder20EntryOffset + 22,
};

static void fail(const char *what)
{
    perror(what);
    exit(EXIT_FAILURE);
}

int main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "usage: %s source.img output.img\n", argv[0]);
        return EXIT_FAILURE;
    }

    FILE *src = fopen(argv[1], "rb");
    if (src == NULL)
        fail("fopen source");

    uint8_t *image = malloc(kImageSize);
    if (image == NULL)
        fail("malloc");
    if (fread(image, 1, kImageSize, src) != kImageSize)
        fail("fread");
    if (fgetc(src) != EOF) {
        errno = EFBIG;
        fail("source size");
    }
    fclose(src);

    if (image[kOrder20EntryOffset] != 0x54 ||
        image[kGlobal256CodeUnitOffset] != 0x41 ||
        image[kGlobal256CodeUnitOffset + 1] != 0x00) {
        errno = EINVAL;
        fail("unexpected source layout");
    }

    image[kGlobal256CodeUnitOffset] = 0;
    image[kGlobal256CodeUnitOffset + 1] = 0;

    FILE *dst = fopen(argv[2], "wb");
    if (dst == NULL)
        fail("fopen output");
    if (fwrite(image, 1, kImageSize, dst) != kImageSize)
        fail("fwrite");
    if (fclose(dst) != 0)
        fail("fclose output");

    free(image);
    return EXIT_SUCCESS;
}
