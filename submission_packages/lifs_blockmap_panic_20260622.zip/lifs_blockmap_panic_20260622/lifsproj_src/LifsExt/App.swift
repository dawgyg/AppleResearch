import ExtensionFoundation
import Foundation
import FSKit
import os

let lg = Logger(subsystem: "com.dawgyg.lifspoc", category: "ext")

@main
struct LifsExt: UnaryFileSystemExtension {
    var fileSystem: FSUnaryFileSystem & FSUnaryFileSystemOperations {
        lg.error("LIFSPOC fileSystem accessor called")
        return LifsFS()
    }
}

@objc
final class LifsFS: FSUnaryFileSystem, FSUnaryFileSystemOperations {
    func probeResource(resource: FSResource,
                       replyHandler: @escaping (FSProbeResult?, (any Error)?) -> Void) {
        lg.error("LIFSPOC probeResource called")
        replyHandler(.usable(name: "lifspoc", containerID: FSContainerIdentifier(uuid: UUID(uuidString: "0000A1A1-0000-0000-0000-00000000F5F5")!)), nil)
    }
    func loadResource(resource: FSResource, options: FSTaskOptions,
                      replyHandler: @escaping (FSVolume?, (any Error)?) -> Void) {
        lg.error("LIFSPOC loadResource called")
        self.containerStatus = FSContainerStatus.ready
        replyHandler(LifsVolume(resource: resource, fs: self), nil)
    }
    func unloadResource(resource: FSResource, options: FSTaskOptions) async throws {
        lg.error("LIFSPOC unloadResource called")
    }
}
