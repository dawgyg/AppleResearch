#import <Foundation/Foundation.h>
@protocol ExecManagerRemote
- (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b;
@end
@protocol ExecManager
- (void)isDeveloperModeEnabledWithReply:(void(^)(BOOL,NSError*))reply;
- (void)setDeveloperModeEnabled:(BOOL)enabled withReply:(void(^)(BOOL,NSError*))reply;
@end
@interface Cb:NSObject<ExecManagerRemote>@end @implementation Cb -(void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b{}@end
static id px(NSXPCConnection**cc){NSXPCConnection*c=[[NSXPCConnection alloc]initWithMachServiceName:@"com.apple.security.syspolicy.exec" options:0];
 c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManager)];c.exportedInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManagerRemote)];c.exportedObject=[Cb new];c.invalidationHandler=^{};c.interruptionHandler=^{};[c resume];*cc=c;
 return [c remoteObjectProxyWithErrorHandler:^(NSError*e){NSLog(@"err %ld",(long)e.code);}];}
static BOOL q(){NSXPCConnection*c;id r=px(&c);__block BOOL v=-1;dispatch_semaphore_t s=dispatch_semaphore_create(0);
 [r isDeveloperModeEnabledWithReply:^(BOOL e,NSError*x){v=e;dispatch_semaphore_signal(s);}];dispatch_semaphore_wait(s,dispatch_time(DISPATCH_TIME_NOW,6*NSEC_PER_SEC));[c invalidate];return v;}
static void st(BOOL val){NSXPCConnection*c;id r=px(&c);dispatch_semaphore_t s=dispatch_semaphore_create(0);
 [r setDeveloperModeEnabled:val withReply:^(BOOL ok,NSError*x){NSLog(@"  set:%d ok=%d",val,ok);dispatch_semaphore_signal(s);}];dispatch_semaphore_wait(s,dispatch_time(DISPATCH_TIME_NOW,6*NSEC_PER_SEC));[c invalidate];}
int main(){@autoreleasepool{ NSLog(@"uid=%d",getuid());
 NSLog(@"syspolicyd isDeveloperModeEnabled (initial) = %d", q());
 NSLog(@"-> set NO"); st(NO); sleep(1); NSLog(@"syspolicyd isDeveloperModeEnabled (after NO) = %d", q());
 NSLog(@"-> set YES"); st(YES); sleep(1); NSLog(@"syspolicyd isDeveloperModeEnabled (after YES) = %d", q());
 return 0; }}
