#import <Foundation/Foundation.h>
@protocol ExecManagerRemote
- (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b;
@end
@protocol ExecManager
- (void)setDeveloperModeEnabled:(BOOL)enabled withReply:(void(^)(BOOL ok, NSError *err))reply;
@end
@interface Cb : NSObject <ExecManagerRemote> @end
@implementation Cb - (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b {} @end
static id mk(NSXPCConnection**cc){ NSXPCConnection*c=[[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.security.syspolicy.exec" options:0];
 c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManager)];
 c.exportedInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManagerRemote)]; c.exportedObject=[Cb new];
 c.invalidationHandler=^{}; c.interruptionHandler=^{}; [c resume]; *cc=c; return c; }
static void setdm(BOOL v){ NSXPCConnection*c; id r=[mk(&c) remoteObjectProxyWithErrorHandler:^(NSError*e){NSLog(@"err %ld",(long)e.code);}];
 dispatch_semaphore_t s=dispatch_semaphore_create(0);
 [r setDeveloperModeEnabled:v withReply:^(BOOL ok,NSError*e){ NSLog(@"[setDeveloperModeEnabled:%d] ok=%d err=%@",v,ok,e); dispatch_semaphore_signal(s);}];
 dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 6*NSEC_PER_SEC)); [c invalidate]; }
int main(int ac,char**av){ @autoreleasepool { NSLog(@"uid=%d",getuid()); BOOL v=(ac>1 && av[1][0]=='1'); setdm(v); sleep(1); return 0; }}
