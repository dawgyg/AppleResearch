// SAFE clocksyncd unauth accept-probe (uid501). Getter-only (getSyncEntityManagerWithReply:),
// NO mutating calls (no add/remove/register/set). Mirrors the avbdeviced Stage-A safe confirm.
#import <Foundation/Foundation.h>

@protocol TSXDaemonServiceServerProtocol
- (void)getSyncEntityManagerWithReply:(void(^)(id manager))reply;
- (void)isActiveWithReply:(void(^)(BOOL active))reply;
@end

int main(void){ @autoreleasepool {
  const char *svcs[] = {"com.apple.timesync.manager","com.apple.timesync.expositor","com.apple.timesync.ptp.manager"};
  for (int i=0;i<3;i++){
    NSString *svc = [NSString stringWithUTF8String:svcs[i]];
    fprintf(stderr,"\n[svc=%s] uid=%d\n", svcs[i], getuid());
    NSXPCConnection *c = [[NSXPCConnection alloc] initWithMachServiceName:svc options:NSXPCConnectionPrivileged];
    c.remoteObjectInterface = [NSXPCInterface interfaceWithProtocol:@protocol(TSXDaemonServiceServerProtocol)];
    __block BOOL invalidated = NO;
    c.invalidationHandler = ^{ invalidated = YES; fprintf(stderr,"  connection INVALIDATED\n"); };
    c.interruptionHandler = ^{ fprintf(stderr,"  connection interrupted\n"); };
    [c resume];
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    id proxy = [c remoteObjectProxyWithErrorHandler:^(NSError *e){
        fprintf(stderr,"  proxy error: %s\n", e.localizedDescription.UTF8String); dispatch_semaphore_signal(sem); }];
    [proxy getSyncEntityManagerWithReply:^(id mgr){
        fprintf(stderr,"  *** REPLY: getSyncEntityManager -> %s (unauth ACCEPTED + serviced) ***\n",
                mgr? "non-nil manager proxy":"nil"); dispatch_semaphore_signal(sem); }];
    dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 3*NSEC_PER_SEC));
    [c invalidate];
  }
  return 0;
}}
