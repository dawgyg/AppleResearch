#!/bin/sh
# Capture stock-venue evidence immediately before a Target Flag attempt.
# Usage: prefire_capture.sh OUTPUT [ASB_READER [ARG...]]
set -eu

OUT=${1:?usage: prefire_capture.sh OUTPUT [ASB_READER [ARG...]]}
shift
TMP="${OUT}.tmp.$$"
trap 'rm -f "$TMP"' EXIT HUP INT TERM

csrutil_status=$(/usr/bin/csrutil status 2>&1) || csrutil_rc=$?
csrutil_rc=${csrutil_rc:-0}
nvram_raw=$(/usr/sbin/nvram boot-args 2>&1) || nvram_rc=$?
nvram_rc=${nvram_rc:-0}
kern_bootargs=$(/usr/sbin/sysctl -n kern.bootargs 2>&1) || kern_rc=$?
kern_rc=${kern_rc:-0}

if [ "$nvram_rc" -eq 0 ]; then
    nvram_normalized=$(printf '%s\n' "$nvram_raw" | /usr/bin/sed -E 's/^boot-args[[:space:]]*//')
elif printf '%s\n' "$nvram_raw" | /usr/bin/grep -qi 'data was not found'; then
    nvram_normalized=
else
    nvram_normalized="__CAPTURE_ERROR__: $nvram_raw"
fi

{
    printf 'PREFIRE_SCHEMA=2\n'
    printf 'PREFIRE_UTC=%s\n' "$(/bin/date -u +%Y-%m-%dT%H:%M:%SZ)"
    /usr/bin/id
    /usr/bin/sw_vers
    /usr/sbin/sysctl kern.version kern.bootsessionuuid
    printf 'CSRUTIL_STATUS=%s\n' "$csrutil_status"
    printf 'CSRUTIL_EXIT=%s\n' "$csrutil_rc"
    printf 'NVRAM_BOOTARGS_NORMALIZED=%s\n' "$nvram_normalized"
    printf 'NVRAM_BOOTARGS_EXIT=%s\n' "$nvram_rc"
    printf 'NVRAM_BOOTARGS_RAW_BEGIN\n%s\nNVRAM_BOOTARGS_RAW_END\n' "$nvram_raw"
    printf 'KERN_BOOTARGS=%s\n' "$kern_bootargs"
    printf 'KERN_BOOTARGS_EXIT=%s\n' "$kern_rc"
    if [ "$#" -gt 0 ]; then
        printf 'PREFIRE_PAYLOAD_BEGIN\n'
        "$@"
        printf 'PREFIRE_PAYLOAD_END\n'
    fi
} > "$TMP"

/bin/chmod 600 "$TMP"
/bin/mv "$TMP" "$OUT"
trap - EXIT HUP INT TERM
/bin/cat "$OUT"

if [ "$csrutil_rc" -ne 0 ] || ! printf '%s\n' "$csrutil_status" | /usr/bin/grep -qi '^System Integrity Protection status: enabled\.$'; then
    printf 'FATAL: SIP is not proven enabled; venue is inadmissible.\n' >&2
    exit 4
fi
if [ "$kern_rc" -ne 0 ] || [ -n "$kern_bootargs" ] || [ -n "$nvram_normalized" ]; then
    printf 'FATAL: boot args are non-empty or could not be captured; venue is inadmissible.\n' >&2
    exit 4
fi

printf 'VENUE_GATE=PASS\n'
