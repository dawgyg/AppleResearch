#!/bin/zsh
set -euo pipefail

fire_arg='--fire-one-stock-mapped-observer-I-accept-kernel-panic'
kit_dir=${0:A:h}
asb_reader=/Users/dawgyg/flagcap/asb_read
expected_host='hacker.local'
expected_build='26A428'
expected_model='MacBookPro18,2'
approval_env='RUN_APPLEUSBSERIAL_STOCK_OBSERVER_V3_PHYSICAL_HOST'
arm_token="$kit_dir/ARM_26A428_OBSERVER_V3.once"

if [[ $# -ne 1 || $1 != $fire_arg ]]; then
  print -u2 "Usage: $approval_env=YES $0 $fire_arg"
  print -u2 'This can corrupt kernel memory or panic the machine.'
  exit 2
fi
if [[ ${(P)approval_env:-} != YES ]]; then
  print -u2 "REFUSING: set $approval_env=YES only after literal approval for this physical-host run."
  exit 2
fi
if [[ $EUID -eq 0 ]]; then
  print -u2 'REFUSING: run as an ordinary non-root user.'
  exit 3
fi
if [[ ! -x $asb_reader ]]; then
  print -u2 "REFUSING: missing ASB reader: $asb_reader"
  exit 3
fi
if [[ ! -f $arm_token || ! -O $arm_token ]]; then
  print -u2 "REFUSING: missing user-owned one-shot arm token: $arm_token"
  print -u2 'Run prepare_arm_token_v3.zsh only after fresh literal approval.'
  exit 3
fi

actual_host=$(/bin/hostname)
actual_build=$(/usr/bin/sw_vers -buildVersion)
actual_model=$(/usr/sbin/sysctl -n hw.model)
hardware=$(/usr/sbin/system_profiler SPHardwareDataType 2>&1)
if [[ $actual_host != $expected_host || $actual_build != $expected_build ||
      $actual_model != $expected_model ]]; then
  print -u2 "REFUSING: wrong target (host=$actual_host build=$actual_build model=$actual_model)."
  exit 3
fi
if print -r -- "$hardware" | /usr/bin/grep -qi 'VirtualMac'; then
  print -u2 'REFUSING: target identifies as a VM; this kit is pinned to the physical research host.'
  exit 3
fi

out="$kit_dir/stock_observer_v3_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -m 700 "$out"

{
  print "TARGET=physical host $actual_host"
  print "BUILD=$actual_build"
  print "MODEL=$actual_model"
  print -r -- "$hardware"
} > "$out/target_identity.txt"

/usr/sbin/ioreg -r -c AppleUSBACMData -l > "$out/ioreg_AppleUSBACMData.txt"
if ! /usr/bin/grep -q AppleUSBACMData "$out/ioreg_AppleUSBACMData.txt"; then
  print -u2 'REFUSING: no AppleUSBACMData provider is attached.'
  exit 4
fi

/usr/bin/clang -Wall -Wextra -Werror -O2 \
  -framework IOKit -framework CoreFoundation \
  "$kit_dir/appleusbserial_sel1_stock_observer_v3.c" \
  -o "$out/appleusbserial_sel1_stock_observer_v3"

{
  print -r -- "$0 $fire_arg"
  /usr/bin/shasum -a 256 \
    "$kit_dir/appleusbserial_sel1_stock_observer_v3.c" \
    "$kit_dir/prefire_capture.sh" \
    "$arm_token" \
    "$asb_reader" \
    "$out/appleusbserial_sel1_stock_observer_v3"
} > "$out/command_and_initial_hashes.txt"

"$out/appleusbserial_sel1_stock_observer_v3" "$fire_arg" "$out" \
  "$kit_dir/prefire_capture.sh" "$asb_reader" "$arm_token" 2>&1 | \
  /usr/bin/tee "$out/run_console.log"

/usr/bin/shasum -a 256 "$out"/* > "$out/SHA256SUMS"
print "Mapped-observer shot returned without a panic. Evidence: $out"
