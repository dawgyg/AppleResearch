# AppleUSBSerial selector-1 stock mapped observer v3 (`26A428`)

Status: release-current, prepared and compile-verified only. It has not been
fired on the physical host.

## Purpose

This is a filing-evidence attempt for the confirmed selector-1 controlled
kernel-heap overwrite. It is not presented as a Target Flag chain.

The prior ASB-marked output-record test established that the deterministic
adjacent victim is raw USB payload storage, not a pointer consumer. An ASB fill
alone therefore does not self-evidence under stock conditions. This version
also snapshots ordinary uid501 read-only client mappings and scans them after
the single oversized call. A new four-qword ASB pattern in the control mapping
is stock before/after proof of cross-allocation corruption without DTrace.

## Exact baseline

- macOS 27.0 release build: `26A428`.
- Physical host: `hacker.local`, `MacBookPro18,2`.
- KDK DMG SHA-256:
  `7ce685e305d3bcee5e1d8fe9418c55c7e0bbc38075ab1841602444e9098a6efc`.
- Kext: `com.apple.driver.usb.serial`, source version `157.0.0`.
- Kext SHA-256:
  `09b6ab0e05875ad7fc368d9065fca81d9f36d04989b45822c2ae976dba469bbe`.
- Mach-O UUID: `ED41522F-5C21-38F3-8CCF-538F38BDAE01` (`arm64e`).

The static root cause and exact Rule Zero operand audit are included. Selector
1 validates the `0x10000` source ring but never compares its chosen copy length
with the selected output record's `0x4000` capacity. Safe sibling
`AppleUSBSerial::enqueueData` computes and applies that exact one-page clamp.

## Run sequence

The binary:

1. requires uid501, exact host/model/build, SIP enabled, empty effective and
   NVRAM boot arguments, one attached `AppleUSBACMData`, and two matching
   same-boot ASB snapshots;
2. calls selector 0 once and maps control type 0, receive type 1, and writable
   transmit type 2;
3. fills transmit with non-ASB `0x5a`, then performs exactly three independently
   in-bounds `submit=0x100` calls to reproduce the known pool position;
4. snapshots control and receive only after those harmless calls settle;
5. fills transmit with alternating live `KERN_ADDRESS,KERN_VALUE` qwords;
6. atomically moves and persists the one-shot arm token into the evidence
   directory;
7. performs exactly one `submit=0x8000` call, with no retry or trigger loop;
8. scans control from offset `0x200` and all of receive for a changed four-qword
   ASB signature, then retains resources for 30 seconds.

Only a control-map hit is classified as filing evidence. Receive-map hits are
diagnostic because a USB peer could echo transmitted bytes.

The only loops are bounded local pattern-fill, safe-call, and post-return scan
loops. There is no launch item, reboot action, automatic retry, or resume path.
The token is consumed before the oversized call and is never recreated.

## Deliberately unexecuted commands

These commands document the package; they do not authorize a physical-host
run. A fresh literal `go` is required after the exact target, command, expected
result/runtime, risks, stop condition, and recovery plan are stated.

Arm once:

```sh
ARM_APPLEUSBSERIAL_STOCK_OBSERVER_V3_PHYSICAL_HOST=YES \
  ./prepare_arm_token_v3.zsh \
  --arm-one-AppleUSBSerial-stock-observer-v3-after-literal-go
```

Fire once:

```sh
RUN_APPLEUSBSERIAL_STOCK_OBSERVER_V3_PHYSICAL_HOST=YES \
  ./run_stock_observer_v3.zsh \
  --fire-one-stock-mapped-observer-I-accept-kernel-panic
```

Expected runtime after preflight is about 35 seconds if the selector returns.
A panic or reboot is possible because the operation intentionally overwrites
kernel heap memory. On any panic, do not re-arm; let the host reboot, log in,
and collect the single panic report.

## Outcome classification

- `OBSERVER HIT` in `control-map`: filing-grade stock corruption evidence.
- Panic: filing-grade only if the panic independently attributes the fault to
  this one call; Target Flag only if it meets Apple's target criterion.
- Return with no control hit: one placement miss, not a root-cause disproof;
  do not automatically retry.
