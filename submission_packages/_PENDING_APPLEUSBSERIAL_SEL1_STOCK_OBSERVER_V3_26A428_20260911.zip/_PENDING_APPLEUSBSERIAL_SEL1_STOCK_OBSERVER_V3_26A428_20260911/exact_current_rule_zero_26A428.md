# AppleUSBSerial selector 1 Rule Zero audit (`26A428`)

Status: exact-current static revalidation only. Nothing in this directory was
fired on the physical host while preparing it.

## Baseline

- macOS 27.0 release build: `26A428`.
- Exact extracted kext: `com.apple.driver.usb.serial`, source version `157.0.0`.
- Kext SHA-256: `09b6ab0e05875ad7fc368d9065fca81d9f36d04989b45822c2ae976dba469bbe`.
- Mach-O UUID: `ED41522F-5C21-38F3-8CCF-538F38BDAE01` (`arm64e`).
- Selector handler: `AppleUSBSerialUserClient::externalMethod` at file
  offset `0x7b68`.
- Vulnerable copy call: `memmove` at file offset `0x7d48`.

## Argument shape

The selector dispatch compares the selector with `1` at `0x7ba8..0x7bac`
and enters the selector-1 branch at `0x7c14`. It requires at least two
scalar inputs with `cmp w8,#2; b.lo` at `0x7c14..0x7c1c`. It then
loads:

- scalar 0 (`ack`) as 64 bits into `x24` at `0x7c40..0x7c44`;
- scalar 1 (`submit`) as 32 bits into `w27` at `0x7c48`.

No structure input, structure output, or scalar output feeds the vulnerable
copy. The detector supplies exactly two scalar inputs and no outputs.

## Sink operands and both-side checks

The sink is `memmove(x0, x1, x2)` at `0x7d48`.

### Destination (`x0`)

- The output-record array is loaded from `[serial+0xe0]` at
  `0x7cf4`.
- The rotating record index is reduced to `[0,7]` by
  `and x8,x10,#7` at `0x7d04` before the record load at
  `0x7d08`.
- The selected record is checked non-null by `cbz x23` at `0x7d0c`.
- The record byte pointer is returned in `x0` by the virtual call at
  `0x7d10..0x7d34`.
- There is no destination offset; the copy starts at the record base.

The eight output records are allocated by the loop at
`0x8798..0x87f0`. Each allocation uses output direction `w1=2` at
`0x87c0` and capacity `x2=1 << PAGE_SHIFT_CONST` at
`0x879c..0x87a4`. On this arm64 host the capacity is one `0x4000`
page.

### Source (`x1`)

- The ring size and mask are formed from `[ring+0x109]` at
  `0x7c9c..0x7ca8`.
- The producer offset is reduced modulo the ring by `and w22,w8,w25`
  at `0x7cc0`.
- `ring_size - producer_offset` is computed at `0x7cc4`.
- `cmp w27,w8; csel w21,w27,w8,lo` at `0x7cc8..0x7ccc`
  limits the source chunk to bytes before ring wrap.
- The ring base is loaded from `[serial+0x120]` at
  `0x7d38..0x7d3c`, and the masked offset is added at `0x7d40`.

### Length (`x2`)

- Attacker `submit` is loaded into `w27` at `0x7c48`.
- Source availability is checked by `cmp w9,w27; b.lo` at
  `0x7cb8..0x7cbc`.
- Source wrap reduces only the current chunk into `w21` at
  `0x7cc8..0x7ccc`.
- `w21` is moved unchanged into `x2` at `0x7d44`.

## Missing bound and sibling proof

No instruction in the selector-1 path from `0x7c98` through the sink
at `0x7d48` compares `w27` or `w21` with the selected
record's `0x4000` capacity. A later reference to
`PAGE_SHIFT_CONST` at `0x8050` belongs to another selector path and
cannot guard this earlier copy.

The safe sibling `AppleUSBSerial::enqueueData` explicitly computes the
same one-page record capacity at `0x90c0..0x90d4`, then clamps its copy
length with `cmp w22,w8` / `csel w26,w22,w8,lo` at
`0x90d8..0x90dc` before its `memmove` at `0x9168`. That
sibling is direct evidence of the intended but omitted selector-1 check.

## Primitive

After three in-bounds `submit=0x100` calls, the source offset is
`0x300`. A `submit=0x8000` request leaves `0xfd00` bytes
before ring wrap, so `w21=0x8000`. The sink writes `0x8000`
attacker-controlled bytes into a `0x4000` destination record: a
`0x4000`-byte controlled kernel-heap overwrite.

Prior uid501 instrumentation on an earlier macOS 27 build showed the excess
bytes changing a distinct adjacent live output record while the selector
returned. That establishes mechanism but is not stock filing evidence because
it used DTrace and a marker fill. The release-current stock ASB detector remains
deliberately unexecuted pending literal approval for the pinned physical-host
command.

