#!/bin/zsh
set -euo pipefail
setopt noclobber

arm_arg='--arm-one-AppleUSBSerial-stock-observer-v3-after-literal-go'
approval_env='ARM_APPLEUSBSERIAL_STOCK_OBSERVER_V3_PHYSICAL_HOST'
kit_dir=${0:A:h}
arm_token="$kit_dir/ARM_26A428_OBSERVER_V3.once"

if [[ $# -ne 1 || $1 != $arm_arg || ${(P)approval_env:-} != YES ]]; then
  print -u2 "Usage: $approval_env=YES $0 $arm_arg"
  print -u2 'Only arm after fresh literal approval for the exact physical-host run.'
  exit 2
fi
if [[ $EUID -eq 0 ]]; then
  print -u2 'REFUSING: arm as the ordinary uid501 research user, not root.'
  exit 3
fi

actual_host=$(/bin/hostname)
actual_build=$(/usr/bin/sw_vers -buildVersion)
actual_model=$(/usr/sbin/sysctl -n hw.model)
if [[ $actual_host != hacker.local || $actual_build != 26A428 ||
      $actual_model != MacBookPro18,2 ]]; then
  print -u2 "REFUSING: wrong target (host=$actual_host build=$actual_build model=$actual_model)."
  exit 3
fi
if [[ -e $arm_token ]]; then
  print -u2 "REFUSING: arm token already exists: $arm_token"
  exit 3
fi

umask 077
print -r -- 'APPLEUSBSERIAL_SEL1_STOCK_OBSERVER_V3_26A428_ONCE' > "$arm_token"
/bin/chmod 600 "$arm_token"
/usr/bin/shasum -a 256 "$arm_token"
print 'Armed exactly one future oversized call. The runner consumes this token'
print 'immediately before firing and never recreates it.'
