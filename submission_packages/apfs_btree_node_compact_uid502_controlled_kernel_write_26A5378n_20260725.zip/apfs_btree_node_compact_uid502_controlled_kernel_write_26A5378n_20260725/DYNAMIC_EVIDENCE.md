# APFS `_btree_node_compact` controlled OOB write

## Build and reachability

- Product: macOS 27.0 beta, build `26A5378n`
- Kernel: `xnu-13432.0.50.501.3~1/RELEASE_ARM64_VMAPPLE`
- APFS: `com.apple.filesystems.apfs` 3283.0.9
- Triggering process: uid 501 `touch`
- Entry: uid 501 `hdiutil attach` of the crafted 16 KiB-block APFS image,
  followed by a file create on the mounted volume
- Control: the corresponding unmodified image mounts, accepts the same
  uid 501 file create, and detaches cleanly

The VM also contains a real non-admin account:

```text
uid=502(rfbstd) gid=20(staff)
user is not a member of the group admin
```

The baseline mounted read-write as `rfbstd`, created a file owned by uid 502,
and detached cleanly. The crafted image then produced
`panic-full-2026-07-25-115202.0002.panic`; its `touch` process record is:

```json
{"userID":502,"groupID":20,"procname":"touch","pid":1060}
```

That panic independently symbolizes to `_btree_node_compact+0x25c`.

## Direct-write panic

Artifact:
`panic-full-2026-07-25-114539.0002.panic`

The panic states:

```text
Kernel data abort
pc  = 0xfffffe0030cf79fc
lr  = 0xfffffe00300d715c (PAC stripped)
esr = 0x96000047
far = 0xfffffe2fba65f6d4
x0  = 0xfffffe2fba65f6d4
x19 = 0x4904
x22 = 0xfffffe2fba663fd8
x26 = 0xfffffe2fba660000
```

`ESR.WnR` is set, so this is a write fault. GZAlloc classifies the address as
a high-confidence out-of-bounds access in `data.kalloc.16384`.

The static sink computes:

```text
destination = value_end - (cumulative_value_length & 0xffff)
```

The runtime registers reproduce that formula exactly:

```text
0xfffffe2fba663fd8 - 0x4904 = 0xfffffe2fba65f6d4
node base - destination = 0x92c
far == x0 == destination
```

The APFS return address symbolizes with the matching 26A5378n KDK to:

```text
btree_node_compact + 604
btree_node_insert_internal + 380
bt_insert + 5756
create_or_modify_jobj + 1572
insert_jobj + 448
fs_obj_create_name_checked + 536
fs_obj_create_do + 372
apfs_vnop_create + 1000
```

`604 == 0x25c`, the instruction immediately after the `memmove` call at
`_btree_node_compact+0x258`.

## Attacker-content control

The replay image repeats the eight-byte marker `CODEX2!!` through every
crafted source span. At the write fault, registers `x8` through `x15`
contain the two overlapping marker words:

```text
x8-x11  = 0x2121325845444f43
x12-x15 = 0x45444f4321213258
```

The earlier `APFSVAL!` image produced the same call chain but placed
`0x214c4156` (`VAL!`) in `x24`. Changing only the marker therefore changes
the attacker-derived data propagated through the corrupting operation.

## Rule-Zero bound audit

Matching KDK APFS arm64e offsets:

```text
+0x214  ldrh w8, [x23, #2]       // val_off
+0x218  cmp  x8, x28             // x28 = 0xfffd
+0x21c  b.hi +0x294              // only bound in the value loop
+0x220  ldrh w2, [x23, #4]       // val_len: no bound
+0x224  add  w19, w2, w19        // cumulative: no capacity bound
+0x228  sub  x9, x25, w19, uxth  // u32-to-u16 width change
+0x22c  add  x0, x22, x9         // destination
+0x240  sub  x8, x25, x8         // source from val_off
+0x244  add  x1, x22, x8
+0x258  bl   memmove
```

Operand accounting for `memmove(dst, src, len)`:

- `val_off` has only the global `<= 0xfffd` comparison.
- `val_len` has no comparison in the value pass.
- cumulative `sum(val_len)` has no comparison to the per-node value area.
- the destination truncates cumulative from 32 to 16 bits with `UXTH`.
- there is no check that destination remains at or above the node base.
- the crafted image independently satisfies
  `val_len <= val_off <= value_area_size`, so every source span is inside the
  attacker-authored node. The missing destination/cumulative bound is the
  only invariant violated.

The correct per-entry range validator exists elsewhere in APFS but is not
called by `_btree_node_compact`.

## Reproducibility

Three crafted-image runs panicked the kernel. Two used `CODEX2!!`; the third
was run while a passive FBT entry probe was enabled, which changed heap
layout enough for GZAlloc to catch the first out-of-node destination as a
direct write. No probe modified APFS inputs or control flow.

The same `CODEX2` image was independently reproduced on a second 26A5378n VM.
Its baseline survived; its crafted run faulted with a different cumulative
value:

```text
esr = 0x96000007                 # WnR=0: source-side read fault
far = 0xfffffe31abd60000
x0  = 0xfffffe31abd46d3e
x19 = 0x1d29a
x22 = 0xfffffe31abd53fd8
x26 = 0xfffffe31abd50000
x22 - (x19 & 0xffff) == x0
```

This is independent reproduction evidence, not a second direct-write panic.
The `0x96000047` artifact above remains the write proof.

Static disclosure and dedicated-zone exploitability analysis is separated
into `DISCLOSURE_AND_EXPLOITABILITY.md` so it is not confused with the
dynamically observed claims in this file.
