# APFS `_btree_node_compact` write/disclosure filing package

Status: the attacker-content relative write is dynamically confirmed three
times on the primary macOS 27.0 `26A5378n` VM and independently reproduced on
a second machine. The strongest replay is a direct GZAlloc-classified kernel
OOB write from uid 501 `touch`. The second-machine replay is a source-side read
fault, not another write panic.

The direct returned disclosure and dedicated-zone arbitrary-R/W chain are
static exploitability results. No dedicated disclosure image/readback
transcript or Target Flag capture is bundled. **Never attach the crafted image
on a real host.**

## Artifacts

- `baseline_16k.img.gz`: compressed clean 64 MiB image from
  `newfs_apfs -b 16384 -v CODEXBTREE`.
- `apfs_btree_compact_16k_CODEX2.img.gz`: primary crafted marker image.
- `apfs_btree_compact_16k_APFSVAL.img.gz`: marker-differential image.
- `apfs_btree_compact_tool.py`: offline inspector, compact-move simulator, and
  deterministic crafter.
- `newfs_16k.log`: formatter output for the clean baseline.
- `panic-full-2026-07-25-114539.0002.panic`: direct-write panic.
- `panic-full-2026-07-25-115202.0002.panic`: non-admin uid 502
  reachability panic.
- `panic-2026-07-25-114539.apfs.symbolicated.txt`: KDK
  symbolication of the APFS frames.
- `DYNAMIC_EVIDENCE.md`: concise register/formula and Rule-Zero analysis.
- `DISCLOSURE_AND_EXPLOITABILITY.md`: disclosure, surgical-write, block-size,
  descriptor-victim, and honest Target Flag analysis.
- `PORTAL_FIELDS_DISCLOSURE.txt`: bounded draft for a separate disclosure
  entry.
- `SECOND_HOST_REPRODUCTION.txt`: exact independent replay registers and the
  `WnR=0` caveat.

Rebuild offline:

```sh
gunzip -k baseline_16k.img.gz

python3 apfs_btree_compact_tool.py craft \
  baseline_16k.img apfs_btree_compact_16k.rebuilt.img

python3 apfs_btree_compact_tool.py craft \
  baseline_16k.img apfs_btree_compact_16k.CODEX2.img --marker 'CODEX2!!'
```

Inspect and simulate:

```sh
python3 apfs_btree_compact_tool.py inspect apfs_btree_compact_16k.CODEX2.img
```

Current packaged-file hashes are in `SHA256SUMS.txt`.

## Exact crafted node

The current root+leaf fs-tree is virtual OID `0x404`, physical block `0x59`,
with B-tree flags `0x42` (`BTREE_KV_NONALIGNED` is set). The crafter:

- expands the TOC from four to seven entries;
- adds three unreferenced high-OID inode keys, preserving key order;
- gives those entries `(val_off,val_len)` values
  `(0x2000,0x1800)`, `(0x2800,0x1800)`, and `(0x3000,0x1800)`;
- fills the union of all three in-node source spans with `APFSVAL!`;
- sets `btn_free_space.len=0`;
- sets both free-list lengths to `0x3000` so `_btree_node_has_room` succeeds;
- updates `bt_key_count`, `bt_longest_val`, and the node Fletcher-64.

The compact simulator, which follows `_inloc_cmp`'s ascending `val_off` order,
places the final move at:

```text
src = [node+0x0fd8, node+0x27d8)  length=0x1800
dst = [node-0x092c, node+0x0ed4)
```

Every source byte is inside the attacker-authored node. The destination begins
`0x92c` below the 16 KiB `kalloc.data` allocation.

## Rule-Zero corrections to the original note

The original `(off=0x10,len=0xf00)` example is not an in-node controlled-copy
example: its source extends `0xef0` bytes above the value-area end. Source-span
safety requires both:

```text
val_len <= val_off <= value_area_size
```

Also, this fresh fs-tree has `BTREE_KV_NONALIGNED`, so the compact pre-pass
uses raw `val_len`, not `align8(val_len)`. This recipe uses multiples of eight,
so either interpretation reaches the same sink.

## Dynamic result

On `vm378n-kasan-fresh-20260716` (release VMAPPLE kernel with `-zp`), the
crafted image mounted as uid 501 and `touch` deterministically panicked the
kernel. The direct-write replay reported:

```text
Panicked task: pid 932 touch
ESR: 0x96000047 (WnR=1)
far == x0 == 0xfffffe2fba65f6d4
Zone: data.kalloc.16384
Kind: out-of-bounds (high confidence)
x26 node base:  0xfffffe2fba660000
x22 value end:  0xfffffe2fba663fd8
x19 cumulative: 0x4904
x22 - (x19 & 0xffff) == x0 == node - 0x92c
```

KDK symbolication places the APFS return address at
`btree_node_compact + 604` (`0x25c`), immediately after the unchecked
`memmove` call at `+0x258`. Registers `x8` through `x15` contain repetitions
of the chosen `CODEX2!!` marker.

The unmodified baseline image mounted, accepted a uid 501 `touch`, and
detached cleanly.

The same control and trigger were then run as the VM's `rfbstd` account
(`uid=502`, not a member of `admin`). Its unmodified baseline mounted
read-write, accepted the file create, and detached cleanly. The crafted image
panicked in `touch`; the panic process record reports `userID: 502` and the
same `_btree_node_compact+0x25c` call site.

## Exploitability supplement

The exact-size fd-table groom from the research lane is intentionally not part
of this filing package: the fd allocation is separated/typed and is not a
useful victim. The stronger current path uses `0x1000` or `0x2000` APFS node
allocations and the plain `btn+0xd0` pointer in `APFS_BTREE_NODES`. See
`DISCLOSURE_AND_EXPLOITABILITY.md` for the placement gate and claim boundary.

## Disposable VM only

Decompress and copy only `apfs_btree_compact_16k_CODEX2.img` into the
disposable VM. As uid 501:

```sh
hdiutil attach /Users/testtest/apfs_btree_compact_16k_CODEX2.img
touch /Volumes/CODEXBTREE/CODEX_TRIGGER
```

If the VM survives, detach the device printed by `hdiutil`. Preserve the KASAN
panic and check for `_btree_node_compact` / `memmove` plus the `APFSVAL!`
destination bytes. Do not run these commands on the host.
