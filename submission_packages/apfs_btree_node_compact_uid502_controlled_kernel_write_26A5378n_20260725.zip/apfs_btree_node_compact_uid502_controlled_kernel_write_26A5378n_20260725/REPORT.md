# APFS `_btree_node_compact` kernel heap write and disclosure

## Verdict

On macOS 27 beta `26A5378n`, a standard local account that is not a member of
`admin` can attach a crafted APFS image and trigger kernel memory corruption
with an ordinary file create.

The primary panic is a direct write data abort from APFS's unchecked
`memmove`. The destination is exactly the static formula applied to the live
attacker-derived registers and lands `0x92c` below a 16 KiB APFS node in
`data.kalloc.16384`.

The same missing validation also provides a separate disclosure primitive:
with a deep on-disk `val_off` and a small value length, the same `memmove`
copies kernel-heap data from a source tens of kilobytes below the node into the
node, then rewrites the TOC to make the copied bytes the entry's ordinary
value. An xattr or symlink value can therefore return those bytes to the
mounting user through `getxattr` or `readlink`.

The dynamically confirmed claim is an attacker-content relative kernel heap
write and an LPE primitive. The disclosure and dedicated-APFS-zone
arbitrary-R/W chain below are static exploitability results; the package does
not contain an end-to-end disclosure image, arbitrary-address write panic,
Target Flag capture, or completed code execution. These boundaries are
intentional.

## Affected build

- macOS 27.0 beta, build `26A5378n`
- XNU `13432.0.50.501.3~1`, `RELEASE_ARM64_VMAPPLE`
- `com.apple.filesystems.apfs` 3283.0.9
- UUID `0B78B9C5-7C51-3BC9-8B6D-14BC20CE5DD0`

The unbounded value pass is also present in the inspected 26A5353q,
26A5368g, and 26A5378j kernelcaches.

## Root cause

`_btree_node_compact` first creates and sorts temporary records containing
the raw per-entry value offset and value length. Its value-area pass is:

```text
+0x214  ldrh w8, [x23, #2]       ; val_off
+0x218  cmp   x8, x28            ; x28 = 0xfffd
+0x21c  b.hi  +0x294             ; only bound in the loop
+0x220  ldrh w2, [x23, #4]       ; val_len
+0x224  add   w19, w2, w19       ; cumulative += val_len
+0x228  sub   x9, x25, w19, uxth
+0x22c  add   x0, x22, x9        ; dst = value_end - cumulative16
+0x240  sub   x8, x25, x8
+0x244  add   x1, x22, x8        ; src = value_end - val_off
+0x258  bl    memmove
```

### Two-sided operand audit

For `memmove(dst, src, len)`:

1. `val_off` is checked only against the global constant `0xfffd`.
2. `val_len` has no comparison in this pass.
3. `sum(val_len)` has no comparison to the current node's value-area span.
4. The destination changes width from a 32-bit cumulative sum to `UXTH`.
5. No instruction checks that the destination remains at or above the node.
6. The crafted image separately satisfies
   `val_len <= val_off <= value_area_size`, so each source span remains inside
   the attacker-authored node.

APFS has a correct `_btree_node_val_range_validate` helper for other
operations, but `_btree_node_compact` does not call it. The key pass in the
same function performs a bounded pre-sum; the value pass does not.

## Direct kernel-heap disclosure

The write panic uses in-node sources and an out-of-node destination. Reversing
those parameters produces an independent information disclosure from the same
unchecked sink:

```text
small cumulative value length  => dst = val_area_end - cumulative, inside node
deep val_off, e.g. 0xf000       => src = val_area_end - val_off, far below node
small val_len                   => memmove copies OOB heap bytes into node
```

For small nodes, the allowed 16-bit offset range provides roughly 57-61 kB of
backward reach (about 56-60 KiB), depending on the exact `val_off` and node
layout. The bytes returned by one entry are exactly its `val_len`; the total
copied into a node cannot exceed the available in-node destination area.
Multiple crafted entries or queries can sample different positions in the
backward window. The only loop comparison remains the global:

```text
0xfffffe000b86c5a8  cmp  x8, x28       ; x8=val_off, x28=0xfffd
0xfffffe000b86c5ac  b.hi 0xfffffe000b86c624
```

There is no comparison to the current value-area span before:

```text
0xfffffe000b86c5d0  sub  x8, x25, x8
0xfffffe000b86c5d4  add  x1, x22, x8   ; src = val_area_end - val_off
0xfffffe000b86c5e8  bl   memmove
```

After the copy, compaction deliberately rewrites the selected entry to its new
in-node location:

```text
0xfffffe000b86c610  strh w19, [x8, #4] ; new val_off = cumulative
0xfffffe000b86c614  strh w0,  [x8, #6] ; preserved/new val_len
```

The ordinary lookup path then calls `_btree_node_val_range_validate` and
returns `val_area_end - new_val_off`. Because the rewritten range is now
inside the node, it passes. `apfs_vnop_getxattr`
(`0xfffffe000b7c9950`) and `apfs_vnop_readlink`
(`0xfffffe000b7e0c44`) provide userspace copyout surfaces for a crafted xattr
or symlink record. This is a direct disclosure path, not merely a kernel read
that faults without returning data.

The disclosure recipe has not yet been packaged as a separate ready-to-run
image, so this section records a static end-to-end primitive rather than a
dynamic leak capture.

## Crafted node

The image uses a valid 16 KiB APFS container. This block size makes the node
a `data.kalloc.16384` object. The fresh root+leaf fs-tree is extended from
four entries to seven with three high, otherwise-unreferenced inode keys.
Their value pairs are:

```text
(val_off=0x2000, val_len=0x1800)
(val_off=0x2800, val_len=0x1800)
(val_off=0x3000, val_len=0x1800)
```

All three sources are inside the node and filled with repetitions of the
chosen eight-byte marker. The node Fletcher-64 is recomputed. The free-space
fields force compaction during the next fs-tree insertion.

The supplied simulator calculates the final move as:

```text
source      = [node+0x0fd8, node+0x27d8)
destination = [node-0x092c, node+0x0ed4)
length      = 0x1800
```

## Direct-write panic

Primary artifact:
`panic-full-2026-07-25-114539.0002.panic`

```text
Panicked process: touch
ESR = 0x96000047                    WnR=1, write fault
FAR = 0xfffffe2fba65f6d4
x0  = 0xfffffe2fba65f6d4           memmove destination
x19 = 0x4904                       cumulative value length
x22 = 0xfffffe2fba663fd8           value-area end
x26 = 0xfffffe2fba660000           node base
```

The live register formula is exact:

```text
x22 - (x19 & 0xffff) = 0xfffffe2fba65f6d4 = FAR = x0
x26 - x0 = 0x92c
```

GZAlloc reports:

```text
Zone    : data.kalloc.16384
Kind    : out-of-bounds (high confidence)
```

KDK symbolication places the PAC-stripped APFS return address at:

```text
btree_node_compact + 604            ; +0x25c
btree_node_insert_internal + 380
bt_insert + 5756
create_or_modify_jobj + 1572
insert_jobj + 448
fs_obj_create_name_checked + 536
fs_obj_create_do + 372
apfs_vnop_create + 1000
```

`+0x25c` is immediately after the `memmove` call at `+0x258`.

## Attacker-content control

The direct-write image uses marker `CODEX2!!`. At the fault:

```text
x8-x11  = 0x2121325845444f43
x12-x15 = 0x45444f4321213258
```

These are overlapping repetitions of the selected marker. A separate image
using `APFSVAL!` produced the same APFS call chain and `VAL!` in `x24`.
Changing the image marker therefore changes the data propagated through the
corrupting operation.

## Surgical single-write construction

The wide write in the bundled image is not intrinsic. The temporary records
are sorted by ascending `val_off` by `_inloc_cmp`
(`0xfffffe000b86cb28`). For each walk-down entry, set `val_off_i` equal to the
post-add cumulative length `cum_i`. The sink then computes:

```text
src = val_area_end - val_off_i
dst = val_area_end - cum_i
src == dst
```

The `memmove` is a self-copy and changes no bytes, while cumulative length and
therefore the eventual destination continue walking downward. A final entry
can perform the only non-self move at the selected displacement. This removes
the need for a broad preparatory smear and leaves only the final move's
overhang beyond the intended victim.

## Block-size control

APFS does not require a power-of-two container block size. On this build,
`_nx_check_superblock` enforces the lower bound at
`0xfffffe000b78d754-0xfffffe000b78d758` and rejects values above `0x10000`
later in the same validation, while `_nx_mount` checks divisibility by the
device block size at:

```text
0xfffffe000b883d68  udiv w8, w20, w21
0xfffffe000b883d6c  msub w8, w8, w21, w20
0xfffffe000b883d74  cbnz w8, reject
```

It also checks that the APFS block size is at least the device logical block
size. With a 512-byte-logical image, every multiple of 512 from `0x1000`
through `0x10000` is therefore selectable. `_apfs_obj_zalloc`
(`0xfffffe000b77cc1c`) special-cases exactly `0x1000` and `0x2000`; other
sizes use the generic data allocator through `0x8000`, and larger values use
the large-allocation path. There is no `data.kalloc.65536` zone.

## Dedicated-zone arbitrary-R/W path

Generic `data.kalloc` block sizes remain report-grade on current evidence. A
sweep of 588 base-kernel `KHEAP_DATA_BUFFERS` allocation sites and 922
`KT_DATA_ONLY` views found no surviving pointer/length/index victim in
`data.kalloc.[4096..32768]`. The examined fd table, ipc_kmsg, pipe,
OSData/OSString, sysctl staging, vm_map_copy, mbuf, icmp6_filter, NECP, and
allocator-metadata routes were either separated, authenticated, bounded, or
not useful for pointer control.

The `0x1000` and `0x2000` block sizes instead use dedicated APFS object zones.
That creates a concrete victim: the `0x108`-byte btree-node descriptor from
`APFS_BTREE_NODES`, allocated at
`0xfffffe000b88f06c-0xfffffe000b88f074` and freed through
`0xfffffe000b88a184`.

The descriptor field at `btn+0xd0` is the value-area end pointer. It is stored
with an ordinary unauthenticated `str` at
`_btree_node_init_ext+0x2e0` (`0xfffffe000b866298`). APFS contains no
`zone_require` use protecting this cross-zone corruption path.

Corrupting `btn+0xd0` relocates the relevant sinks:

1. `_btree_node_insert_internal` loads it at `0xfffffe000b86bf44` and derives
   the destination as `btn->val_area_end - val_off`; its source is the live
   insertion value in `x25` and its length is `w21`. A chosen pointer and
   offset therefore give a controlled-content arbitrary-address write.
   `_btree_node_compact` also loads the field at `0xfffffe000b86c580`, but
   compact derives both source and destination from the same corrupted base,
   so compact alone is an arbitrary relative copy rather than the clean
   write-what-where sink.
2. `_btree_node_val_ptr` first validates the on-disk offset/length, then loads
   the same plain pointer at `0xfffffe000b865dd8` and subtracts the value
   offset. A corrupted pointer therefore yields an arbitrary read which
   `getxattr` or `readlink` can return to userspace.

The direct disclosure supplies the kernel-pointer discovery step for this
chain. The remaining placement gate is probabilistic: the six APFS zones lack
`ZC_DATA`, so each receives an independently boot-random GEN submap and bump
direction. The estimated chance that `APFS_8K_OBJS` and
`APFS_BTREE_NODES` co-reside in a reachable orientation is approximately
`1/8` per boot. A disclosure can detect a nearby descriptor signature, and a
failed layout can be rerolled by rebooting.

The best analyzed variant is a `0x2000` APFS block size, whose node comes from
`APFS_8K_OBJS`. On the tested configuration the normal 4096-byte root
container does not populate that zone, and the backward reach is
`0xdff8` (57,336 bytes). This establishes a static path to a write with
`FAR == ASB_TARGET_KERN_ADDRESS` and a read of the target value, but neither
operation is claimed as dynamically captured in this package.

## Sibling-sink comparison

The omission is specific to compaction's pass over existing on-disk entries.
`_btree_node_remove` calls `_btree_node_val_range_validate` at
`0xfffffe000b86d540` before its `btn+0xd0` use at
`0xfffffe000b86d56c`. `_btree_node_entry_update` calls the validator at
`0xfffffe000b86b370` before its corresponding value move at
`0xfffffe000b86ba24`. `_btree_node_insert_internal` operates on live insertion
inputs and gates aggregate room at `0xfffffe000b86bbf0`, with per-allocation
free-space checks before its `btn+0xd0` sink at
`0xfffffe000b86bf44`. Those checks defend normal insertion lengths but do not
authenticate a previously corrupted `btn+0xd0`, which is why the same sink
supplies the follow-on arbitrary write.

Therefore the report should say that compaction is the only analyzed
existing-entry move missing the per-node value-range invariant; it should not
say that every sibling literally calls the same helper.

## Non-admin reachability

The VM account used for the non-admin run is:

```text
uid=502(rfbstd) gid=20(staff)
user is not a member of the group admin
```

The unmodified control image mounted read-write as this user, accepted a file
create owned by uid 502, and detached cleanly. The crafted image produced
`panic-full-2026-07-25-115202.0002.panic`. Its process record is:

```json
{"userID":502,"groupID":20,"procname":"touch","pid":1060}
```

That panic independently has APFS in the backtrace and symbolizes to
`_btree_node_compact+0x25c`.

## Independent second-machine reproduction

A separate stopped 26A5378n VM was cloned on a second machine and the same
`CODEX2` image was run as uid 501. The baseline mounted and accepted `touch`;
the crafted image panicked. Its independent registers were:

```text
ESR = 0x96000007                    WnR=0, read fault
FAR = 0xfffffe31abd60000
x0  = 0xfffffe31abd46d3e
x19 = 0x1d29a
x22 = 0xfffffe31abd53fd8
x26 = 0xfffffe31abd50000
Zone: data.kalloc.16384, out-of-bounds (high confidence)
```

The destination formula independently matches:

```text
x22 - (x19 & 0xffff) = 0xfffffe31abd46d3e = x0
x26 - x0 = 0x92c2
```

This is a source-side read fault at `node_base+0x10000`, not a write panic.
It is included only as a second-host reproduction with a different cumulative
value and an exact destination-formula match. The bundled
`0x96000047` panic remains the direct-write evidence.

## Reproduction

Use a disposable machine or VM. Do not attach the crafted image to a
production host.

```sh
gunzip apfs_btree_compact_16k_CODEX2.img.gz
hdiutil attach ./apfs_btree_compact_16k_CODEX2.img
touch /Volumes/CODEXBTREE/TRIGGER
```

The image mounts successfully. The `touch` triggers compaction and the
kernel panic.

For the negative control:

```sh
gunzip baseline_16k.img.gz
hdiutil attach ./baseline_16k.img
touch /Volumes/CODEXBTREE/CONTROL
hdiutil detach <container-device-from-hdiutil>
```

The supplied Python tool rebuilds and inspects both images offline.

`DISCLOSURE_AND_EXPLOITABILITY.md` records the disclosure recipe, surgical
move, block-size matrix, dedicated-zone victim, and evidence boundaries.
`PORTAL_FIELDS_DISCLOSURE.txt` is a draft second-entry summary; it should be
filed separately only if Apple accepts the static return-to-userspace chain or
after a dedicated disclosure image/readback transcript is added.

## Mitigation

Before the value pass moves any entry:

1. Validate every `(val_off, val_len)` against the current value-area size.
2. Accumulate value lengths in a non-truncating type with checked addition.
3. Reject if the cumulative length exceeds the node value-area span.
4. Verify the computed source and destination spans are contained in the
   node allocation.

Calling the existing per-entry value-range validator is necessary but not
sufficient; the aggregate cumulative bound must also be enforced.
