# ActiveDirectory CLDAP label stack-vector candidate - negative static review

Date: 2026-06-12T0237Z
Binary: `/System/Library/OpenDirectory/Modules/ActiveDirectory.bundle/Contents/MacOS/ActiveDirectory`
Copied evidence binary:
`static_evidence/ActiveDirectory`

## Bottom line

This looked like another canary-adjacent stack-vector bug during the indexed
store scan, but manual review says it is bounded. Do not treat it as a current
submission candidate.

The suspicious store is in the CLDAP site-discovery response parser:

```text
15be4  add x8, sp, #0x50
15be8  str x27, [x8, w24, sxtw #3]
15bec  add w24, w24, #0x1
```

The stack frame has an 8-qword vector at `sp+0x50..sp+0x8f` and the saved
stack guard at `sp+0x90`:

```text
15a7c  sub sp, sp, #0x100
15a98  add x29, sp, #0xf0
15aac  stur stack_guard, [x29, #-0x60]  ; sp+0x90
15acc  stp q0, q0, [sp, #0x70]
15ad0  stp q0, q0, [sp, #0x50]         ; 64-byte vector
```

At first glance, `vector[8]` would land on the stack guard. The key correction
is that `w24` is the accumulated output-string count for the outer loop, not
the DNS label count inside one compressed name. The outer loop is capped:

```text
15afc  mov w28, #0x1
...
15b40  str w24, [sp, #0x34]     ; save accumulated vector count
15b48  mov w24, #0x0            ; reuse w24 as current string length
...
15be0  ldr w24, [sp, #0x34]     ; restore accumulated vector count
15be8  str x27, [sp+0x50 + w24*8]
15bec  add w24, w24, #0x1
...
15d20  add w28, w28, #0x1
15d24  cmp w28, #0x9
15d28  b.ne 0x15b18
```

With successful parsing, the stores are indexes `0..7`; after the eighth store,
`w28` becomes `9` and the loop exits. Error paths restore the prior accumulated
count and do not create a path to index `8`.

## Reachability signal that caused the review

The path is still useful context for future CLDAP research because it is rooted
in Active Directory site discovery:

```text
locating site using domain %{public}@ using CLDAP
_ldap_connection_query_create
func.00015a78 callback
Error decompressing CLDAP result - %d
using site of '%{public}s' from CLDAP
```

But the specific stack-vector overwrite candidate is negative on static review.

## Files

```text
static_evidence/ActiveDirectory
static_evidence/cldap_decompress_label_disasm.txt
static_evidence/cldap_site_discovery_caller_disasm.txt
static_evidence/relevant_strings.txt
```
