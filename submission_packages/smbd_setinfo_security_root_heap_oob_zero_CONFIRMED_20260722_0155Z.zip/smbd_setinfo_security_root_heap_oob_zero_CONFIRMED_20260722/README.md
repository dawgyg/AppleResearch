# smbd SMB2 SET_INFO(Security) root heap OOB zero-write

## Summary

On macOS 27 beta 26A5378n, a remote SMB client can supply a self-relative
security descriptor whose SACL and DACL offsets alias the same wire ACL. Apple
`smbd` allocates a native output buffer from the wire input byte length, but
`ConvertWireSecurityDescriptorToSecurityDescriptor` computes its destination
end as if that length were a count of 40-byte native descriptors. Each aliased
ACL is then independently initialized into consecutive destination space.

The included guest-session reproducer causes root `smbd`, launched with Apple's
Guard Malloc, to write through the end of the output allocation and crash in
`_platform_memset -> InitializeAcl`.

## Impact boundary

- Process: `/usr/sbin/smbd`, running as root.
- Trigger: remote SMB2 `SET_INFO`, `InfoType=3` (security).
- Demonstrated access: passwordless guest SMB session after the administrator
  enables global SMB guest access and guest access on a writable share.
- General access: any SMB account able to obtain a file handle reaches the
  conversion before the backend security operation.
- Primitive: attacker-sized linear heap zero-write past an output allocation.
- Stock allocator: the malformed request returns `STATUS_NOT_SUPPORTED` on the
  observed layout after silently completing conversion; no stock crash is
  claimed.
- Guard Malloc: deterministic native root-daemon `EXC_BAD_ACCESS` with the
  complete vulnerable stack in the included `.ips` report.

## Reproduction

Requirements: macOS 27 beta 26A5378n test VM, File Sharing enabled, SIP disabled
for test instrumentation, Python 3, and `impacket==0.13.1` on the client.

Create a disposable guest share on the VM:

```sh
sudo sysadminctl -smbGuestAccess on
sudo mkdir -p /Users/Shared/smbtest
sudo chmod 0777 /Users/Shared/smbtest
sudo sharing -a /Users/Shared/smbtest -S smbtest -s 001 -g 001
```

Apply Guard Malloc to the next `smbd` launch, then terminate the current
instance so launchd starts the instrumented instance on the next connection:

```sh
sudo launchctl debug system/com.apple.smbd \
  --guard-malloc --malloc-stack-logging \
  --stdout /tmp/smbd_gm.out --stderr /tmp/smbd_gm.err
sudo pkill -9 -x smbd
```

Run from the client:

```sh
python3 -m pip install impacket==0.13.1
python3 smbd_setinfo_sd_overflow.py \
  --host VM_ADDRESS --share smbtest --size 0x4000 --alias-sacl
```

Expected client result:

```text
connected ... size=0x4000 alias_sacl=True
SET_INFO result: NetBIOSError: Error while reading from remote
```

Expected server result: root `smbd` exits and writes an `.ips` report under
`/Library/Logs/DiagnosticReports/`. The included report is
`smbd-2026-07-21-184635-guardmalloc-setinfo-security.ips`.

## Included files

- `smbd_setinfo_sd_overflow.py`: guest SMB2 reproducer.
- `smbd-2026-07-21-184635-guardmalloc-setinfo-security.ips`: native crash.
- `TECHNICAL_ANALYSIS.md`: operand-by-operand static and dynamic analysis.
- `SHA256SUMS.txt`: package checksums.

