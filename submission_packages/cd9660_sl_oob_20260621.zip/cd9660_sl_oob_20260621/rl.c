#include <stdio.h>
#include <unistd.h>
#include <sys/stat.h>
int main(int argc, char** argv){
  if(argc<2){fprintf(stderr,"usage: rl <path>\n");return 2;}
  char buf[4096]; for(int i=0;i<(int)sizeof buf;i++) buf[i]=0x7e; // poison so we see exactly what kernel wrote
  ssize_t n = readlink(argv[1], buf, sizeof buf);
  struct stat st; lstat(argv[1],&st);
  printf("readlink ret=%zd  lstat.st_size=%lld\n", n, (long long)st.st_size);
  if(n<0){perror("readlink");return 1;}
  for(ssize_t i=0;i<n;i++){
    if(i%16==0) printf("\n%04zx: ", i);
    printf("%02x ", (unsigned char)buf[i]);
  }
  printf("\n--- ascii ---\n");
  for(ssize_t i=0;i<n;i++){ unsigned char c=buf[i]; putchar((c>=32&&c<127)?c:'.'); }
  printf("\n");
  return 0;
}
