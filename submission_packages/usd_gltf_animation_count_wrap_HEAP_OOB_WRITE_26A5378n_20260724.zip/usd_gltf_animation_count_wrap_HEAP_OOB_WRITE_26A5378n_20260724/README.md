# Heap out-of-bounds write in Apple's glTF animation importer

## Summary

Apple's current `libusd_ms.dylib` glTF importer validates two
attacker-controlled sizes using wrapping 64-bit multiplication:

1. destination capacity: `accessor.count * expectedComponents * sizeof(float)`
2. strided source span: `(accessor.count - 1) * byteStride + elementSize`

Both expressions can wrap to a small value and pass their checks. The subsequent
conversion loop still iterates the full 64-bit `accessor.count` and advances the
destination on every iteration. A crafted animation accessor therefore writes
past a small heap allocation.

The attached 32 MiB source-buffer reproducer deterministically faults on the
destination `str s0, [x19, x12, lsl #2]` instruction. The crash report identifies
the abort as a byte-write translation fault.

## Tested environment

- macOS 27.0 beta
- Build: `26A5378n`
- Architecture: Apple silicon / arm64e
- Trigger user: uid 501
- Trigger binary: `/usr/bin/usdchecker`
- Apple library: `/usr/lib/usd/libusd_ms.dylib`
- Extracted library UUID: `B76E8AB3-96BE-3C92-A967-B481241A5627`
- Extracted library SHA-256:
  `4f876aeebf0b32a92f6276936f5291076636ceec7c1cf412b62f4e76706d0c80`

No elevated privileges or special entitlements are required.

## Reproduction

Run in a disposable VM:

```sh
cd repro
../reproduce.sh controls
../reproduce.sh embedded
../reproduce.sh write
../reproduce.sh usdz
```

Expected results:

- `controls`: both files are accepted and `usdchecker` exits normally.
- `embedded`: `usdchecker` receives `SIGBUS`; the source load eventually faults
  after prior out-of-bounds destination writes.
- `write`: creates a sparse 32 MiB source buffer, then `usdchecker` receives
  `SIGBUS` on the destination store itself.
- `usdz`: the USDZ root layer resolves `payload.gltf` and reaches the same
  vulnerable glTF importer.

The sparse 32 MiB payload is generated locally and is intentionally omitted from
the archive.

## Differential controls

`animation_count_wrap_benign.gltf` uses the same animation layout and strides
with `count = 1`; it succeeds.

`animation_count_wrap_contiguous_control.gltf` uses the malicious
`count = 2^62 + 1` but omits `byteStride`; it succeeds. This demonstrates that
the parser accepts the full 64-bit count and that the strided conversion path is
the condition that exposes the wrapped checks.

## Dynamic evidence

`evidence/usdchecker-2026-07-24-132455.ips` is the strongest report:

- `EXC_BAD_ACCESS / SIGBUS`
- `KERN_PROTECTION_FAILURE`
- ESR: `(Data Abort) byte write Translation fault`
- frame:
  `adobe::usd::readAccessorDataToFloat(...)+2180`
- exact instruction:
  `str s0, [x19, x12, lsl #2]`
- `x8 = 0x4000000000000001` (`2^62 + 1`, attacker count)
- `x9 = 8` (attacker stride)
- `x20 = 1` (destination components)
- `x21 = 4` (destination byte capacity)
- `x23 = 0x02000000` (32 MiB source buffer)
- `x24 = 4` (wrapped required source span)
- `x25 = 4` (component size)
- `far = x19` (the destination pointer)

`evidence/usdchecker-2026-07-24-132246.ips` is the compact embedded-buffer
reproducer. It faults at the adjacent source load after the loop has already
performed out-of-bounds destination stores.

`evidence/usdchecker-2026-07-24-132929.ips` shows that a USDZ root layer
referencing the malicious glTF asset reaches the same vulnerable importer.

## Root cause

The crafted input uses:

```text
accessor.count = 0x4000000000000001
input expectedComponents = 1
input componentSize = 4
input byteStride = 8
```

The destination check computes:

```text
(count * 1) << 2
= (0x4000000000000001 << 2) mod 2^64
= 4
```

The strided source check computes:

```text
(count - 1) * 8 + 4
= (0x4000000000000000 * 8 + 4) mod 2^64
= 4
```

Both checks therefore accept a one-float destination and a tiny source span.
The loop termination compares against the original full-width count and writes
one float per iteration.

See `STATIC_ANALYSIS.md` for the exact current-build instructions and the
per-operand bounds analysis.

## Fix

Validate using division before multiplication:

```cpp
if (componentCount != 0 &&
    accessor.count > destinationFloatCount / componentCount) {
    return;
}
```

The source-span calculation also needs checked multiply/add operations, or
equivalent division-form validation, before pointer arithmetic.

Adobe's upstream `2026.07` release contains this division-form destination check
and explicitly notes that direct multiplication can wrap while the conversion
loop still iterates the real `accessor.count`. Apple's current `26A5378n`
binary instead contains the vulnerable multiplication-form check.

## Prior-fix relationship

ZDI-25-687 / CVE-2025-31281 publicly identifies
`readAccessorDataToFloat` as an out-of-bounds-read site. A public Apple binary
diff from the 2025 macOS 26 beta cycle shows the function changing from three
arguments to the five-argument form still present in `26A5378n`. The added
destination-capacity check is multiplication-form and can be bypassed by this
report's count.

This therefore appears to be an incomplete arithmetic fix in the same function,
with a current heap-write manifestation rather than the previously described
read. The broad public description of ZDI-26-314 / CVE-2026-28940 also covers a
USD out-of-bounds write but does not identify a function, so relation to that
case cannot be conclusively determined from public information.

Adobe's exact division-form repair was published in the upstream `2026.07`
release on 2026-07-17. The current Apple beta tested here was still vulnerable
on 2026-07-24.

## Impact

This is deterministic attacker-controlled heap memory corruption in an Apple
file-format parser reachable by an unprivileged local process. A `.usdz` asset
can resolve the malicious `.gltf` layer and reach the same parser. Code
execution and automatic Finder/Quick Look invocation are not claimed by this
package.
