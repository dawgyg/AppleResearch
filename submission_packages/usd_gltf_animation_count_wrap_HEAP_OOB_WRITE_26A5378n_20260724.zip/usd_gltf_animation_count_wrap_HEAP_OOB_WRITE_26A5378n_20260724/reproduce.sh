#!/bin/sh
set -u

SCRIPT_DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
REPRO_DIR="$SCRIPT_DIR/repro"
USDCHECKER=/usr/bin/usdchecker

if [ ! -x "$USDCHECKER" ]; then
    echo "missing $USDCHECKER" >&2
    exit 1
fi

run_case()
{
    label=$1
    file=$2
    echo "=== $label ==="
    "$USDCHECKER" "$file"
    status=$?
    echo "exit=$status"
    return 0
}

case "${1:-}" in
    controls)
        run_case benign "$REPRO_DIR/animation_count_wrap_benign.gltf"
        run_case huge-count-contiguous \
            "$REPRO_DIR/animation_count_wrap_contiguous_control.gltf"
        ;;
    embedded)
        run_case embedded-crash \
            "$REPRO_DIR/animation_count_wrap_2p62_plus_1.gltf"
        ;;
    write)
        mkfile -n 32m "$REPRO_DIR/animation_count_wrap_32m_payload.bin"
        run_case direct-write-crash \
            "$REPRO_DIR/animation_count_wrap_32m_external.gltf"
        ;;
    usdz)
        run_case usdz-bridge "$REPRO_DIR/bridge_small.usdz"
        ;;
    *)
        echo "usage: $0 {controls|embedded|write|usdz}" >&2
        exit 2
        ;;
esac

