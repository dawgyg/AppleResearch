# Current-build static analysis

## Function

```text
adobe::usd::readAccessorDataToFloat(
    tinygltf::Model const&, int, float*, unsigned long, unsigned long)

preferred address: 0x2b3a75554
```

The following addresses are preferred addresses from the extracted current
`libusd_ms.dylib`.

## Index validation

The importer correctly validates the three vector indices:

```text
0x2b3a75588  tbnz w1, #31, ...        accessor index nonnegative
0x2b3a755c0  cmp  x10, x8
0x2b3a755c4  b.ls ...                 accessor index < accessors.size

0x2b3a755d4  ldr  w9, [x22]          accessor.bufferView
0x2b3a755d8  tbnz w9, #31, ...
0x2b3a755fc  cmp  x11, x9
0x2b3a75600  b.ls ...                 bufferView < bufferViews.size

0x2b3a7560c  ldr  w24, [x23, #0x18]  bufferView.buffer
0x2b3a75610  tbnz w24, #31, ...
0x2b3a75624  cmp  x8, x24
0x2b3a75628  b.ls ...                 buffer < buffers.size
```

These checks do not bound either arithmetic expression used by the copy loop.

## Destination-capacity gap

Inputs:

- `x20`: caller-supplied expected destination component count
- `x8`: full 64-bit attacker-controlled `accessor.count`
- `x21`: actual destination byte capacity

Check:

```text
0x2b3a75708  ldr  x8, [x22, #0x30]   attacker accessor.count
0x2b3a7570c  mul  x9, x20, x8        wrapping multiply
0x2b3a75710  cmp  x21, x9, lsl #2   wrapping shift by sizeof(float)
0x2b3a75714  b.hs 0x2b3a75870
```

Missing checks:

- no `umulh` check for `x20 * x8`
- no check that `x9 <= UINT64_MAX / 4`
- no division-form comparison of `x8` against the destination capacity

The caller separately truncates the count while sizing the vector:

```text
0x2b3a8907c  ...                      input count returned in x24
0x2b3a89094  add  w8, w24, w26       truncates count to 32 bits
0x2b3a89098  sxtw x1, w8             resize count becomes 1
0x2b3a89100  bl   0x2b3a75554        x3=1, x4=4
```

The second animation specialization has the same truncation at
`0x2b3a89264`/`0x2b3a89268`.

## Strided-source-span gap

Inputs:

- `x8`: attacker `accessor.count`
- `x9`: attacker-influenced `bufferView.byteStride`
- `x12`: component count times component size
- `x23`: source buffer size remaining

Check:

```text
0x2b3a75870  mul  x12, x27, x25
0x2b3a75874  sxtw x9, w0             ByteStride
0x2b3a7588c  mul  x13, x8, x12       contiguous span, wrapping
0x2b3a75890  sub  x14, x8, #1
0x2b3a75894  madd x14, x14, x9, x12  strided span, wrapping
0x2b3a75898  cmp  x12, x9
0x2b3a7589c  csel x24, x13, x14, eq
0x2b3a758a0  cmp  x24, x23
0x2b3a758a4  b.ls 0x2b3a75970
```

Missing checks:

- no bound for `(count - 1) * stride`
- no checked addition of the final element size
- no rejection when `count == 0` before `count - 1`
- no `umulh`, carry, or division-form validation

For the reproducer, the selected strided span wraps to `4`, so the source check
passes against both the 28-byte embedded source and the 32 MiB source.

## Write sink

The strided float loop uses the full-width attacker count:

```text
0x2b3a75dd4  ldr  s0, [x1, x12, lsl #2]
0x2b3a75dd8  str  s0, [x19, x12, lsl #2]  heap write
0x2b3a75de8  add  x12, x1, x9              source += stride
0x2b3a75dec  add  x19, x19, x20, lsl #2   destination += components*4
0x2b3a75df8  cmp  x11, x8                  compare to full attacker count
0x2b3a75dfc  b.ne ...
```

Per-sink operand accounting:

- destination base `x19`: valid vector allocation at loop entry, but the loop
  advances it without a non-wrapping total-capacity check
- component offset `x12`: bounded by the small parser-derived component count
- destination step `x20 << 2`: small semantic-derived value
- iteration bound `x8`: attacker-controlled 64-bit count, not bounded by the
  vector's truncated allocation count

The dynamic direct-write report faults at `0x2b3a75dd8`, proving that the
destination pointer has advanced beyond the heap allocation.

