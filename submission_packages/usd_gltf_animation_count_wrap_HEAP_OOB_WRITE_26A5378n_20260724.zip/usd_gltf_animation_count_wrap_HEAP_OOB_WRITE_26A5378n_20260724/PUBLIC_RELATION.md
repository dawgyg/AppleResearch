# Public-fix comparison and duplicate-risk assessment

## Exact prior function advisory

ZDI-25-687 / CVE-2025-31281:

```text
Apple macOS USD readAccessorDataToFloat Out-Of-Bounds Read
https://www.zerodayinitiative.com/advisories/ZDI-25-687/
```

The advisory was published on 2025-07-29 and names the same function. It
describes an out-of-bounds read.

A public `ipsw-diffs` comparison between macOS 26 beta builds `23A5260u` and
`23A5276f` records this ABI change:

```text
- readAccessorDataToFloat(Model const&, int, float*)
+ readAccessorDataToFloat(Model const&, int, float*, size_t, size_t)
```

Source:

```text
https://github.com/blacktop/ipsw-diffs/blob/46bf64e62e6d15aa805e4fdbda0adcba6a2d545c/26_0_23A5260u__vs_26_0_23A5276f/DYLIBS/libusd_ms.dylib.md
```

The five-argument form remains present in `26A5378n`. Its destination check is:

```text
mul x9, x20, x8
cmp x21, x9, lsl #2
b.hs accepted
```

The new reproducer bypasses this check by making the product wrap to four while
the loop compares against the original full 64-bit count. The resulting dynamic
fault is a destination heap write, not the earlier advisory's described read.

## Other public USD write advisory

ZDI-26-314 / CVE-2026-28940:

```text
Apple macOS USD File Parsing Out-Of-Bounds Write
https://www.zerodayinitiative.com/advisories/ZDI-26-314/
```

Apple lists that issue under Model I/O in the macOS Tahoe 26.5 security notes.
The public material does not disclose the function or file-format field, so
whether it covers this exact site cannot be established from public evidence.

## Upstream repair

Adobe's `USD-Fileformat-plugins` tag `2026.07`, published on 2026-07-17,
contains an exact division-form repair and comments describing this count-wrap
condition:

```text
commit 6441b97807a59472337f9c3d02df089d45ed1c48
https://github.com/adobe/USD-Fileformat-plugins
```

The repair rejects:

```cpp
componentCount != 0 &&
accessor.count > dstFloatCount / componentCount
```

The Apple `26A5378n` binary does not contain that repair and is dynamically
vulnerable. Because the upstream fix predates this report by seven days, this
candidate has elevated duplicate/known-issue risk even though the newest
available Apple beta remains affected.

