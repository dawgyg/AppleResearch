# Upstream comparison

Repository:

```text
https://github.com/adobe/USD-Fileformat-plugins
```

Compared revisions:

```text
2026.03  b852d27e507ffa968255a85438b791d50db3451e
2026.07  6441b97807a59472337f9c3d02df089d45ed1c48
```

The `2026.07` release was committed on 2026-07-17 and adds this check to
`gltf/src/gltf.cpp`:

```cpp
// accessor.count is an attacker-controlled size_t, so compare in division form:
// a direct accessor.count * componentCount could wrap size_t, land small, pass
// this check, and still let the conversion loop (which iterates the real
// accessor.count) overflow dst.
if (componentCount != 0 &&
    accessor.count > dstFloatCount / componentCount) {
    return;
}
```

The full local diff is included as
`adobe_2026_03_to_07_gltf_cpp.diff`.

Apple's `26A5378n` library has the expanded five-argument function, but its
check is still multiplication-form:

```text
mul x9, x20, x8
cmp x21, x9, lsl #2
b.hs accepted
```

The reproducer chooses a count for which this calculation wraps to the exact
four-byte destination capacity.

