# AppleUSBSerial selector-1 stock ASB detector (`26A428`)

Status: release-current, prepared and compile-verified only. It has not been
fired on `26A428`.

## Exact baseline

- macOS 27.0 release build: `26A428`.
- KDK DMG: `Kernel_Debug_Kit_27.0_build_26A428.dmg`.
- KDK DMG SHA-256:
  `7ce685e305d3bcee5e1d8fe9418c55c7e0bbc38075ab1841602444e9098a6efc`.
- Kext: `com.apple.driver.usb.serial`, source version `157.0.0`.
- Kext SHA-256:
  `09b6ab0e05875ad7fc368d9065fca81d9f36d04989b45822c2ae976dba469bbe`.
- Mach-O UUID: `ED41522F-5C21-38F3-8CCF-538F38BDAE01` (`arm64e`).

The exact KDK kext has:

- `AppleUSBSerialUserClient::externalMethod` at file offset `0x7b68`;
- selector-1 `memmove` at file offset `0x7d48`;
- `AppleUSBSerial::allocResources` at file offset `0x851c`;
- safe sibling `AppleUSBSerial::enqueueData` at file offset `0x9070`.

Selector 1 bounds source availability (`0x7cb8`), source offset/wrap
(`0x7cc0` through `0x7ccc`), and the output-pool index (`0x7d04`). It
never compares the resulting copy length in `w21` against the selected output
record's `0x4000` capacity before `memmove` at `0x7d48`. The same driver
computes that capacity and clamps a sibling copy with `cmp w22,w8` / `csel`
at `0x90d8` / `0x90dc`. Exact disassembly and the full Rule Zero operand
audit are included.

## Detector behavior

The detector reads both live ASB kernel qwords through
`/Users/dawgyg/flagcap/asb_read`; no target value is compiled in or accepted
on the command line. It captures a stock prefire record, opens
`AppleUSBACMData` as uid501, performs selector 0, maps client-memory type 2,
makes exactly three in-bounds `submit=0x100` pool-advance calls, captures a
second prefire record, and requires the boot UUID and both ASB qwords to
match. It then fills the `0x10000` transmit ring with alternating
`KERN_ADDRESS,KERN_VALUE` qwords and makes exactly one `submit=0x8000` call.
There is no retry or loop around that oversized call.

The runner refuses root, the wrong hostname/model/build, a VM, disabled SIP,
non-empty NVRAM or live kernel boot arguments, a missing provider, or
different same-boot ASB snapshots.

An additional one-shot arm token prevents an automatic reboot loop. The token
is created only by a separate explicit arming command and is atomically moved
into the evidence directory immediately before the oversized call. A panic at
or after the call leaves no token for a repeated invocation. Any re-arm
requires a separate manual command and fresh literal approval.

## Deliberately unexecuted commands

These commands are documentation, not authorization. The physical-host lock
still requires a new literal `go` for this exact run after the operator is
given the target, expected runtime/result, risks, stop condition, and recovery
plan.

Arm once:

```sh
ARM_APPLEUSBSERIAL_STOCK_ASB_PHYSICAL_HOST=YES ./prepare_arm_token.zsh \\
  --arm-one-AppleUSBSerial-26A428-shot-after-literal-go
```

Fire once:

```sh
RUN_APPLEUSBSERIAL_STOCK_ASB_PHYSICAL_HOST=YES ./run_stock_asb_shot.zsh \\
  --fire-live-same-boot-asb-I-accept-kernel-panic
```

If the call returns, the process retains resources for 30 seconds so the
normal consumer can run. A result is a kernel Target Flag only if a same-boot
panic has `FAR == KERN_ADDRESS`. Call it a write flag only with `WnR=1`.

The earlier `0x41` plus DTrace result is useful mechanism proof but is not
stock filing evidence. A silent stock return is a negative flag shot, not a
disproof of the statically proven controlled heap overwrite.
