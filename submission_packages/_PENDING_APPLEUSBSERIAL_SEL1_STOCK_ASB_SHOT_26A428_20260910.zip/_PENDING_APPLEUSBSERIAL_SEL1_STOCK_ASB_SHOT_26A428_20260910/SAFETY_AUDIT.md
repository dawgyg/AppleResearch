# One-shot safety audit (`26A428`)

Status: static inspection and compile/syntax verification only. Nothing in
this package was executed against IOKit while performing this audit.

## Destructive-call count

`appleusbserial_sel1_asb_shot.c` invokes selector 1 through `submit()` in two
places:

- the `SAFE_CALLS == 3` loop uses `SAFE_SUBMIT == 0x100`; these calls remain
  within the output record's `0x4000` capacity;
- one non-looping call uses `FIRE_SUBMIT == 0x8000` after every venue,
  same-boot, and arm-token check succeeds.

There is no retry, recursion, process relaunch, or loop around the oversized
call. After that single call returns, the process only logs, sleeps for 30
seconds, releases resources, and exits.

## Consumed-before-fire ordering

Immediately before the oversized call, `consume_arm_token()`:

1. requires a regular, uid-owned, mode-0600, single-link token with exact
   contents;
2. opens it with `O_NOFOLLOW` and verifies the contents;
3. atomically renames it from the package directory to
   `EVIDENCE_DIR/ARM_CONSUMED.once`;
4. `fsync()`s the consumed file, evidence directory, and token parent;
5. returns success only after those persistence operations succeed.

The oversized call occurs only after that function returns success. A panic,
reboot, terminal reconnection, runner relaunch, or automation retry therefore
finds no arm token and refuses before opening the destructive path. Re-arming
requires a separate explicit command and is never automatic.

## Pinned venue

The wrapper requires all of the following before invoking the detector:

- ordinary non-root user;
- hostname `hacker.local`;
- build `26A428`;
- model `MacBookPro18,2` and no `VirtualMac` identity;
- an attached `AppleUSBACMData` provider;
- executable `/Users/dawgyg/flagcap/asb_read`;
- the separately created one-shot token.

The detector then independently requires SIP enabled, empty NVRAM and live
boot arguments, and two identical same-boot ASB snapshots before consuming the
token. These checks are safety gates, not authorization. A fresh literal `go`
for the exact physical-host run remains mandatory.

## Verification performed

- `clang -Wall -Wextra -Werror -O2` with IOKit and CoreFoundation: pass.
- `zsh -n run_stock_asb_shot.zsh`: pass.
- `zsh -n prepare_arm_token.zsh`: pass.
- `sh -n prefire_capture.sh`: pass.
- Existing package hashes before this documentation update: pass.

