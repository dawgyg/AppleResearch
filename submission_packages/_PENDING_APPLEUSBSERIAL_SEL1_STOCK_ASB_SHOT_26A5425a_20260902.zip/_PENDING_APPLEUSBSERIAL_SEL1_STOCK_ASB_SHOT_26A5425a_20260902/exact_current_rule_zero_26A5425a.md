# AppleUSBSerial selector 1 Rule Zero audit (`26A5425a`)

Status: static exact-current revalidation only. Nothing in this directory was
fired on the physical host while preparing this update.

## Baseline

- Host build: macOS 27 `26A5425a`.
- Exact extracted kext: `com.apple.driver.usb.serial`.
- Kext SHA-256: `9212a79b54e741ad0f358f2a581538480532ac68e99f865ccadd4007da2fafb6`.
- Mach-O UUID: `90B8D9E2-FEFE-3473-ADE2-F3F9FA7F7E80`.
- Selector handler: `AppleUSBSerialUserClient::externalMethod` at
  `0xfffffe000a20e5c4`.
- Vulnerable copy call: `0xfffffe000a20e7a0`.

## Argument shape

Selector 1 accepts at least two scalar inputs and reads:

- scalar 0 (`ack`) as a 64-bit value into `x24`;
- scalar 1 (`submit`) as a 32-bit value into `w27`.

The scalar-count check is `cmp w8,#2; b.lo` at
`0xfffffe000a20e670..0xfffffe000a20e674`. The loads are at
`0xfffffe000a20e698..0xfffffe000a20e6a0`. The reproducer uses exactly two
scalar inputs and no scalar output or structure input/output.

## Sink operands and both-side checks

The sink is `memmove(x0, x1, x2)` at `0xfffffe000a20e7a0`.

### Destination (`x0`)

- The output-record array is loaded at `0xfffffe000a20e74c`.
- The rotating record index is bounded to `[0,7]` by `and x8,x10,#7` at
  `0xfffffe000a20e75c` before `ldr x23,[x9,x8,lsl #3]` at
  `0xfffffe000a20e760`.
- The selected record is checked non-null at `0xfffffe000a20e764`.
- Its byte pointer is returned in `x0` by the virtual `getBytesNoCopy` call at
  `0xfffffe000a20e768..0xfffffe000a20e78c`.
- There is no destination offset; the copy begins at the record base.

Each destination record is created in the eight-iteration output loop at
`0xfffffe000a20f1dc..0xfffffe000a20f240`. The call uses `x1=2` (output
direction) at `0xfffffe000a20f210` and `x2=1 << page_shift` at
`0xfffffe000a20f1ec..0xfffffe000a20f1f4`. On this arm64 machine that capacity
is `PAGE_SIZE == 0x4000`.

### Source (`x1`)

- The transmit-ring producer offset is masked by the ring mask at
  `0xfffffe000a20e718`.
- `ring_size - producer_offset` is computed at `0xfffffe000a20e71c`.
- `cmp w27,w8; csel w21,w27,w8,cc` at
  `0xfffffe000a20e720..0xfffffe000a20e724` limits the current chunk to bytes
  remaining before source-ring wrap.
- The ring base is loaded at `0xfffffe000a20e790..0xfffffe000a20e794`, and
  the bounded producer offset is added at `0xfffffe000a20e798`.

Thus the source pointer and current source span are bounded against the source
ring. The prior dynamic proof also mapped this uid501-writable ring as
`0x10000` bytes.

### Length (`x2`)

- Attacker `submit` is loaded into `w27` at `0xfffffe000a20e6a0`.
- Source free space is compared against the full `submit` by
  `cmp w9,w27; b.lo` at `0xfffffe000a20e710..0xfffffe000a20e714`.
- Source wrap reduces only the current chunk into `w21` at
  `0xfffffe000a20e720..0xfffffe000a20e724`.
- `w21` is passed unchanged as `x2` at `0xfffffe000a20e79c`.

## Missing bound and primitive

No instruction compares `w27` or `w21` against the selected destination
record's `0x4000` capacity. The existing checks validate source availability,
source wrap, and the pool index, but not the sibling destination span feeding
the same `memmove`.

With `submit=0x8000` and at least that much contiguous source-ring data, the
copy writes `0x4000` attacker-controlled bytes beyond the `0x4000` destination
record. On `26A5421a`, uid501 dynamic instrumentation proved those bytes
changed a distinct immediately adjacent live output record while the selector
returned. The normalized `26A5425a` allocator is identical, and selector 1 has
only two rebased internal-address literal differences; no validation,
allocation, or copy semantics changed.

This establishes persistence of the root cause in `26A5425a`. Current-build
dynamic stock qualification remains deliberately unexecuted pending literal
approval for the pinned physical-host command.
