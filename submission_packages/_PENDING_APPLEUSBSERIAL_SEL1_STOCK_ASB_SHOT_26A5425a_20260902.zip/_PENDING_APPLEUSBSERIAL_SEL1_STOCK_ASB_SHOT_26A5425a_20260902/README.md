# AppleUSBSerial selector-1 stock ASB detector (`26A5425a`)

Status: prepared and compile-verified only. It has not been fired.

The vulnerable code was revalidated against the exact current macOS 27 build
`26A5425a`. The extracted `com.apple.driver.usb.serial` has SHA-256
`9212a79b54e741ad0f358f2a581538480532ac68e99f865ccadd4007da2fafb6`.
Selector 1's sink is now at `0xfffffe000a20e7a0`; its source-availability and
source-wrap checks remain, but there is still no comparison between the copied
length and the destination record capacity. The eight destination records are
still allocated in `allocResources` with `options=2` and
`capacity=1 << page_shift`, which is `0x4000` on this machine.

The normalized `allocResources` disassembly is identical to `26A5421a`.
Selector 1 is also identical except for two internal-address literals changed
by text rebasing; neither difference touches validation, allocation, or copy
semantics. Exact-current disassembly excerpts and hashes are included here.

This preserves the original `0x41`/DTrace package as mechanism proof and adds
a separate stock-only detector. The source reads both live ASB kernel qwords
through `/Users/dawgyg/flagcap/asb_read`; no target value is compiled in or
accepted on the command line. It captures `prefire.txt`, performs selector 0,
maps client-memory type 2, makes exactly three in-bounds `submit=0x100` calls,
captures `prefire_immediate.txt`, requires the boot UUID and both ASB qwords to
match, refills the full `0x10000` ring with alternating
`KERN_ADDRESS,KERN_VALUE` qwords, and only then submits `0x8000`.

The venue gate refuses root, disabled SIP, and any non-empty NVRAM or live
kernel boot arguments. Satisfying those gates is still not permission to run:
the physical-host lock requires a new literal approval for this exact command.

After a clean stock boot on the dedicated physical research host
`hacker.local` (`MacBookPro18,2`) with the same USB CDC ACM provider attached,
the deliberately long acknowledgement is:

```sh
RUN_APPLEUSBSERIAL_STOCK_ASB_PHYSICAL_HOST=YES ./run_stock_asb_shot.zsh \
  --fire-live-same-boot-asb-I-accept-kernel-panic
```

The runner refuses any hostname, model, or build other than the pinned physical
host and `26A5425a`. It also retains the original gates requiring uid != 0,
SIP enabled, empty NVRAM/live boot arguments, a live AppleUSBACMData provider,
and two matching same-boot ASB snapshots.

If the call returns, the probe retains the resources for 30 seconds so normal
consumption can run. A result is a kernel Target Flag only if a same-boot panic
has `FAR == KERN_ADDRESS`. Call it a kernel write flag only with `WnR=1`.

Important ceiling: the already demonstrated adjacent victim is a raw USB
output-data backing allocation. Alternating ASB qwords make this shot a useful
stock detector, but they do not themselves prove that the consumer interprets
the overwritten bytes as pointers. A silent return is a negative Target Flag
shot, not a disproof of the underlying controlled heap overwrite.
