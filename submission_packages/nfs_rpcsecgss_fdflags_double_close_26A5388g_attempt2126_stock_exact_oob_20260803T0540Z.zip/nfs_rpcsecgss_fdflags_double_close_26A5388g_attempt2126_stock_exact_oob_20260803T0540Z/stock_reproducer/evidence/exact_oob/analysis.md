# Stock integrity READDIRPLUS completes the exact AES-to-DES3 MIC OOB

Date: 2026-08-03

Build: macOS 27 beta 4 `26A5388g`

Kernel: `xnu-13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE`

Pre-run boot UUID: `9C885B32-415D-4041-AEC4-6B7FB07B9D83`

Verdict: a uid501 authenticated RPCSEC_GSS client naturally completed the
exact AES-digest-12 allocation followed by a DES3-digest-20 copy on the same
reclaimed crypto-context address. The operation returned success. This is an
8-byte logical OOB write and a 4-byte physical cross-slot overwrite from the
28-byte `data.kalloc.32` MIC allocation.

## Test conditions

The run used 24 independently authenticated contexts. Context indices
`0,4,8,12,16,20` were selected before the run by the fixed rule
`index % 4 == 0`; each sent eight valid integrity READDIRPLUS DATA requests.
Every context sent one valid DES3 `CONTINUE_INIT` at delay zero. DATA delays
were `38,500 + index * 1,500` microseconds, with a 100-microsecond stagger.
The valid READDIRPLUS reply was 656,820 bytes and its HMAC input was 656,732
bytes.

The observer was passive DTrace at 100 Hz. It read and printed state only. It
did not hold, stop, signal, select, reject, or mutate any worker or kernel
state. There was no LLDB and no post-observation release oracle. DTrace may
still perturb scheduling, so the exact-OOB claim is "stock code under passive
observation." A separate no-DTrace run already proves the underlying active
HMAC UAF on the same release kernel.

All 24 clients exited normally, all expected replies were received, and the
VM did not panic:

```text
multictx_complete count=24 data_count=8 data_stagger_us=100 continue_delay_us=0 failures=0 data124=0 data20=0 continue76=6 continue100=18
multictx_data_subset stride=4 offset=0
```

## Decisive trace

```text
NATURAL_CFX_MIC_ENTRY tid=2366 cpu=0 outer=fffffe1d4e3f2200 cctx=fffffe1d4e3f2248 entry_digest=12 alloc_length=28 timestamp_ns=76587492291
NATURAL_LARGE_MBUF_ENTRY tid=2366 cpu=0 cctx=fffffe1d4e3f2248 len=656732 digest=12 timestamp_ns=76587500416
NATURAL_MBUF_DESTROY_OVERLAP cctx=fffffe1d4e3f2248 active_mbuf=1 destroy_gen=1 timestamp_ns=76587551291
MAKE_RETURN tid=2382 cpu=2 outer=fffffe1d4e3f2200 cctx=fffffe1d4e3f2248 active_mbuf=1 di=fffffe0019065df0 digest=20 make_gen=2 timestamp_ns=76587598041
NATURAL_MBUF_MAKE_OVERLAP cctx=fffffe1d4e3f2248 active_mbuf=1 make_gen=2 timestamp_ns=76587600041
NATURAL_LARGE_MBUF_RETURN tid=2366 cpu=0 cctx=fffffe1d4e3f2248 len=656732 entry_digest=12 live_digest=20 duration_ns=498584 return=0x0 timestamp_ns=76587993875
NATURAL_MBUF_DIGEST_MISMATCH tid=2366 cpu=0 cctx=fffffe1d4e3f2248 len=656732 entry_digest=12 live_digest=20 duration_ns=499917 return=0x0 timestamp_ns=76587995208
NATURAL_MBUF_CHANGED_RETURN tid=2366 cpu=0 cctx=fffffe1d4e3f2248 entry_di=fffffe0019065df0 entry_digest=12 destroy_gen=0->1 make_gen=1->2 duration_ns=501834 timestamp_ns=76587997125
NATURAL_CFX_MIC_RETURN tid=2366 cpu=0 outer=fffffe1d4e3f2200 cctx=fffffe1d4e3f2248 entry_digest=12 live_digest=20 duration_ns=511125 return=0x0 timestamp_ns=76588001166
NATURAL_CFX_MIC_OOB_COMPLETED tid=2366 cpu=0 outer=fffffe1d4e3f2200 cctx=fffffe1d4e3f2248 entry_digest=12 live_digest=20 duration_ns=511709 return=0x0 timestamp_ns=76588001750
```

The trace totals were 144 `krb5_mic_mbuf` entries and returns, 48 outer CFX
MIC entries and returns, one exact digest mismatch, one destroy overlap, one
same-address make overlap, one changed-generation return, and one completed
outer OOB tuple. No event was lost at the relevant probes.

## Rule Zero: every sink operand and both bounds

Exact KDK UUID: `E324BD2E-ABD7-3384-BFCA-6CFD1435DC72`.

### Destination allocation

`gss_krb5_cfx_get_mic_mbuf` reads the generation-1 AES digest size and fixes
the allocation length before the concurrent replacement:

```asm
0xfffffe0007511fe4  ldr  w8,[x23,#0xc0]  ; old cctx->digest_size = 12
0xfffffe0007511fe8  add  x1,x8,#0x10     ; requested capacity = 16 + 12 = 28
0xfffffe0007511fec  str  x1,[x20]        ; mic->length = 28
0xfffffe0007512004  bl   kalloc_ext       ; kalloc_data(28)
0xfffffe0007512008  str  x0,[x20,#8]     ; mic->value
```

The only size used for this allocation is the old load at `...11fe4`. There
is no retained context, generation token, or lock covering allocation through
copy. Prior direct allocator tracing on this exact build established that a
28-byte request is served by a 32-byte `data.kalloc.32` slot.

### Destination base and offset

The caller passes the allocation plus the fixed 16-byte token header:

```asm
0xfffffe0007512074  ldr  x8,[x20,#8]      ; allocation base
0xfffffe0007512084  add  x6,x8,#0x10      ; destination = base + 16
0xfffffe000751209c  bl   krb5_mic_mbuf
```

The offset is constant 16 and is valid against the original 28-byte request.
No instruction carries the original capacity into `krb5_mic_mbuf` or checks
the eventual copy extent against it.

### Source allocation

At `krb5_mic_mbuf` entry, the SHA-1 digest scratch is allocated from the
then-current `ctx->di->output_size`:

```asm
0xfffffe00075110dc  ldr  x8,[x19,#0x30]   ; ctx->di
0xfffffe00075110e0  ldr  x1,[x8]          ; di->output_size = 20
0xfffffe00075110f4  bl   kalloc_ext       ; digest scratch
0xfffffe00075110fc  mov  x21,x0            ; source base
```

There is no explicit copy-length-versus-source-capacity compare. For the
observed AES-to-DES3 transition, both algorithms use SHA-1 and the measured
scratch capacity and final copy length are 20, so the source side is valid.

### Copy length and sink

After the long mbuf walk, teardown and exact-address DES3 replacement have
completed. The function independently reloads the generation-2 digest size:

```asm
0xfffffe00075112ec  ldr  w2,[x19,#0x78]   ; new digest_size = 20
0xfffffe00075112f0  cbz  x20,0xfffffe0007511318 ; verify == NULL -> write
0xfffffe0007511318  ldr  x0,[sp]          ; destination base + 16
0xfffffe000751131c  mov  x1,x21           ; 20-byte HMAC source
0xfffffe0007511320  bl   memcpy            ; copy generation-2 length
```

There is no `cmp`/conditional branch that bounds the `w2` reload at
`...112ec` against:

- the old digest load at `...11fe4`;
- `mic->length - 16`;
- the 28-byte requested allocation capacity; or
- an unchanged context generation/type/enctype.

The write covers allocation offsets 16 through 35. Against the requested
28-byte object, offsets 28 through 35 are an 8-byte logical overrun. Against
the actual 32-byte slot, offsets 32 through 35 overwrite four bytes of the
next `data.kalloc.32` slot.

## Claim boundary

This run proves natural stock-code completion of the exact cross-generation
OOB under passive observation. It does not by itself record the four HMAC tail
bytes or choose a neighboring victim. Separate preserved runs prove that the
authenticated client can independently predict the written HMAC dword and
that the same sink can change a live adjacent ACL field to that exact value.
The clean no-DTrace stock run separately proves unaided reachability of the
active-HMAC lifetime race. Those results should be presented together, not
collapsed into a claim that this one trace alone proves an uninstrumented
chosen-value overwrite.

## Artifact hashes

```text
9c671430c23abd862c5cef041488192d7e5e404f63d716013a1efe087ae4bcca  stock_rdp_integrity_24ctx_stride4_8data_656k_stream_1.stock_hmac.dtrace.out
c091a53644c03bbc6d61919ebe018e280c13e1188ff3a40623449bc717114713  stock_rdp_integrity_24ctx_stride4_8data_656k_stream_1.stock_hmac.dtrace.stderr
c5b4df0c63bd75df163d7bbe8da83bde06abd18999e1b35f27d01bd8c35427e9  stock_rdp_integrity_24ctx_stride4_8data_656k_stream_1.stock_multictx.run.log
b5d549714db4ed3ed5297bc6057fa43f85ef3d2f5dc50c164af8f224bb6d6b90  stock_rdp_integrity_24ctx_stride4_8data_656k_stream_1.bootsessionuuid.txt
53ee94e68f590b1494a37a766b58cac0e607ddb6ce2679702de5df96704c38ea  trace_nfs_stock_mbuf_uaf_overlap.d
b88157768aa57fed77b1b86236b8953e467a23f0ab522551779ebc97da10979b  run_nfs_stock_multicontext_batch.sh
eb62d662cfb4374667129b181be28c40c54261c608aed679e313cf8d2c0ca213  run_nfs_stock_multicontext_batch_remote.sh
bd225585a443eeee9511fe0f94896b01c78673d78263772a6876c294db2f6cdb  kernel.release.vmapple
```
