#!/bin/zsh

set -u
set -o pipefail
setopt NULL_GLOB

run_id=${1:?usage: $0 run_id count base_delay_us delay_step_us [data_count [data_stagger_us]]}
count=${2:?usage: $0 run_id count base_delay_us delay_step_us [data_count [data_stagger_us]]}
base_delay_us=${3:?usage: $0 run_id count base_delay_us delay_step_us [data_count [data_stagger_us]]}
delay_step_us=${4:?usage: $0 run_id count base_delay_us delay_step_us [data_count [data_stagger_us]]}
data_count=${5:-1}
data_stagger_us=${6:-0}
continue_delay_us=${RPC_GSS_CONTINUE_DELAY_US:-0}
data_service=${RPC_GSS_DATA_SERVICE:-privacy}
data_context_stride=${RPC_GSS_DATA_CONTEXT_STRIDE:-1}
data_context_offset=${RPC_GSS_DATA_CONTEXT_OFFSET:-0}

root=/Users/testtest
prefix=${root}/${run_id}
stage_gate=${prefix}.stage.go
prearm_gate=${prefix}.prearm.go
des3_token=${root}/stock_multictx_des3.client.bin
client=${root}/rgstockctx
pids=()

cleanup()
{
	if (( ${#pids[@]} != 0 )); then
		kill ${pids[@]} 2>/dev/null || true
		for pid in ${pids[@]}; do
			wait ${pid} 2>/dev/null || true
		done
	fi
}

trap cleanup EXIT
trap 'cleanup; exit 1' HUP INT TERM

if [[ ${count} != <-> || ${base_delay_us} != <-> ||
    ${delay_step_us} != <-> || ${data_count} != <-> ||
    ${data_stagger_us} != <-> || ${continue_delay_us} != <-> ]] ||
    [[ ${data_context_stride} != <-> ||
    ${data_context_offset} != <-> ]] ||
    (( count < 1 || count > 32 ||
    data_count < 1 || data_count > 8 ||
    data_context_stride < 1 || data_context_stride > count ||
    data_context_offset >= data_context_stride ||
    base_delay_us > 1000000 || delay_step_us > 1000000 ||
    data_stagger_us > 1000000 || continue_delay_us > 1000000 ||
    base_delay_us + (count - 1) * delay_step_us +
    (data_count - 1) * data_stagger_us > 1000000 )); then
	print -u2 "invalid multicontext batch geometry"
	exit 2
fi
if [[ ${data_service} != privacy && ${data_service} != integrity ]]; then
	print -u2 "invalid RPC_GSS_DATA_SERVICE: ${data_service}"
	exit 2
fi
if [[ ! -x ${client} || ! -s ${des3_token} ]]; then
	print -u2 "missing multicontext client or DES3 token"
	exit 1
fi

rm -f ${stage_gate} ${prearm_gate} ${prefix}.*.log \
    ${prefix}.*.client.bin ${prefix}.*.server.bin \
    ${prefix}.*.data.reply.bin ${prefix}.*.continue.reply.bin

for index in $(seq 0 $((count - 1))); do
	delay=$((base_delay_us + index * delay_step_us))
	context_data_count=${data_count}
	if (( index % data_context_stride != data_context_offset )); then
		context_data_count=0
	fi
	log=${prefix}.${index}.log
	env \
	    KRB5_CONFIG=${root}/krb5-mit-beta4.conf \
	    KRB5CCNAME=FILE:${root}/mit_testtest_beta4.ccache \
	    RPC_GSS_RACE_WAIT_FILE=${stage_gate} \
	    RPC_GSS_PREARM_WAIT_FILE=${prearm_gate} \
	    RPC_GSS_RELOAD_TOKENS_AFTER_GATE=1 \
	    RPC_GSS_CONTINUE_TOKEN_FILE=${des3_token} \
	    RPC_GSS_DATA_SEQUENCE=$((100000 + index * 16)) \
	    RPC_GSS_CAPTURE_DATA_REPLY_FILE=${prefix}.${index}.data.reply.bin \
	    RPC_GSS_CAPTURE_CONTINUE_REPLY_FILE=${prefix}.${index}.continue.reply.bin \
	    RPC_GSS_DATA_DELAY_US=${delay} \
	    RPC_GSS_DATA_STAGGER_US=${data_stagger_us} \
	    RPC_GSS_SOCKET_TIMEOUT_SECONDS=8 \
	    RPC_GSS_DATA_SERVICE=${data_service} \
	    ${RPC_GSS_NFS_FH_FILE:+RPC_GSS_NFS_FH_FILE=${RPC_GSS_NFS_FH_FILE}} \
	    ${RPC_GSS_NFS_PROC:+RPC_GSS_NFS_PROC=${RPC_GSS_NFS_PROC}} \
	    ${RPC_GSS_NFS_READDIRPLUS_DIRCOUNT:+RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=${RPC_GSS_NFS_READDIRPLUS_DIRCOUNT}} \
	    ${RPC_GSS_NFS_READDIRPLUS_MAXCOUNT:+RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=${RPC_GSS_NFS_READDIRPLUS_MAXCOUNT}} \
	    ${client} 192.168.64.84 nfs@tests-virtual-machine.local \
	    ${prefix}.${index}.client.bin ${prefix}.${index}.server.bin \
	    0 ${context_data_count} 1 ${continue_delay_us} 8 >${log} 2>&1 &
	pids+=($!)
done

for attempt in $(seq 1 2400); do
	ready=$(grep -l '^race_waiting ' ${prefix}.*.log 2>/dev/null |
	    wc -l | tr -d ' ')
	if (( ready == count )); then
		break
	fi
	alive=0
	for pid in ${pids[@]}; do
		kill -0 ${pid} 2>/dev/null && (( alive++ ))
	done
	if (( alive != count )); then
		break
	fi
	sleep 0.025
done
if (( ${ready:-0} != count )); then
	print -u2 "context setup failed ready=${ready:-0}/${count}"
	for log in ${prefix}.*.log; do
		print "=== ${log} ==="
		tail -20 ${log}
	done
	exit 1
fi
print "multictx_stage_ready count=${count}"
touch ${stage_gate}

for attempt in $(seq 1 1200); do
	ready=$(grep -l '^race_prearmed_waiting ' ${prefix}.*.log \
	    2>/dev/null | wc -l | tr -d ' ')
	if (( ready == count )); then
		break
	fi
	sleep 0.025
done
if (( ${ready:-0} != count )); then
	print -u2 "context prearm failed ready=${ready:-0}/${count}"
	exit 1
fi
print "multictx_prearm_ready count=${count}"
touch ${prearm_gate}

failures=0
for pid in ${pids[@]}; do
	wait ${pid} || (( failures++ ))
done
pids=()

data124=$(grep -h 'kind=data result=0 reply_len=124' \
    ${prefix}.*.log 2>/dev/null | wc -l | tr -d ' ')
data20=$(grep -h 'kind=data result=0 reply_len=20' \
    ${prefix}.*.log 2>/dev/null | wc -l | tr -d ' ')
continue76=$(grep -h 'kind=continue result=0 reply_len=76' \
    ${prefix}.*.log 2>/dev/null | wc -l | tr -d ' ')
continue100=$(grep -h 'kind=continue result=0 reply_len=100' \
    ${prefix}.*.log 2>/dev/null | wc -l | tr -d ' ')
print "multictx_complete count=${count} data_count=${data_count} data_stagger_us=${data_stagger_us} continue_delay_us=${continue_delay_us} failures=${failures} data124=${data124} data20=${data20} continue76=${continue76} continue100=${continue100}"
print "multictx_data_subset stride=${data_context_stride} offset=${data_context_offset}"

for log in ${prefix}.*.log; do
	index=${${log:t}%.log}
	delay=$(sed -n 's/.*delay_us=\([0-9]*\) kind=data.*/\1/p' \
	    ${log} | head -1)
	data_reply=$(sed -n \
	    's/.*kind=data result=[^ ]* reply_len=\([0-9]*\).*/\1/p' \
	    ${log} | head -1)
	continue_reply=$(sed -n \
	    's/.*kind=continue result=[^ ]* reply_len=\([0-9]*\).*/\1/p' \
	    ${log} | head -1)
	print "context_result id=${index} delay_us=${delay:-missing} data_reply=${data_reply:-missing} continue_reply=${continue_reply:-missing}"
done

exit ${failures}
