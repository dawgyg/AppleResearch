#!/usr/sbin/dtrace -s

#pragma D option quiet
#pragma D option dynvarsize=32m
#pragma D option bufsize=16m

/*
 * Passive lifetime oracle for RPCSEC_GSS reply protection.  It never holds,
 * signals, writes kernel memory, or selects/rejects a worker.  A crypto_ctx is
 * embedded at +0x48 in gss_ctx_id_desc on 26A5388g.
 */

dtrace:::BEGIN
{
	destroy_gen[0] = 0;
	make_gen[0] = 0;
	active_mbuf[0] = 0;
	active_first_ts[0] = 0;
	printf("trace_begin mode=stock_mbuf_uaf_overlap\n");
}

fbt:mach_kernel:gss_krb5_cfx_get_mic_mbuf:entry
/arg1 != 0/
{
	self->stock_cfx_mic = 1;
	self->stock_cfx_outer = (uintptr_t)arg1;
	self->stock_cfx_cctx = (uintptr_t)arg1 + 0x48;
	self->stock_cfx_entry_digest =
	    *(uint32_t *)(self->stock_cfx_cctx + 0x78);
	self->stock_cfx_entry_ts = timestamp;
	@cfx_mic_entries = count();
	if (self->stock_cfx_entry_digest == 12) {
		printf("NATURAL_CFX_MIC_ENTRY tid=%d cpu=%d outer=%p cctx=%p entry_digest=12 alloc_length=28 timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cfx_outer, self->stock_cfx_cctx,
		    (uint64_t)timestamp);
	}
}

fbt:mach_kernel:krb5_mic_mbuf:entry
/arg0 != 0/
{
	self->stock_mbuf = 1;
	self->stock_cctx = (uintptr_t)arg0;
	self->stock_entry_ts = timestamp;
	self->stock_entry_di = *(uintptr_t *)(arg0 + 0x30);
	self->stock_entry_digest = *(uint32_t *)(arg0 + 0x78);
	self->stock_len = (uint64_t)arg4;
	self->stock_entry_destroy_gen = destroy_gen[(uintptr_t)arg0];
	self->stock_entry_make_gen = make_gen[(uintptr_t)arg0];
	active_mbuf[(uintptr_t)arg0]++;
	active_first_ts[(uintptr_t)arg0] =
	    active_mbuf[(uintptr_t)arg0] == 1 ? timestamp :
	    active_first_ts[(uintptr_t)arg0];
	@mbuf_entries = count();
	if (self->stock_len >= 100000) {
		printf("NATURAL_LARGE_MBUF_ENTRY tid=%d cpu=%d cctx=%p len=%llu digest=%d timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cctx, self->stock_len,
		    self->stock_entry_digest, (uint64_t)timestamp);
	}
}

fbt:com.apple.kec.corecrypto:cchmac_final:return
/self->stock_mbuf/
{
	@hmac_final_returns = count();
	if (destroy_gen[self->stock_cctx] != self->stock_entry_destroy_gen ||
	    make_gen[self->stock_cctx] != self->stock_entry_make_gen) {
		printf("MBUF_CHANGED_AT_HMAC_RETURN tid=%d cpu=%d cctx=%p entry_di=%p entry_digest=%d destroy_gen=%d->%d make_gen=%d->%d age_ns=%llu timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cctx, self->stock_entry_di,
		    self->stock_entry_digest, self->stock_entry_destroy_gen,
		    destroy_gen[self->stock_cctx], self->stock_entry_make_gen,
		    make_gen[self->stock_cctx],
		    (uint64_t)(timestamp - self->stock_entry_ts),
		    (uint64_t)timestamp);
	}
}

fbt:mach_kernel:gss_krb5_destroy_context:entry
/arg0 != 0/
{
	this->cctx = (uintptr_t)arg0 + 0x48;
	destroy_gen[this->cctx]++;
	@destroy_entries = count();
	printf("DESTROY_ENTRY tid=%d cpu=%d outer=%p cctx=%p active_mbuf=%d di=%p digest=%d active_age_ns=%llu destroy_gen=%d timestamp_ns=%llu\n",
	    tid, cpu, arg0, this->cctx, active_mbuf[this->cctx],
	    *(uintptr_t *)(this->cctx + 0x30),
	    *(uint32_t *)(this->cctx + 0x78),
	    active_mbuf[this->cctx] == 0 ? (uint64_t)0 :
	    (uint64_t)(timestamp - active_first_ts[this->cctx]),
	    destroy_gen[this->cctx], (uint64_t)timestamp);
	if (active_mbuf[this->cctx] != 0) {
		@destroy_overlaps = count();
		printf("NATURAL_MBUF_DESTROY_OVERLAP cctx=%p active_mbuf=%d destroy_gen=%d timestamp_ns=%llu\n",
		    this->cctx, active_mbuf[this->cctx],
		    destroy_gen[this->cctx], (uint64_t)timestamp);
	}
}

fbt:mach_kernel:gss_krb5_make_context:return
/arg1 != 0/
{
	this->cctx = (uintptr_t)arg1 + 0x48;
	make_gen[this->cctx]++;
	@make_returns = count();
	printf("MAKE_RETURN tid=%d cpu=%d outer=%p cctx=%p active_mbuf=%d di=%p digest=%d make_gen=%d timestamp_ns=%llu\n",
	    tid, cpu, arg1, this->cctx, active_mbuf[this->cctx],
	    *(uintptr_t *)(this->cctx + 0x30),
	    *(uint32_t *)(this->cctx + 0x78), make_gen[this->cctx],
	    (uint64_t)timestamp);
	if (active_mbuf[this->cctx] != 0) {
		@make_overlaps = count();
		printf("NATURAL_MBUF_MAKE_OVERLAP cctx=%p active_mbuf=%d make_gen=%d timestamp_ns=%llu\n",
		    this->cctx, active_mbuf[this->cctx], make_gen[this->cctx],
		    (uint64_t)timestamp);
	}
}

fbt:mach_kernel:krb5_mic_mbuf:return
/self->stock_mbuf/
{
	this->live_digest = *(uint32_t *)(self->stock_cctx + 0x78);
	@mbuf_returns = count();
	if (self->stock_len >= 100000) {
		printf("NATURAL_LARGE_MBUF_RETURN tid=%d cpu=%d cctx=%p len=%llu entry_digest=%d live_digest=%d duration_ns=%llu return=0x%llx timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cctx, self->stock_len,
		    self->stock_entry_digest, this->live_digest,
		    (uint64_t)(timestamp - self->stock_entry_ts), arg1,
		    (uint64_t)timestamp);
	}
	if (self->stock_entry_digest == 12 && this->live_digest == 20) {
		@mbuf_digest_mismatches = count();
		printf("NATURAL_MBUF_DIGEST_MISMATCH tid=%d cpu=%d cctx=%p len=%llu entry_digest=12 live_digest=20 duration_ns=%llu return=0x%llx timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cctx, self->stock_len,
		    (uint64_t)(timestamp - self->stock_entry_ts), arg1,
		    (uint64_t)timestamp);
	}
	if (destroy_gen[self->stock_cctx] != self->stock_entry_destroy_gen ||
	    make_gen[self->stock_cctx] != self->stock_entry_make_gen) {
		@changed_returns = count();
		printf("NATURAL_MBUF_CHANGED_RETURN tid=%d cpu=%d cctx=%p entry_di=%p entry_digest=%d destroy_gen=%d->%d make_gen=%d->%d duration_ns=%llu timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cctx, self->stock_entry_di,
		    self->stock_entry_digest, self->stock_entry_destroy_gen,
		    destroy_gen[self->stock_cctx], self->stock_entry_make_gen,
		    make_gen[self->stock_cctx],
		    (uint64_t)(timestamp - self->stock_entry_ts),
		    (uint64_t)timestamp);
	}
	active_mbuf[self->stock_cctx]--;
	active_first_ts[self->stock_cctx] =
	    active_mbuf[self->stock_cctx] == 0 ? (uint64_t)0 :
	    active_first_ts[self->stock_cctx];
	self->stock_mbuf = 0;
	self->stock_cctx = (uintptr_t)0;
	self->stock_entry_ts = (uint64_t)0;
	self->stock_entry_di = (uintptr_t)0;
	self->stock_entry_digest = 0;
	self->stock_len = (uint64_t)0;
	self->stock_entry_destroy_gen = 0;
	self->stock_entry_make_gen = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic_mbuf:return
/self->stock_cfx_mic/
{
	this->live_digest =
	    *(uint32_t *)(self->stock_cfx_cctx + 0x78);
	@cfx_mic_returns = count();
	if (self->stock_cfx_entry_digest == 12) {
		printf("NATURAL_CFX_MIC_RETURN tid=%d cpu=%d outer=%p cctx=%p entry_digest=12 live_digest=%d duration_ns=%llu return=0x%llx timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cfx_outer, self->stock_cfx_cctx,
		    this->live_digest,
		    (uint64_t)(timestamp - self->stock_cfx_entry_ts), arg1,
		    (uint64_t)timestamp);
	}
	if (self->stock_cfx_entry_digest == 12 && this->live_digest == 20) {
		@cfx_mic_oob_completed = count();
		printf("NATURAL_CFX_MIC_OOB_COMPLETED tid=%d cpu=%d outer=%p cctx=%p entry_digest=12 live_digest=20 duration_ns=%llu return=0x%llx timestamp_ns=%llu\n",
		    tid, cpu, self->stock_cfx_outer, self->stock_cfx_cctx,
		    (uint64_t)(timestamp - self->stock_cfx_entry_ts), arg1,
		    (uint64_t)timestamp);
	}
	self->stock_cfx_mic = 0;
	self->stock_cfx_outer = (uintptr_t)0;
	self->stock_cfx_cctx = (uintptr_t)0;
	self->stock_cfx_entry_digest = 0;
	self->stock_cfx_entry_ts = (uint64_t)0;
}

tick-60sec
{
	exit(0);
}

dtrace:::END
{
	printa("MBUF_ENTRIES %@d\n", @mbuf_entries);
	printa("MBUF_RETURNS %@d\n", @mbuf_returns);
	printa("MBUF_DIGEST_MISMATCHES %@d\n", @mbuf_digest_mismatches);
	printa("CFX_MIC_ENTRIES %@d\n", @cfx_mic_entries);
	printa("CFX_MIC_RETURNS %@d\n", @cfx_mic_returns);
	printa("CFX_MIC_OOB_COMPLETED %@d\n", @cfx_mic_oob_completed);
	printa("HMAC_FINAL_RETURNS %@d\n", @hmac_final_returns);
	printa("DESTROY_ENTRIES %@d\n", @destroy_entries);
	printa("DESTROY_OVERLAPS %@d\n", @destroy_overlaps);
	printa("MAKE_RETURNS %@d\n", @make_returns);
	printa("MAKE_OVERLAPS %@d\n", @make_overlaps);
	printa("CHANGED_RETURNS %@d\n", @changed_returns);
	printf("trace_end mode=stock_mbuf_uaf_overlap\n");
}
