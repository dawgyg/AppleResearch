# Integrity 24x2 stock race: active HMAC context UAF

## Identity

- Build: macOS 27 beta 4 `26A5388g`
- Kernel UUID: `E324BD2E-ABD7-3384-BFCA-6CFD1435DC72`
- Pre-panic boot UUID: `15387270-FE10-4153-B370-A5ABF028C7A5`
- Post-panic boot UUID: `5CE6E25D-3E70-4465-81D4-0EC7F7CD7073`
- Panicked task: root `nfsd`, pid 330, tid 2142

## Trigger

Twenty-four authenticated uid501 RPCSEC_GSS contexts were prearmed. Each sent
two valid integrity-protected NFSv3 READDIRPLUS requests, staggered by 500 us,
at base delays 39,000 us through 73,500 us. Each context concurrently sent a
valid DES3 CONTINUE_INIT at delay zero. The READDIRPLUS result was configured
for a valid 524 KiB reply.

A passive DTrace observer was active at 100 Hz. It did not hold, signal,
select, reject, or modify any kernel state. The VM panicked immediately after
`multictx_prearm_ready count=24`; the trace output did not survive the reboot.

## Fault

```text
Kernel data abort
runtime pc = 0xfffffe002f0b12f8
FAR = 0x8
ESR = 0x96000006
x0 = 0
```

For this boot, the effective executable relocation is:

```text
0x27728000 (panic Kernel text exec slide) - 0x2f8000 = 0x27430000
```

Exact KDK symbolication against `kernel.release.vmapple` gives:

```text
0xfffffe0007c812f8  ccdigest_update + 48
0xfffffe0007c81a98  cchmac_update + 24
0xfffffe00075112b4  krb5_mic_mbuf + 560
0xfffffe00075120a0  gss_krb5_cfx_get_mic_mbuf + 284
0xfffffe0007513fb8  gss_krb5_get_mic_mbuf + 276
0xfffffe00074f3180  nfs_gss_svc_protect_reply + 136
0xfffffe00074efde8  nfssvc_nfsd + 2332
0xfffffe00074eec4c  nfssvc + 208
```

`ccdigest_update+48` is `ldp x8, x9, [x0, #8]`; x0 was NULL. The caller is
the trailer `cchmac_update(ctx->di, ...)` at `gss_krb5_mech.c:697`. Thus the
concurrent CONTINUE teardown cleared/freed the raw crypto context while the
large reply HMAC still consumed it.

## Bounded conclusion

This independently proves integrity-mode stock reachability of the active
HMAC use-after-free. It is not the exact 28-byte allocation / 36-byte final
copy proof: this invocation faulted at the earlier trailer update before
`cchmac_final` and the final `memcpy` at line 710.

The next timing change is to send DATA slightly earlier so a same-slot DES3
replacement completes before the trailer reload. If allocation generation
read digest 12 and the final copy generation reads digest 20, the MIC buffer is
28 bytes while `memcpy(mic, digest, 20)` writes through byte 35, four bytes
past its physical `data.kalloc.32` slot.

## Hashes

```text
5511fcb852def6f3f957622365b5629d90d820315f7fd4de673239978243aa41  panic-full-2026-07-30-234012.0002.panic
4d849b6743dd7eec0b1fc0aa0a98c5ead1cd3950abacedeeb74dc9a8c42efba2  ../stock_rdp_integrity_24x2_shift19ms_2.stock_multictx.run.log
fd52f959a25a9394a3143b90d698dad4f4973203f6c88a76a32b67d00e04046a  ../stock_rdp_integrity_24x2_shift19ms_2.bootsessionuuid.txt
```
