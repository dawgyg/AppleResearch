# Stock active-HMAC UAF and exact MIC-OOB reproducer

This directory contains the exact uid501 clients, scheduler, and evidence for
the active-HMAC use-after-free and successful cross-generation MIC overwrite
on macOS 27 beta 4 `26A5388g`. The strongest lifetime reproduction used no
DTrace process, debugger, signal, timing hold, userspace release oracle, or
kernel mutation. A separate passive-observation run records the exact
digest-12 allocation to digest-20 `memcpy` returning success.

## Result

Twenty-four unprivileged RPCSEC_GSS clients race valid protected NFSv3
READDIRPLUS replies against valid CONTINUE_INIT messages on their completed
contexts. The large reply keeps `krb5_mic_mbuf` active while another request
destroys the raw GSS crypto context. The kernel then calls:

```text
cchmac_final(di=NULL, ...)
```

and faults at `ldr x8, [x0, #8]`, `FAR 0x8`, in task `nfsd`.

## Preconditions

- macOS 27 beta 4 `26A5388g` NFS server;
- an export permitting `krb5p`, `krb5i`, and `krb5`;
- a non-root user with valid AES and DES3 Kerberos credentials for the NFS
  service; and
- a directory large enough for a roughly 524 KB READDIRPLUS reply.

`source/example_exports` shows the test export. Kerberos ccaches are
intentionally not packaged because they contain lab credentials.

## Exact no-DTrace UAF run

The preserved VM used the source and binary under `source/`. The host wrapper
is lab-path-specific but records the exact invocation:

```sh
RPC_GSS_STOCK_ENABLE_TRACE=0 \
RPC_GSS_STOCK_CLIENT_NAME=rpc_gss_crypto_race_readdirplus \
RPC_GSS_NFS_FH_FILE=export-root.vm84.fh \
RPC_GSS_NFS_PROC=readdirplus \
RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=524288 \
RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=524288 \
RPC_GSS_CONTINUE_DELAY_US=0 \
./run_nfs_stock_multicontext_batch.sh \
  stock_rdp_24x2_shift19ms_notrace_1 24 39000 1500 2 500
```

The file handle under `evidence/` belongs only to the preserved test export;
compile `source/fetch_mountd_fh3.c` and run it as root to obtain the
corresponding handle on a new setup. The test server rejects unprivileged
mountd clients as having credentials that are too weak.

## Exact OOB-completion run

The successful integrity-mode run used the fixed subset
`index % 4 == 0`; that choice is made before execution and is not based on any
observed address or race state. DTrace only records function entry/return and
context fields. It contains no hold, stop, signal, selection, rejection, or
kernel mutation.

```sh
RPC_GSS_STOCK_TRACE_SCRIPT=trace_nfs_stock_mbuf_uaf_overlap.d \
RPC_GSS_STOCK_STREAM_TRACE=1 \
RPC_GSS_STOCK_CLIENT_NAME=rpc_gss_crypto_race_integrity \
RPC_GSS_DATA_SERVICE=integrity \
RPC_GSS_DTRACE_SWITCHRATE=100hz \
RPC_GSS_DATA_CONTEXT_STRIDE=4 \
RPC_GSS_DATA_CONTEXT_OFFSET=0 \
RPC_GSS_NFS_FH_FILE=export-root.vm84.fh \
RPC_GSS_NFS_PROC=readdirplus \
RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=786432 \
RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=786432 \
./run_nfs_stock_multicontext_batch.sh \
  stock_rdp_integrity_24ctx_stride4_8data_656k_stream_1 \
  24 38500 1500 8 100
```

The run completed all clients with no panic. The decisive same-address tuple
is preserved in `evidence/exact_oob/`: old digest 12 fixed a 28-byte MIC
allocation; teardown and DES3 digest-20 reconstruction completed during the
same active HMAC; both the inner and outer MIC functions then returned zero.
Exact KDK disassembly shows that returning from the inner function means the
20-byte `memcpy` at allocation offset 16 completed.

This is an 8-byte logical overrun of the requested object and a 4-byte
cross-slot overwrite from its physical `data.kalloc.32` element. Because
DTrace may perturb scheduling, use the no-DTrace panic above for unaided stock
reachability and this trace for exact sink completion.

## Evidence

- `evidence/stock_rdp_24x2_shift19ms_notrace_1.panic`: full no-DTrace panic.
- `evidence/stock_rdp_24x2_shift19ms_notrace_1.stock_multictx.run.log`:
  stage/prearm output followed by connection loss.
- `evidence/stock_rdp_24x2_shift19ms_notrace_1.bootsessionuuid.txt`: pre-panic
  boot UUID, matching the panic report.
- `evidence/ACTIVE_HMAC_UAF_ANALYSIS.md`: register, KDK, source-line, and call
  chain analysis.
- `evidence/exact_oob/analysis.md`: every allocation/copy operand and missing
  cross-generation bound, with the decisive trace tuple.
- `evidence/exact_oob/*.dtrace.out`: full passive trace. Primary SHA-256 is
  `9c671430c23abd862c5cef041488192d7e5e404f63d716013a1efe087ae4bcca`.
- `evidence/integrity_uaf/`: independent integrity-mode active-HMAC panic and
  symbolication.
- `source/rpc_gss_crypto_race_integrity.c` and matching binary: exact client
  used for integrity DATA.
- `source/trace_nfs_stock_mbuf_uaf_overlap.d`: exact passive observer.

The no-DTrace panic SHA-256 is
`101d27007ab4b84364763e55abc52f792e68deb7c9eca5ffc458bcaa6f3f0774`.
