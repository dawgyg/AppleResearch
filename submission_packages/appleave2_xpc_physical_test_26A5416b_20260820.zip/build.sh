#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
BUILD="$ROOT/build"
mkdir -p "$BUILD"

xcrun clang -std=c11 -O2 -g -Wall -Wextra -Werror \
  -dynamiclib "$ROOT/ave2_interpose.c" \
  -framework CoreFoundation -framework IOKit -framework IOSurface -ldl \
  -o "$BUILD/libave2_interpose.dylib"

xcrun clang -std=c11 -O2 -g -Wall -Wextra -Werror \
  -dynamiclib "$ROOT/ave2_hevc_interpose.c" \
  -framework IOKit -ldl \
  -o "$BUILD/libave2_hevc_interpose.dylib"

xcrun clang -std=c11 -O2 -g -Wall -Wextra -Werror \
  "$ROOT/ave2_vt_h264_seed.c" \
  -framework CoreFoundation -framework CoreMedia -framework CoreVideo \
  -framework VideoToolbox \
  -o "$BUILD/ave2_vt_h264_seed"

codesign --force --sign - "$BUILD/libave2_interpose.dylib"
codesign --force --sign - "$BUILD/libave2_hevc_interpose.dylib"
codesign --force --sign - "$BUILD/ave2_vt_h264_seed"

echo "built: $BUILD"
