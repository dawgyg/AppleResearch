#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
EXPECTED_BUILD="26A5416b"
EXPECTED_PLUGIN_UUID="9E31048E-2D20-3E3E-82BF-DB2CFE99D025"
RESEARCH_HOST_UUID="70318744-FF5C-58D2-8C50-4A6DB4E8C2D0"
SERVICE_PATH="/System/Library/Frameworks/VideoToolbox.framework/Versions/A/XPCServices/VTEncoderXPCService.xpc/Contents/MacOS/VTEncoderXPCService"
PLUGIN_PATH="/System/Library/Video/Plug-Ins/AppleVideoEncoder.bundle/Contents/MacOS/AppleVideoEncoder"
VALUE="${1:-0x80000000}"
SELECTOR="${2:-4}"
CALL="${3:-1}"
BUILD="$(sw_vers -buildVersion)"
PLATFORM_UUID="$(ioreg -rd1 -c IOPlatformExpertDevice | awk -F'"' '/IOPlatformUUID/{print $4}')"
PLUGIN_UUID="$(dwarfdump --uuid "$PLUGIN_PATH" | awk '{print $2}')"
typeset -A existing_pids
typeset seed_pid=""
typeset target_pid=""

[[ "$BUILD" == "$EXPECTED_BUILD" ]] || {
  print -u2 "refusing: build=$BUILD expected=$EXPECTED_BUILD"; exit 2
}
[[ "$PLUGIN_UUID" == "$EXPECTED_PLUGIN_UUID" ]] || {
  print -u2 "refusing: plugin UUID=$PLUGIN_UUID expected=$EXPECTED_PLUGIN_UUID"; exit 2
}
(( EUID == 501 )) || {
  print -u2 "refusing: run from the uid501 test account"; exit 2
}
[[ "$PLATFORM_UUID" != "$RESEARCH_HOST_UUID" ]] || {
  print -u2 "refusing: Dawgyg research host is permanently denied"; exit 2
}
[[ "${AVE2_DISPOSABLE_PHYSICAL_MAC:-}" == "YES" ]] || {
  print -u2 "refusing: export AVE2_DISPOSABLE_PHYSICAL_MAC=YES"; exit 2
}
[[ -n "$(ioreg -r -n AppleAVE2Driver 2>/dev/null)" ]] || {
  print -u2 "refusing: AppleAVE2Driver is absent"; exit 3
}
if ! [[ "$VALUE" =~ '^(0[xX][0-9a-fA-F]+|[0-9]+)$' ]]; then
  print -u2 "refusing: value must be a 32-bit integer"
  exit 2
fi
typeset -i value_number=$VALUE
(( value_number >= 0x80000000 && value_number <= 0xfffffffb )) || {
  print -u2 "refusing: value must be in 0x80000000..0xfffffffb"; exit 2
}
(( SELECTOR == 4 || SELECTOR == 5 )) || {
  print -u2 "refusing: selector must be 4 or 5"; exit 2
}
(( CALL >= 1 && CALL <= 60 )) || {
  print -u2 "refusing: occurrence must be in 1..60"; exit 2
}
(( SELECTOR != 4 || CALL == 1 )) || {
  print -u2 "refusing: selector 4 has one Prepare call per session"; exit 2
}

STAMP="$(date +%Y%m%dT%H%M%S)"
OUT="$ROOT/artifacts/hevc-lldb-ARMED-value-${VALUE}-sel${SELECTOR}-$STAMP"
mkdir -p "$OUT"
sync

for pid in ${(f)"$(pgrep -f "$SERVICE_PATH" 2>/dev/null || true)"}; do
  [[ -n "$pid" ]] && existing_pids[$pid]=1
done

print "ARMED disposable run: value=$VALUE selector=$SELECTOR call=$CALL artifacts=$OUT"
env -u DYLD_INSERT_LIBRARIES -u AVE2_ARM -u AVE2_LLDB_ARM \
  AVE2_CODEC=hevc \
  AVE2_SEED_PREPARE_HOLD_SECONDS=20 \
  AVE2_SEED_HOLD_SECONDS=3 \
  "$ROOT/build/ave2_vt_h264_seed" "$CALL" \
  >"$OUT/seed.log" 2>&1 &
seed_pid=$!

for _ in {1..100}; do
  for pid in ${(f)"$(pgrep -f "$SERVICE_PATH" 2>/dev/null || true)"}; do
    if [[ -n "$pid" && ${+existing_pids[$pid]} -eq 0 ]]; then
      target_pid="$pid"
      break 2
    fi
  done
  sleep 0.1
done

if [[ -z "$target_pid" ]]; then
  print -u2 "failed to find the transient VTEncoderXPCService"
  kill -TERM "$seed_pid" 2>/dev/null || true
  wait "$seed_pid" 2>/dev/null || true
  exit 4
fi
[[ "$(ps -o uid= -p "$target_pid" | tr -d ' ')" == "501" ]] || {
  print -u2 "refusing: transient target is not uid501"; exit 5
}

print "attaching armed debugger: seed=$seed_pid target=$target_pid"
env \
  AVE2_LLDB_CAPTURE_DIR="$OUT" \
  AVE2_LLDB_ARM=26A5416b_DISPOSABLE_PHYSICAL_HEVC_LLDB \
  AVE2_DISPOSABLE_PHYSICAL_MAC=YES \
  AVE2_HEVC_SPS_VALUE="$VALUE" \
  AVE2_TARGET_SELECTOR="$SELECTOR" \
  AVE2_MUTATE_CALL="$CALL" \
  lldb -b -p "$target_pid" \
    -o "command script import $ROOT/mutate_vtencoder.py" \
    -o continue |& tee "$OUT/lldb.log"

wait "$seed_pid"
print "armed run returned without a panic; preserve and inspect $OUT"
