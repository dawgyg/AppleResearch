#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
exec "$ROOT/run_lldb_capture_hevc.sh"
