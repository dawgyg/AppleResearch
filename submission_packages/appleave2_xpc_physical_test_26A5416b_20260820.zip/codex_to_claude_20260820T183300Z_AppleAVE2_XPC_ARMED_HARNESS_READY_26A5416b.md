# Codex -> Claude: AppleAVE2 XPC-aware physical harness ready on 26A5416b

Date: 2026-08-20
Status: DISARMED PATH VERIFIED; armed physical run not executed
Priority: execute on one disposable physical Apple-Silicon Mac

## What changed

The obsolete seed-only HEVC interposer path has been replaced by a deterministic
transient-`VTEncoderXPCService` workflow:

1. Launch a stock uid501 HEVC session and hold before Prepare.
2. Diff the live `VTEncoderXPCService` PID set to find the new per-session PID.
3. Attach LLDB to that process.
4. Verify current build, plugin UUID, process name, uid, and callsite.
5. Capture and fsync the original selector request at the exact
   AppleVideoEncoder call instruction.
6. In armed mode only, update the seven audited HEVC fields, read back and
   verify the complete request, fsync the sent copy, then allow the existing
   call to enter AppleAVE2.

`run_capture_hevc.sh` and `run_once_hevc.sh` are compatibility entrypoints and
now delegate to the XPC-aware runners.

## Safety gates

Armed mode requires all of:

- macOS build `26A5416b`
- AppleVideoEncoder UUID `9E31048E-2D20-3E3E-82BF-DB2CFE99D025`
- target executable `VTEncoderXPCService`
- target uid exactly `501`
- `AppleAVE2Driver` present
- selector exactly 4 or 5 with exact `0x12c08`/`0x12c18` input size
- SPS value in `0x80000000..0xfffffffb`
- explicit arm token and `AVE2_DISPOSABLE_PHYSICAL_MAC=YES`
- platform UUID not equal to Dawgyg's research host

Dawgyg's host UUID `70318744-FF5C-58D2-8C50-4A6DB4E8C2D0` is permanently
denied in both the shell runner and LLDB Python script. A local armed attempt
refused before launching a seed.

## Disarmed verification

Command:

```sh
cd /Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5416b
./run_lldb_capture_hevc.sh
```

Result: exit 0, hardware HEVC encode successful, selector 4 and selector 5
captured, every original/sent pair byte-identical, metadata says `armed=no` and
`mutated=no`, and no debugger/seed process remained.

Artifact directory:

`/Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5416b/artifacts/hevc-lldb-capture-20260820T143048/`

Hashes:

```text
selector 4 orig/sent d000522f12d0517396f44aa0177c0f868707487644048b697a2190c4fc808003
selector 5 orig/sent 76016b7a404d1ef3eba662eaae18bb31767448b99488be3277b9c68c44d46256
```

The pure mutation model was run offline against both captures with value
`0x80000000`. It preserved both request sizes, set every intended field, and
proved every changed byte lies inside one of the seven exact field spans.

## Tool hashes

```text
mutate_vtencoder.py          0939491d5131ba63a4dbda8846963716a7cef9d5a67f5af73393e61f19e5076f
run_lldb_capture_hevc.sh     1229a1132b1fff598ef7b2dc05cbdab1e325449a332a1c1c85bd6e73a844fa08
run_lldb_once_hevc.sh        b75cf77aad4060f44b041a657a90cc94fa2ec16f517736030015c10fc3165180
run_capture_hevc.sh          7ee034781e69e1997c5d72fb638fd836b87196e05133a996ad12212356f3020f
run_once_hevc.sh             037f27703622e497ec4f2167768784c64964ae3b23a0d81be57203bff025d5fc
```

## Disposable physical run

The disposable machine needs exact build `26A5416b`, AppleAVE2 hardware,
Xcode/LLDB attach capability, and a uid501 test account.

First prove capture-only:

```sh
./build.sh
./run_lldb_capture_hevc.sh
```

Then arm one selector-4 Prepare request:

```sh
export AVE2_DISPOSABLE_PHYSICAL_MAC=YES
./run_lldb_once_hevc.sh 0x80000000 4 1
```

If selector 4 survives or returns before the vulnerable SPS generation path,
reboot if needed and test selector 5:

```sh
export AVE2_DISPOSABLE_PHYSICAL_MAC=YES
./run_lldb_once_hevc.sh 0x80000000 5 1
```

Preserve the panic, the artifact directory, and the unified log around the
run. Do not execute either armed command on Dawgyg's research host.
