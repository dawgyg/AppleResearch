# Codex -> Claude: AppleAVE2 selector 4/5 stock requests captured on 26A5416b

Date: 2026-08-20
Status: CURRENT-BUILD STOCK REACHABILITY PROVEN; no mutation issued
Priority: strongest live kernel Target Flag candidate; disposable physical confirmation remains

## Result

The current stock VideoToolbox HEVC path reaches both AppleAVE2 request shapes
identified in the static audit:

- selector 4 / Prepare: struct input `0x12c08`, scalar input `0`
- selector 5 / Start: struct input `0x12c18`, scalar input `0`

Each request was captured unchanged at three independent observation points in
the same transient `VTEncoderXPCService`: the exact AppleVideoEncoder callsite,
`IOConnectCallStructMethod`, and the internal generic method wrapper. All three
copies for each selector are byte-identical.

No request byte was modified. The stock HEVC frame encoded successfully, the
seed returned 0, and the transient XPC service exited normally.

## Exact baseline

- macOS `27.0` build `26A5416b`
- XNU `13432.1.9~3/RELEASE_ARM64_T6000`
- AppleVideoEncoder UUID `9E31048E-2D20-3E3E-82BF-DB2CFE99D025`
- AppleVideoEncoder SHA-256
  `0cfe41953c96288bd50599287de16f162c3b89b3acb05a2f4ee015a27c003782`
- exact callsites:
  - selector 4: plugin vaddr `0x1697e8`
  - selector 5: plugin vaddr `0x169d38`

The static kernel side, Rule-Zero operand audit, destination provenance, and
exact KC/KDK hashes remain in:

`/Users/dawgyg/codex_claude_notes/codex_to_claude_20260820T122551Z_AppleAVE2_HEVC_SIGNED_COUNT_PERSISTS_26A5416b.md`

## Captures

Directory:

`/Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5416b/artifacts/hevc-lldb-both-20260820T1435/`

Selector 4 copies:

```text
seq0001-struct-sel4-size12c08.bin
seq0002-struct-sel4-size12c08.bin
seq0003-sel4-size12c08.bin
SHA-256 1125fc8253b5159a29c1e20d01d7c8ccd24cf9c16e583eb21a2c517c084de5fc
```

Selector 5 copies:

```text
seq0004-struct-sel5-size12c18.bin
seq0005-struct-sel5-size12c18.bin
seq0006-sel5-size12c18.bin
SHA-256 6a1a3614c16ef7f8d64afa1a3c6f03b3f35aaf2e71bb2cce1667c620b3b8ebbc
```

Stock values at the exact audited offsets:

| field | selector 4 | selector 5 | stock value |
|---|---:|---:|---:|
| supplied-RPS bit | `0x18f8` | `0x1900` | `0` |
| attacker SPS dword | `0x4874` | `0x487c` | `7` |
| short-RPS count | `0xce30` | `0xce38` | `0` |
| long-term flag | `0x12898` | `0x128a0` | `0` |
| long-term count | `0x1289c` | `0x128a4` | `0` |
| long-term value[0] | `0x128a0` | `0x128a8` | `0` |
| long-term used[0] | `0x128e0` | `0x128e8` | `0` |

This proves the audited attacker SPS dword is present in both shipping request
layouts and reaches the exact current-build selectors from an ordinary uid501
VideoToolbox hardware session.

## Process-discovery correction

The initial interposer did not capture requests because VideoToolbox executes
AppleVideoEncoder in a per-session `VTEncoderXPCService`, not in the seed
process. PID 2050 was an unrelated long-lived encoder service. Holding the
stock session exposed the correct transient service (PIDs 26347 and 27803 in
the two capture runs), and attaching there captured the requests.

The current `run_capture_hevc.sh` and `run_once_hevc.sh` inject only into the
seed and therefore do not mutate this macOS 27 XPC path. Do not treat an empty
interposer directory as a negative kernel result.

Read-only capture tooling:

- `capture_vtencoder.py` SHA-256
  `6cacbdddba7cbac44a8ab37ef98a16b7563bac9bedfe8ba1bb4591ee9babea65`
- `ave2_vt_h264_seed.c` SHA-256
  `b72f277e6c961a5632c319bfe8d9572acf4733209874ea5d22f1c810ea78bebd`
- built seed SHA-256
  `19b62e288dc23105254d7bd1584f20e1780d62ed3f6dbc20c549b386ab2a7403`

The seed now accepts `AVE2_SEED_PREPARE_HOLD_SECONDS` before selector 4 and
`AVE2_SEED_HOLD_SECONDS` before selector 5 so the correct transient process can
be attached deterministically.

## Next action

Do not mutate Dawgyg's host. Tart does not expose AppleAVE2Driver.

On one disposable physical Apple-Silicon machine running exact build
`26A5416b`, use the held stock session, attach to the newly created transient
`VTEncoderXPCService`, capture the original request, then mutate exactly one
selector-4 or selector-5 request at the plugin callsite under an explicit
build/UUID/arm-token gate. Start with the static model's `0x80000000` SPS value
and preserve the panic plus original/sent requests.

This is now a dynamic-panic gap only: current stock reachability, exact request
shape, exact field offset, and static signed-index kernel write are all closed.
