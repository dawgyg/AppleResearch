#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
EXPECTED_BUILD="26A5416b"
VALUE="${1:-0x80000000}"
CALL="${2:-1}"
SELECTOR="${3:-4}"
BUILD="$(sw_vers -buildVersion)"

if [[ "$BUILD" != "$EXPECTED_BUILD" ]]; then
  print -u2 "refusing: build is $BUILD, expected $EXPECTED_BUILD"
  exit 2
fi
if ! [[ "$VALUE" =~ '^(0[xX][0-9a-fA-F]+|[0-9]+)$' ]]; then
  print -u2 "refusing: value must be a 32-bit integer"
  exit 2
fi
typeset -i VALUE_NUM=$VALUE
if (( VALUE_NUM < 0x80000000 || VALUE_NUM > 0xfffffffb )); then
  print -u2 "refusing: value must be in 0x80000000..0xfffffffb"
  exit 2
fi
if (( CALL < 1 || CALL > 60 )); then
  print -u2 "refusing: call occurrence must be in 1..60"
  exit 2
fi
if (( SELECTOR != 4 && SELECTOR != 5 )); then
  print -u2 "refusing: selector must be 4 (Prepare) or 5 (Start)"
  exit 2
fi
if (( EUID == 0 )); then
  print -u2 "refusing: run as the unprivileged test user, not root"
  exit 2
fi
if ! ioreg -r -n AppleAVE2Driver >/dev/null 2>&1; then
  print -u2 "refusing: AppleAVE2Driver is not present on this machine"
  exit 3
fi
if [[ "${AVE2_DISPOSABLE_PHYSICAL_MAC:-}" != "YES" ]]; then
  print -u2 "refusing: export AVE2_DISPOSABLE_PHYSICAL_MAC=YES on a disposable physical Mac"
  exit 4
fi

print "using XPC-aware armed path: build=$BUILD uid=$EUID value=$VALUE selector=$SELECTOR call=$CALL"
exec "$ROOT/run_lldb_once_hevc.sh" "$VALUE" "$SELECTOR" "$CALL"
