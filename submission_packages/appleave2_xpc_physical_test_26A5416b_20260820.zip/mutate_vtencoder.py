import os
import pathlib
import re
import struct
import subprocess
import threading

import lldb


EXPECTED_BUILD = "26A5416b"
EXPECTED_PLUGIN_UUID = "9E31048E-2D20-3E3E-82BF-DB2CFE99D025"
ARM_TOKEN = "26A5416b_DISPOSABLE_PHYSICAL_HEVC_LLDB"
RESEARCH_HOST_UUID = "70318744-FF5C-58D2-8C50-4A6DB4E8C2D0"

REQUESTS = {
    4: {
        "callsite": 0x1697E8,
        "size": 0x12C08,
        "use_supplied_rps": 0x18F8,
        "sps_bit_count": 0x4874,
        "short_rps_count": 0xCE30,
        "long_term_flag": 0x12898,
        "long_term_count": 0x1289C,
        "long_term_value": 0x128A0,
        "long_term_used": 0x128E0,
    },
    5: {
        "callsite": 0x169D38,
        "size": 0x12C18,
        "use_supplied_rps": 0x1900,
        "sps_bit_count": 0x487C,
        "short_rps_count": 0xCE38,
        "long_term_flag": 0x128A0,
        "long_term_count": 0x128A4,
        "long_term_value": 0x128A8,
        "long_term_used": 0x128E8,
    },
}

_lock = threading.Lock()
_occurrences = {4: 0, 5: 0}
_config = None
_mutation_done = False


def _command_output(argv):
    return subprocess.check_output(argv, text=True).strip()


def _parse_integer(name, default=None):
    text = os.environ.get(name)
    if text is None or text == "":
        return default
    try:
        return int(text, 0)
    except ValueError:
        return None


def _write_sync(path, data):
    path.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with path.open("xb") as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    directory_fd = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory_fd)
    finally:
        os.close(directory_fd)


def _read_request(process, pointer, size):
    error = lldb.SBError()
    data = process.ReadMemory(pointer, size, error)
    if error.Fail() or len(data) != size:
        raise RuntimeError(f"ReadMemory failed: {error.GetCString()}")
    return data


def _mutated_request(original, selector, value):
    request = REQUESTS[selector]
    mutated = bytearray(original)
    mutated[request["use_supplied_rps"]] |= 1
    struct.pack_into("<I", mutated, request["short_rps_count"], 0)
    struct.pack_into("<I", mutated, request["sps_bit_count"], value)
    mutated[request["long_term_flag"]] = 1
    struct.pack_into("<I", mutated, request["long_term_count"], 1)
    struct.pack_into("<I", mutated, request["long_term_value"], 0)
    mutated[request["long_term_used"]] = 1
    return bytes(mutated)


def _target_uid(process):
    return int(_command_output(["/bin/ps", "-o", "uid=", "-p", str(process.GetProcessID())]))


def _platform_uuid():
    output = _command_output(
        ["/usr/sbin/ioreg", "-rd1", "-c", "IOPlatformExpertDevice"]
    )
    match = re.search(r'"IOPlatformUUID"\s*=\s*"([^"]+)"', output)
    return match.group(1).upper() if match else ""


def _detach_on_refusal(debugger, reasons):
    print("[ave2-mutate] MUTATION REFUSED: " + "; ".join(reasons))
    process = debugger.GetSelectedTarget().GetProcess()
    if process.IsValid():
        error = process.Detach()
        if error.Fail():
            print(f"[ave2-mutate] detach failed: {error.GetCString()}")


def capture_or_mutate(frame, _bp_loc, _internal_dict):
    global _mutation_done

    selector = frame.FindRegister("x1").GetValueAsUnsigned(0) & 0xFFFFFFFF
    pointer = frame.FindRegister("x2").GetValueAsUnsigned(0)
    size = frame.FindRegister("x3").GetValueAsUnsigned(0)
    if selector not in REQUESTS or size != REQUESTS[selector]["size"]:
        print(
            "[ave2-mutate] unexpected callsite shape "
            f"selector={selector} size=0x{size:x}; stopping"
        )
        return True

    with _lock:
        _occurrences[selector] += 1
        occurrence = _occurrences[selector]

    process = frame.GetThread().GetProcess()
    original = _read_request(process, pointer, size)
    stem = _config["capture_dir"] / (
        f"pid{process.GetProcessID()}-sel{selector}-call{occurrence}"
    )
    _write_sync(stem.with_suffix(".orig.bin"), original)

    should_mutate = (
        _config["armed"]
        and not _mutation_done
        and selector == _config["selector"]
        and occurrence == _config["occurrence"]
    )
    sent = original
    if should_mutate:
        sent = _mutated_request(original, selector, _config["value"])
        error = lldb.SBError()
        written = process.WriteMemory(pointer, sent, error)
        if error.Fail() or written != size:
            process.WriteMemory(pointer, original, lldb.SBError())
            print(f"[ave2-mutate] WriteMemory failed: {error.GetCString()}")
            return True
        verified = _read_request(process, pointer, size)
        if verified != sent:
            process.WriteMemory(pointer, original, lldb.SBError())
            print("[ave2-mutate] write verification failed; original restored")
            return True
        _mutation_done = True

    _write_sync(stem.with_suffix(".sent.bin"), sent)
    metadata = (
        f"build={_config['build']}\n"
        f"plugin_uuid={_config['plugin_uuid']}\n"
        f"platform_uuid={_config['platform_uuid']}\n"
        f"pid={process.GetProcessID()}\nuid={_config['uid']}\n"
        f"selector={selector}\nsize=0x{size:x}\n"
        f"occurrence={occurrence}\narmed={'yes' if _config['armed'] else 'no'}\n"
        f"mutated={'yes' if should_mutate else 'no'}\n"
        f"value=0x{_config['value']:08x}\n"
    ).encode()
    _write_sync(stem.with_suffix(".meta.txt"), metadata)
    print(
        "[ave2-mutate] "
        f"selector={selector} size=0x{size:x} call={occurrence} "
        f"armed={'yes' if _config['armed'] else 'no'} "
        f"mutated={'yes' if should_mutate else 'no'} "
        f"orig={stem.with_suffix('.orig.bin')} "
        f"sent={stem.with_suffix('.sent.bin')}"
    )
    return False


def __lldb_init_module(debugger, _internal_dict):
    global _config

    target = debugger.GetSelectedTarget()
    process = target.GetProcess()
    plugin = target.FindModule(lldb.SBFileSpec("AppleVideoEncoder"))
    plugin_uuid = plugin.GetUUIDString().upper() if plugin.IsValid() else ""
    plugin_base = plugin.GetObjectFileHeaderAddress().GetLoadAddress(target)
    build = _command_output(["/usr/bin/sw_vers", "-buildVersion"])
    uid = _target_uid(process)
    selector = _parse_integer("AVE2_TARGET_SELECTOR", 4)
    occurrence = _parse_integer("AVE2_MUTATE_CALL", 1)
    value = _parse_integer("AVE2_HEVC_SPS_VALUE", 0)
    arm_requested = os.environ.get("AVE2_LLDB_ARM") is not None
    platform_uuid = _platform_uuid()
    capture_dir = pathlib.Path(
        os.environ.get("AVE2_LLDB_CAPTURE_DIR", "/tmp/ave2-lldb-capture")
    )

    reasons = []
    if build != EXPECTED_BUILD:
        reasons.append(f"build={build}, expected={EXPECTED_BUILD}")
    if plugin_uuid != EXPECTED_PLUGIN_UUID:
        reasons.append(
            f"plugin UUID={plugin_uuid or 'missing'}, expected={EXPECTED_PLUGIN_UUID}"
        )
    if plugin_base == lldb.LLDB_INVALID_ADDRESS:
        reasons.append("AppleVideoEncoder is not loaded")
    if target.GetExecutable().GetFilename() != "VTEncoderXPCService":
        reasons.append("target is not VTEncoderXPCService")
    if uid != 501:
        reasons.append(f"target uid={uid}, expected uid501")
    if selector not in REQUESTS:
        reasons.append("selector must be 4 or 5")
    if occurrence is None or occurrence < 1 or occurrence > 60:
        reasons.append("occurrence must be in 1..60")

    armed = arm_requested
    if armed and os.environ.get("AVE2_LLDB_ARM") != ARM_TOKEN:
        reasons.append("arm token mismatch")
    if armed and os.environ.get("AVE2_DISPOSABLE_PHYSICAL_MAC") != "YES":
        reasons.append("disposable physical marker missing")
    if armed and platform_uuid == RESEARCH_HOST_UUID:
        reasons.append("research host is permanently denied for armed runs")
    if armed and (value is None or value < 0x80000000 or value > 0xFFFFFFFB):
        reasons.append("SPS value must be in 0x80000000..0xfffffffb")
    if value is None:
        reasons.append("SPS value is not an integer")
    if reasons:
        _detach_on_refusal(debugger, reasons)
        return

    _config = {
        "armed": armed,
        "build": build,
        "capture_dir": capture_dir,
        "occurrence": occurrence,
        "plugin_uuid": plugin_uuid,
        "platform_uuid": platform_uuid,
        "selector": selector,
        "uid": uid,
        "value": value,
    }
    capture_dir.mkdir(mode=0o700, parents=True, exist_ok=True)

    selectors = (selector,) if armed else (4, 5)
    breakpoint_ids = []
    for current_selector in selectors:
        address = plugin_base + REQUESTS[current_selector]["callsite"]
        breakpoint = target.BreakpointCreateByAddress(address)
        breakpoint.SetScriptCallbackFunction(
            "mutate_vtencoder.capture_or_mutate"
        )
        breakpoint_ids.append(breakpoint.GetID())

    print(
        "[ave2-mutate] "
        f"build={build} plugin_uuid={plugin_uuid} pid={process.GetProcessID()} "
        f"uid={uid} armed={'yes' if armed else 'no'} "
        f"selector={selector} occurrence={occurrence} value=0x{value:08x} "
        f"breakpoints={breakpoint_ids} capture_dir={capture_dir}"
    )
