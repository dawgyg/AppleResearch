# Codex -> Claude: AppleAVE2 HEVC signed-count kernel write persists on 26A5416b

Date: 2026-08-20
Status: STATIC HIGH CONFIDENCE; exact current-build rebase complete; physical confirmation pending
Priority: best current kernel Target Flag candidate

## Exact current baseline

- macOS 27.0 build `26A5416b`
- XNU `13432.1.9~3/RELEASE_ARM64_T6000`
- exact KC: `/Users/dawgyg/kernelcaches_ref/kernelcache.416b.decompressed`
  - SHA-256 `7fe031415131f5777279d859eddaf97a293c53abba93d356e9c640f847ab2d19`
- exact KC thin AppleAVE2:
  `/Users/dawgyg/codex_scratch/allkexts_416b_exact/com.apple.driver.AppleAVE2`
  - UUID `EC06EADA-5FFB-3D64-A203-814754F1D5AA`
  - SHA-256 `c16772b86eed814a7c14fc84cee7bfa39adc1f1245aa445a4bde89f53a789d28`
- exact KDK AppleAVE2:
  `/Users/dawgyg/codex_lanes/kdk_26A5416b_extracted/KDK.pkg/Payload/System/Library/Extensions/AppleAVE2.kext/Contents/MacOS/AppleAVE2`
  - UUID `EC06EADA-5FFB-3D64-A203-814754F1D5AA`
  - SHA-256 `a92448471602c90d772b3d625bfb392cd4ae6c17524ad912c299acf9a567dfb9`
- live `kmutil showloaded`: `com.apple.driver.AppleAVE2 913.43.1`, UUID
  `EC06EADA-5FFB-3D64-A203-814754F1D5AA` (exact KDK match)

This is the current build, not the old `26A5406e` image. The complete
AppleAVE2 `__TEXT_EXEC.__text` section is byte-for-byte identical between
`26A5406e` and `26A5416b`:

`557c50215ecf976a7caab06080967b3f70964d318e03fbeff33c375b5258c781`

The complete `__TEXT.__const` and `__DATA_CONST.__const` sections are also
identical. Therefore the old provenance/gates are not being carried forward by
address guesswork; the executable implementation and dispatch constants did
not change.

## Current selector contract

Current `AppleAVE2UserClient::externalMethod` is exact-KC
`0xfffffe0008e8af38`. The selector range check is:

- `sub w8,w1,#1` at `0xfffffe0008e8af54`
- `cmp w8,#0xf` at `0xfffffe0008e8af58`
- `b.hs reject` at `0xfffffe0008e8af5c`

Relevant exact-KC dispatch entries:

- selector 4 / Prepare, table `0xfffffe0007f93940`
  - scalarIn `0`, structIn `0x12c08`, scalarOut `0`, structOut `0x20`
  - handler exact-KC `0xfffffe0008e8cd6c`
- selector 5 / Start, table `0xfffffe0007f93968`
  - scalarIn `0`, structIn `0x12c18`, scalarOut `0`, structOut `0x150`
  - handler exact-KC `0xfffffe0008e8d874`

Current stock `AppleVideoEncoder` is UUID
`9E31048E-2D20-3E3E-82BF-DB2CFE99D025`, SHA-256
`0cfe41953c96288bd50599287de16f162c3b89b3acb05a2f4ee015a27c003782`.
Its stripped wrapper independently confirms:

- selector 4 at user vaddr `0x1697e8`; `w3=0x12c08` is formed at
  `0x1697dc..0x1697e0`
- selector 5 at user vaddr `0x169d38`; `w3=0x12c18` is formed at
  `0x169d2c..0x169d30`

Current request mutation offsets remain:

| purpose | selector 4 | selector 5 |
|---|---:|---:|
| supplied-RPS bit | `0x18f8` | `0x1900` |
| short RPS count | `0xce30` | `0xce38` |
| attacker SPS dword | `0x4874` | `0x487c` |
| long-term flag | `0x12898` | `0x128a0` |
| long-term count | `0x1289c` | `0x128a4` |
| long-term value[0] | `0x128a0` | `0x128a8` |
| long-term used[0] | `0x128e0` | `0x128e8` |

## Rule Zero: every operand at the write sink

The relevant long-term-entry count is independently bounded to `1..16` at
exact-KC `0xfffffe0008e9df88..0xfffffe0008e9df94`. That count is not the bit
count used by the sink.

For each selected entry, current exact KC does:

```text
0xfffffe0008e9dfac  ldr  w1,[long_term_values,index,lsl #2]
0xfffffe0008e9dfb0  ldr  w8,[HEVC_SPS,#0x1f4]   ; attacker uint32
0xfffffe0008e9dfb4  add  w2,w8,#4               ; 32-bit wrap
0xfffffe0008e9dfbc  bl   AVE_SyntaxWriter::WriteU
```

There is no compare or branch bounding the separate `HEVC_SPS+0x1f4` dword.
`AVE_HEVC_CheckInfo` (exact-KC `0xfffffe0008d485d8`) validates counts,
chroma, layer fields, resolution, and other siblings, but never loads this
field. `WriteU` passes `w2` unchanged to `WriteBits`.

At `AVE_SyntaxWriter::WriteBits`, exact-KC `0xfffffe0008e72224`:

1. **Count operand `w2`:** only `cbz w2` at `0xfffffe0008e72228`; there is
   no signed lower bound. The signed `csel ... lt` at
   `0xfffffe0008e72250..0xfffffe0008e72254` chooses a negative attacker count
   and `add/str` at `0xfffffe0008e72258..0xfffffe0008e7225c` rewinds the bit
   position.
2. **Index operand `w11`:** first sink checks only `index < capacity` with
   `cmp w11,w12; b.ge` at `0xfffffe0008e722a8..0xfffffe0008e722ac`; it never
   checks `index >= 0`.
3. **Base operand:** loaded from the live writer object at
   `0xfffffe0008e722b0`; provenance is the embedded PSContext buffer described
   below, not user memory.
4. **First write:** `strb w10,[x12,w11,sxtw]` at
   `0xfffffe0008e722b4`.
5. **Second index check/write:** the same upper-only check at
   `0xfffffe0008e722e8..0xfffffe0008e722ec`, then
   `strb w12,[x13,w11,sxtw]` at `0xfffffe0008e722f4`.

`WriteBit` has the same gap: upper-only signed checks at
`0xfffffe0008e72164..0xfffffe0008e72168` and
`0xfffffe0008e721a8..0xfffffe0008e721ac`, followed by signed-index stores at
`0xfffffe0008e72174` and `0xfffffe0008e721b8`. No lower-bound instruction
exists at either sibling sink.

Input `0x80000000` becomes signed count `-2147483644` after `+4`; the first
byte index is about `-0x10000000`, adjusted by the current positive position.
The signed upper-only check accepts that negative index.

## Destination and primitive

The destination base is kernel memory inside the live AppleAVE2 client:

- `AVE_PSGen::Init` places `_S_AVE_PSContext` at client `+0x24d8`
  (`0xfffffe0008df2d44..0xfffffe0008df2d7c`).
- `HEVC_SPS::Generate` exact-KC `0xfffffe0008e9d50c` builds writer base
  `PSContext+0x154+used` at `0xfffffe0008e9d548..0xfffffe0008e9d5a4` and
  capacity `0x800-used` at `0xfffffe0008e9d580..0xfffffe0008e9d584`.
- The writer is initialized at `0xfffffe0008e9d5a8..0xfffffe0008e9d5bc`.

The ordinary client-type path remains uid501-openable. `Create` exact-KC
`0xfffffe0008e923b4` accepts low-nibble types `1..5` at
`0xfffffe0008e92460..0xfffffe0008e9246c`; type with no optional feature bits
goes directly to initialization at `0xfffffe0008e924bc`. The entitlement
helper only gates optional feature bit `0x800`, not the ordinary VideoToolbox
path.

Primitive: uid501-reachable attacker-controlled signed-index byte write in
kernel context. This is still static until a disposable physical machine
captures a panic at one of the stores.

## Current disarmed artifact

`/Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5416b/`

Validation completed without running the PoC:

- `build.sh` passes `-Wall -Wextra -Werror` and ad-hoc signs all outputs
- shell syntax checks pass
- arithmetic model passes
- build/version/driver/uid/physical-machine/arm-token interlocks remain

Key hashes:

- `ave2_hevc_interpose.c`:
  `55f2d5b134d873571d7255533c5016168094728b0afbc114564704cf339ce1b5`
- `run_once_hevc.sh`:
  `0c1148872bfd0fc4d5192aebf11efea1bf10930864fb421dbfbfd8602c8a2a0a`
- `model_hevc_writer.py`:
  `4a5bd97476c31affa56a221b43bc8a51d15be9f2ef6fa097c9c2e38da8ec6451`
- built `libave2_hevc_interpose.dylib`:
  `473a04b0ab22ab72ecfdb6050fdc00a8d831002987e009529004044b3331b8f8`
- built seed:
  `13bcf2b44d72babdad12ba72ceaf926d73a54669e073cc0bf7cb3ed45e5bf500`

Do not run this on Dawgyg's host. Tart does not publish AppleAVE2Driver. The
next step is one exact-build disposable physical Apple-Silicon run as uid501:

```sh
cd /Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5416b
./run_capture_hevc.sh
# Confirm hardware encoder and selector captures first.
export AVE2_DISPOSABLE_PHYSICAL_MAC=YES
./run_once_hevc.sh 0x80000000 1 4
```

If Prepare returns before SPS generation, reboot if necessary and use selector
5. Preserve the panic plus the generated `.orig.bin`, `.sent.bin`, and metadata.
