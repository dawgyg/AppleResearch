#include <CoreFoundation/CoreFoundation.h>
#include <CoreMedia/CoreMedia.h>
#include <CoreVideo/CoreVideo.h>
#include <VideoToolbox/VideoToolbox.h>

#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct callback_state {
    unsigned callbacks;
    unsigned samples;
    OSStatus last_status;
};

static void
encode_callback(void *opaque, void *source_frame_refcon, OSStatus status,
                VTEncodeInfoFlags flags, CMSampleBufferRef sample)
{
    struct callback_state *state = opaque;
    (void)source_frame_refcon;

    state->callbacks++;
    state->last_status = status;
    if (sample != NULL && CMSampleBufferDataIsReady(sample)) {
        state->samples++;
    }
    fprintf(stderr,
            "[seed] callback=%u status=%d flags=0x%x sample=%s ready=%s\n",
            state->callbacks, status, flags, sample != NULL ? "yes" : "no",
            sample != NULL && CMSampleBufferDataIsReady(sample) ? "yes" : "no");
}

static void
fill_pixel_buffer(CVPixelBufferRef pixel, unsigned frame_number)
{
    CVReturn cvret = CVPixelBufferLockBaseAddress(pixel, 0);
    if (cvret != kCVReturnSuccess) {
        fprintf(stderr, "[seed] CVPixelBufferLockBaseAddress: %d\n", cvret);
        exit(2);
    }

    if (CVPixelBufferIsPlanar(pixel) && CVPixelBufferGetPlaneCount(pixel) >= 2) {
        uint8_t *y = CVPixelBufferGetBaseAddressOfPlane(pixel, 0);
        uint8_t *uv = CVPixelBufferGetBaseAddressOfPlane(pixel, 1);
        size_t y_stride = CVPixelBufferGetBytesPerRowOfPlane(pixel, 0);
        size_t uv_stride = CVPixelBufferGetBytesPerRowOfPlane(pixel, 1);
        size_t y_height = CVPixelBufferGetHeightOfPlane(pixel, 0);
        size_t uv_height = CVPixelBufferGetHeightOfPlane(pixel, 1);

        for (size_t row = 0; row < y_height; row++) {
            memset(y + row * y_stride, (int)(16 + (frame_number & 31)),
                   y_stride);
        }
        for (size_t row = 0; row < uv_height; row++) {
            memset(uv + row * uv_stride, 128, uv_stride);
        }
    } else {
        uint8_t *base = CVPixelBufferGetBaseAddress(pixel);
        size_t bytes = CVPixelBufferGetDataSize(pixel);
        memset(base, (int)(frame_number & 0xff), bytes);
    }

    CVPixelBufferUnlockBaseAddress(pixel, 0);
}

static void
set_session_property(VTCompressionSessionRef session, CFStringRef key,
                     CFTypeRef value, const char *name)
{
    OSStatus status = VTSessionSetProperty(session, key, value);
    if (status != noErr) {
        fprintf(stderr, "[seed] VTSessionSetProperty(%s): %d\n", name, status);
        exit(2);
    }
}

static bool
session_uses_hardware(VTCompressionSessionRef session)
{
    CFTypeRef value = NULL;
    bool result = false;
    OSStatus status = VTSessionCopyProperty(
        session, kVTCompressionPropertyKey_UsingHardwareAcceleratedVideoEncoder,
        NULL, &value);

    if (status == noErr && value != NULL && CFGetTypeID(value) == CFBooleanGetTypeID()) {
        result = CFBooleanGetValue((CFBooleanRef)value);
    }
    if (value != NULL) {
        CFRelease(value);
    }
    return result;
}

int
main(int argc, char **argv)
{
    const int32_t width = 1920;
    const int32_t height = 1080;
    unsigned frame_count = 3;
    struct callback_state state = {0};
    VTCompressionSessionRef session = NULL;
    CFDictionaryRef encoder_spec = NULL;
    CFMutableDictionaryRef pixel_attrs = NULL;
    CFNumberRef pixel_format = NULL;
    CFNumberRef width_number = NULL;
    CFNumberRef height_number = NULL;
    CFNumberRef bitrate = NULL;
    CFDictionaryRef surface_props = NULL;
    const char *codec_env = getenv("AVE2_CODEC");
    bool use_hevc = codec_env != NULL && strcmp(codec_env, "hevc") == 0;
    CMVideoCodecType codec =
        use_hevc ? kCMVideoCodecType_HEVC : kCMVideoCodecType_H264;
    CFStringRef profile = use_hevc ? kVTProfileLevel_HEVC_Main_AutoLevel
                                   : kVTProfileLevel_H264_Main_AutoLevel;
    const char *codec_name = use_hevc ? "HEVC" : "H.264";
    OSStatus status;

    if (argc == 2) {
        char *end = NULL;
        unsigned long parsed = strtoul(argv[1], &end, 0);
        if (end == argv[1] || *end != '\0' || parsed == 0 || parsed > 60) {
            fprintf(stderr, "usage: %s [frame-count:1..60]\n", argv[0]);
            return 2;
        }
        frame_count = (unsigned)parsed;
    }

    const void *spec_keys[] = {
        kVTVideoEncoderSpecification_RequireHardwareAcceleratedVideoEncoder,
    };
    const void *spec_values[] = {kCFBooleanTrue};
    encoder_spec = CFDictionaryCreate(NULL, spec_keys, spec_values, 1,
                                      &kCFTypeDictionaryKeyCallBacks,
                                      &kCFTypeDictionaryValueCallBacks);

    pixel_attrs = CFDictionaryCreateMutable(
        NULL, 4, &kCFTypeDictionaryKeyCallBacks,
        &kCFTypeDictionaryValueCallBacks);
    int32_t pixel_format_value = kCVPixelFormatType_420YpCbCr8BiPlanarVideoRange;
    pixel_format = CFNumberCreate(NULL, kCFNumberSInt32Type, &pixel_format_value);
    width_number = CFNumberCreate(NULL, kCFNumberSInt32Type, &width);
    height_number = CFNumberCreate(NULL, kCFNumberSInt32Type, &height);
    CFDictionarySetValue(pixel_attrs, kCVPixelBufferPixelFormatTypeKey,
                         pixel_format);
    CFDictionarySetValue(pixel_attrs, kCVPixelBufferWidthKey, width_number);
    CFDictionarySetValue(pixel_attrs, kCVPixelBufferHeightKey, height_number);
    surface_props = CFDictionaryCreate(NULL, NULL, NULL, 0,
                                       &kCFTypeDictionaryKeyCallBacks,
                                       &kCFTypeDictionaryValueCallBacks);
    CFDictionarySetValue(pixel_attrs, kCVPixelBufferIOSurfacePropertiesKey,
                         surface_props);

    fprintf(stderr,
            "[seed] creating required-hardware %s session %dx%d, frames=%u\n",
            codec_name, width, height, frame_count);
    status = VTCompressionSessionCreate(
        NULL, width, height, codec, encoder_spec, pixel_attrs, NULL,
        encode_callback, &state, &session);
    if (status != noErr || session == NULL) {
        fprintf(stderr, "[seed] VTCompressionSessionCreate: %d\n", status);
        return 3;
    }

    set_session_property(session, kVTCompressionPropertyKey_RealTime,
                         kCFBooleanTrue, "RealTime");
    set_session_property(session, kVTCompressionPropertyKey_AllowFrameReordering,
                         kCFBooleanFalse, "AllowFrameReordering");
    set_session_property(session, kVTCompressionPropertyKey_ProfileLevel,
                         profile, "ProfileLevel");
    int32_t bitrate_value = 8 * 1000 * 1000;
    bitrate = CFNumberCreate(NULL, kCFNumberSInt32Type, &bitrate_value);
    set_session_property(session, kVTCompressionPropertyKey_AverageBitRate,
                         bitrate, "AverageBitRate");

    const char *prepare_hold_env =
        getenv("AVE2_SEED_PREPARE_HOLD_SECONDS");
    if (prepare_hold_env != NULL && *prepare_hold_env != '\0') {
        char *end = NULL;
        unsigned long hold_seconds = strtoul(prepare_hold_env, &end, 0);
        if (end != prepare_hold_env && *end == '\0' && hold_seconds <= 120) {
            fprintf(stderr,
                    "[seed] holding before prepare for %lu seconds\n",
                    hold_seconds);
            sleep((unsigned)hold_seconds);
        }
    }

    status = VTCompressionSessionPrepareToEncodeFrames(session);
    if (status != noErr) {
        fprintf(stderr, "[seed] VTCompressionSessionPrepareToEncodeFrames: %d\n",
                status);
        return 4;
    }
    fprintf(stderr, "[seed] hardware encoder=%s\n",
            session_uses_hardware(session) ? "yes" : "no");
    const char *hold_env = getenv("AVE2_SEED_HOLD_SECONDS");
    if (hold_env != NULL && *hold_env != '\0') {
        char *end = NULL;
        unsigned long hold_seconds = strtoul(hold_env, &end, 0);
        if (end != hold_env && *end == '\0' && hold_seconds <= 120) {
            fprintf(stderr, "[seed] holding session for %lu seconds\n",
                    hold_seconds);
            sleep((unsigned)hold_seconds);
        }
    }

    CVPixelBufferPoolRef pool = VTCompressionSessionGetPixelBufferPool(session);
    if (pool == NULL) {
        fprintf(stderr, "[seed] no pixel buffer pool\n");
        return 5;
    }

    for (unsigned frame = 0; frame < frame_count; frame++) {
        CVPixelBufferRef pixel = NULL;
        CVReturn cvret = CVPixelBufferPoolCreatePixelBuffer(NULL, pool, &pixel);
        if (cvret != kCVReturnSuccess || pixel == NULL) {
            fprintf(stderr, "[seed] CVPixelBufferPoolCreatePixelBuffer: %d\n",
                    cvret);
            return 6;
        }
        fill_pixel_buffer(pixel, frame);

        CFDictionaryRef frame_props = NULL;
        if (frame == 0) {
            const void *keys[] = {kVTEncodeFrameOptionKey_ForceKeyFrame};
            const void *values[] = {kCFBooleanTrue};
            frame_props = CFDictionaryCreate(
                NULL, keys, values, 1, &kCFTypeDictionaryKeyCallBacks,
                &kCFTypeDictionaryValueCallBacks);
        }

        VTEncodeInfoFlags flags = 0;
        status = VTCompressionSessionEncodeFrame(
            session, pixel, CMTimeMake((int64_t)frame, 30), CMTimeMake(1, 30),
            frame_props, NULL, &flags);
        fprintf(stderr, "[seed] encode frame=%u status=%d flags=0x%x\n", frame,
                status, flags);
        if (frame_props != NULL) {
            CFRelease(frame_props);
        }
        CVPixelBufferRelease(pixel);
        if (status != noErr) {
            return 7;
        }
    }

    status = VTCompressionSessionCompleteFrames(session, kCMTimeInvalid);
    fprintf(stderr,
            "[seed] complete status=%d callbacks=%u samples=%u last=%d\n",
            status, state.callbacks, state.samples, state.last_status);

    VTCompressionSessionInvalidate(session);
    CFRelease(session);
    CFRelease(encoder_spec);
    CFRelease(pixel_attrs);
    CFRelease(pixel_format);
    CFRelease(width_number);
    CFRelease(height_number);
    CFRelease(bitrate);
    CFRelease(surface_props);
    return status == noErr && state.samples != 0 ? 0 : 8;
}
