#!/bin/zsh
set -euo pipefail

ROOT="${0:A:h}"
SERVICE_PATH="/System/Library/Frameworks/VideoToolbox.framework/Versions/A/XPCServices/VTEncoderXPCService.xpc/Contents/MacOS/VTEncoderXPCService"
STAMP="$(date +%Y%m%dT%H%M%S)"
OUT="$ROOT/artifacts/hevc-lldb-capture-$STAMP"
typeset -A existing_pids
typeset seed_pid=""
typeset target_pid=""

mkdir -p "$OUT"

for pid in ${(f)"$(pgrep -f "$SERVICE_PATH" 2>/dev/null || true)"}; do
  [[ -n "$pid" ]] && existing_pids[$pid]=1
done

env -u DYLD_INSERT_LIBRARIES -u AVE2_ARM -u AVE2_LLDB_ARM \
  -u AVE2_HEVC_SPS_VALUE -u AVE2_DISPOSABLE_PHYSICAL_MAC \
  AVE2_CODEC=hevc \
  AVE2_SEED_PREPARE_HOLD_SECONDS=20 \
  AVE2_SEED_HOLD_SECONDS=3 \
  "$ROOT/build/ave2_vt_h264_seed" 1 >"$OUT/seed.log" 2>&1 &
seed_pid=$!

for _ in {1..100}; do
  for pid in ${(f)"$(pgrep -f "$SERVICE_PATH" 2>/dev/null || true)"}; do
    if [[ -n "$pid" && ${+existing_pids[$pid]} -eq 0 ]]; then
      target_pid="$pid"
      break 2
    fi
  done
  sleep 0.1
done

if [[ -z "$target_pid" ]]; then
  print -u2 "failed to find the transient VTEncoderXPCService"
  kill -TERM "$seed_pid" 2>/dev/null || true
  wait "$seed_pid" 2>/dev/null || true
  exit 3
fi

print "capture-only: seed=$seed_pid target=$target_pid artifacts=$OUT"
env -u AVE2_LLDB_ARM -u AVE2_HEVC_SPS_VALUE \
  -u AVE2_DISPOSABLE_PHYSICAL_MAC \
  AVE2_LLDB_CAPTURE_DIR="$OUT" \
  lldb -b -p "$target_pid" \
    -o "command script import $ROOT/mutate_vtencoder.py" \
    -o continue |& tee "$OUT/lldb.log"

wait "$seed_pid"

typeset -a originals
originals=("$OUT"/*.orig.bin(N))
if (( ${#originals} < 2 )); then
  print -u2 "capture incomplete: expected selector 4 and selector 5"
  exit 4
fi
for original in $originals; do
  sent="${original%.orig.bin}.sent.bin"
  [[ -f "$sent" ]] || { print -u2 "missing $sent"; exit 5; }
  cmp -s "$original" "$sent" || {
    print -u2 "capture-only invariant failed: $original differs from $sent"
    exit 6
  }
done
rg -q '^armed=no$' "$OUT"/*.meta.txt
rg -q '^mutated=no$' "$OUT"/*.meta.txt
shasum -a 256 "$OUT"/*.orig.bin "$OUT"/*.sent.bin
print "capture-only validation passed: $OUT"

