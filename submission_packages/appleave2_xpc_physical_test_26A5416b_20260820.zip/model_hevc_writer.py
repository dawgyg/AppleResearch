#!/usr/bin/env python3
"""Model the 26A5416b HEVC SPS dword-to-signed-count writer transition."""


def s32(value: int) -> int:
    value &= 0xFFFFFFFF
    return value - 0x100000000 if value & 0x80000000 else value


def trunc_div8(value: int) -> int:
    return value // 8 if value >= 0 else -((-value) // 8)


def poison(bit_position: int, field: int):
    count = s32(field + 4)
    alignment = 8 - (bit_position % 8)
    chunk = count if count < alignment else alignment
    after = s32(bit_position + chunk)
    if after % 8 == 0:
        return count, after, trunc_div8(s32(after - 8)), 0
    for later_bits in range(1, 9):
        old = after
        after = s32(after + 1)
        if after % 8 == 0:
            return count, after, trunc_div8(s32(old - 7)), later_bits
    raise AssertionError("byte boundary not reached")


def main():
    print("field initial signed_count after first_store_index later_bits")
    for field in (0x80000000, 0xFFFFF000, 0xFFFFFF00):
        for initial in (256, 512, 1024, 2048, 4096):
            count, after, index, later = poison(initial, field)
            print(f"0x{field:08x} {initial:7d} {count:12d} {after:12d} "
                  f"{index:17d} {later:10d}")


if __name__ == "__main__":
    main()
