#!/bin/bash
set +e
PROBE=/Users/test/dsh_repair_probe
# fresh post-reboot helper; attacker is naturally first connection => cached=501

echo "### FORWARD reliability sanity (root-owned /tmp file -> attacker) ###"
for i in 1 2; do
  T=/tmp/sane_${i}_$$; echo test | sudo -S sh -c ": > '$T'; chown root:wheel '$T'; chmod 600 '$T'"
  sandbox-exec -p '(version 1)(allow default)' "$PROBE" "$T" >/dev/null 2>&1
  sleep 1
  echo "  sane$i: root -> $(stat -f '%Su' $T)"
  echo test | sudo -S rm -f "$T"
done

echo
echo "### PATH SCOPE — which root-owned locations will forward chown reach? ###"
LOCS=(
  "/tmp/sc_tmp"
  "/private/var/tmp/sc_pvt"
  "/Users/Shared/sc_shared"
  "/Library/sc_lib"
  "/Library/LaunchDaemons/sc_ld.plist"
  "/private/etc/sc_etc"
  "/private/etc/sudoers.d/sc_sudoers"
  "/var/folders/sc_vf"
)
for T in "${LOCS[@]}"; do
  d=$(dirname "$T"); [ -d "$d" ] || { echo "  $T : SKIP (no dir)"; continue; }
  echo test | sudo -S sh -c "rm -f '$T'; : > '$T' 2>/dev/null; chown root:wheel '$T' 2>/dev/null; chmod 600 '$T' 2>/dev/null"
  [ "$(stat -f '%Su' "$T" 2>/dev/null)" = "root" ] || { echo "  $T : SKIP (not root-owned)"; continue; }
  sandbox-exec -p '(version 1)(allow default)' "$PROBE" "$T" >/dev/null 2>&1
  sleep 1
  a=$(stat -f '%Su' "$T" 2>/dev/null)
  [ "$a" = "test" ] && R="*** CHOWNED to attacker ***" || R="(rejected, stayed $a)"
  echo "  $T : root -> $a   $R"
  echo test | sudo -S rm -f "$T" 2>/dev/null
done
echo
echo "=== DSH health ==="
echo test | sudo -S launchctl print system/com.apple.DesktopServicesHelper 2>&1 | egrep -i 'state =|successive' | head -3