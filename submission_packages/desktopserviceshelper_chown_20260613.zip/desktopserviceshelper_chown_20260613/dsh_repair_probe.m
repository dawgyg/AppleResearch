#import <Foundation/Foundation.h>
#include <dispatch/dispatch.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <xpc/xpc.h>

static void dump_xpc(const char *prefix, xpc_object_t obj) {
    char *desc = xpc_copy_description(obj);
    fprintf(stderr, "%s%s\n", prefix, desc ? desc : "(null)");
    free(desc);
}

static NSData *archive_paths(const char *path) {
    @autoreleasepool {
        NSString *nsPath = [NSString stringWithUTF8String:path];
        NSArray *paths = @[ nsPath ];
        NSError *error = nil;
        NSData *data = [NSKeyedArchiver archivedDataWithRootObject:paths
                                             requiringSecureCoding:YES
                                                             error:&error];
        if (!data) {
            fprintf(stderr, "archive failed: %s\n",
                    [[error description] UTF8String] ?: "(unknown)");
            return nil;
        }
        return [data retain];
    }
}

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc != 2) {
            fprintf(stderr, "usage: %s /path/to/repair\n", argv[0]);
            return 2;
        }

        NSData *pathsData = archive_paths(argv[1]);
        if (!pathsData) {
            return 1;
        }

        dispatch_queue_t q = dispatch_queue_create("dsh-repair-probe", NULL);
        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        __block int got_terminal_event = 0;

        xpc_connection_t conn =
            xpc_connection_create_mach_service("com.apple.DesktopServicesHelper", NULL, 0);
        if (!conn) {
            fprintf(stderr, "failed to create DesktopServicesHelper connection\n");
            [pathsData release];
            return 1;
        }

        xpc_connection_set_target_queue(conn, q);
        xpc_connection_set_event_handler(conn, ^(xpc_object_t event) {
            dump_xpc("event: ", event);
            if (xpc_get_type(event) == XPC_TYPE_ERROR) {
                got_terminal_event = 1;
                dispatch_semaphore_signal(sem);
                return;
            }

            const char *request = xpc_dictionary_get_string(event, "request");
            if (request && strstr(request, "Reply")) {
                got_terminal_event = 1;
                dispatch_semaphore_signal(sem);
            }
        });
        xpc_connection_resume(conn);

        xpc_object_t msg = xpc_dictionary_create(NULL, NULL, 0);
        xpc_dictionary_set_string(msg, "request", "RepairPermissionsForCloudItems");
        xpc_dictionary_set_data(msg, "Paths", [pathsData bytes], [pathsData length]);
        dump_xpc("sending: ", msg);
        xpc_connection_send_message(conn, msg);
        xpc_release(msg);

        long waited = dispatch_semaphore_wait(
            sem, dispatch_time(DISPATCH_TIME_NOW, 8LL * NSEC_PER_SEC));
        if (waited != 0) {
            fprintf(stderr, "timeout waiting for reply (got_terminal_event=%d)\n",
                    got_terminal_event);
        }

        xpc_connection_cancel(conn);
        xpc_release(conn);
        [pathsData release];
        sleep(1);
        return waited == 0 ? 0 : 3;
    }
}
