# Persistence from shipping macOS 26.6 through current macOS 27

The selector-1 source-only bound and destination-capacity omission are present
in shipping macOS 26.6 `25G72` and all archived macOS 27 builds checked through
current `26A5421a`.

| Build | kext SHA-256 | UUID | source-space check | copy sink |
|---|---|---|---:|---:|
| `25G72` | `5bd5dd6b431484e59ccd2b4ab658970492c67de4338acecb8b2b8c2d6f3cf933` | `758DCD16-E2E4-3ACA-B181-B749589D63F6` | `0xfffffe0009ec1200` | `0xfffffe0009ec1294` |
| `26A5378n` | `16a114d2f9cd0cb92c7a95621cfc37f4b516e33f07035c9dc3114a3534fa759d` | `81A28B1E-18EB-3022-9B6D-1F344CB85D73` | `0xfffffe000a1f4358` | `0xfffffe000a1f43e8` |
| `26A5416b` | `a572ea1208c48f501b84a1261211f11244b47935ba8be9b787463557fc31e43e` | `90B8D9E2-FEFE-3473-ADE2-F3F9FA7F7E80` | `0xfffffe000a20cc50` | `0xfffffe000a20cce0` |
| `26A5421a` | `3530146e10d1718c4a93fd67670e2d86f58ed4db83a3c205e3d99b1cfd87842d` | `90B8D9E2-FEFE-3473-ADE2-F3F9FA7F7E80` | `0xfffffe000a20e450` | `0xfffffe000a20e4e0` |

At each source check, the code compares the client submit length with available
transmit-ring bytes. At each following `csel`, the length is reduced only to
the transmit-ring wrap distance. The destination comes from one of eight
fixed-page output records. No intervening instruction compares the selected
copy length with that record's page capacity.

For `25G72`, `AppleUSBSerial::allocResources` loads the architecture page shift
and calls the output-record allocator with `x2 = 1 << PAGE_SHIFT`. Its selector
path then reaches `_memmove @ 0xfffffe0009ec1294` with the exact same missing
destination bound. This is therefore a persistent shipping-code bug rather
than a macOS 27 beta regression.

The attached `persistence/*.dis` files contain the complete relevant routines,
and the extracted kext images permit independent symbol/address verification.

