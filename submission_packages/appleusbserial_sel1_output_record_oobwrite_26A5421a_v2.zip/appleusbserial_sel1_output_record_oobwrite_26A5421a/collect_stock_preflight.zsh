#!/bin/zsh
set -euo pipefail

cd "${0:A:h}"
out="stock_preflight_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -p "$out"

{
  sw_vers
  uname -a
  sysctl kern.version
  id
  csrutil status
  csrutil authenticated-root status
  nvram boot-args 2>&1 || true
} | tee "$out/environment.txt"

if [[ $EUID -eq 0 ]]; then
  print -u2 "Refusing: run as an ordinary non-root user."
  exit 2
fi

if ! csrutil status | grep -q 'status: enabled'; then
  print -u2 "Refusing: SIP is not enabled."
  exit 3
fi

bootargs=$({ nvram boot-args 2>/dev/null || true; } |
  sed 's/^boot-args[[:space:]]*//')
if [[ -n "$bootargs" ]]; then
  print -u2 "Refusing: boot-args is non-empty: $bootargs"
  exit 4
fi

ioreg -r -c AppleUSBACMData -l | tee "$out/ioreg_AppleUSBACMData.txt"
if ! grep -q 'AppleUSBACMData' "$out/ioreg_AppleUSBACMData.txt"; then
  print -u2 "No AppleUSBACMData provider is attached."
  exit 5
fi

clang -Wall -Wextra -O2 -framework IOKit -framework CoreFoundation \
  appleusbserial_sel1_probe.c -o "$out/appleusbserial_sel1_probe"

"$out/appleusbserial_sel1_probe" --preflight | tee "$out/preflight.log"
shasum -a 256 appleusbserial_sel1_probe.c "$out/appleusbserial_sel1_probe" \
  > "$out/SHA256SUMS"

print "Stock preflight complete: $out"
print "No oversized selector-1 submission was made."

