#!/usr/sbin/dtrace -s

#pragma D option quiet

fbt:com.apple.driver.usb.serial:_ZN24AppleUSBSerialUserClient14externalMethodEjP25IOExternalMethodArgumentsP24IOExternalMethodDispatchP8OSObjectPv:entry
/arg1 == 1/
{
    self->active = 1;
    self->provider = *(uintptr_t *)(arg0 + 0xd8);
    self->pool = *(uintptr_t *)(self->provider + 0xe0);
    self->index = *(uint8_t *)(self->provider + 0xf1) & 7;
    self->record = *(uintptr_t *)(self->pool + self->index * 8);
    self->backing = *(uintptr_t *)(self->record + 0xb8);
    self->p0 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x00) + 0xb8);
    self->p1 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x08) + 0xb8);
    self->p2 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x10) + 0xb8);
    self->p3 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x18) + 0xb8);
    self->p4 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x20) + 0xb8);
    self->p5 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x28) + 0xb8);
    self->p6 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x30) + 0xb8);
    self->p7 = *(uintptr_t *)(*(uintptr_t *)(self->pool + 0x38) + 0xb8);
    self->adjacent =
        self->p0 == self->backing + 0x4000 ||
        self->p1 == self->backing + 0x4000 ||
        self->p2 == self->backing + 0x4000 ||
        self->p3 == self->backing + 0x4000 ||
        self->p4 == self->backing + 0x4000 ||
        self->p5 == self->backing + 0x4000 ||
        self->p6 == self->backing + 0x4000 ||
        self->p7 == self->backing + 0x4000;
    self->before0 = self->adjacent ? *(uint64_t *)(self->backing + 0x4000) : 0;
    self->before1 = self->adjacent ? *(uint64_t *)(self->backing + 0x4008) : 0;

    printf("ENTRY index=%u backing=%p adjacent_output=%u neighbor_before=%#llx/%#llx\n",
        self->index, (void *)self->backing, self->adjacent,
        self->before0, self->before1);
    printf("POOL %p %p %p %p %p %p %p %p\n",
        (void *)self->p0, (void *)self->p1, (void *)self->p2,
        (void *)self->p3, (void *)self->p4, (void *)self->p5,
        (void *)self->p6, (void *)self->p7);
}

fbt:com.apple.driver.usb.serial:_ZN24AppleUSBSerialUserClient14externalMethodEjP25IOExternalMethodArgumentsP24IOExternalMethodDispatchP8OSObjectPv:return
/self->active/
{
    printf("RETURN index=%u backing=%p adjacent_output=%u neighbor_after=%#llx/%#llx\n",
        self->index, (void *)self->backing, self->adjacent,
        self->adjacent ? *(uint64_t *)(self->backing + 0x4000) : 0,
        self->adjacent ? *(uint64_t *)(self->backing + 0x4008) : 0);

    self->active = 0;
    self->provider = 0;
    self->pool = 0;
    self->index = 0;
    self->record = 0;
    self->backing = 0;
    self->adjacent = 0;
    self->before0 = 0;
    self->before1 = 0;
    self->p0 = 0;
    self->p1 = 0;
    self->p2 = 0;
    self->p3 = 0;
    self->p4 = 0;
    self->p5 = 0;
    self->p6 = 0;
    self->p7 = 0;
}
