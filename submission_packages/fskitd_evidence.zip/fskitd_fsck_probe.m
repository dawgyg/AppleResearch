#import <Foundation/Foundation.h>
#import <dlfcn.h>

@protocol FSClientXPC
- (void)currentTasks:(void (^)(id result, NSError *error))reply;
- (void)currentResourceIDs:(void (^)(id result, NSError *error))reply;
- (void)startFSCKWithDevice:(NSString *)device
                    volumes:(NSArray *)volumes
               replyHandler:(void (^)(NSUUID *taskID, NSError *error))reply;
- (void)doneFSCKWithTask:(NSUUID *)taskID
            replyHandler:(void (^)(NSError *error))reply;
@end

static NSSet<Class> *AllowedClasses(void) {
    NSMutableSet<Class> *classes = [NSMutableSet setWithObjects:
        [NSArray class], [NSMutableArray class],
        [NSDictionary class], [NSMutableDictionary class],
        [NSString class], [NSMutableString class],
        [NSNumber class], [NSError class], [NSURL class],
        [NSData class], [NSDate class], [NSUUID class],
        [NSSet class], [NSMutableSet class], nil];

    const char *names[] = {
        "FSTaskDescription",
        "FSResource",
        "FSBlockDeviceResource",
        "FSGenericURLResource",
        "FSPathURLResource",
        "FSContainerIdentifier",
        "FSVolumeIdentifier",
        "FSModuleIdentity",
        "FSTaskOptions",
        "FSTaskOptionsBundle"
    };
    for (size_t i = 0; i < sizeof(names) / sizeof(names[0]); i++) {
        Class cls = NSClassFromString([NSString stringWithUTF8String:names[i]]);
        if (cls) {
            [classes addObject:cls];
        }
    }
    return classes;
}

static void ConfigureInterface(NSXPCInterface *iface) {
    NSSet<Class> *classes = AllowedClasses();

    [iface setClasses:classes
          forSelector:@selector(currentTasks:)
        argumentIndex:0
              ofReply:YES];
    [iface setClasses:classes
          forSelector:@selector(currentResourceIDs:)
        argumentIndex:0
              ofReply:YES];
    [iface setClasses:classes
          forSelector:@selector(startFSCKWithDevice:volumes:replyHandler:)
        argumentIndex:1
              ofReply:NO];
    [iface setClasses:classes
          forSelector:@selector(startFSCKWithDevice:volumes:replyHandler:)
        argumentIndex:0
              ofReply:YES];
    [iface setClasses:classes
          forSelector:@selector(startFSCKWithDevice:volumes:replyHandler:)
        argumentIndex:1
              ofReply:YES];
    [iface setClasses:classes
          forSelector:@selector(doneFSCKWithTask:replyHandler:)
        argumentIndex:0
              ofReply:YES];
}

static NSString *KVCString(id obj, NSString *key) {
    @try {
        id value = [obj valueForKey:key];
        return value ? [value description] : @"(nil)";
    } @catch (NSException *ex) {
        return [NSString stringWithFormat:@"<%@>", ex.name];
    }
}

static void DumpResource(id resource, const char *prefix) {
    if (!resource) {
        printf("%sresource=(nil)\n", prefix);
        return;
    }
    printf("%sresource.class=%s desc=%s\n",
           prefix,
           NSStringFromClass([resource class]).UTF8String,
           [[resource description] UTF8String]);
    for (NSString *key in @[@"kind", @"resourceID", @"BSDName", @"writable", @"revoked"]) {
        printf("%sresource.%s=%s\n",
               prefix,
               key.UTF8String,
               [KVCString(resource, key) UTF8String]);
    }
}

static void DumpTask(id task, NSUInteger idx) {
    printf("  task[%lu].class=%s desc=%s\n",
           (unsigned long)idx,
           NSStringFromClass([task class]).UTF8String,
           [[task description] UTF8String]);
    for (NSString *key in @[@"taskID", @"taskState", @"taskPurpose", @"taskBundleID",
                            @"taskExtensionInstanceID", @"taskInitiatorID", @"taskSigningID"]) {
        printf("  task[%lu].%s=%s\n",
               (unsigned long)idx,
               key.UTF8String,
               [KVCString(task, key) UTF8String]);
    }
    id resource = nil;
    @try {
        resource = [task valueForKey:@"taskResource"];
    } @catch (NSException *ex) {
        printf("  task[%lu].taskResource=<%s>\n", (unsigned long)idx, ex.name.UTF8String);
    }
    DumpResource(resource, "  ");
}

static void DumpArrayDetails(NSString *label, id result) {
    if (![result isKindOfClass:[NSArray class]]) {
        return;
    }
    NSArray *array = (NSArray *)result;
    printf("%s.detail.count=%lu\n", label.UTF8String, (unsigned long)array.count);
    [array enumerateObjectsUsingBlock:^(id obj, NSUInteger idx, BOOL *stop) {
        if ([label containsString:@"Tasks"]) {
            DumpTask(obj, idx);
        } else {
            printf("  item[%lu].class=%s desc=%s\n",
                   (unsigned long)idx,
                   NSStringFromClass([obj class]).UTF8String,
                   [[obj description] UTF8String]);
        }
    }];
}

static id SyncObjectCall(NSString *label, void (^invoke)(void (^reply)(id, NSError *))) {
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    __block id result = nil;
    __block NSError *err = nil;
    invoke(^(id obj, NSError *error) {
        result = obj;
        err = error;
        dispatch_semaphore_signal(sem);
    });
    dispatch_time_t timeout = dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC);
    if (dispatch_semaphore_wait(sem, timeout) != 0) {
        printf("%s: TIMEOUT\n", label.UTF8String);
        return nil;
    }
    if (err) {
        printf("%s: ERROR domain=%s code=%ld desc=%s\n",
               label.UTF8String,
               err.domain.UTF8String,
               (long)err.code,
               err.localizedDescription.UTF8String);
    } else {
        printf("%s: OK class=%s value=%s\n",
               label.UTF8String,
               result ? NSStringFromClass([result class]).UTF8String : "(nil)",
               result ? [[result description] UTF8String] : "(nil)");
        DumpArrayDetails(label, result);
    }
    return result;
}

static NSError *SyncDone(id<FSClientXPC> proxy, NSUUID *uuid) {
    dispatch_semaphore_t sem = dispatch_semaphore_create(0);
    __block NSError *err = nil;
    [proxy doneFSCKWithTask:uuid replyHandler:^(NSError *error) {
        err = error;
        dispatch_semaphore_signal(sem);
    }];
    dispatch_time_t timeout = dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC);
    if (dispatch_semaphore_wait(sem, timeout) != 0) {
        printf("doneFSCKWithTask: TIMEOUT\n");
        return nil;
    }
    if (err) {
        printf("doneFSCKWithTask: ERROR domain=%s code=%ld desc=%s\n",
               err.domain.UTF8String,
               (long)err.code,
               err.localizedDescription.UTF8String);
    } else {
        printf("doneFSCKWithTask: OK\n");
    }
    return err;
}

int main(int argc, const char *argv[]) {
    @autoreleasepool {
        dlopen("/System/Library/Frameworks/FSKit.framework/FSKit", RTLD_LAZY);
        BOOL noCleanup = NO;
        BOOL doneOnly = NO;
        NSUUID *doneOnlyID = nil;
        int deviceArg = 1;
        if (argc > 1 && strcmp(argv[1], "--no-cleanup") == 0) {
            noCleanup = YES;
            deviceArg = 2;
        } else if (argc > 2 && strcmp(argv[1], "--done") == 0) {
            doneOnly = YES;
            doneOnlyID = [[NSUUID alloc] initWithUUIDString:[NSString stringWithUTF8String:argv[2]]];
        }

        NSString *device = argc > deviceArg ? [NSString stringWithUTF8String:argv[deviceArg]] : @"codexbogus";
        NSArray *volumes = @[];

        NSXPCInterface *iface = [NSXPCInterface interfaceWithProtocol:@protocol(FSClientXPC)];
        ConfigureInterface(iface);

        NSXPCConnection *conn = [[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.filesystems.fskitd"
                                                                          options:NSXPCConnectionPrivileged];
        conn.remoteObjectInterface = iface;
        conn.invalidationHandler = ^{
            fprintf(stderr, "connection invalidated\n");
        };
        conn.interruptionHandler = ^{
            fprintf(stderr, "connection interrupted\n");
        };
        [conn resume];

        id<FSClientXPC> proxy = [conn remoteObjectProxyWithErrorHandler:^(NSError *error) {
            fprintf(stderr, "proxy error domain=%s code=%ld desc=%s\n",
                    error.domain.UTF8String,
                    (long)error.code,
                    error.localizedDescription.UTF8String);
        }];

        printf("uid=%d device=%s noCleanup=%d doneOnly=%d\n",
               getuid(),
               device.UTF8String,
               noCleanup,
               doneOnly);
        SyncObjectCall(@"before.currentResourceIDs", ^(void (^reply)(id, NSError *)) {
            [proxy currentResourceIDs:reply];
        });
        SyncObjectCall(@"before.currentTasks", ^(void (^reply)(id, NSError *)) {
            [proxy currentTasks:reply];
        });

        if (doneOnly) {
            if (!doneOnlyID) {
                printf("doneOnly: invalid UUID\n");
                [conn invalidate];
                return 2;
            }
            SyncDone(proxy, doneOnlyID);
            SyncObjectCall(@"after_done.currentResourceIDs", ^(void (^reply)(id, NSError *)) {
                [proxy currentResourceIDs:reply];
            });
            SyncObjectCall(@"after_done.currentTasks", ^(void (^reply)(id, NSError *)) {
                [proxy currentTasks:reply];
            });
            [conn invalidate];
            return 0;
        }

        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        __block NSUUID *taskID = nil;
        __block NSError *startErr = nil;
        [proxy startFSCKWithDevice:device volumes:volumes replyHandler:^(NSUUID *uuid, NSError *error) {
            taskID = uuid;
            startErr = error;
            dispatch_semaphore_signal(sem);
        }];
        dispatch_time_t timeout = dispatch_time(DISPATCH_TIME_NOW, 8 * NSEC_PER_SEC);
        if (dispatch_semaphore_wait(sem, timeout) != 0) {
            printf("startFSCKWithDevice: TIMEOUT\n");
        } else if (startErr) {
            printf("startFSCKWithDevice: ERROR domain=%s code=%ld desc=%s uuid=%s\n",
                   startErr.domain.UTF8String,
                   (long)startErr.code,
                   startErr.localizedDescription.UTF8String,
                   taskID.UUIDString.UTF8String ?: "(nil)");
        } else {
            printf("startFSCKWithDevice: OK uuid=%s\n", taskID.UUIDString.UTF8String);
        }

        SyncObjectCall(@"after_start.currentResourceIDs", ^(void (^reply)(id, NSError *)) {
            [proxy currentResourceIDs:reply];
        });
        SyncObjectCall(@"after_start.currentTasks", ^(void (^reply)(id, NSError *)) {
            [proxy currentTasks:reply];
        });

        if (taskID && !noCleanup) {
            SyncDone(proxy, taskID);
            SyncObjectCall(@"after_done.currentResourceIDs", ^(void (^reply)(id, NSError *)) {
                [proxy currentResourceIDs:reply];
            });
            SyncObjectCall(@"after_done.currentTasks", ^(void (^reply)(id, NSError *)) {
                [proxy currentTasks:reply];
            });
        } else if (taskID) {
            printf("cleanup skipped for uuid=%s\n", taskID.UUIDString.UTF8String);
        }

        [conn invalidate];
    }
    return 0;
}
