NFS RPCSEC_GSS shared-token write-after-free - macOS 27 beta 26A5388g

Purpose
=======

This is a current-build reproduction update for the NFS RPCSEC_GSS context
lifetime bug documented in the earlier 26A5378n package:

  nfs_rpcsecgss_context_uaf_26A5378n_BULK_UAF_20260725.zip
  SHA-256:
  9c49445631987f199c35b10449afd9fd8be3a7e037531b2ae4af764bb490a399

It is not presented as a separate root cause. The important update is that the
same shared-token race remains present on 26A5388g and now reproduces with a
small uid501 client command, without DTrace, a debugger, a privileged helper,
DATA traffic, or manual daemon suspension.

Confirmed current-build results
===============================

- macOS 27.0 beta 4, build 26A5388g
- xnu-13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE
- Kernel UUID E324BD2E-ABD7-3384-BFCA-6CFD1435DC72
- Trigger process runs as uid501
- Victim is the root kernel NFS server path
- Requests are valid NFS NULL calls using RPCSEC_GSS_CONTINUE_INIT
- 64 concurrent requests produced:

    [data.kalloc.192]: element modified after free

- A separate 128-request run independently produced the same panic class and
  the same structured Kerberos/DER bytes in another freed allocation.
- Two, eight, and sixteen-request runs completed as negative controls.
- The race is nondeterministic: a second 64-request run completed cleanly.

The panic dump contains the GSS output-token bytes written after the allocation
was freed, including the NFS service principal. The current evidence proves an
authenticated uid501-reachable kernel data-heap write-after-free. It does not
prove arbitrary write-what-where, controlled PC, privilege escalation, or
remote code execution.

Files
=====

- PORTAL_FIELDS.txt
  Paste-ready report text.
- EVIDENCE.txt
  Root cause, exact 26A5388g instructions, and panic map.
- reproduce_current_build.sh
  The exact 128-request command used for the current-build trigger.
- rpc_gss_continue_uaf_fanout.c
  Client source.
- rpc_gss_continue_uaf_fanout
  arm64 client binary.
- continue_token.des3.client.bin
  The preserved valid continuation token used in both panicking runs.
- krb5.conf
  Test-realm client configuration.
- test_only.ccache
  Test-only uid501 credential cache from the disposable VM. It may expire;
  reviewers may substitute credentials and a token from their own test realm.
- run_64_uid501.log and run_128_uid501.log
  Complete unprivileged client logs.
- panic_64_uid501.panic and panic_128_uid501.panic
  Full system panic reports.
- panic_64_uid501.panicString.txt and
  panic_128_uid501.panicString.txt
  Extracted panic strings.
- nfs_gss_svc_ctx_init_26A5388g.disasm
  Exact KDK-backed disassembly.
- SHA256SUMS.txt
  Artifact hashes.

Build
=====

  clang -O2 -Wall -Wextra -Werror \
    rpc_gss_continue_uaf_fanout.c \
    -o rpc_gss_continue_uaf_fanout \
    -framework GSS

Preconditions
=============

The server must have:

- NFS enabled with an export using sec=krb5;
- a Kerberos service principal for the NFS service; and
- enough NFS workers to make the race practical (128 were configured in the
  test VM).

The unprivileged client needs valid Kerberos credentials for that service.
Administrative server/KDC setup is a laboratory precondition; the triggering
client itself runs entirely as uid501.

Run only on a disposable test machine. A successful run panics the kernel.
