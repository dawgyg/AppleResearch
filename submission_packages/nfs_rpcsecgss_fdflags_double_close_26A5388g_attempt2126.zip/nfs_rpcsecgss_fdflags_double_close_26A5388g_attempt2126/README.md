# Package map

- `REPORT.md`: technical report for the complete attempt-2126 chain.
- `PORTAL_FIELDS.txt`: portal-ready title, description, steps, and claim boundary.
- `stock_reproducer/`: exact source, scheduler, full panic, and analysis for the
  uid501 active-HMAC UAF reproduced with no DTrace process or debugger.
- `evidence/attempt2126_exact_analysis.md`: instruction-level correlation of the
  overwrite, double close, panic registers, KDK source line, and PAC failure.
- `evidence/`: exact run transcript, setup maps, generated DTrace, panic, and
  symbolication from attempt 2126.
- `base_reproducer/`: the earlier submission-ready RPCSEC_GSS context-race
  reproducer, without the advanced heap-placement harness.
- `diagnostic_harness/`: the lab-specific placement/race harness and predictor.
  `voucher32_prearmed_oracle_attempt2126.c` is the exact source used in attempt
  2126. `voucher32_prearmed_oracle.c` and its binary contain only the follow-up
  user-space signal-routing fix intended to remove the LLDB waiter release.
- `SHA256SUMS.txt`: hashes for every packaged artifact.

Start with `REPORT.md`, then read `stock_reproducer/README.md` for the clean
stock UAF and `evidence/attempt2126_exact_analysis.md` for the complete
controlled-overwrite/double-close chain. The advanced harness expects the
attached Kerberos/NFS VM lab and is diagnostic material, not a generic
one-command PoC.
