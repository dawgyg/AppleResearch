# Remote NFS context UAF enables controlled kernel overwrite and fileproc double close

## Verdict

On macOS 27 beta 4 build `26A5388g`, an authenticated uid501 NFS client drove a
kernel RPCSEC_GSS allocation/use race through two adjacent heap objects and
into the file-descriptor close path:

1. an attacker-selected HMAC tail changed a live ACL count from 1 to 2;
2. `kauth_acl_inherit` copied 64 bytes into a destination allocated as 32 bytes;
3. the second forged ACE cleared `UF_RESERVED|UF_CLOSING` in the adjacent
   `fd_ofileflags` element;
4. two threads entered `fp_close_and_unlock_with_action` for the same exact
   `fileproc *`; and
5. the second closer used a stale saved `fileglob *` and failed PAC
   authentication of `fileglob->fg_ops`.

The panic thread, fileproc register, fileglob register, and KDK instruction all
correlate with the second close recorded by DTrace. This demonstrates a
control-flow-relevant double close/UAF consequence of the remote controlled
kernel overwrite. It is not claimed as attacker-selected PC or a completed
privilege-escalation payload.

## Stock no-instrumentation reproduction

The underlying lifetime violation also reproduces independently of the
diagnostic heap-placement harness. Twenty-four uid501 clients issued valid
524 KB RPCSEC_GSS-privacy NFSv3 READDIRPLUS replies while valid CONTINUE_INIT
messages replaced their completed contexts. With no DTrace process, LLDB,
signal, timing hold, userspace release oracle, or kernel mutation, the VM
rebooted immediately after all contexts reached the prearm barrier.

The fresh panic is in active reply protection, not cleanup:

```text
Panicked task: pid 319: nfsd
Kernel data abort, FAR 0x8
runtime pc 0xfffffe001e2adad8
x0 0x0
```

KDK UUID `E324BD2E-ABD7-3384-BFCA-6CFD1435DC72` exactly matches the panic.
Relocation maps the PC to `0xfffffe0007c81ad8`,
`cchmac_final + 44`, `cchmac_final.c:50:48`:

```asm
ldr x8, [x0, #0x8]  // di == NULL
```

`krb5_mic_mbuf` snapshots `ctx->di` into its walker for the long mbuf walk,
but then re-reads the raw `ctx->di` at finalization without retaining or
locking the context across the operation. Concurrent teardown frees the
`gss_ctx_id_desc`; the stale worker reaches `cchmac_final(ctx->di, ...)` after
that free. The same geometry first produced the identical fault with passive
entry/return logging, then reproduced it with logging fully disabled.

The exact no-instrumentation artifacts and source are under
`stock_reproducer/`. Panic SHA-256:
`101d27007ab4b84364763e55abc52f792e68deb7c9eca5ffc458bcaa6f3f0774`.

## Affected configuration

- macOS 27.0 beta 4 `26A5388g`
- Darwin `xnu-13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE`
- NFS server export configured with `sec=krb5`
- remote client has a valid Kerberos credential for the NFS service
- triggering client runs as uid 501

## Root cause: allocation and copy use different context generations

The NFS server accepts RPCSEC_GSS `CONTINUE_INIT` on an already-complete
context. Concurrent DATA and CONTINUE_INIT workers can use and replace the same
GSS crypto-context pointer without one lifetime lock covering every field.

The DATA worker starts with AES and digest size 12, so the kernel requests a
`16 + 12 = 28` byte MIC allocation. That occupies one 32-byte data-zone
element. A concurrent valid CONTINUE_INIT replaces the context with DES3 and
digest size 20. The stale DATA worker later reloads 20 for the final copy to
`mic_buffer + 16`; bytes 32 through 35 overwrite dword zero of the adjacent
`data.kalloc.32` object.

The checks accept both digest sizes independently. The missing invariant is
that the final copy length must match the context generation and digest size
used for the allocation.

## Attacker-selected dword

The authenticated client knows its own lucid Kerberos key and MIC input. The
included predictor searched valid signed-range RPCSEC_GSS sequence numbers for
a final little-endian dword of 2:

```text
selected_sequence=1249385819
rpc_sequence=1249385820
hmac_sha1=3a63031d60b5ff01ccf902fda619f86302000000
overwrite_dword=0x00000002
handle=4b242342
```

The final bytes `02 00 00 00` changed the selected adjacent ACL's count from 1
to 2.

## Exact heap composition

Attempt 2126 recorded:

```text
MIC A        0xfffffe31c0f3a1c0
ACL source B 0xfffffe31c0f3a1e0 = A + 0x20
ACL dest E   0xfffffe31c0f3a840
fdflags      0xfffffe31c0f3a860 = E + 0x20
child        pid 760, fd 17
fileproc     0xfffffe2aef6072e0
```

The trace proves every transition:

```text
SELECTIVE_MIC_OWNER ... ptr=fffffe31c0f3a1c0 owner_pid=684 slot=4 exact=1
INHERIT_SOURCE_OBSERVED ... source=fffffe31c0f3a1e0 count=1 source_is_b=1
EXACT_INHERIT_DST_ALLOC_RETURN ... dst=fffffe31c0f3a840 request=32 fdflags_exact=1
HMAC_SECOND_DIGEST_RETURN_RESUME ... len_before=12 len_live=20 exact_des3=1
krb5_mic_return ... neighbor=fffffe31c0f3a1e0 overflow_dword=0x2
INHERIT_DIR_COUNT_BRACKET ... count_at_alloc_return=1 count_post_hold_pre_copy=2
EXACT_INHERIT_RETURN ... dst=fffffe31c0f3a840 product_count=2 overflow_proven=1
FDFLAGS_COUNT2_GEOMETRY ... fdflags=fffffe31c0f3a860 exact=1
```

`kauth_acl_inherit` allocated E using count 1, then reloaded count 2 and copied
two 32-byte ACEs. ACE 2 landed at `E + 0x20`, exactly the live fdflags object,
and cleared the in-progress bits for fd 17.

## Double close and stale fileglob use

The kernel close guard tests `UF_RESERVED|UF_CLOSING` (`0x0c`) and normally
rejects a second close. The overwrite cleared those bits after close A set
them. DTrace then recorded both threads entering with the same fileproc:

```text
FDFLAGS_FP_CLOSE_ENTRY ... tid=4778 ordinal=1 fd=17 fp=fffffe2aef6072e0
FDFLAGS_FP_CLOSE_ENTRY ... tid=4779 ordinal=2 fd=17 fp=fffffe2aef6072e0
FDFLAGS_SECOND_CLOSE_CLASS=DOUBLE_CLOSE_PATH ... tid=4779 fd=17
```

Both closers cached the same `fp->fp_glob`. After the flock barrier was
released, close A could drop/free the shared objects while close B retained
the same pointers in registers.

The immediate panic reported:

```text
Break 0xC472 instruction exception
Ptrauth failure with DA key
runtime pc = 0xfffffe0026392ea8
x19 = 0xfffffe2aef6072e0
x24 = 0xfffffe1a8ff7c748
Panicked task pid 760: v32select
Panicked thread tid 4779
```

`x19` is the exact fileproc recorded for both closes, and tid 4779 is the exact
second closer. Mapping the runtime address through the kernel slide and
fileset delta gives KDK address `0xfffffe00078beea8`,
`fp_close_and_unlock_with_action`, `kern_descrip.c:1867`, offset `+0x73c`.

The faulting sequence is:

```text
mov   x17, x24
ldr   x16, [x17, #0x28]!
movk  x17, #0x853c, lsl #48
autda x16, x17
mov   x17, x16
xpacd x17
cmp   x16, x17
b.eq  success
brk   #0xc472
```

KDK DWARF identifies `fileglob + 0x28` as the DA-key PAC-protected
`const fileops *fg_ops`. Therefore the panic is authentication of a stale or
corrupted `fileglob->fg_ops`, not nearest-symbol inference.

## Reproduction and debugger boundary

The `base_reproducer` archive demonstrates the underlying remote
RPCSEC_GSS context race without the heap-placement harness. The advanced
`diagnostic_harness` makes the two adjacent-object transitions deterministic
in the disposable VM.

Attempt 2126 used:

```sh
VOUCHER32_SETUP_PRE_STAGE1_DRAIN_COUNT=256 \
VOUCHER32_SETUP_POSTFREE_SEQUENTIAL_RECLAIM=1 \
VOUCHER32_SETUP_POSTFREE_RELEASE_B_THEN_E=0 \
RPC_GSS_PREFORK_COHORT_LIMIT=7 \
RPC_GSS_PREFORK_SELECTIVE_A_FREE_SLACK=1 \
RPC_GSS_SECOND_DATA_DTRACE_GATE=0 \
RPC_GSS_PREFORK_DATA_STAGGER_US=50000 \
RPC_GSS_PREALLOC_HOLD_NS=1 \
RPC_GSS_PREFORK_REPAIR_CONTINUE_COUNT=0 \
RPC_GSS_PREFORK_PREDICTOR_MAX_SEQUENCE=2147483647 \
./run_fdflags_flock_context.sh 2125 2126 0 0 2 2 435000000 0 499000000
```

The overwrite and both kernel close entries were complete before debugger
use. LLDB was attached only after the two user threads were sleeping. It set
the victim process's user-space `fdflags_release_waiter_requested` flag from 0
to 1, then the process was continued. No kernel address, kernel register, or
kernel object was read or modified through LLDB.

`voucher32_prearmed_oracle_attempt2126.c` is the exact source used in that run
(SHA-256
`df0de7d63fe9ab0dc2a835f255f1186843d1415d6547ed7672f328f9c02a23f6`).
The adjacent `voucher32_prearmed_oracle.c` follow-up only blocks the three
process-directed control signals while creating worker threads, then unblocks
them in the coordinator. Its source SHA-256 is
`f6fcc1de63a06030afcfbd6f4e2158a0cf1deb58a23baf5c8b82e624996a15d9`, and
the included binary SHA-256 is
`b877f011c3b0b83a4038b11d7acd64884c7270c158d9ae0552d505467093cf9c`.
That routes the existing DTrace release signal to the coordinator and removes
the need for the LLDB user-space flag change; it does not alter the kernel
trigger or payload.

## Environment and claim boundary

The experiments ran in a disposable VM on the release kernel. The stock UAF
reproduction used no DTrace process or debugger. SIP was disabled for the lab
configuration, but the trigger itself used only uid501 NFS RPC traffic. The
advanced controlled-overwrite experiment separately used DTrace timing holds
for deterministic allocation/race ordering.
Boot arguments were:

```text
-zp keepsyms=1 amfi_get_out_of_my_way=1
```

Confirmed:

- debugger-free and DTrace-free uid501 kernel UAF during active
  `cchmac_final` reply protection;
- authenticated remote uid501 reachability;
- attacker-selected four-byte write beyond the MIC allocation;
- live ACL count corruption from 1 to 2;
- 64-byte ACL copy into a 32-byte allocation;
- exact overwrite of adjacent live `fd_ofileflags`;
- bypass of the close-in-progress exclusion;
- two close paths for the same exact live `fileproc`;
- stale `fileglob->fg_ops` use by the second closer; and
- DA-key PAC failure on the exact second-close thread.

Not demonstrated:

- attacker-selected kernel PC;
- a complete privilege-escalation or remote-code-execution payload;
- a captured Apple Target Flag; or
- debugger-free reproduction of the final fileproc PAC panic in attempt 2126.
