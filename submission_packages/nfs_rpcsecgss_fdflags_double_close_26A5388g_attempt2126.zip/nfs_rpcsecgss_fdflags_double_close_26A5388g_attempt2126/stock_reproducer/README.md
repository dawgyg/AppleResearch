# Stock active-HMAC UAF reproducer

This directory contains the exact uid501 client, scheduler, and evidence for a
two-run kernel use-after-free reproduction on macOS 27 beta 4 `26A5388g`.
The strongest preserved run used no DTrace process, debugger, signal, timing
hold, userspace release oracle, or kernel mutation.

## Result

Twenty-four unprivileged RPCSEC_GSS clients race valid protected NFSv3
READDIRPLUS replies against valid CONTINUE_INIT messages on their completed
contexts. The large reply keeps `krb5_mic_mbuf` active while another request
destroys the raw GSS crypto context. The kernel then calls:

```text
cchmac_final(di=NULL, ...)
```

and faults at `ldr x8, [x0, #8]`, `FAR 0x8`, in task `nfsd`.

## Preconditions

- macOS 27 beta 4 `26A5388g` NFS server;
- an export permitting `krb5p`, `krb5i`, and `krb5`;
- a non-root user with valid AES and DES3 Kerberos credentials for the NFS
  service; and
- a directory large enough for a roughly 524 KB READDIRPLUS reply.

`source/example_exports` shows the test export. Kerberos ccaches are
intentionally not packaged because they contain lab credentials.

## Exact run

The preserved VM used the source and binary under `source/`. The host wrapper
is lab-path-specific but records the exact invocation:

```sh
RPC_GSS_STOCK_ENABLE_TRACE=0 \
RPC_GSS_STOCK_CLIENT_NAME=rpc_gss_crypto_race_readdirplus \
RPC_GSS_NFS_FH_FILE=export-root.vm84.fh \
RPC_GSS_NFS_PROC=readdirplus \
RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=524288 \
RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=524288 \
RPC_GSS_CONTINUE_DELAY_US=0 \
./run_nfs_stock_multicontext_batch.sh \
  stock_rdp_24x2_shift19ms_notrace_1 24 39000 1500 2 500
```

The file handle under `evidence/` belongs only to the preserved test export;
compile `source/fetch_mountd_fh3.c` and run it as root to obtain the
corresponding handle on a new setup. The test server rejects unprivileged
mountd clients as having credentials that are too weak.

## Evidence

- `evidence/stock_rdp_24x2_shift19ms_notrace_1.panic`: full no-DTrace panic.
- `evidence/stock_rdp_24x2_shift19ms_notrace_1.stock_multictx.run.log`:
  stage/prearm output followed by connection loss.
- `evidence/stock_rdp_24x2_shift19ms_notrace_1.bootsessionuuid.txt`: pre-panic
  boot UUID, matching the panic report.
- `evidence/ACTIVE_HMAC_UAF_ANALYSIS.md`: register, KDK, source-line, and call
  chain analysis.

The no-DTrace panic SHA-256 is
`101d27007ab4b84364763e55abc52f792e68deb7c9eca5ffc458bcaa6f3f0774`.
