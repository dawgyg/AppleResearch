#!/bin/zsh

set -eu
set -o pipefail

run_id=${1:?usage: $0 run_id [count [base_delay_us [delay_step_us [data_count [data_stagger_us]]]]]}
count=${2:-8}
base_delay_us=${3:-70000}
delay_step_us=${4:-5000}
data_count=${5:-1}
data_stagger_us=${6:-0}
trace_script_name=${RPC_GSS_STOCK_TRACE_SCRIPT:-trace_nfs_stock_hmac_mismatch_all_aes.d}
stream_trace=${RPC_GSS_STOCK_STREAM_TRACE:-0}
stock_client_name=${RPC_GSS_STOCK_CLIENT_NAME:-rpc_gss_crypto_race_double_gate}
nfs_fh_file=${RPC_GSS_NFS_FH_FILE:-}
continue_delay_us=${RPC_GSS_CONTINUE_DELAY_US:-0}
dtrace_switchrate=${RPC_GSS_DTRACE_SWITCHRATE:-1hz}
enable_trace=${RPC_GSS_STOCK_ENABLE_TRACE:-1}

host=192.168.64.84
user=testtest
password=test
root=/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727
lane=/Users/dawgyg/codex_lanes/nfs_rpcsecgss_poc
remote_root=/Users/testtest
remote_trace=${remote_root}/${run_id}.stock_hmac.dtrace.out
remote_stderr=${remote_root}/${run_id}.stock_hmac.dtrace.stderr
remote_pid=${remote_root}/${run_id}.stock_hmac.dtrace.pid
remote_trace_script=${remote_root}/${trace_script_name:t}
local_trace=${root}/${run_id}.stock_hmac.dtrace.out
local_stderr=${root}/${run_id}.stock_hmac.dtrace.stderr
local_run=${root}/${run_id}.stock_multictx.run.log
boot_uuid_file=${root}/${run_id}.bootsessionuuid.txt
trace_client_pid=0

ssh_opts=(
	-o ControlMaster=no
	-o ConnectTimeout=15
	-o ServerAliveInterval=2
	-o ServerAliveCountMax=3
	-o StrictHostKeyChecking=no
	-o UserKnownHostsFile=/dev/null
)

if [[ ${count} != <-> || ${base_delay_us} != <-> ||
    ${delay_step_us} != <-> || ${data_count} != <-> ||
    ${data_stagger_us} != <-> || ${continue_delay_us} != <-> ||
    ${dtrace_switchrate} != <->hz ||
    ${enable_trace} != [01] ||
    ${stream_trace} != [01] ||
    ${trace_script_name} != ${trace_script_name:t} ||
    ${stock_client_name} != ${stock_client_name:t} ]] ||
    [[ ! -f ${root}/${trace_script_name} ]] ||
    [[ ! -x ${lane}/${stock_client_name} ]] ||
    (( count < 1 || count > 32 ||
    data_count < 1 || data_count > 8 ||
    base_delay_us > 1000000 || delay_step_us > 1000000 ||
    data_stagger_us > 1000000 || continue_delay_us > 1000000 ||
    base_delay_us + (count - 1) * delay_step_us +
    (data_count - 1) * data_stagger_us > 1000000 )); then
	print -u2 "invalid multicontext batch geometry"
	exit 2
fi

cleanup_trace()
{
	if (( trace_client_pid > 0 )); then
		kill ${trace_client_pid} 2>/dev/null || true
		wait ${trace_client_pid} 2>/dev/null || true
		trace_client_pid=0
	fi
	sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
	    "if test -s ${remote_pid}; then printf 'test\\n' | sudo -S kill -TERM \$(cat ${remote_pid}) 2>/dev/null || true; fi" \
	    >/dev/null 2>&1 || true
}

trap cleanup_trace EXIT
trap 'cleanup_trace; exit 130' HUP INT TERM

sshpass -p ${password} scp ${ssh_opts[@]} \
    ${lane}/${stock_client_name} \
    ${lane}/rpc_gss_crypto_race_prestaged_nonmutual \
    ${root}/krb5-mit-beta4.conf \
    ${root}/krb5-mit-des3-beta4.conf \
    ${root}/mit_testtest_beta4.ccache \
    ${root}/mit_testtest_des3_beta4.ccache \
	${root}/${trace_script_name} \
	${root}/run_nfs_stock_multicontext_batch_remote.sh \
    ${user}@${host}:${remote_root}/ >/dev/null

if [[ -n ${nfs_fh_file} ]]; then
	if [[ ! -f ${nfs_fh_file} ]]; then
		print -u2 "missing NFS filehandle: ${nfs_fh_file}"
		exit 1
	fi
	sshpass -p ${password} scp ${ssh_opts[@]} ${nfs_fh_file} \
	    ${user}@${host}:${remote_root}/stock_nfs_fh.bin >/dev/null
fi

sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
	"set -e; cp ${remote_root}/${stock_client_name} ${remote_root}/rgstockctx; cp ${remote_root}/rpc_gss_crypto_race_prestaged_nonmutual ${remote_root}/rgstocktoken; chmod +x ${remote_root}/rgstockctx ${remote_root}/rgstocktoken ${remote_root}/run_nfs_stock_multicontext_batch_remote.sh; rm -f ${remote_root}/stock_multictx_des3.client.bin ${remote_root}/stock_multictx_des3.server.bin ${remote_root}/stock_multictx_des3.lucid.txt ${remote_root}/stock_multictx_des3.generate.log ${remote_trace} ${remote_stderr} ${remote_pid}; printf 'test\\n' | sudo -S launchctl kickstart -k system/com.apple.gssd; env KRB5_CONFIG=${remote_root}/krb5-mit-des3-beta4.conf KRB5CCNAME=FILE:${remote_root}/mit_testtest_des3_beta4.ccache RPC_GSS_NO_MUTUAL=1 RPC_GSS_TOKEN_ONLY=1 RPC_GSS_EXPORT_LUCID_FILE=${remote_root}/stock_multictx_des3.lucid.txt ${remote_root}/rgstocktoken ${host} nfs@tests-virtual-machine.local ${remote_root}/stock_multictx_des3.client.bin ${remote_root}/stock_multictx_des3.server.bin 0 0 0 0 8 >${remote_root}/stock_multictx_des3.generate.log 2>&1; test -s ${remote_root}/stock_multictx_des3.client.bin; test -s ${remote_root}/stock_multictx_des3.lucid.txt"

rm -f ${local_trace} ${local_stderr}
if (( enable_trace )); then
	if (( stream_trace )); then
		sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
		    "printf 'test\\n' | sudo -S sh -c 'echo \$\$ > ${remote_pid}; exec /usr/sbin/dtrace -x switchrate=${dtrace_switchrate} -s ${remote_trace_script}'" \
		    >${local_trace} 2>${local_stderr} &
		trace_client_pid=$!
	else
		sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
		    "printf 'test\\n' | sudo -S nohup /usr/sbin/dtrace -x switchrate=${dtrace_switchrate} -o ${remote_trace} -s ${remote_trace_script} >${remote_stderr} 2>&1 & echo \$! >${remote_pid}"
	fi

	for attempt in $(seq 1 800); do
		if (( stream_trace )) && rg -q trace_begin ${local_trace} 2>/dev/null; then
			break
		elif (( ! stream_trace )) &&
		    sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
		    "grep -q trace_begin ${remote_trace}" >/dev/null 2>&1; then
			break
		fi
		sleep 0.025
	done
	if (( attempt == 800 )); then
		print -u2 "passive DTrace probe did not start"
		if (( stream_trace )); then
			cat ${local_stderr} >&2 || true
		else
			sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
			    "cat ${remote_stderr}" >&2 || true
		fi
		exit 1
	fi
fi

boot_uuid=$(sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
    /usr/sbin/sysctl -n kern.bootsessionuuid)
print -r -- ${boot_uuid} >${boot_uuid_file}
print "vm_bootsessionuuid=${boot_uuid}"

set +e
sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
	"env RPC_GSS_NFS_FH_FILE=${nfs_fh_file:+${remote_root}/stock_nfs_fh.bin} RPC_GSS_NFS_PROC=${RPC_GSS_NFS_PROC:-} RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=${RPC_GSS_NFS_READDIRPLUS_DIRCOUNT:-} RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=${RPC_GSS_NFS_READDIRPLUS_MAXCOUNT:-} RPC_GSS_CONTINUE_DELAY_US=${continue_delay_us} ${remote_root}/run_nfs_stock_multicontext_batch_remote.sh ${run_id} ${count} ${base_delay_us} ${delay_step_us} ${data_count} ${data_stagger_us}" \
    2>&1 | tee ${local_run}
run_status=${pipestatus[1]}
set -e

if (( enable_trace )); then
	sleep 1
	sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
		"if test -s ${remote_pid}; then printf 'test\\n' | sudo -S kill -TERM \$(cat ${remote_pid}) 2>/dev/null || true; fi" >/dev/null 2>&1 || true
	if (( stream_trace )); then
		for attempt in $(seq 1 100); do
			if rg -q trace_end ${local_trace} 2>/dev/null ||
			    ! kill -0 ${trace_client_pid} 2>/dev/null; then
				break
			fi
			sleep 0.05
		done
		wait ${trace_client_pid} 2>/dev/null || true
		trace_client_pid=0
	else
		for attempt in $(seq 1 100); do
			if sshpass -p ${password} ssh ${ssh_opts[@]} ${user}@${host} \
			    "grep -q trace_end ${remote_trace}" >/dev/null 2>&1; then
				break
			fi
			sleep 0.05
		done
		sshpass -p ${password} scp ${ssh_opts[@]} \
		    ${user}@${host}:${remote_trace} ${local_trace} >/dev/null || true
		sshpass -p ${password} scp ${ssh_opts[@]} \
		    ${user}@${host}:${remote_stderr} ${local_stderr} >/dev/null || true
	fi
fi

if [[ -s ${local_trace} ]]; then
	rg 'NATURAL_HMAC_MISMATCH|NATURAL_MBUF_|NATURAL_LARGE_MBUF_|MBUF_CHANGED_|AES_MIC_ENTRIES|AES_SECOND_DIGEST|SECOND_LIVE_LEN|NATURAL_MISMATCHES|MBUF_ENTRIES|MBUF_RETURNS|HMAC_FINAL_RETURNS|DESTROY_ENTRIES|DESTROY_OVERLAPS|MAKE_RETURNS|MAKE_OVERLAPS|CHANGED_RETURNS|trace_end' ${local_trace} || true
fi

exit ${run_status}
