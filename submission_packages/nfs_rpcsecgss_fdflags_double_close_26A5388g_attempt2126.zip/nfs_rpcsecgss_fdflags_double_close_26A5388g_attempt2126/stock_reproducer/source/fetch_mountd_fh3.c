#include <errno.h>
#include <rpc/rpc.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MOUNT_PROGRAM 100005U
#define MOUNT_VERSION_3 3U
#define MOUNTPROC_MNT 1U
#define MNT3_OK 0
#define MOUNT_PATH_MAX 1024U
#define NFS3_FH_MAX 64U

struct variable_bytes {
    u_int length;
    char *bytes;
};

struct auth_flavors {
    u_int count;
    int *values;
};

struct mountres3 {
    enum_t status;
    struct variable_bytes handle;
    struct auth_flavors flavors;
};

static bool_t xdr_int_adapter(XDR *, void *, unsigned int);

static bool_t
xdr_mount_path(XDR *xdrs, char **path)
{
    return xdr_string(xdrs, path, MOUNT_PATH_MAX);
}

static bool_t
xdr_mountres3(XDR *xdrs, struct mountres3 *result)
{
    if (!xdr_enum(xdrs, &result->status)) {
        return FALSE;
    }
    if (result->status != MNT3_OK) {
        return TRUE;
    }
    if (!xdr_bytes(xdrs, &result->handle.bytes, &result->handle.length,
        NFS3_FH_MAX)) {
        return FALSE;
    }
    return xdr_array(xdrs, (char **)&result->flavors.values,
        &result->flavors.count, 64, sizeof(*result->flavors.values),
        xdr_int_adapter);
}

static bool_t
xdr_int_adapter(XDR *xdrs, void *value, unsigned int ignored)
{
    (void)ignored;
    return xdr_int(xdrs, value);
}

static bool_t
xdr_mount_path_adapter(XDR *xdrs, void *value, unsigned int ignored)
{
    (void)ignored;
    return xdr_mount_path(xdrs, value);
}

static bool_t
xdr_mountres3_adapter(XDR *xdrs, void *value, unsigned int ignored)
{
    (void)ignored;
    return xdr_mountres3(xdrs, value);
}

#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wdeprecated-non-prototype"
static void
destroy_auth(AUTH *auth)
{
    auth_destroy(auth);
}
#pragma clang diagnostic pop

int
main(int argc, char **argv)
{
    struct timeval timeout = { .tv_sec = 5, .tv_usec = 0 };
    struct mountres3 result = {0};
    CLIENT *client;
    char *path;
    FILE *output;
    int close_result;
    enum clnt_stat status;

    if (argc != 4) {
        fprintf(stderr, "usage: %s host export-path output\n", argv[0]);
        return 2;
    }
    path = argv[2];
    client = clnt_create(argv[1], MOUNT_PROGRAM, MOUNT_VERSION_3, "tcp");
    if (client == NULL) {
        clnt_pcreateerror(argv[1]);
        return 1;
    }
    client->cl_auth = authunix_create_default();
    if (client->cl_auth == NULL) {
        fprintf(stderr, "authunix_create_default failed\n");
        clnt_destroy(client);
        return 1;
    }

    status = clnt_call(client, MOUNTPROC_MNT,
        xdr_mount_path_adapter, &path,
        xdr_mountres3_adapter, &result, timeout);
    if (status != RPC_SUCCESS) {
        clnt_perror(client, "MOUNTPROC_MNT");
        destroy_auth(client->cl_auth);
        clnt_destroy(client);
        return 1;
    }
    if (result.status != MNT3_OK || result.handle.length == 0 ||
        result.handle.length > NFS3_FH_MAX) {
        fprintf(stderr, "mountd status=%d fh_len=%u\n", result.status,
            result.handle.length);
        xdr_free(xdr_mountres3_adapter, (char *)&result);
        destroy_auth(client->cl_auth);
        clnt_destroy(client);
        return 1;
    }

    output = fopen(argv[3], "wb");
    if (output == NULL) {
        fprintf(stderr, "open(%s): %s\n", argv[3], strerror(errno));
        xdr_free(xdr_mountres3_adapter, (char *)&result);
        destroy_auth(client->cl_auth);
        clnt_destroy(client);
        return 1;
    }
    close_result = 0;
    if (fwrite(&result.handle.length, sizeof(result.handle.length), 1,
        output) != 1 ||
        fwrite(result.handle.bytes, result.handle.length, 1, output) != 1) {
        fprintf(stderr, "write(%s): %s\n", argv[3], strerror(errno));
        close_result = fclose(output);
        xdr_free(xdr_mountres3_adapter, (char *)&result);
        destroy_auth(client->cl_auth);
        clnt_destroy(client);
        return 1;
    }
    close_result = fclose(output);
    if (close_result != 0) {
        fprintf(stderr, "close(%s): %s\n", argv[3], strerror(errno));
        xdr_free(xdr_mountres3_adapter, (char *)&result);
        destroy_auth(client->cl_auth);
        clnt_destroy(client);
        return 1;
    }

    printf("fh_len=%u flavors=", result.handle.length);
    for (u_int index = 0; index < result.flavors.count; index++) {
        printf("%s%d", index == 0 ? "" : ",", result.flavors.values[index]);
    }
    printf(" fh=");
    for (u_int index = 0; index < result.handle.length; index++) {
        printf("%02x", (unsigned char)result.handle.bytes[index]);
    }
    printf("\n");

    xdr_free(xdr_mountres3_adapter, (char *)&result);
    destroy_auth(client->cl_auth);
    clnt_destroy(client);
    return 0;
}
