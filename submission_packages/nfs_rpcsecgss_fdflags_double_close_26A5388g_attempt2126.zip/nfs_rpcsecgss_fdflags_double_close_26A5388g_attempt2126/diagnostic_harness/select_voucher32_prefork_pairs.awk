function value(name,    i, pair) {
	for (i = 1; i <= NF; i++) {
		split($i, pair, "=")
		if (pair[1] == name) {
			return pair[2]
		}
	}
	return ""
}

function hex_add_20(value,    chars, result, position, digit, carry, sum) {
	chars = "0123456789abcdef"
	result = value
	carry = 2
	for (position = length(result) - 1;
	    position >= 1 && carry != 0; position--) {
		digit = index(chars, substr(result, position, 1)) - 1
		if (digit < 0) {
			return ""
		}
		sum = digit + carry
		result = substr(result, 1, position - 1) \
		    substr(chars, (sum % 16) + 1, 1) \
		    substr(result, position + 1)
		carry = int(sum / 16)
	}
	return carry == 0 ? result : ""
}

$2 == "VOUCHER_SLOT" {
	pid = value("pid")
	if (pid == "") {
		next
	}
	slot = ++slot_count[pid]
	slot_index[pid, slot] = value("idx")
	slot_ptr[pid, slot] = value("ptr")
	next
}

$2 == "VOUCHER_PAIR" {
	pid = value("pid")
	if (pid == "") {
		next
	}
	slot = ++pair_count[pid]
	pair_e[pid, slot] = value("e_idx")
	pair_f[pid, slot] = value("f_idx")
	pair_eptr[pid, slot] = value("e_ptr")
	pair_fptr[pid, slot] = value("f_ptr")
}

END {
	if (limit == "" || limit < 1) {
		limit = 16
	}
	for (pid in pair_count) {
		selected = 0
		for (ab_pair = 1; ab_pair <= pair_count[pid]; ab_pair++) {
			a = pair_e[pid, ab_pair]
			b = pair_f[pid, ab_pair]
			if (a == "" || b == "" ||
			    used[pid, a] || used[pid, b]) {
				continue
			}
			for (ef_pair = 1; ef_pair <= pair_count[pid]; ef_pair++) {
				e = pair_e[pid, ef_pair]
				f = pair_f[pid, ef_pair]
				if (a == "" || b == "" || e == "" || f == "" ||
				    e == a || e == b || f == a || f == b ||
				    e == f || used[pid, e] || used[pid, f]) {
					continue
				}
				if (pair_eptr[pid, ef_pair] != \
				    hex_add_20(pair_fptr[pid, ab_pair])) {
					continue
				}
				for (candidate = 1;
				    candidate <= slot_count[pid]; candidate++) {
					c = slot_index[pid, candidate]
					if (c == a || c == b || c == e || c == f ||
					    used[pid, c]) {
						continue
					}
					printf "%s %s %s %s %s %s %s %s %s %s %s\n",
					    pid, a, b, c, e, f,
					    pair_eptr[pid, ab_pair],
					    pair_fptr[pid, ab_pair],
					    slot_ptr[pid, candidate],
					    pair_eptr[pid, ef_pair],
					    pair_fptr[pid, ef_pair]
					used[pid, a] = 1
					used[pid, b] = 1
					used[pid, c] = 1
					used[pid, e] = 1
					used[pid, f] = 1
					selected++
					break
				}
				if (candidate <= slot_count[pid]) {
					break
				}
			}
			if (selected >= limit) {
				break
			}
		}
	}
}
