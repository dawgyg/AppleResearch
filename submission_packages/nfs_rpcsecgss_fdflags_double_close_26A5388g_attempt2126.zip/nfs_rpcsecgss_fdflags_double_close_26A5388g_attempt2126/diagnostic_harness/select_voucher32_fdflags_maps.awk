function value(name,    i, pair) {
	for (i = 1; i <= NF; i++) {
		split($i, pair, "=")
		if (pair[1] == name) {
			return pair[2]
		}
	}
	return ""
}

$2 == "VOUCHER_TRIPLE" {
	pid = value("pid")
	c = value("c_idx")
	if (pid == "" || c < 400 || c > 402) {
		next
	}
	slot = ++triple_count[pid]
	triple_a[pid, slot] = value("a_idx")
	triple_b[pid, slot] = value("b_idx")
	triple_c[pid, slot] = c
	triple_aptr[pid, slot] = value("a_ptr")
	triple_bptr[pid, slot] = value("b_ptr")
	triple_cptr[pid, slot] = value("c_ptr")
	next
}

$2 == "FD_TARGET" {
	pid = value("parent_pid")
	if (pid == "" || target_seen[pid]) {
		next
	}
	target_seen[pid] = 1
	target_e[pid] = value("e_idx")
	target_eptr[pid] = value("e_ptr")
	target_flags[pid] = value("flags")
}

END {
	for (pid in target_seen) {
		e = target_e[pid]
		for (slot = 1; slot <= triple_count[pid]; slot++) {
			a = triple_a[pid, slot]
			b = triple_b[pid, slot]
			c = triple_c[pid, slot]
			if (a == "" || b == "" || c == "" ||
			    a == e || b == e || c == e) {
				continue
			}
			printf "%s %s %s %s %s %s %s %s %s %s\n",
			    pid, a, b, c, e,
			    triple_aptr[pid, slot],
			    triple_bptr[pid, slot],
			    triple_cptr[pid, slot],
			    target_eptr[pid],
			    target_flags[pid]
			break
		}
	}
}
