# Diagnostic harness

This directory is the lab-specific allocator/race harness used to compose the
RPCSEC_GSS context bug into the attempt-2126 fdflags overwrite and double close.
It expects the Kerberos/NFS VM paths, address, credentials, symbols, DTrace
availability, and helper layout encoded in the scripts.

Important source identities:

- `voucher32_prearmed_oracle_attempt2126.c`: exact source used in attempt 2126,
  SHA-256 `df0de7d63fe9ab0dc2a835f255f1186843d1415d6547ed7672f328f9c02a23f6`.
- The exact attempt-2126 binary had SHA-256
  `0f9b4a22e55aa1e1275e3da69532a821e0153555bbff0a41e8666efdcb118263`;
  that binary is identified in the evidence but is not reconstructed here.
- `voucher32_prearmed_oracle.c` and `voucher32_prearmed_oracle`: follow-up
  signal-routing revision, hashes `f6fcc1de...` and `b877f011...`.

The follow-up revision only blocks `SIGUSR1`, `SIGUSR2`, and `SIGALRM` while
creating the waiter/closer threads and unblocks them in the coordinator. It is
intended to replace the one LLDB user-space waiter release from attempt 2126.

See the top-level `REPORT.md` for the exact attempt command and claim boundary.
