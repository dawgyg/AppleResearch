function value(name,    i, pair) {
	for (i = 1; i <= NF; i++) {
		split($i, pair, "=")
		if (pair[1] == name) {
			return pair[2]
		}
	}
	return ""
}

FNR == NR {
	parent = $1
	slot = selection_count[parent]++
	prefork_a[parent, slot] = $2
	prefork_b[parent, slot] = $3
	prefork_c[parent, slot] = $4
	prefork_e[parent, slot] = $5
	prefork_f[parent, slot] = $6
	prefork_aptr[parent, slot] = $7
	prefork_bptr[parent, slot] = $8
	prefork_cptr[parent, slot] = $9
	prefork_eptr[parent, slot] = $10
	prefork_fptr[parent, slot] = $11
	next
}

$2 == "FD_FORK_FLAGS" {
	parent = value("parent_pid")
	flags = value("flags")
	if (parent == "" || flags == "" || emitted[parent]) {
		next
	}
	for (slot = 0; slot < selection_count[parent]; slot++) {
		if (flags != prefork_fptr[parent, slot]) {
			continue
		}
		emitted[parent] = 1
		printf "%s %s %s %s %s %s %s %s %s %s %s\n",
		    parent,
		    prefork_a[parent, slot],
		    prefork_b[parent, slot],
		    prefork_c[parent, slot],
		    prefork_e[parent, slot],
		    prefork_aptr[parent, slot],
		    prefork_bptr[parent, slot],
		    prefork_cptr[parent, slot],
		    prefork_eptr[parent, slot],
		    flags,
		    slot
		break
	}
}
