function value(name,    i, pair) {
	for (i = 1; i <= NF; i++) {
		split($i, pair, "=")
		if (pair[1] == name) {
			return pair[2]
		}
	}
	return ""
}

FNR == NR {
	parent = $1
	prefork_a[parent] = $2
	prefork_b[parent] = $3
	prefork_c[parent] = $4
	prefork_e[parent] = $5
	prefork_f[parent] = $6
	prefork_aptr[parent] = $7
	prefork_bptr[parent] = $8
	prefork_cptr[parent] = $9
	prefork_eptr[parent] = $10
	prefork_fptr[parent] = $11
	next
}

$2 == "FD_TARGET" {
	parent = value("parent_pid")
	e = value("e_idx")
	flags = value("flags")
	if (parent == "" || emitted[parent] ||
	    prefork_e[parent] == "" ||
	    e != prefork_e[parent] ||
	    flags != prefork_fptr[parent]) {
		next
	}
	emitted[parent] = 1
	printf "%s %s %s %s %s %s %s %s %s %s\n",
	    parent,
	    prefork_a[parent],
	    prefork_b[parent],
	    prefork_c[parent],
	    prefork_e[parent],
	    prefork_aptr[parent],
	    prefork_bptr[parent],
	    prefork_cptr[parent],
	    prefork_eptr[parent],
	    flags
}
