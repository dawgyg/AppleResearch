#!/usr/sbin/dtrace -s

#pragma D option quiet
#pragma D option dynvarsize=16m
#pragma D option switchrate=1ms

dtrace:::BEGIN
{
	configured_candidate_min_aes_mic = $1;
	configured_mic_hold_ns = (uint64_t)$2;
	configured_target_gss_handle = (uint32_t)$3;
	configured_fdflags_ptr = (uintptr_t)$4;
	configured_fdflags_pid = (int)$5;
	configured_fdflags_parent_pid = (int)$6;
	configured_replacement_ctx_init_hold_ns = (uint64_t)$31;
	configured_prealloc_hold_ns = (uint64_t)$32;
	configured_target_bp_u32 = (uint32_t)$34;
	configured_target_bp_be_u32 =
	    ((configured_target_bp_u32 & 0x000000ff) << 24) |
	    ((configured_target_bp_u32 & 0x0000ff00) << 8) |
	    ((configured_target_bp_u32 & 0x00ff0000) >> 8) |
	    ((configured_target_bp_u32 & 0xff000000) >> 24);
	configured_prime_bp_be_u32 = configured_target_bp_be_u32 - 1;
	configured_prime_bp_u32 =
	    ((configured_prime_bp_be_u32 & 0x000000ff) << 24) |
	    ((configured_prime_bp_be_u32 & 0x0000ff00) << 8) |
	    ((configured_prime_bp_be_u32 & 0x00ff0000) >> 8) |
	    ((configured_prime_bp_be_u32 & 0xff000000) >> 24);
	configured_replacement_destroy_hold_ns = (uint64_t)$35;
	configured_repair_on_fdflags_exact = (int)$36;
	configured_cchmac_return_hold_ns = (uint64_t)$37;
	configured_candidate_any_target_outer = (int)$38;
	configured_selective_a_frees_per_target = (int)$39;
	configured_defer_last_four = (int)$40;
	configured_pre_destroy_hold_ns = (uint64_t)$41;
	configured_selective_a_free_slack = (int)$42;
	configured_selective_fanout_fallback_ns = (uint64_t)20000000;
	configured_data_release_deadline_ns = (uint64_t)350000000;
	configured_selective_target_count = 0;
	configured_prime_target_count = 0;
	configured_deferred_target_count = 0;
	if ((int)$7 > 1 && (int)$8 > 1 && (uintptr_t)$9 != 0) {
		fdflags_child_by_parent[(int)$7] = (int)$8;
		fdflags_ptr_by_parent[(int)$7] = (uintptr_t)$9;
		configured_selective_target_count++;
	}
	if ((int)$10 > 1 && (int)$11 > 1 && (uintptr_t)$12 != 0) {
		fdflags_child_by_parent[(int)$10] = (int)$11;
		fdflags_ptr_by_parent[(int)$10] = (uintptr_t)$12;
		configured_selective_target_count++;
	}
	if ((int)$13 > 1 && (int)$14 > 1 && (uintptr_t)$15 != 0) {
		fdflags_child_by_parent[(int)$13] = (int)$14;
		fdflags_ptr_by_parent[(int)$13] = (uintptr_t)$15;
		configured_selective_target_count++;
	}
	if ((int)$16 > 1 && (int)$17 > 1 && (uintptr_t)$18 != 0) {
		fdflags_child_by_parent[(int)$16] = (int)$17;
		fdflags_ptr_by_parent[(int)$16] = (uintptr_t)$18;
		configured_selective_target_count++;
	}
	if ((int)$19 > 1 && (int)$20 > 1 && (uintptr_t)$21 != 0) {
		fdflags_child_by_parent[(int)$19] = (int)$20;
		fdflags_ptr_by_parent[(int)$19] = (uintptr_t)$21;
		configured_selective_target_count++;
	}
	if ((int)$22 > 1 && (int)$23 > 1 && (uintptr_t)$24 != 0) {
		fdflags_child_by_parent[(int)$22] = (int)$23;
		fdflags_ptr_by_parent[(int)$22] = (uintptr_t)$24;
		configured_selective_target_count++;
	}
	if ((int)$25 > 1 && (int)$26 > 1 && (uintptr_t)$27 != 0) {
		fdflags_child_by_parent[(int)$25] = (int)$26;
		fdflags_ptr_by_parent[(int)$25] = (uintptr_t)$27;
		configured_selective_target_count++;
	}
	if ((int)$28 > 1 && (int)$29 > 1 && (uintptr_t)$30 != 0) {
		fdflags_child_by_parent[(int)$28] = (int)$29;
		fdflags_ptr_by_parent[(int)$28] = (uintptr_t)$30;
		configured_selective_target_count++;
	}
	if ((int)$7 > 1 && (uintptr_t)$9 != 0) {
		prime_stage1_parent[(int)$7] = 1;
		configured_prime_target_count++;
	}
	if ((int)$10 > 1 && (uintptr_t)$12 != 0) {
		prime_stage1_parent[(int)$10] = 1;
		configured_prime_target_count++;
	}
	if ((int)$13 > 1 && (uintptr_t)$15 != 0) {
		prime_stage1_parent[(int)$13] = 1;
		configured_prime_target_count++;
	}
	if ((int)$16 > 1 && (uintptr_t)$18 != 0) {
		prime_stage1_parent[(int)$16] = 1;
		configured_prime_target_count++;
	}
	if ((int)$19 > 1 && (uintptr_t)$21 != 0) {
		if (configured_defer_last_four != 0) {
			deferred_stage1_parent[(int)$19] = 1;
			configured_deferred_target_count++;
		} else {
			prime_stage1_parent[(int)$19] = 1;
			configured_prime_target_count++;
		}
	}
	if ((int)$22 > 1 && (uintptr_t)$24 != 0) {
		if (configured_defer_last_four != 0) {
			deferred_stage1_parent[(int)$22] = 1;
			configured_deferred_target_count++;
		} else {
			prime_stage1_parent[(int)$22] = 1;
			configured_prime_target_count++;
		}
	}
	if ((int)$25 > 1 && (uintptr_t)$27 != 0) {
		if (configured_defer_last_four != 0) {
			deferred_stage1_parent[(int)$25] = 1;
			configured_deferred_target_count++;
		} else {
			prime_stage1_parent[(int)$25] = 1;
			configured_prime_target_count++;
		}
	}
	if ((int)$28 > 1 && (uintptr_t)$30 != 0) {
		if (configured_defer_last_four != 0) {
			deferred_stage1_parent[(int)$28] = 1;
			configured_deferred_target_count++;
		} else {
			prime_stage1_parent[(int)$28] = 1;
			configured_prime_target_count++;
		}
	}
	configured_deferred_release_required =
	    configured_deferred_target_count > 1 ?
	    configured_deferred_target_count - 1 :
	    configured_deferred_target_count;
	configured_prime_required_frees =
	    configured_prime_target_count *
	    configured_selective_a_frees_per_target -
	    configured_selective_a_free_slack;
	/* BEGIN GENERATED FDFLAGS MAP */
	configured_prime_required_frees = configured_prime_target_count *
	    configured_selective_a_frees_per_target -
	    configured_selective_a_free_slack;
	/* END GENERATED FDFLAGS MAP */
}

dtrace:::BEGIN
{
	target_outer = (uintptr_t)0;
	target_nfs_cp = (uintptr_t)0;
	outer_cp_freed = 0;
	candidate_outer = (uintptr_t)0;
	target_mic_buf = (uintptr_t)0;
	target_alloc_cpu = -1;
	neighbor_alloc_caller = (uintptr_t)0;
	neighbor_alloc_request = 0;
	neighbor_alloc_key_derivation = 0;
	acl_neighbor_ptr = (uintptr_t)0;
	acl_neighbor_count_before = 0;
	acl_oob_ace_ptr = (uintptr_t)0;
	acl_ready = 0;
	acl_auth_ready = 0;
	acl_window_vap = (uintptr_t)0;
	acl_window_ptr = (uintptr_t)0;
	acl_window_getattr_return_ts = (uint64_t)0;
	acl_window_authorize_entry_ts = (uint64_t)0;
	inherit_exact_seen = 0;
	inherit_result_seen = 0;
	exact_des3 = 0;
	mic_finished = 0;
	mic_async_notified = 0;
	continue_signal_sent = 0;
	candidate_claimed = 0;
	candidate_is_prime = 0;
	replacement_make_done = 0;
	staged_replace_cp = (uintptr_t)0;
	staged_replace_outer = (uintptr_t)0;
	staged_replace_cpu = -1;
	replacement_destroy_cpu = -1;
	replacement_destroy_barrier_done = 0;
	replacement_destroy_barrier_ready = 0;
	pre_destroy_data_barrier_done = 0;
	pre_destroy_data_barrier_ready = 0;
	pre_destroy_barrier_start_ts = (uint64_t)0;
	pre_destroy_data_release_after_ts = (uint64_t)0;
	selective_stage1_total = 0;
	selective_a_free_total = 0;
	target_prealloc_barrier_ready = 0;
	target_deferred_signal_sent = 0;
	target_deferred_parent = 0;
	target_deferred_free_count = 0;
	target_deferred_signal_total = 0;
	deferred_stage1_cpu_used[0] = 0;
	deferred_stage1_cpu_used[1] = 0;
	deferred_stage1_cpu_used[2] = 0;
	deferred_stage1_cpu_used[3] = 0;
	selective_stage1_cpu_used[0] = 0;
	selective_stage1_cpu_used[1] = 0;
	selective_stage1_cpu_used[2] = 0;
	selective_stage1_cpu_used[3] = 0;
	selective_a_owner[(uintptr_t)0] = 0;
	selective_a_slot_plus1[(uintptr_t)0] = 0;
	selective_fanout_signal_sent = 0;
	selected_mic_owner_plus1 = 0;
	selected_mic_slot_plus1 = 0;
	prealloc_barrier_ready = 0;
	prealloc_release_after_ts = (uint64_t)0;
	early_continue_barrier_ready = 0;
	continue_barrier_ready = 0;
	configured_target_client_pid = $33;
	digest_barrier_ready = 0;
	digest_barrier_start_ts = (uint64_t)0;
	target_digest_ptr = (uintptr_t)0;
	digest_temp_ready = 0;
	precopy_ready = 0;
	precopy_async_notified = 0;
	precopy_tid = 0;
	precopy_len = 0;
	precopy_sink = (uintptr_t)0;
	precopy_digest = (uintptr_t)0;
	precopy_cctx = (uintptr_t)0;
	precopy_di = (uintptr_t)0;
	precopy_etype = 0;
	target_mic_tid = 0;
	cchmac_return_barrier_done = 0;
	use_cchmac_return_barrier = 0;
	repair_barrier_ready = 0;
	repair_signal_sent = 0;
	repair_stop_signal_sent = 0;
	repair_make_done = 0;
	repair_null_seen = 0;
	candidate_make_miss_ready = 0;
	mic_entry_hold_active = 0;
	mic_entry_observer_samples = 0;
	fdflags_exact_repair_ready = 0;
	target_crypto_free_count = 0;
	target_crypto_free_hold_count = 0;
	data_signal_sent = 0;
	second_data_signal_sent = 0;
	first_aes_mic_return_seen = 0;
	first_aes_mic_return_ts = (uint64_t)0;
	data_gate_armed = 0;
	target_destroy_count = 0;
	neighbor_freed = 0;
	selected_neighbor_freed = 0;
	postfree_exact_reclaim_seen = 0;
	postfree_exact_e_reclaim_seen = 0;
	voucher_signal_sent = 0;
	fdflags_destination_exact = 0;
	fdflags_inherit_returned = 0;
	fd_close_a_ready = 0;
	fd_close_a_signal_sent = 0;
	fd_close_a_hold_seen = 0;
	fd_close_a_hold_active = 0;
	fd_close_b_signal_sent = 0;
	fd_close_entries = 0;
	fd_fp_close_entries = 0;
	fd_close_a_tid = 0;
	fd_close_b_tid = 0;
	fd_close_a_drain_seen = 0;
	fd_close_b_drain_seen = 0;
	fdflags_waiter_release_signal_sent = 0;
	printf("%llu trace_begin candidate_min_aes_mic=%d mic_hold_ns=%llu cchmac_return_hold_ns=%llu candidate_any_target_outer=%d target_gss_handle=0x%x target_bp_u32=0x%x prime_bp_u32=0x%x fdflags=%p child_pid=%d parent_pid=%d replacement_ctx_init_hold_ns=%llu pre_destroy_hold_ns=%llu replacement_destroy_hold_ns=%llu prealloc_hold_ns=%llu selective_targets=%d prime_targets=%d deferred_targets=%d selective_a_frees_per_target=%d selective_a_free_slack=%d prime_required_frees=%d selective_fanout_fallback_ns=%llu repair_on_fdflags_exact=%d\n",
	    (uint64_t)walltimestamp, configured_candidate_min_aes_mic,
	    configured_mic_hold_ns, configured_cchmac_return_hold_ns,
	    configured_candidate_any_target_outer, configured_target_gss_handle,
	    configured_target_bp_u32,
	    configured_prime_bp_u32,
	    configured_fdflags_ptr, configured_fdflags_pid,
	    configured_fdflags_parent_pid,
	    configured_replacement_ctx_init_hold_ns,
	    configured_pre_destroy_hold_ns,
	    configured_replacement_destroy_hold_ns,
		    configured_prealloc_hold_ns,
		    configured_selective_target_count,
		    configured_prime_target_count,
		    configured_deferred_target_count,
		    configured_selective_a_frees_per_target,
		    configured_selective_a_free_slack,
		    configured_prime_required_frees,
		    configured_selective_fanout_fallback_ns,
		    configured_repair_on_fdflags_exact);
}

fbt:mach_kernel:nfs_gss_svc_verf_put:entry
{
	self->verf_cp = *(uintptr_t *)(arg0 + 0x140);
}

fbt:mach_kernel:nfs_gss_svc_verf_put:return
{
	if (self->verf_cp == target_nfs_cp && target_nfs_cp != 0) {
		printf("%llu OUTER_CP_VERF_RETURN tid=%d cp=%p freed=%d\n",
		    (uint64_t)walltimestamp, tid, self->verf_cp,
		    outer_cp_freed);
	}
	self->verf_cp = 0;
}

fbt:mach_kernel:nfs_gss_svc_ctx_init:entry
{
	self->ctx_init_cp = *(uintptr_t *)(arg0 + 0x140);
	this->ctx_init_inner = self->ctx_init_cp == 0 ? 0 :
	    *(uintptr_t *)(self->ctx_init_cp + 0xa0);
	if (self->ctx_init_cp != 0 &&
	    *(uint32_t *)(self->ctx_init_cp + 0x28) == 2 &&
	    this->ctx_init_inner != 0 &&
	    *(uint32_t *)(this->ctx_init_inner + 0x48) == 18 &&
	    *(uint32_t *)(this->ctx_init_inner + 0xc0) == 12) {
		staged_replace_cp = self->ctx_init_cp;
		staged_replace_outer = this->ctx_init_inner;
		staged_replace_cpu = cpu;
		printf("%llu STAGED_REPLACE_CTX_INIT tid=%d cpu=%d cp=%p outer=%p etype=%d digest=%d\n",
		    (uint64_t)walltimestamp, tid, staged_replace_cpu,
		    staged_replace_cp,
		    staged_replace_outer,
		    *(uint32_t *)(staged_replace_outer + 0x48),
		    *(uint32_t *)(staged_replace_outer + 0xc0));
		if (configured_replacement_ctx_init_hold_ns != 0) {
			printf("%llu STAGED_REPLACE_CTX_INIT_HOLD tid=%d outer=%p holding_ns=%llu\n",
			    (uint64_t)walltimestamp, tid, staged_replace_outer,
			    configured_replacement_ctx_init_hold_ns);
			chill(configured_replacement_ctx_init_hold_ns);
			printf("%llu STAGED_REPLACE_CTX_INIT_RESUME tid=%d outer=%p\n",
			    (uint64_t)walltimestamp, tid,
			    staged_replace_outer);
		}
	}
	printf("%llu OUTER_CP_CTX_INIT tid=%d cp=%p target=%d refcnt=%d proc=%d inner=%p\n",
	    (uint64_t)walltimestamp, tid, self->ctx_init_cp,
	    self->ctx_init_cp == target_nfs_cp,
	    self->ctx_init_cp == 0 ? -1 :
	    *(uint32_t *)(self->ctx_init_cp + 0x24),
	    self->ctx_init_cp == 0 ? -1 :
	    *(uint32_t *)(self->ctx_init_cp + 0x28),
	    self->ctx_init_cp == 0 ? 0 :
	    *(uintptr_t *)(self->ctx_init_cp + 0xa0));
}

fbt:mach_kernel:kfree_type_impl_internal:entry
/self->ctx_init_cp != 0 && arg1 == self->ctx_init_cp/
{
	printf("%llu OUTER_CP_FREE tid=%d view=%p cp=%p target=%d refcnt=%d proc=%d inner=%p\n",
	    (uint64_t)walltimestamp, tid, arg0, arg1,
	    arg1 == target_nfs_cp, *(uint32_t *)(arg1 + 0x24),
	    *(uint32_t *)(arg1 + 0x28), *(uintptr_t *)(arg1 + 0xa0));
	if (arg1 == target_nfs_cp) {
		outer_cp_freed = 1;
	}
}

fbt:mach_kernel:nfs_gss_svc_ctx_init:return
{
	printf("%llu OUTER_CP_CTX_INIT_RETURN tid=%d cp=%p target=%d freed=%d retval=%d\n",
	    (uint64_t)walltimestamp, tid, self->ctx_init_cp,
	    self->ctx_init_cp == target_nfs_cp, outer_cp_freed,
	    (int)arg1);
	self->ctx_init_cp = 0;
}

/*
 * The lucid-context copy returns immediately before the old crypto context is
 * destroyed. Release the groom and DATA request here, then hold this thread so
 * the selected verifier reaches its HMAC barrier while cctx->di is still live.
 */
fbt:mach_kernel:nfs_gss_mach_vmcopyout:return
/self->ctx_init_cp != 0 &&
  self->ctx_init_cp == staged_replace_cp &&
  staged_replace_outer != 0 &&
  pre_destroy_data_barrier_done == 0 &&
  configured_pre_destroy_hold_ns != 0/
{
	pre_destroy_data_barrier_done = 1;
	pre_destroy_data_barrier_ready = 1;
	pre_destroy_barrier_start_ts = timestamp;
	pre_destroy_data_release_after_ts = timestamp;
	prealloc_barrier_ready = 1;
	prealloc_release_after_ts = timestamp;
	printf("%llu PRE_DESTROY_DATA_BARRIER tid=%d cpu=%d cp=%p outer=%p result=%d holding_ns=%llu\n",
	    (uint64_t)walltimestamp, tid, cpu, self->ctx_init_cp,
	    staged_replace_outer, (int)arg1,
	    configured_pre_destroy_hold_ns);
	chill(configured_pre_destroy_hold_ns);
	pre_destroy_data_barrier_ready = 0;
	prealloc_barrier_ready = 0;
	printf("%llu PRE_DESTROY_DATA_RESUME tid=%d cpu=%d outer=%p data_signal=%d frees=%d required=%d precopy_ready=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, staged_replace_outer,
	    data_signal_sent, selective_a_free_total,
	    configured_prime_required_frees, precopy_ready);
}

fbt:mach_kernel:nfs_gss_svc_ctx_deref:entry
/target_nfs_cp != 0 && arg0 == target_nfs_cp/
{
	printf("%llu OUTER_CP_DEREF tid=%d cp=%p freed=%d\n",
	    (uint64_t)walltimestamp, tid, arg0, outer_cp_freed);
}

profile:::profile-997
/target_mic_buf != 0 && mic_finished == 0 && mic_async_notified == 0/
{
	mic_async_notified = 1;
	printf("%llu MIC_ALLOC_ASYNC cpu=%d ptr=%p outer=%p\n",
	    (uint64_t)walltimestamp, cpu, target_mic_buf, target_outer);
}

profile:::profile-997
/precopy_ready != 0 && precopy_async_notified == 0/
{
	precopy_async_notified = 1;
	printf("%llu PRE_MEMCPY_ASYNC target_tid=%d observer_cpu=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d exact_des3=%d\n",
	    (uint64_t)walltimestamp, precopy_tid, cpu, precopy_cctx,
	    precopy_di, precopy_sink, precopy_digest, precopy_len,
	    precopy_etype, exact_des3);
}

syscall::getpid:entry
/execname == "rgssig" && pid == configured_target_client_pid &&
  candidate_claimed != 0 && target_outer != 0 &&
  (early_continue_barrier_ready != 0 || continue_barrier_ready != 0) &&
  (selected_mic_owner_plus1 != 0 || mic_finished != 0) &&
  continue_signal_sent == 0/
{
	continue_signal_sent = 1;
	printf("%llu DTRACE_CONTINUE_SIGNAL pid=%d ptr=%p outer=%p early=%d final=%d signal=SIGIO\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    early_continue_barrier_ready, continue_barrier_ready);
	raise(23);
}

syscall::access:entry
/execname == "rgssig" && pid == configured_target_client_pid &&
  candidate_claimed != 0 && target_outer != 0 &&
  (early_continue_barrier_ready != 0 || continue_barrier_ready != 0) &&
  (selected_mic_owner_plus1 != 0 || mic_finished != 0) &&
  continue_signal_sent == 0/
{
	continue_signal_sent = 1;
	printf("%llu DTRACE_CONTINUE_SIGNAL pid=%d ptr=%p outer=%p early=%d final=%d syscall=access signal=SIGIO\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    early_continue_barrier_ready, continue_barrier_ready);
	raise(23);
}

syscall::getpgid:entry
/execname == "rgssig" && pid == configured_target_client_pid &&
  target_outer != 0 &&
  (repair_barrier_ready != 0 || exact_des3 != 0) &&
  repair_signal_sent == 0 && arg0 == 0x7b02/
{
	repair_signal_sent = 1;
	candidate_make_miss_ready = 0;
	printf("%llu DTRACE_REPAIR_CONTINUE_RELEASE pid=%d ptr=%p outer=%p cctx=%p di=%p destroy_count=%d exact_des3=%d send=%d signal=SIGUSR2\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    target_outer + 0x48, *(uintptr_t *)(target_outer + 0x78),
	    target_destroy_count, exact_des3, exact_des3 == 0);
	raise(31);
}

syscall::getpgid:entry
/execname == "rgssig" && pid == configured_target_client_pid &&
  target_outer != 0 && exact_des3 != 0 && repair_signal_sent != 0 &&
  repair_stop_signal_sent == 0 && arg0 == 0x7b03/
{
	repair_stop_signal_sent = 1;
	printf("%llu DTRACE_REPAIR_CONTINUE_STOP pid=%d ptr=%p outer=%p destroy_count=%d repair_make=%d signal=SIGALRM\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf, target_outer,
	    target_destroy_count, repair_make_done);
	raise(14);
}

syscall::getpgid:entry
/execname == "rgssig" && staged_replace_outer != 0 &&
  data_gate_armed == 0 && arg0 == 0x7b04/
{
	data_gate_armed = 1;
	printf("%llu STAGED_CTX_DATA_GATE_ARMED pid=%d cpu=%d replacement=%p released=%d\n",
	    (uint64_t)walltimestamp, pid, cpu, staged_replace_outer,
	    selective_stage1_total);
}

syscall::getpgid:entry
	/execname == "rgssig" && pid == configured_target_client_pid &&
	  staged_replace_outer != 0 &&
	  (pre_destroy_data_barrier_ready != 0 ||
	  replacement_destroy_barrier_ready != 0) &&
	  first_aes_mic_return_seen != 0 &&
	  (configured_defer_last_four == 0 ||
  target_deferred_free_count >= configured_deferred_release_required *
    configured_selective_a_frees_per_target) &&
  second_data_signal_sent == 0 && arg0 == 0x7b05/
{
	this->first_mic_age = timestamp >= first_aes_mic_return_ts ?
	    timestamp - first_aes_mic_return_ts : (uint64_t)0;
	second_data_signal_sent = 1;
	printf("%llu DTRACE_SECOND_DATA_RELEASE pid=%d cpu=%d replacement=%p di=%p first_mic_age_ns=%llu deferred_signals=%d deferred_frees=%d signal=SIGURG\n",
	    (uint64_t)walltimestamp, pid, cpu, staged_replace_outer,
	    *(uintptr_t *)(staged_replace_outer + 0x78),
	    (uint64_t)this->first_mic_age,
	    target_deferred_signal_total, target_deferred_free_count);
	raise(16);
}

fbt:mach_kernel:gss_krb5_destroy_context:entry
/staged_replace_outer != 0 && arg0 == staged_replace_outer &&
  replacement_destroy_barrier_done == 0/
{
	replacement_destroy_barrier_done = 1;
	replacement_destroy_barrier_ready = 1;
	replacement_destroy_cpu = cpu;
	if (cpu >= 0 && cpu < 4) {
		deferred_stage1_cpu_used[cpu] = 1;
	}
	prealloc_barrier_ready = 1;
	prealloc_release_after_ts = timestamp;
	self->replacement_first_destroy = 1;
	this->replacement_destroy_applied_ns =
	    precopy_ready != 0 &&
	    candidate_is_prime == 0 &&
	    configured_replacement_destroy_hold_ns > 100000000 ?
	    (uint64_t)100000000 :
	    configured_replacement_destroy_hold_ns;
	printf("%llu REPLACEMENT_DESTROY_BARRIER tid=%d cpu=%d outer=%p cp=%p configured_ns=%llu holding_ns=%llu precopy_ready=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0, staged_replace_cp,
	    configured_replacement_destroy_hold_ns,
	    this->replacement_destroy_applied_ns, precopy_ready);
	if (this->replacement_destroy_applied_ns != 0) {
		chill(this->replacement_destroy_applied_ns);
	}
	printf("%llu REPLACEMENT_DESTROY_RESUME tid=%d outer=%p target=%p\n",
	    (uint64_t)walltimestamp, tid, arg0, target_outer);
	this->replacement_destroy_applied_ns = 0;
}

fbt:mach_kernel:gss_krb5_destroy_context:entry
/staged_replace_outer != 0 && arg0 == staged_replace_outer &&
  replacement_destroy_barrier_done != 0 &&
  self->replacement_first_destroy == 0 &&
  target_outer == 0 && mic_finished == 0/
{
	self->replacement_extra_destroy = 1;
	printf("%llu REPLACEMENT_EXTRA_DESTROY_HOLD tid=%d cpu=%d outer=%p di=%p candidate=%d holding_ns=%llu\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uintptr_t *)(arg0 + 0x78), candidate_claimed,
	    configured_replacement_destroy_hold_ns);
	if (configured_replacement_destroy_hold_ns != 0) {
		chill(configured_replacement_destroy_hold_ns);
	}
	printf("%llu REPLACEMENT_EXTRA_DESTROY_RESUME tid=%d outer=%p di=%p candidate=%d target=%p\n",
	    (uint64_t)walltimestamp, tid, arg0,
	    *(uintptr_t *)(arg0 + 0x78), candidate_claimed, target_outer);
}

fbt:mach_kernel:gss_krb5_destroy_context:return
/self->replacement_first_destroy || self->replacement_extra_destroy/
{
	replacement_destroy_barrier_ready = 0;
	printf("%llu REPLACEMENT_DESTROY_RETURN tid=%d outer=%p first=%d extra=%d candidate=%d target=%p\n",
	    (uint64_t)walltimestamp, tid, staged_replace_outer,
	    self->replacement_first_destroy,
	    self->replacement_extra_destroy, candidate_claimed, target_outer);
	self->replacement_first_destroy = 0;
	self->replacement_extra_destroy = 0;
}

syscall::getpid:entry
/execname == "v32datafanout" && data_gate_armed != 0 &&
  configured_pre_destroy_hold_ns != 0 &&
  pre_destroy_data_barrier_ready != 0 &&
	  timestamp >= pre_destroy_data_release_after_ts &&
	  timestamp - pre_destroy_data_release_after_ts <=
	    configured_data_release_deadline_ns &&
	  staged_replace_outer != 0 &&
	  *(uintptr_t *)(staged_replace_outer + 0x78) != 0 &&
	  configured_selective_target_count > 0 &&
	  data_signal_sent == 0/
{
	data_signal_sent = 1;
	printf("%llu DTRACE_PRE_DESTROY_DATA_FANOUT_SIGNAL pid=%d cpu=%d replacement=%p di=%p frees=%d required=%d elapsed_ns=%llu\n",
	    (uint64_t)walltimestamp, pid, cpu, staged_replace_outer,
	    *(uintptr_t *)(staged_replace_outer + 0x78),
	    selective_a_free_total, configured_prime_required_frees,
	    (uint64_t)(timestamp - pre_destroy_data_release_after_ts));
	raise(30);
}

syscall::getpid:entry
/execname == "v32datafanout" && data_gate_armed != 0 &&
  replacement_destroy_barrier_ready != 0 &&
	  timestamp >= prealloc_release_after_ts &&
	  timestamp - prealloc_release_after_ts <=
	    configured_data_release_deadline_ns &&
	  selective_a_free_total >= configured_prime_required_frees &&
	  (configured_defer_last_four == 0 ||
	  target_deferred_free_count >= configured_deferred_release_required *
	    configured_selective_a_frees_per_target) &&
  staged_replace_outer != 0 &&
  *(uintptr_t *)(staged_replace_outer + 0x78) != 0 &&
  configured_selective_target_count > 0 &&
  data_signal_sent == 0/
{
	data_signal_sent = 1;
	printf("%llu DTRACE_DESTROY_DATA_FANOUT_SIGNAL pid=%d cpu=%d replacement=%p di=%p holding=%d a_frees=%d prime_required=%d deferred_signals=%d deferred_frees=%d deferred_required=%d elapsed_ns=%llu\n",
	    (uint64_t)walltimestamp, pid, cpu, staged_replace_outer,
	    *(uintptr_t *)(staged_replace_outer + 0x78),
	    replacement_destroy_barrier_ready,
	    selective_a_free_total,
	    configured_prime_required_frees,
	    target_deferred_signal_total, target_deferred_free_count,
	    configured_deferred_release_required *
	    configured_selective_a_frees_per_target,
	    (uint64_t)(timestamp - prealloc_release_after_ts));
	raise(30);
}

syscall::getpid:entry
/execname == "v32datafanout" && data_gate_armed != 0 &&
  replacement_destroy_barrier_ready != 0 &&
  prealloc_release_after_ts != 0 &&
	  timestamp >= prealloc_release_after_ts &&
	    timestamp - prealloc_release_after_ts >
	      configured_data_release_deadline_ns &&
  data_signal_sent == 0/
{
	data_signal_sent = -1;
	printf("%llu DTRACE_DESTROY_DATA_DEADLINE_ABORT pid=%d cpu=%d replacement=%p elapsed_ns=%llu a_frees=%d required_a_frees=%d\n",
	    (uint64_t)walltimestamp, pid, cpu, staged_replace_outer,
	    (uint64_t)(timestamp - prealloc_release_after_ts),
	    selective_a_free_total,
	    configured_prime_required_frees);
	raise(15);
}

fbt:mach_kernel:gss_krb5_destroy_context:entry
/target_outer != 0 && arg0 == target_outer/
{
	self->repair_target_destroy = 1;
	target_destroy_count++;
	printf("%llu TARGET_DESTROY_ENTRY tid=%d cpu=%d outer=%p etype=%d digest=%d di=%p count=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uint32_t *)(arg0 + 0x48), *(uint32_t *)(arg0 + 0xc0),
	    *(uintptr_t *)(arg0 + 0x78), target_destroy_count);
}

fbt:mach_kernel:gss_krb5_make_context:return
/candidate_outer != 0 && arg1 != 0 &&
  self->ctx_init_cp == target_nfs_cp/
{
	printf("%llu MAKE_AFTER_CANDIDATE tid=%d ctx=%p candidate=%p exact_addr=%d etype=%d digest=%d keylen=%d di=%p repair_sent=%d\n",
	    (uint64_t)walltimestamp, tid, arg1, candidate_outer,
	    arg1 == candidate_outer,
	    *(uint32_t *)(arg1 + 0x48), *(uint32_t *)(arg1 + 0xc0),
	    *(uint32_t *)(arg1 + 0xc4), *(uintptr_t *)(arg1 + 0x78),
	    repair_signal_sent);
	if (arg1 != candidate_outer && exact_des3 == 0) {
		candidate_make_miss_ready = 1;
		repair_barrier_ready = 1;
		printf("%llu CANDIDATE_MAKE_MISS_RETRY_ARMED tid=%d ctx=%p candidate=%p repair_sent=%d\n",
		    (uint64_t)walltimestamp, tid, arg1, candidate_outer,
		    repair_signal_sent);
	}
	if (arg1 == candidate_outer &&
	    *(uint32_t *)(arg1 + 0x48) == 16 &&
	    *(uint32_t *)(arg1 + 0xc0) == 20 &&
	    *(uint32_t *)(arg1 + 0xc4) == 24 &&
	    *(uintptr_t *)(arg1 + 0x78) != 0) {
		exact_des3 = 1;
		repair_make_done = 1;
		candidate_make_miss_ready = 0;
		digest_barrier_ready = 1;
		repair_barrier_ready = 0;
		printf("%llu EXACT_DES3_REPAIR_READY_PREALLOC tid=%d outer=%p di=%p destroy_count=%d\n",
		    (uint64_t)walltimestamp, tid, arg1,
		    *(uintptr_t *)(arg1 + 0x78), target_destroy_count);
	}
}

syscall::getpid:entry
/execname == "v32select" &&
  prealloc_barrier_ready != 0 &&
  cpu >= 0 && cpu < 4 &&
  selective_stage1_cpu_used[cpu] == 0 &&
  prime_stage1_parent[pid] != 0 &&
  selective_stage1_total < configured_prime_target_count &&
  selective_stage1_signal_sent[pid] == 0/
{
	selective_stage1_total++;
	selective_stage1_cpu_used[cpu] = 1;
	selective_stage1_signal_sent[pid] = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE1_SIGNAL pid=%d target_cpu=%d helper_cpu=%d release_ordinal=%d elapsed_ns=%llu\n",
	    (uint64_t)walltimestamp, pid, target_alloc_cpu, cpu,
	    selective_stage1_total,
	    (uint64_t)(timestamp - prealloc_release_after_ts));
	raise(30);
}

syscall::getpid:entry
/execname == "v32fanout" &&
	  prealloc_barrier_ready != 0 &&
  prealloc_release_after_ts != 0 &&
  timestamp - prealloc_release_after_ts >=
    configured_selective_fanout_fallback_ns &&
  configured_prime_target_count > 0 &&
  selective_a_free_total < configured_prime_required_frees &&
  selective_fanout_signal_sent == 0/
{
	selective_fanout_signal_sent = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE1_FANOUT_FALLBACK pid=%d cpu=%d a_frees=%d required_a_frees=%d elapsed_ns=%llu\n",
	    (uint64_t)walltimestamp, pid, cpu, selective_a_free_total,
	    configured_prime_required_frees,
	    (uint64_t)(timestamp - prealloc_release_after_ts));
	raise(30);
}

syscall::getpid:entry
/execname == "v32select" &&
	  replacement_destroy_barrier_ready != 0 &&
	  selective_a_free_total >= configured_prime_required_frees &&
	  deferred_stage1_parent[pid] != 0 &&
	  cpu >= 0 && cpu < 4 &&
	  deferred_stage1_cpu_used[cpu] == 0 &&
	  selective_stage1_signal_sent[pid] == 0 &&
	  target_deferred_signal_total < configured_deferred_release_required/
{
	deferred_stage1_cpu_used[cpu] = 1;
	target_deferred_signal_total++;
	selective_stage1_signal_sent[pid] = 1;
	printf("%llu DTRACE_DEFERRED_AVAILABLE_CPU_STAGE1_SIGNAL pid=%d destroy_cpu=%d helper_cpu=%d ordinal=%d targets=%d frees_needed=%d\n",
	    (uint64_t)walltimestamp, pid, replacement_destroy_cpu, cpu,
	    target_deferred_signal_total, configured_deferred_release_required,
	    configured_deferred_release_required *
	    configured_selective_a_frees_per_target);
	raise(30);
}

syscall::getpid:entry
/execname == "v32select" &&
  replacement_destroy_barrier_ready != 0 &&
  prealloc_release_after_ts != 0 &&
  timestamp >= prealloc_release_after_ts &&
  timestamp - prealloc_release_after_ts >= 30000000 &&
  selective_a_free_total >= configured_prime_required_frees &&
  deferred_stage1_parent[pid] != 0 &&
  selective_stage1_signal_sent[pid] == 0 &&
  target_deferred_signal_total < configured_deferred_release_required/
{
	target_deferred_signal_total++;
	selective_stage1_signal_sent[pid] = 1;
	printf("%llu DTRACE_DEFERRED_STAGE1_FALLBACK_SIGNAL pid=%d destroy_cpu=%d helper_cpu=%d ordinal=%d targets=%d elapsed_ns=%llu\n",
	    (uint64_t)walltimestamp, pid, replacement_destroy_cpu, cpu,
	    target_deferred_signal_total, configured_deferred_release_required,
	    (uint64_t)(timestamp - prealloc_release_after_ts));
	raise(30);
}

syscall::getpgid:entry
/execname == "v32select" && target_mic_buf != 0 &&
  selected_mic_owner_plus1 != 0 &&
  selected_mic_slot_plus1 > 0 &&
  selected_mic_slot_plus1 <= 32 &&
  pid + 1 == selected_mic_owner_plus1 &&
  arg0 == 0x6a00 + selected_mic_slot_plus1 &&
  selective_stage2_diagnostic[pid] == 0/
{
	selective_stage2_diagnostic[pid] = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE2_STATE pid=%d configured_parent=%d owner=%d slot=%d mic_finished=%d digest_ready=%d\n",
	    (uint64_t)walltimestamp, pid, configured_fdflags_parent_pid,
	    selected_mic_owner_plus1 - 1, selected_mic_slot_plus1 - 1,
	    mic_finished, digest_temp_ready);
}

syscall::getpgid:entry
/execname == "v32select" &&
  candidate_is_prime == 0 &&
  precopy_ready != 0 &&
  selected_mic_slot_plus1 > 0 &&
  selected_mic_slot_plus1 <= 32 &&
  pid + 1 == selected_mic_owner_plus1 &&
  arg0 == 0x6a00 + selected_mic_slot_plus1 &&
  selective_stage2_signal_sent[pid] == 0/
{
	selective_stage2_signal_sent[pid] = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE2_PROBE pid=%d slot=%d marker=0x%x target_cpu=%d helper_cpu=%d digest_ptr=%p etype_live=%d digest_live=%d\n",
	    (uint64_t)walltimestamp, pid, selected_mic_slot_plus1 - 1,
	    (int)arg0, target_alloc_cpu, cpu, target_digest_ptr,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0));
	raise(31);
}

syscall::getpgid:entry
/execname == "v32select" &&
  candidate_is_prime == 0 &&
  precopy_ready != 0 &&
  selected_mic_slot_plus1 > 0 &&
  selected_mic_slot_plus1 <= 32 &&
  pid + 1 == selected_mic_owner_plus1 &&
  arg0 == 0x6b00 + selected_mic_slot_plus1 &&
  selective_stage2_prefree_signal_sent[pid] == 0/
{
	selective_stage2_prefree_signal_sent[pid] = 1;
	printf("%llu DTRACE_SELECTIVE_STAGE2_PREFREE pid=%d slot=%d marker=0x%x target_cpu=%d helper_cpu=%d mic=%p b=%p fdflags=%p\n",
	    (uint64_t)walltimestamp, pid, selected_mic_slot_plus1 - 1,
	    (int)arg0, target_alloc_cpu, cpu, target_mic_buf,
	    target_mic_buf + 32, configured_fdflags_ptr);
	raise(16);
}

syscall::getpgid:entry
/pid == configured_fdflags_pid &&
  arg0 == configured_fdflags_parent_pid &&
  inherit_exact_seen != 0 && fd_close_a_signal_sent == 0/
{
	fd_close_a_signal_sent = 1;
	printf("%llu FDFLAGS_CLOSE_A_SIGNAL child_pid=%d parent_pid=%d flags=%p byte17=0x%x\n",
	    (uint64_t)walltimestamp, pid, arg0, configured_fdflags_ptr,
	    *(uint8_t *)(configured_fdflags_ptr + 17));
	raise(30);
}

syscall::getpgid:entry
/pid == configured_fdflags_pid &&
  arg0 == configured_fdflags_parent_pid &&
  fd_close_a_drain_seen != 0 && fd_close_b_signal_sent == 0 &&
  fdflags_destination_exact != 0 && fdflags_inherit_returned != 0/
{
	fd_close_b_signal_sent = 1;
	printf("%llu FDFLAGS_CLOSE_B_SIGNAL child_pid=%d parent_pid=%d flags=%p byte17=0x%x influx=0x%x close_entries=%d inherit_returned=%d\n",
	    (uint64_t)walltimestamp, pid, arg0, configured_fdflags_ptr,
	    *(uint8_t *)(configured_fdflags_ptr + 17),
	    *(uint8_t *)(configured_fdflags_ptr + 17) & 0xc,
	    fd_close_entries, fdflags_inherit_returned);
	raise(31);
}

fbt:mach_kernel:close_nocancel:entry
/pid == configured_fdflags_pid && arg2 == 17/
{
	fd_close_entries++;
	printf("%llu FDFLAGS_CLOSE_ENTRY pid=%d tid=%d ordinal=%d fd=%d flags=%p byte17=0x%x q0=0x%llx\n",
	    (uint64_t)walltimestamp, pid, tid, fd_close_entries, (int)arg2,
	    configured_fdflags_ptr,
	    *(uint8_t *)(configured_fdflags_ptr + 17),
	    *(uint64_t *)configured_fdflags_ptr);
}

fbt:mach_kernel:fp_close_and_unlock_with_action:entry
/pid == configured_fdflags_pid && arg2 == 17/
{
	fd_fp_close_entries++;
	if (fd_fp_close_entries == 1) {
		fd_close_a_tid = tid;
	}
	if (fd_fp_close_entries == 2) {
		fd_close_b_tid = tid;
	}
	printf("%llu FDFLAGS_FP_CLOSE_ENTRY pid=%d tid=%d ordinal=%d fd=%d fp=%p flags=%p byte17=0x%x\n",
	    (uint64_t)walltimestamp, pid, tid, fd_fp_close_entries,
	    (int)arg2, arg3, configured_fdflags_ptr,
	    *(uint8_t *)(configured_fdflags_ptr + 17));
	if (fd_fp_close_entries == 2 &&
	    (*(uint8_t *)(configured_fdflags_ptr + 17) & 0xc) == 0) {
		printf("%llu FDFLAGS_SECOND_CLOSE_CLASS=DOUBLE_CLOSE_PATH pid=%d tid=%d fd=%d byte17=0x%x\n",
		    (uint64_t)walltimestamp, pid, tid, (int)arg2,
		    *(uint8_t *)(configured_fdflags_ptr + 17));
	}
	if (fd_fp_close_entries == 2 &&
	    (*(uint8_t *)(configured_fdflags_ptr + 17) & 0xc) != 0) {
		printf("%llu FDFLAGS_SECOND_CLOSE_CLASS=INFLUX_PANIC_NEGATIVE_CONTROL pid=%d tid=%d fd=%d byte17=0x%x\n",
		    (uint64_t)walltimestamp, pid, tid, (int)arg2,
		    *(uint8_t *)(configured_fdflags_ptr + 17));
	}
}

fbt:mach_kernel:lck_mtx_sleep:entry
/pid == configured_fdflags_pid && fd_close_a_tid != 0 &&
  tid == fd_close_a_tid && fd_close_a_drain_seen == 0/
{
	fd_close_a_drain_seen = 1;
	printf("%llu FDFLAGS_CLOSE_A_DRAIN_SLEEP pid=%d tid=%d cpu=%d flags=%p byte17=0x%x close_entries=%d fp_close_entries=%d lock=%p event=%p\n",
	    (uint64_t)walltimestamp, pid, tid, cpu, configured_fdflags_ptr,
	    *(uint8_t *)(configured_fdflags_ptr + 17), fd_close_entries,
	    fd_fp_close_entries, arg0, arg1);
}

fbt:mach_kernel:lck_mtx_sleep:entry
/pid == configured_fdflags_pid && fd_close_b_tid != 0 &&
  tid == fd_close_b_tid && fd_close_b_drain_seen == 0/
{
	fd_close_b_drain_seen = 1;
	printf("%llu FDFLAGS_CLOSE_B_DRAIN_SLEEP pid=%d tid=%d cpu=%d flags=%p byte17=0x%x close_entries=%d fp_close_entries=%d lock=%p event=%p\n",
	    (uint64_t)walltimestamp, pid, tid, cpu, configured_fdflags_ptr,
	    *(uint8_t *)(configured_fdflags_ptr + 17), fd_close_entries,
	    fd_fp_close_entries, arg0, arg1);
	if (fdflags_waiter_release_signal_sent == 0) {
		fdflags_waiter_release_signal_sent = 1;
		printf("%llu FDFLAGS_WAITER_RELEASE_SIGNAL pid=%d tid=%d signal=SIGALRM\n",
		    (uint64_t)walltimestamp, pid, tid);
		raise(14);
	}
}

syscall::getpid:entry
/execname == "aclbridge" && selected_neighbor_freed != 0 &&
  exact_des3 != 0 &&
  acl_signal_sent[pid] == 0/
{
	acl_signal_sent[pid] = 1;
	raise(30);
}

syscall::getpid:entry
/execname == "v32oracle" && acl_ready != 0 &&
  target_alloc_cpu >= 0 && cpu == target_alloc_cpu &&
  voucher_signal_sent == 0/
{
	voucher_signal_sent = 1;
	printf("%llu DTRACE_VOUCHER_SIGNAL pid=%d acl=%p oob_ace=%p\n",
	    (uint64_t)walltimestamp, pid, acl_neighbor_ptr,
	    acl_neighbor_ptr + 32);
	raise(30);
}

fbt:mach_kernel:vnode_getattr:entry
/(execname == "aclsig" || execname == "v32select") &&
  target_mic_buf != 0 &&
  mic_finished == 0 && arg1 != 0/
{
	self->window_vap = arg1;
}

fbt:mach_kernel:vnode_getattr:return
/self->window_vap != 0/
{
	this->window_acl = *(uintptr_t *)(self->window_vap + 0x58);
	if (target_mic_buf != 0 && mic_finished == 0 &&
	    this->window_acl == target_mic_buf + 32) {
		acl_window_vap = self->window_vap;
		acl_window_ptr = this->window_acl;
		acl_window_getattr_return_ts = timestamp;
		acl_window_authorize_entry_ts = (uint64_t)0;
		printf("%llu EXACT_ACL_WINDOW_GETATTR_RETURN tid=%d vap=%p ptr=%p count=0x%x mono_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, acl_window_vap,
		    acl_window_ptr, *(uint32_t *)acl_window_ptr,
		    acl_window_getattr_return_ts);
	}
	self->window_vap = (uintptr_t)0;
}

fbt:mach_kernel:vfs_attr_pack_ext:entry
/(execname == "aclsig" || execname == "v32select") &&
  target_mic_buf != 0 &&
  mic_finished == 0 && arg5 != 0 &&
  *(uintptr_t *)(arg5 + 0x58) == target_mic_buf + 32/
{
	acl_neighbor_ptr = *(uintptr_t *)(arg5 + 0x58);
	acl_neighbor_count_before = *(uint32_t *)acl_neighbor_ptr;
	acl_ready = 1;
	printf("%llu EXACT_ACL32_PACK_ENTRY tid=%d vap=%p ptr=%p count_before=%u holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, arg5, acl_neighbor_ptr,
	    acl_neighbor_count_before);
	printf("%llu EXACT_ACL32_PACK_RESUME tid=%d ptr=%p count_after=0x%x exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, acl_neighbor_ptr,
	    *(uint32_t *)acl_neighbor_ptr, exact_des3);
}

fbt:mach_kernel:vnode_attr_authorize_internal:entry
/(execname == "aclsig" || execname == "v32select") &&
  target_mic_buf != 0 &&
  mic_finished == 0 && acl_ready == 0 && arg0 != 0 &&
  *(uintptr_t *)(arg0 + 8) != 0 &&
  *(uintptr_t *)(*(uintptr_t *)(arg0 + 8) + 0x58) ==
    target_mic_buf + 32/
{
	this->vap = *(uintptr_t *)(arg0 + 8);
	acl_neighbor_ptr = *(uintptr_t *)(this->vap + 0x58);
	acl_neighbor_count_before = *(uint32_t *)acl_neighbor_ptr;
	acl_oob_ace_ptr = acl_neighbor_ptr + 32;
	acl_ready = 1;
	acl_auth_ready = 1;
	self->exact_auth = 1;
	if (acl_window_getattr_return_ts != 0 &&
	    this->vap == acl_window_vap &&
	    acl_neighbor_ptr == acl_window_ptr) {
		acl_window_authorize_entry_ts = timestamp;
		printf("%llu EXACT_ACL_WINDOW_AUTHORIZE_ENTRY tid=%d vap=%p ptr=%p count=0x%x mono_ns=%llu delta_getattr_return_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, this->vap,
		    acl_neighbor_ptr, *(uint32_t *)acl_neighbor_ptr,
		    acl_window_authorize_entry_ts,
		    acl_window_authorize_entry_ts -
		    acl_window_getattr_return_ts);
	}
	printf("%llu EXACT_ACL32_AUTH_ENTRY tid=%d vcp=%p vap=%p ptr=%p count_before=%u oob_ace=%p guid_q0=0x%llx guid_q1=0x%llx flags=0x%x rights=0x%x holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, arg0, this->vap,
	    acl_neighbor_ptr, acl_neighbor_count_before, acl_oob_ace_ptr,
	    *(uint64_t *)acl_oob_ace_ptr,
	    *(uint64_t *)(acl_oob_ace_ptr + 8),
	    *(uint32_t *)(acl_oob_ace_ptr + 16),
	    *(uint32_t *)(acl_oob_ace_ptr + 20));
	printf("%llu EXACT_ACL32_AUTH_RESUME tid=%d ptr=%p count_after=0x%x exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, acl_neighbor_ptr,
	    *(uint32_t *)acl_neighbor_ptr, exact_des3);
}

/*
 * kauth_acl_inherit sizes a separate destination from the first source scan,
 * then reloads the source count for its copy loop. Hold only after the exact
 * 32-byte destination allocation, once vnode_getattr has returned the MIC
 * neighbor as the source. The MIC thread can then change source count 1 to a
 * predictor-selected value in [2,128] while the destination remains sized for
 * one inheritable ACE.
 */
fbt:mach_kernel:kauth_acl_inherit:entry
/execname == "v32select" && target_mic_buf != 0 && mic_finished == 0/
{
	self->in_inherit = 1;
	self->inherit_start = timestamp;
	self->inherit_initial = (uintptr_t)arg1;
	self->inherit_productp = (uintptr_t)arg2;
	self->inherit_isdir = (uint32_t)arg3;
	self->inherit_getattr = 0;
	self->inherit_source = (uintptr_t)0;
	self->inherit_source_count_before = 0;
	self->inherit_source_count_at_alloc_entry = 0;
	self->inherit_source_count_at_alloc_return = 0;
	self->inherit_source_count_after = 0;
	self->inherit_source_exact = 0;
	self->inherit_oob_q0 = 0;
	self->inherit_oob_q1 = 0;
	self->inherit_oob_q2 = 0;
	self->inherit_dst_alloc = 0;
	self->inherit_dst_seen = 0;
	self->inherit_dst = (uintptr_t)0;
	printf("%llu ACL_INHERIT_ENTRY tid=%d cpu=%d dvp=%p initial=%p productp=%p isdir=%u\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0, arg1, arg2,
	    (uint32_t)arg3);
}

fbt:mach_kernel:vnode_getattr:entry
/self->in_inherit && arg1 != 0/
{
	self->inherit_getattr = 1;
	self->inherit_vap = (uintptr_t)arg1;
}

fbt:mach_kernel:vnode_getattr:return
/self->inherit_getattr/
{
	this->inherit_acl = *(uintptr_t *)(self->inherit_vap + 0x58);
	self->inherit_source = this->inherit_acl;
	self->inherit_source_count_before = this->inherit_acl == 0 ? 0 :
	    *(uint32_t *)this->inherit_acl;
	printf("%llu INHERIT_SOURCE_OBSERVED tid=%d cpu=%d source=%p count=%u b=%p e=%p source_is_b=%d source_is_e=%d source_a_owner=%d source_a_slot=%d getattr_error=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, this->inherit_acl,
	    (uint32_t)self->inherit_source_count_before, target_mic_buf + 32,
	    configured_fdflags_ptr - 32,
	    this->inherit_acl == target_mic_buf + 32,
	    this->inherit_acl + 32 == configured_fdflags_ptr,
	    selective_a_owner[this->inherit_acl] == 0 ? -1 :
	    selective_a_owner[this->inherit_acl] - 1,
	    selective_a_slot_plus1[this->inherit_acl] == 0 ? -1 :
	    selective_a_slot_plus1[this->inherit_acl] - 1,
	    (int)arg1);
	if (this->inherit_acl == target_mic_buf + 32 &&
	    self->inherit_source_count_before == 1) {
		self->inherit_source_exact = 1;
		self->inherit_oob_q0 =
		    *(uint64_t *)(this->inherit_acl + 32);
		self->inherit_oob_q1 =
		    *(uint64_t *)(this->inherit_acl + 40);
		self->inherit_oob_q2 =
		    *(uint64_t *)(this->inherit_acl + 48);
		inherit_exact_seen = 1;
		printf("%llu EXACT_INHERIT_SOURCE tid=%d vap=%p source=%p count_before=%u oob_ace=%p flags=0x%x rights=0x%x getattr_error=%d\n",
		    (uint64_t)walltimestamp, tid, self->inherit_vap,
		    this->inherit_acl,
		    (uint32_t)self->inherit_source_count_before,
		    this->inherit_acl + 32,
		    *(uint32_t *)(this->inherit_acl + 48),
			*(uint32_t *)(this->inherit_acl + 52), (int)arg1);
	}
	postfree_release_window = 0;
	self->inherit_getattr = 0;
}

fbt:mach_kernel:kalloc_ext:entry
/self->in_inherit && self->inherit_source_exact &&
  self->inherit_dst_seen == 0 && arg1 == 32/
{
	self->inherit_dst_alloc = 1;
	self->inherit_dst_seen = 1;
	self->inherit_dst_request = (uint64_t)arg1;
	self->inherit_dst_caller = (uintptr_t)caller;
	self->inherit_source_count_at_alloc_entry =
	    *(uint32_t *)self->inherit_source;
	printf("%llu EXACT_INHERIT_DST_ALLOC_ENTRY tid=%d source=%p count_getattr=%u count_at_alloc_entry=%u request=%llu caller=%p\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source,
	    (uint32_t)self->inherit_source_count_before,
	    (uint32_t)self->inherit_source_count_at_alloc_entry,
	    (uint64_t)arg1, caller);
}

fbt:mach_kernel:kalloc_ext:return
/self->inherit_dst_alloc/
{
	self->inherit_dst = (uintptr_t)arg1;
	self->inherit_source_count_at_alloc_return =
	    *(uint32_t *)self->inherit_source;
	this->fdflags_exact =
	    self->inherit_dst + 32 == configured_fdflags_ptr;
	this->inherit_hold_ns = this->fdflags_exact ?
	    configured_cchmac_return_hold_ns : (uint64_t)0;
	printf("%llu EXACT_INHERIT_DST_ALLOC_RETURN tid=%d source=%p dst=%p request=%llu caller=%p count_getattr=%u count_at_alloc_entry=%u count_at_alloc_return=%u flags=0x%x mic_finished=%d fdflags=%p fdflags_exact=%d holding_ns=%llu\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source, arg1,
	    (uint64_t)self->inherit_dst_request, self->inherit_dst_caller,
	    (uint32_t)self->inherit_source_count_before,
	    (uint32_t)self->inherit_source_count_at_alloc_entry,
	    (uint32_t)self->inherit_source_count_at_alloc_return,
		    *(uint32_t *)(self->inherit_source + 48), mic_finished,
		    configured_fdflags_ptr, this->fdflags_exact,
		    this->inherit_hold_ns);
	if (this->fdflags_exact) {
		fdflags_destination_exact = 1;
		fdflags_inherit_returned = 0;
		fd_close_a_ready = 1;
		chill(this->inherit_hold_ns);
	}
	self->inherit_source_count_after =
	    *(uint32_t *)self->inherit_source;
	self->inherit_oob_q0 =
	    *(uint64_t *)(self->inherit_source + 32);
	self->inherit_oob_q1 =
	    *(uint64_t *)(self->inherit_source + 40);
	self->inherit_oob_q2 =
	    *(uint64_t *)(self->inherit_source + 48);
	printf("%llu INHERIT_DIR_COUNT_BRACKET tid=%d source=%p count_getattr=%u count_at_alloc_entry=%u count_at_alloc_return=%u count_post_hold_pre_copy=%u request=%llu exact_1_to_2=%d\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source,
	    (uint32_t)self->inherit_source_count_before,
	    (uint32_t)self->inherit_source_count_at_alloc_entry,
	    (uint32_t)self->inherit_source_count_at_alloc_return,
	    (uint32_t)self->inherit_source_count_after,
	    (uint64_t)self->inherit_dst_request,
	    self->inherit_source_count_before == 1 &&
	    self->inherit_source_count_at_alloc_entry == 1 &&
	    self->inherit_source_count_at_alloc_return == 1 &&
	    self->inherit_source_count_after == 2 &&
	    self->inherit_dst_request == 32);
	printf("%llu EXACT_INHERIT_DST_ALLOC_RESUME tid=%d source=%p dst=%p count_after=0x%x flags=0x%x rights=0x%x exact_des3=%d mic_finished=%d fdflags_byte17=0x%x close_a_hold=%d\n",
	    (uint64_t)walltimestamp, tid, self->inherit_source,
	    self->inherit_dst, (uint32_t)self->inherit_source_count_after,
	    *(uint32_t *)(self->inherit_source + 48),
	    *(uint32_t *)(self->inherit_source + 52), exact_des3, mic_finished,
	    *(uint8_t *)(configured_fdflags_ptr + 17),
	    fd_close_a_hold_active);
	self->inherit_dst_alloc = 0;
}

fbt:mach_kernel:kauth_acl_inherit:return
/self->in_inherit/
{
	this->inherit_product = self->inherit_productp == 0 ?
	    (uintptr_t)0 : *(uintptr_t *)self->inherit_productp;
	this->inherit_product_count = this->inherit_product == 0 ? 0 :
	    *(uint32_t *)this->inherit_product;
	printf("%llu EXACT_INHERIT_RETURN tid=%d cpu=%d error=%d source=%p count_before=%u count_after=0x%x dst=%p product=%p product_count=%u isdir=%u total_ns=%llu overflow_proven=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, (int)arg1,
	    self->inherit_source,
	    (uint32_t)self->inherit_source_count_before,
	    (uint32_t)self->inherit_source_count_after, self->inherit_dst,
	    this->inherit_product, (uint32_t)this->inherit_product_count,
	    (uint32_t)self->inherit_isdir,
	    (uint64_t)(timestamp - self->inherit_start),
	    self->inherit_dst_request == 32 &&
	    this->inherit_product_count >= 2);
	if (fdflags_destination_exact != 0 &&
	    self->inherit_dst + 32 == configured_fdflags_ptr) {
		fdflags_inherit_returned = 1;
		this->fdflags_q0 = *(uint64_t *)configured_fdflags_ptr;
		this->fdflags_q1 =
		    *(uint64_t *)(configured_fdflags_ptr + 8);
		this->fdflags_q2 =
		    *(uint64_t *)(configured_fdflags_ptr + 16);
		this->count2_counts =
		    self->inherit_source_exact != 0 &&
		    self->inherit_source_count_before == 1 &&
		    self->inherit_source_count_at_alloc_entry == 1 &&
		    self->inherit_source_count_at_alloc_return == 1 &&
		    self->inherit_source_count_after == 2 &&
		    self->inherit_dst_request == 32;
		this->count2_source =
		    this->inherit_product_count == 2 &&
		    self->inherit_isdir == 1 &&
		    self->inherit_oob_q0 == 0 &&
		    self->inherit_oob_q1 == 0 &&
		    self->inherit_oob_q2 == 0x41;
		this->count2_destination =
		    this->fdflags_q0 == 0 &&
		    this->fdflags_q1 == 0 &&
		    this->fdflags_q2 == 0x51;
		this->count2_fdflags_geometry =
		    this->count2_counts &&
		    this->count2_source &&
		    this->count2_destination;
		printf("%llu FDFLAGS_EXACT_INHERIT_RETURNED tid=%d dst=%p flags=%p byte17=0x%x influx=0x%x\n",
		    (uint64_t)walltimestamp, tid, self->inherit_dst,
		    configured_fdflags_ptr,
		    *(uint8_t *)(configured_fdflags_ptr + 17),
		    *(uint8_t *)(configured_fdflags_ptr + 17) & 0xc);
		printf("%llu FDFLAGS_COUNT2_GEOMETRY tid=%d source=%p source_oob_q0=0x%llx source_oob_q1=0x%llx source_oob_q2=0x%llx dst=%p fdflags=%p fdflags_q0=0x%llx fdflags_q1=0x%llx fdflags_q2=0x%llx exact=%d\n",
		    (uint64_t)walltimestamp, tid, self->inherit_source,
		    (uint64_t)self->inherit_oob_q0,
		    (uint64_t)self->inherit_oob_q1,
		    (uint64_t)self->inherit_oob_q2,
		    self->inherit_dst, configured_fdflags_ptr,
		    (uint64_t)this->fdflags_q0,
		    (uint64_t)this->fdflags_q1,
		    (uint64_t)this->fdflags_q2,
		    this->count2_fdflags_geometry);
	}
	inherit_result_seen = 1;
	self->in_inherit = 0;
	self->inherit_getattr = 0;
	self->inherit_source_exact = 0;
	self->inherit_source_count_at_alloc_entry = 0;
	self->inherit_source_count_at_alloc_return = 0;
	self->inherit_oob_q0 = 0;
	self->inherit_oob_q1 = 0;
	self->inherit_oob_q2 = 0;
	self->inherit_dst_alloc = 0;
}

fbt:mach_kernel:kauth_acl_evaluate:entry
/self->exact_auth && arg1 != 0/
{
	self->exact_acl_eval = 1;
	self->exact_eval_ptr = arg1;
	this->acl = *(uintptr_t *)arg1 - 8;
	this->oob_ace = this->acl + 32;
	if (acl_window_getattr_return_ts != 0 &&
	    this->acl == acl_window_ptr) {
		printf("%llu EXACT_ACL_WINDOW_EVAL_ENTRY tid=%d acl=%p ae_count=0x%x acl_entrycount=0x%x mono_ns=%llu delta_getattr_return_ns=%llu delta_authorize_entry_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, this->acl,
		    *(uint32_t *)(arg1 + 8), *(uint32_t *)this->acl,
		    (uint64_t)timestamp,
		    (uint64_t)timestamp -
		    acl_window_getattr_return_ts,
		    acl_window_authorize_entry_ts == 0 ?
		    (uint64_t)0 :
		    (uint64_t)timestamp -
		    acl_window_authorize_entry_ts);
	}
	printf("%llu EXACT_ACL_EVAL_ENTRY tid=%d eval=%p ae_acl=%p ae_count=0x%x ae_requested=0x%x ae_residual=0x%x ae_result=0x%x ae_options=0x%x acl=%p acl_entrycount=0x%x expected_ae_acl=%p oob_ace=%p guid_q0=0x%llx guid_q1=0x%llx flags=0x%x rights=0x%x\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    *(uintptr_t *)arg1, *(uint32_t *)(arg1 + 8),
	    *(uint32_t *)(arg1 + 12), *(uint32_t *)(arg1 + 16),
	    *(uint32_t *)(arg1 + 20), *(uint32_t *)(arg1 + 28),
	    this->acl, *(uint32_t *)this->acl,
	    target_mic_buf + 40, this->oob_ace,
	    *(uint64_t *)this->oob_ace,
	    *(uint64_t *)(this->oob_ace + 8),
	    *(uint32_t *)(this->oob_ace + 16),
	    *(uint32_t *)(this->oob_ace + 20));
}

fbt:mach_kernel:kauth_acl_evaluate:return
/self->exact_acl_eval/
{
	printf("%llu EXACT_ACL_EVAL_RETURN tid=%d function_result=%d eval=%p ae_count=0x%x ae_requested=0x%x ae_residual=0x%x ae_result=0x%x found_deny=0x%x\n",
	    (uint64_t)walltimestamp, tid, arg1, self->exact_eval_ptr,
	    *(uint32_t *)(self->exact_eval_ptr + 8),
	    *(uint32_t *)(self->exact_eval_ptr + 12),
	    *(uint32_t *)(self->exact_eval_ptr + 16),
	    *(uint32_t *)(self->exact_eval_ptr + 20),
	    *(uint32_t *)(self->exact_eval_ptr + 24));
	self->exact_acl_eval = 0;
	self->exact_eval_ptr = (uintptr_t)0;
}

fbt:mach_kernel:vnode_attr_authorize_internal:return
/self->exact_auth/
{
	printf("%llu EXACT_ACL_AUTH_RETURN tid=%d result=%d acl=%p count_now=0x%x\n",
	    (uint64_t)walltimestamp, tid, arg1, acl_neighbor_ptr,
	    acl_neighbor_ptr == 0 ? 0 : *(uint32_t *)acl_neighbor_ptr);
	self->exact_auth = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/staged_replace_outer != 0 && arg1 == staged_replace_outer &&
  *(uintptr_t *)(arg1 + 0x78) == 0/
{
	printf("%llu CFX_NULL_DI_HOLD tid=%d cpu=%d outer=%p holding_ns=1000000\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1);
	chill(1000000);
	printf("%llu CFX_NULL_DI_RESUME tid=%d cpu=%d outer=%p di=%p etype=%d digest=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1,
	    *(uintptr_t *)(arg1 + 0x78), *(uint32_t *)(arg1 + 0x48),
	    *(uint32_t *)(arg1 + 0xc0));
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/* This trace starts after setup, so the raced DATA verifier is #1. */
/ *(uint32_t *)(arg1 + 0xc0) == 12 /
{
	aes_mic_seen++;
	self->any_aes_cfx = 1;
	self->any_aes_cfx_outer = arg1;
	self->any_aes_cfx_ordinal = aes_mic_seen;
	printf("%llu aes_mic_seen count=%d outer=%p\n",
	    (uint64_t)walltimestamp, aes_mic_seen, arg1);
	/*
	 * Entry proves DATA #1 already loaded the live AES context. Release DATA
	 * #2 now, before the replacement thread can clear cctx->di. Waiting for
	 * the first MIC to return leaves the second verifier on the NULL-di side
	 * of the race (attempt2048).
	 */
	if (aes_mic_seen == 1 && arg1 == staged_replace_outer) {
		first_aes_mic_return_ts = timestamp;
		first_aes_mic_return_seen = 1;
		printf("%llu FIRST_AES_MIC_ENTRY tid=%d outer=%p second_release=next_poll\n",
		    (uint64_t)walltimestamp, tid, arg1);
	}
	/*
	 * For candidate ordinals above two, keep each preceding 28-byte MIC
	 * allocation live briefly. The target request is staggered behind them,
	 * so it advances past transient per-CPU magazine entries instead of
	 * repeatedly reusing the first bystander's just-freed buffer.
	 */
	if (configured_candidate_min_aes_mic > 2 &&
	    aes_mic_seen < configured_candidate_min_aes_mic &&
	    arg1 == staged_replace_outer) {
		self->pre_candidate_aes = 1;
		self->pre_candidate_aes_ordinal = aes_mic_seen;
		self->pre_candidate_mic_held = 0;
		self->pre_candidate_alloc_size = 0;
	}
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:return
/self->any_aes_cfx/
{
	if (self->any_aes_cfx_ordinal == 1 &&
	    self->any_aes_cfx_outer == staged_replace_outer) {
		printf("%llu FIRST_AES_MIC_RETURN tid=%d outer=%p second_release_sent=%d\n",
		    (uint64_t)walltimestamp, tid, self->any_aes_cfx_outer,
		    second_data_signal_sent);
	}
	self->any_aes_cfx = 0;
	self->any_aes_cfx_outer = (uintptr_t)0;
	self->any_aes_cfx_ordinal = 0;
	self->pre_candidate_aes = 0;
	self->pre_candidate_aes_ordinal = 0;
	self->pre_candidate_mic_held = 0;
	self->pre_candidate_alloc_size = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/ *(uint32_t *)(arg1 + 0xc0) == 12 &&
  arg3 != 0 && *(uint64_t *)arg3 >= 16 &&
  *(uintptr_t *)(arg3 + 8) != 0 /
{
	this->aes_mic_input = *(uintptr_t *)(arg3 + 8);
	printf("%llu AES_MIC_INPUT count=%d tid=%d cpu=%d outer=%p desc=%p len=%llu data=%p d0=0x%x d1=0x%x d2=0x%x d3=0x%x target=0x%x match=%d\n",
	    (uint64_t)walltimestamp, aes_mic_seen, tid, cpu, arg1, arg3,
	    *(uint64_t *)arg3, this->aes_mic_input,
	    *(uint32_t *)(this->aes_mic_input),
	    *(uint32_t *)(this->aes_mic_input + 4),
	    *(uint32_t *)(this->aes_mic_input + 8),
	    *(uint32_t *)(this->aes_mic_input + 12),
	    configured_target_bp_u32,
	    *(uint32_t *)(this->aes_mic_input) == configured_target_bp_u32);
	this->aes_mic_input = (uintptr_t)0;
}

fbt:mach_kernel:krb5_key_derivation:entry
{
	self->in_key_derivation = 1;
}

fbt:mach_kernel:krb5_key_derivation:return
/self->in_key_derivation/
{
	self->in_key_derivation = 0;
}

fbt:mach_kernel:user_data_release_value:entry
/execname == "v32select" && digest_barrier_ready == 0/
{
	self->selective_a_release = 1;
	selective_stage1_signal_sent[pid] = 1;
}

fbt:mach_kernel:kfree_ext:entry
/self->selective_a_release && arg1 != 0 && arg2 == 32/
{
	selective_a_owner[(uintptr_t)arg1] = pid + 1;
	selective_a_release_count[pid]++;
	selective_a_free_total++;
	if (deferred_stage1_parent[pid] != 0) {
		target_deferred_free_count++;
	}
	selective_a_slot_plus1[(uintptr_t)arg1] =
	    selective_a_release_count[pid];
	if (selective_a_release_count[pid] == 1 ||
	    selective_a_release_count[pid] == 2 ||
	    selective_a_release_count[pid] == 32) {
		printf("%llu SELECTIVE_A_FREE_EDGE pid=%d cpu=%d ptr=%p slot=%d\n",
		    (uint64_t)walltimestamp, pid, cpu, arg1,
		    selective_a_release_count[pid] - 1);
	}
}

fbt:mach_kernel:user_data_release_value:return
/self->selective_a_release/
{
	self->selective_a_release = 0;
}

fbt:mach_kernel:user_data_release_value:entry
/execname == "v32select" && target_mic_buf != 0 &&
  selected_mic_owner_plus1 != 0 &&
  pid + 1 == selected_mic_owner_plus1 &&
  selective_stage2_signal_sent[pid] != 0/
{
	self->selected_b_release = 1;
}

fbt:mach_kernel:kfree_ext:entry
/self->selected_b_release && arg1 != 0 && arg2 == 32 &&
  (uintptr_t)arg1 == target_mic_buf + 32/
{
	self->selected_b_exact = 1;
	printf("%llu EXACT_SELECTED_B_FREE_ENTRY pid=%d cpu=%d slot=%d ptr=%p mic=%p\n",
	    (uint64_t)walltimestamp, pid, cpu,
	    selected_mic_slot_plus1 - 1, arg1, target_mic_buf);
}

fbt:mach_kernel:kfree_ext:return
/self->selected_b_exact/
{
	selected_neighbor_freed = 1;
	self->selected_b_exact = 0;
	printf("%llu EXACT_SELECTED_B_FREED pid=%d ptr=%p\n",
	    (uint64_t)walltimestamp, pid, target_mic_buf + 32);
}

fbt:mach_kernel:user_data_release_value:return
/self->selected_b_release/
{
	self->selected_b_release = 0;
}

syscall::getpgid:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  arg0 == 0x6c00/
{
	postfree_drain_active[pid] = 1;
	postfree_exact_reclaim_seen = 0;
	postfree_exact_e_reclaim_seen = 0;
	printf("%llu POSTFREE_DRAIN_BEGIN pid=%d cpu=%d b=%p\n",
	    (uint64_t)walltimestamp, pid, cpu, target_mic_buf + 32);
}

syscall::getpgid:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  arg0 == 0x6c01/
{
	postfree_drain_active[pid] = 0;
	postfree_release_window = 1;
	postfree_release_alloc_ordinal = 0;
	printf("%llu POSTFREE_DRAIN_END pid=%d cpu=%d exact_b=%d exact_e=%d b=%p e=%p\n",
	    (uint64_t)walltimestamp, pid, cpu, postfree_exact_reclaim_seen,
	    postfree_exact_e_reclaim_seen, target_mic_buf + 32,
	    configured_fdflags_ptr - 32);
}

syscall::getpgid:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_drain_active[pid] != 0 &&
  arg0 >= 0x6d000000 && arg0 < 0x6d000100/
{
	postfree_iteration_active[pid] = 1;
	postfree_iteration_index[pid] = arg0 - 0x6d000000;
	postfree_iteration_b_live[pid] = 0;
	postfree_iteration_e_live[pid] = 0;
}

fbt:mach_kernel:kalloc_ext:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_iteration_active[pid] != 0 && selected_neighbor_freed != 0 &&
  arg1 == 32/
{
	self->postfree_voucher_alloc = 1;
}

fbt:mach_kernel:kalloc_ext:return
/self->postfree_voucher_alloc &&
  arg1 == target_mic_buf + 32/
{
	postfree_iteration_b_live[pid] = 1;
}

fbt:mach_kernel:kalloc_ext:return
/self->postfree_voucher_alloc && configured_fdflags_ptr != 0 &&
  arg1 + 32 == configured_fdflags_ptr/
{
	postfree_iteration_e_live[pid] = 1;
}

fbt:mach_kernel:kalloc_ext:return
/self->postfree_voucher_alloc/
{
	self->postfree_voucher_alloc = 0;
}

fbt:mach_kernel:kfree_ext:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_iteration_active[pid] != 0 && arg2 == 32 &&
  arg1 == target_mic_buf + 32/
{
	postfree_iteration_b_live[pid] = 0;
}

fbt:mach_kernel:kfree_ext:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_iteration_active[pid] != 0 && arg2 == 32 &&
  configured_fdflags_ptr != 0 &&
  arg1 + 32 == configured_fdflags_ptr/
{
	postfree_iteration_e_live[pid] = 0;
}

syscall::getpgid:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_iteration_active[pid] != 0 &&
  arg0 >= 0x6e000000 && arg0 < 0x6e000100 &&
  postfree_iteration_b_live[pid] != 0 &&
  postfree_exact_reclaim_seen == 0/
{
	postfree_exact_reclaim_seen = 1;
	printf("%llu POSTFREE_EXACT_B_RECLAIM_SIGNAL pid=%d cpu=%d ptr=%p index=%d signal=SIGALRM\n",
	    (uint64_t)walltimestamp, pid, cpu, target_mic_buf + 32,
	    postfree_iteration_index[pid]);
	raise(14);
}

syscall::getpgid:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_iteration_active[pid] != 0 &&
  arg0 >= 0x6e000000 && arg0 < 0x6e000100 &&
  postfree_iteration_e_live[pid] != 0 &&
  postfree_exact_e_reclaim_seen == 0/
{
	postfree_exact_e_reclaim_seen = 1;
	printf("%llu POSTFREE_EXACT_E_RECLAIM_SIGNAL pid=%d cpu=%d ptr=%p index=%d signal=SIGVTALRM\n",
	    (uint64_t)walltimestamp, pid, cpu,
	    configured_fdflags_ptr - 32,
	    postfree_iteration_index[pid]);
	raise(26);
}

syscall::getpgid:entry
/execname == "v32select" && pid + 1 == selected_mic_owner_plus1 &&
  postfree_iteration_active[pid] != 0 &&
  arg0 >= 0x6e000000 && arg0 < 0x6e000100/
{
	postfree_iteration_active[pid] = 0;
}

fbt:mach_kernel:kfree_ext:entry
/postfree_release_window != 0 && target_mic_buf != 0 &&
  configured_fdflags_ptr != 0 && arg2 > 16 && arg2 <= 32 &&
  arg1 + 32 == configured_fdflags_ptr &&
  postfree_e_free_log_count < 8/
{
	postfree_e_free_log_count++;
	printf("%llu POSTFREE_EXACT_E_FREE tid=%d cpu=%d ptr=%p request=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1, (int)arg2);
}

fbt:mach_kernel:kalloc_ext:entry
/self->any_aes_cfx && arg1 == 28/
{
	data_heap = arg0;
}

fbt:mach_kernel:kalloc_ext:entry
/target_mic_buf != 0 && mic_finished == 0 && inherit_result_seen == 0 &&
  data_heap != 0 &&
  arg0 == data_heap && arg1 > 16 && arg1 <= 32/
{
	self->track32_caller = caller;
	self->track32_request = arg1;
	self->track32_key_derivation = self->in_key_derivation;
}

fbt:mach_kernel:kalloc_ext:return
/self->track32_caller != 0 && arg1 != 0 &&
  postfree_release_window != 0 &&
  postfree_release_alloc_ordinal < 24/
{
	printf("%llu POSTFREE_RELEASE_ALLOC ordinal=%d tid=%d cpu=%d ptr=%p request=%d caller=%p\n",
	    (uint64_t)walltimestamp, postfree_release_alloc_ordinal,
	    tid, cpu, arg1, (int)self->track32_request,
	    self->track32_caller);
	if (self->track32_request != 32) {
		stack(12);
	}
	postfree_release_alloc_ordinal++;
}

fbt:mach_kernel:kalloc_ext:return
/self->track32_caller != 0 && arg1 != 0/
{
	if (target_mic_buf != 0 &&
	    (uintptr_t)arg1 == target_mic_buf + 32) {
		neighbor_alloc_caller = self->track32_caller;
		neighbor_alloc_request = self->track32_request;
		neighbor_alloc_key_derivation =
		    self->track32_key_derivation;
	}

	self->track32_caller = 0;
	self->track32_request = 0;
	self->track32_key_derivation = 0;
}

fbt:mach_kernel:kalloc_ext:return
/self->track32_caller != 0 && arg1 == 0/
{
	self->track32_caller = 0;
	self->track32_request = 0;
	self->track32_key_derivation = 0;
}

fbt:mach_kernel:kfree_ext:entry
/target_mic_buf != 0 && mic_finished == 0 && inherit_result_seen == 0 &&
  data_heap != 0 &&
  arg0 == data_heap && arg2 > 16 && arg2 <= 32 &&
  (uintptr_t)arg1 == target_mic_buf + 32/
{
	self->exact_neighbor_free_request = neighbor_alloc_request;
	self->exact_neighbor_free =
	    neighbor_alloc_request == 24 &&
	    neighbor_alloc_key_derivation != 0 &&
	    neighbor_alloc_caller != 0;
	printf("%llu EXACT_32_NEIGHBOR_FREE ptr=%p request=%d alloc_request=%d alloc_caller=%p key_derivation=%d free_caller=%p\n",
	    (uint64_t)walltimestamp, arg1,
	    (int)arg2, (int)neighbor_alloc_request,
	    neighbor_alloc_caller, neighbor_alloc_key_derivation, caller);
	neighbor_alloc_caller = (uintptr_t)0;
	neighbor_alloc_request = 0;
	neighbor_alloc_key_derivation = 0;
}

fbt:mach_kernel:kfree_ext:return
/self->exact_neighbor_free/
{
	neighbor_freed = 1;
	printf("%llu EXACT_32_NEIGHBOR_FREED ptr=%p alloc_request=%d acl_ready=%d acl_ptr=%p\n",
	    (uint64_t)walltimestamp, target_mic_buf + 32,
	    (int)self->exact_neighbor_free_request, acl_ready,
	    acl_neighbor_ptr);
	self->exact_neighbor_free = 0;
	self->exact_neighbor_free_request = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/candidate_claimed == 0 &&
  configured_target_bp_u32 != 0 &&
  arg3 != 0 && *(uint64_t *)arg3 >= 4 &&
  *(uintptr_t *)(arg3 + 8) != 0 &&
  *(uint32_t *)(*(uintptr_t *)(arg3 + 8)) ==
    configured_prime_bp_u32 &&
  *(uint32_t *)(arg1 + 0xc0) == 12 &&
  aes_mic_seen >= configured_candidate_min_aes_mic/
{
	candidate_claimed = 1;
	candidate_is_prime = 1;
	candidate_outer = arg1;
	target_nfs_cp = self->verf_cp;
	self->candidate = 1;
	self->outer = arg1;
	self->mic_desc = arg4;
	target_alloc_cpu = cpu;
	printf("%llu get_mic_candidate tid=%d cpu=%d outer=%p nfs_cp=%p refcnt=%d etype=%d digest=%d prime=%d prealloc_hold_ms=0\n",
	    (uint64_t)walltimestamp, tid, target_alloc_cpu, arg1,
	    target_nfs_cp,
	    target_nfs_cp == 0 ? -1 :
	    *(uint32_t *)(target_nfs_cp + 0x24),
	    *(uint32_t *)(arg1 + 0x48),
	    *(uint32_t *)(arg1 + 0xc0), candidate_is_prime);
	prealloc_barrier_ready = 1;
	if (configured_prealloc_hold_ns != 0) {
		prealloc_release_after_ts = timestamp;
		printf("%llu PREALLOC_RELEASE_HOLD tid=%d cpu=%d holding_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, cpu,
		    configured_prealloc_hold_ns);
		chill(configured_prealloc_hold_ns);
		printf("%llu PREALLOC_RELEASE_RESUME tid=%d cpu=%d released=%d\n",
		    (uint64_t)walltimestamp, tid, cpu,
		    selective_stage1_total);
	}
	prealloc_barrier_ready = 0;
	prealloc_release_after_ts = (uint64_t)0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/candidate_claimed == 0 &&
  configured_target_bp_u32 != 0 &&
  arg3 != 0 && *(uint64_t *)arg3 >= 4 &&
  *(uintptr_t *)(arg3 + 8) != 0 &&
  *(uint32_t *)(*(uintptr_t *)(arg3 + 8)) ==
    configured_target_bp_u32 &&
  *(uint32_t *)(arg1 + 0xc0) == 12 &&
  aes_mic_seen >= configured_candidate_min_aes_mic/
{
	candidate_claimed = 1;
	candidate_is_prime = 0;
	candidate_outer = arg1;
	target_nfs_cp = self->verf_cp;
	self->candidate = 1;
	self->outer = arg1;
	self->mic_desc = arg4;
	target_alloc_cpu = cpu;
	printf("%llu get_mic_candidate tid=%d cpu=%d outer=%p nfs_cp=%p refcnt=%d etype=%d digest=%d prime=%d prealloc_hold_ms=0\n",
	    (uint64_t)walltimestamp, tid, target_alloc_cpu, arg1,
	    target_nfs_cp,
	    target_nfs_cp == 0 ? -1 :
	    *(uint32_t *)(target_nfs_cp + 0x24),
	    *(uint32_t *)(arg1 + 0x48),
	    *(uint32_t *)(arg1 + 0xc0), candidate_is_prime);
	target_prealloc_barrier_ready = 1;
	prealloc_barrier_ready = 1;
	prealloc_release_after_ts = timestamp;
	if (configured_prealloc_hold_ns != 0) {
		printf("%llu TARGET_PREALLOC_RELEASE_HOLD tid=%d cpu=%d holding_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, cpu,
		    configured_prealloc_hold_ns);
		chill(configured_prealloc_hold_ns);
		printf("%llu TARGET_PREALLOC_RELEASE_RESUME tid=%d cpu=%d released=%d prime_required=%d deferred_signals=%d deferred_frees=%d deferred_required=%d\n",
		    (uint64_t)walltimestamp, tid, cpu,
		    selective_a_free_total,
		    configured_prime_required_frees,
		    target_deferred_signal_total, target_deferred_free_count,
		    configured_deferred_release_required *
		    configured_selective_a_frees_per_target);
	}
	prealloc_barrier_ready = 0;
	target_prealloc_barrier_ready = 0;
	prealloc_release_after_ts = (uint64_t)0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:entry
/candidate_claimed != 0 && self->candidate == 0 &&
  arg1 == candidate_outer/
{
	printf("%llu get_mic_bystander_hold tid=%d cpu=%d outer=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1);
	printf("%llu get_mic_bystander_resume tid=%d outer=%p etype=%d digest=%d\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    *(uint32_t *)(arg1 + 0x48), *(uint32_t *)(arg1 + 0xc0));
}

/*
 * A verifier can enter gss_krb5_cfx_get_mic while cctx->di is still valid,
 * then reach krb5_mic after the replacement destroy clears it. Guard the
 * concrete dereference site as well as the outer CFX entry.
 */
fbt:mach_kernel:krb5_mic:entry
/staged_replace_outer != 0 &&
  arg0 == staged_replace_outer + 0x48 &&
  self->candidate == 0 &&
  replacement_destroy_barrier_ready != 0 &&
  exact_des3 == 0/
{
	this->bystander_repair_hold_ns =
	    *(uintptr_t *)(arg0 + 0x30) == 0 ?
	    (uint64_t)450000000 : (uint64_t)0;
	printf("%llu KRB5_MIC_BYSTANDER_DESTROY_PASS tid=%d cpu=%d cctx=%p di=%p repair_hold_ns=%llu destroy_hold_ns=%llu\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uintptr_t *)(arg0 + 0x30),
	    this->bystander_repair_hold_ns,
	    configured_replacement_destroy_hold_ns);
	if (this->bystander_repair_hold_ns != 0) {
		chill(this->bystander_repair_hold_ns);
	}
	printf("%llu KRB5_MIC_BYSTANDER_DESTROY_RESUME tid=%d cpu=%d cctx=%p di=%p repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uintptr_t *)(arg0 + 0x30), repair_make_done,
	    target_destroy_count);
	this->bystander_repair_hold_ns = 0;
}

fbt:mach_kernel:krb5_mic:entry
/staged_replace_outer != 0 &&
  arg0 == staged_replace_outer + 0x48 &&
  *(uintptr_t *)(arg0 + 0x30) == 0/
{
	printf("%llu KRB5_MIC_NULL_DI_HOLD tid=%d cpu=%d cctx=%p outer=%p repair_make=%d destroy_count=%d holding_ns=1000000\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0, staged_replace_outer,
	    repair_make_done, target_destroy_count);
	chill(1000000);
	printf("%llu KRB5_MIC_NULL_DI_RESUME tid=%d cpu=%d cctx=%p di=%p repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uintptr_t *)(arg0 + 0x30), repair_make_done,
	    target_destroy_count);
}

fbt:mach_kernel:krb5_mic:entry
/candidate_outer != 0 && self->candidate == 0 &&
  arg0 == candidate_outer + 0x48 && exact_des3 != 0/
{
	printf("%llu krb5_mic_bystander_hold tid=%d cpu=%d cctx=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0);
	printf("%llu krb5_mic_bystander_resume tid=%d cctx=%p digest=%d\n",
	    (uint64_t)walltimestamp, tid, arg0,
	    *(uint32_t *)(arg0 + 0x78));
}

/*
 * NFS reply protection can reuse the target cctx after the selected get_mic
 * returns. Keep that later user out of the destroy/make window where cctx->di
 * is transiently NULL.
 */
fbt:mach_kernel:krb5_mic_mbuf:entry
/target_outer != 0 && self->candidate == 0 &&
  arg0 == target_outer + 0x48 &&
  *(uintptr_t *)(arg0 + 0x30) == 0/
{
	self->target_mbuf_bystander = 1;
	printf("%llu KRB5_MBUF_TARGET_MAKE_HOLD tid=%d cpu=%d cctx=%p di=%p repair_make=%d destroy_count=%d holding_ns=1000000\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uintptr_t *)(arg0 + 0x30), repair_make_done,
	    target_destroy_count);
	chill(1000000);
	printf("%llu KRB5_MBUF_TARGET_MAKE_RESUME tid=%d cpu=%d cctx=%p di=%p repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0,
	    *(uintptr_t *)(arg0 + 0x30), repair_make_done,
	    target_destroy_count);
}

fbt:mach_kernel:krb5_mic_mbuf:return
/self->target_mbuf_bystander/
{
	printf("%llu KRB5_MBUF_TARGET_RETURN tid=%d cctx=%p di=%p repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, target_outer + 0x48,
	    *(uintptr_t *)(target_outer + 0x78), repair_make_done,
	    target_destroy_count);
	self->target_mbuf_bystander = 0;
}

fbt:mach_kernel:kalloc_ext:entry
/self->candidate && !self->in_krb5/
{
	self->outer_alloc_size = arg1;
}

fbt:mach_kernel:kalloc_ext:entry
/self->pre_candidate_aes && !self->pre_candidate_mic_held/
{
	self->pre_candidate_alloc_size = arg1;
}

fbt:mach_kernel:kalloc_ext:return
/self->pre_candidate_aes && !self->pre_candidate_mic_held &&
  self->pre_candidate_alloc_size == 28 && arg1 != 0/
{
	self->pre_candidate_mic_held = 1;
	printf("%llu PRE_CANDIDATE_MIC_ALLOC_HOLD tid=%d cpu=%d ordinal=%d ptr=%p request=%d holding_ns=15000000\n",
	    (uint64_t)walltimestamp, tid, cpu,
	    self->pre_candidate_aes_ordinal, arg1,
	    (int)self->pre_candidate_alloc_size);
	chill(15000000);
	printf("%llu PRE_CANDIDATE_MIC_ALLOC_RESUME tid=%d cpu=%d ordinal=%d ptr=%p\n",
	    (uint64_t)walltimestamp, tid, cpu,
	    self->pre_candidate_aes_ordinal, arg1);
	self->pre_candidate_alloc_size = 0;
}

fbt:mach_kernel:kalloc_ext:return
/self->candidate && !self->in_krb5 && self->outer_alloc_size != 0 &&
  (selective_a_owner[(uintptr_t)arg1] == 0 ||
  selective_a_slot_plus1[(uintptr_t)arg1] == 0)/
{
	printf("%llu MIC_CANDIDATE_REJECT tid=%d cpu=%d ptr=%p request=%d outer=%p owner_pid=%d slot=%d reason=not_prearmed_a\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1,
	    (int)self->outer_alloc_size, self->outer,
	    selective_a_owner[(uintptr_t)arg1] == 0 ?
	    -1 : selective_a_owner[(uintptr_t)arg1] - 1,
	    selective_a_slot_plus1[(uintptr_t)arg1] == 0 ?
	    -1 : selective_a_slot_plus1[(uintptr_t)arg1] - 1);
	candidate_claimed = 0;
	candidate_is_prime = 0;
	candidate_outer = (uintptr_t)0;
	target_outer = (uintptr_t)0;
	target_nfs_cp = (uintptr_t)0;
	target_mic_buf = (uintptr_t)0;
	target_alloc_cpu = -1;
	selected_mic_owner_plus1 = 0;
	selected_mic_slot_plus1 = 0;
	self->candidate = 0;
	self->outer = (uintptr_t)0;
	self->mic_desc = (uintptr_t)0;
	self->mic_buf = (uintptr_t)0;
	self->outer_alloc_size = 0;
}

fbt:mach_kernel:kalloc_ext:return
/self->candidate && !self->in_krb5 && self->outer_alloc_size != 0 &&
  selective_a_owner[(uintptr_t)arg1] != 0 &&
  selective_a_slot_plus1[(uintptr_t)arg1] != 0/
{
	self->mic_buf = arg1;
	target_outer = self->outer;
	target_mic_buf = arg1;
	target_alloc_cpu = cpu;
	selected_mic_owner_plus1 =
	    selective_a_owner[(uintptr_t)target_mic_buf];
	selected_mic_slot_plus1 =
	    selective_a_slot_plus1[(uintptr_t)target_mic_buf];
	this->selected_parent = selected_mic_owner_plus1 == 0 ?
	    0 : selected_mic_owner_plus1 - 1;
	if (this->selected_parent > 1 &&
	    fdflags_ptr_by_parent[this->selected_parent] != 0 &&
	    fdflags_child_by_parent[this->selected_parent] > 1) {
		configured_fdflags_parent_pid = this->selected_parent;
		configured_fdflags_pid =
		    fdflags_child_by_parent[this->selected_parent];
		configured_fdflags_ptr =
		    fdflags_ptr_by_parent[this->selected_parent];
		printf("%llu FDFLAGS_TARGET_REBOUND owner_pid=%d child_pid=%d flags=%p\n",
		    (uint64_t)walltimestamp,
		    configured_fdflags_parent_pid,
		    configured_fdflags_pid,
		    configured_fdflags_ptr);
	}
	this->neighbor = (uintptr_t)arg1 + 32;
	printf("%llu mic_alloc tid=%d cpu=%d ptr=%p request=%d heap=%p neighbor=%p outer=%p holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, target_alloc_cpu, arg1,
	    (int)self->outer_alloc_size, data_heap,
	    this->neighbor, target_outer);
	printf("%llu SELECTIVE_MIC_OWNER ptr=%p owner_pid=%d slot=%d exact=%d\n",
	    (uint64_t)walltimestamp, target_mic_buf,
	    selected_mic_owner_plus1 == 0 ?
	    -1 : selected_mic_owner_plus1 - 1,
	    selected_mic_slot_plus1 == 0 ?
	    -1 : selected_mic_slot_plus1 - 1,
	    selected_mic_owner_plus1 != 0);
	self->outer_alloc_size = 0;
}

fbt:mach_kernel:krb5_mic:entry
/self->candidate/
{
	self->digest_barrier_done = 0;
	self->digest_alloc_size = 0;
	self->digest_ptr = (uintptr_t)0;
	self->target_cchmac_final_public = 0;
	self->target_cchmac_final_internal = 0;
	self->postcopy_output_free = 0;
	self->postcopy_output_ptr = (uintptr_t)0;
	target_mic_tid = tid;
	mic_entry_hold_active = 1;
	printf("%llu KRB5_MIC_TARGET_ENTRY_HOLD tid=%d cpu=%d cctx=%p outer=%p di=%p etype=%d digest=%d holding_ns=%llu\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0, target_outer,
	    *(uintptr_t *)(arg0 + 0x30),
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0),
	    configured_mic_hold_ns);
	if (*(uintptr_t *)(arg0 + 0x30) == 0 && repair_make_done == 0) {
		repair_barrier_ready = 1;
		printf("%llu NULL_DI_ENTRY_ARMED tid=%d cpu=%d cctx=%p outer=%p repair_sent=%d repair_make=%d destroy_count=%d\n",
		    (uint64_t)walltimestamp, tid, cpu, arg0, target_outer,
		    repair_signal_sent, repair_make_done, target_destroy_count);
	}
	chill(configured_mic_hold_ns);
	mic_entry_hold_active = 0;
	printf("%llu KRB5_MIC_TARGET_ENTRY_RESUME tid=%d cpu=%d cctx=%p outer=%p di=%p etype=%d digest=%d exact_des3=%d repair_sent=%d repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg0, target_outer,
	    *(uintptr_t *)(arg0 + 0x30),
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0), exact_des3,
	    repair_signal_sent, repair_make_done, target_destroy_count);
	self->in_krb5 = 1;
	self->hmac_digest_final_entry_count = 0;
	self->hmac_digest_final_count = 0;
	self->cctx = arg0;
	self->sink = arg4;
	self->bp = arg2;
	self->trailer = arg3;
	printf("%llu krb5_mic_entry_resume tid=%d cctx=%p outer=%p etype=%d digest=%d di=%p repair_sent=%d repair_make=%d destroy_count=%d\n",
	    (uint64_t)walltimestamp, tid, arg0, target_outer,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(arg0 + 0x78), *(uintptr_t *)(arg0 + 0x30),
	    repair_signal_sent, repair_make_done, target_destroy_count);
	self->digest_info = *(uintptr_t *)(arg0 + 0x30);
	printf("%llu krb5_mic_enter tid=%d cctx=%p sink=%p digest=%d mic_buf=%p expected_sink=%p\n",
	    (uint64_t)walltimestamp, tid, arg0, arg4,
	    *(uint32_t *)(arg0 + 0x78), self->mic_buf,
	    self->mic_buf + 16);
}

fbt:mach_kernel:kalloc_ext:entry
/self->in_krb5 && !self->digest_barrier_done &&
  self->digest_alloc_size == 0 && arg1 == 20/
{
	self->digest_alloc_size = arg1;
	printf("%llu digest_alloc_entry_observed tid=%d request=%d outer=%p etype=%d digest=%d holding_ms=0\n",
	    (uint64_t)walltimestamp, tid, (int)arg1, target_outer,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0));
}

fbt:mach_kernel:kalloc_ext:return
/self->in_krb5 && !self->digest_barrier_done &&
  self->digest_alloc_size == 20/
{
	self->digest_ptr = arg1;
	target_digest_ptr = arg1;
	digest_temp_ready = 1;
	printf("%llu digest_alloc_observed tid=%d ptr=%p request=%d outer=%p exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    (int)self->digest_alloc_size, target_outer, exact_des3);
	self->digest_alloc_size = 0;
}

fbt:com.apple.kec.corecrypto:cchmac_final:entry
/target_mic_tid != 0 && tid == target_mic_tid &&
  cchmac_return_barrier_done == 0/
{
	printf("%llu TARGET_CCHMAC_FINAL_ENTRY tid=%d cpu=%d outer=%p digest=%p arg0=%p arg1=%p arg2=%p arg3=%p output_match=%d len=%d etype=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, target_outer,
	    self->digest_ptr, arg0, arg1, arg2, arg3,
	    arg2 == self->digest_ptr,
	    *(uint32_t *)(self->cctx + 0x78),
	    *(uint32_t *)(target_outer + 0x48));
	self->target_cchmac_final_public = 1;
}

fbt:com.apple.kec.corecrypto:cchmac_final:return
/self->target_cchmac_final_public &&
  target_mic_tid != 0 && tid == target_mic_tid &&
  cchmac_return_barrier_done == 0/
{
	precopy_tid = tid;
	precopy_cctx = target_outer + 0x48;
	precopy_sink = target_mic_buf + 16;
	precopy_digest = self->digest_ptr;
	precopy_di = *(uintptr_t *)(precopy_cctx + 0x30);
	precopy_len = *(uint32_t *)(precopy_cctx + 0x78);
	precopy_etype = *(uint32_t *)(target_outer + 0x48);
	printf("%llu TARGET_CCHMAC_FINAL_RETURN tid=%d cpu=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d output_match=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, precopy_cctx,
	    precopy_di, precopy_sink, precopy_digest, precopy_len,
	    precopy_etype, precopy_digest == precopy_sink);
	if (precopy_len == 12) {
		precopy_ready = 1;
		this->cchmac_hold_ns = candidate_is_prime ?
		    (uint64_t)20000000 :
		    configured_cchmac_return_hold_ns;
		if (selected_mic_owner_plus1 != 0) {
			continue_barrier_ready = 1;
		}
		printf("%llu TARGET_CCHMAC_RETURN_HOLD tid=%d cpu=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d exact_des3=%d holding_ns=%llu\n",
		    (uint64_t)walltimestamp, tid, cpu, precopy_cctx,
		    precopy_di, precopy_sink, precopy_digest, precopy_len,
		    precopy_etype, exact_des3,
		    this->cchmac_hold_ns);
		if (this->cchmac_hold_ns != 0) {
			chill(this->cchmac_hold_ns);
		}
		precopy_ready = 0;
		printf("%llu TARGET_CCHMAC_RETURN_RESUME tid=%d cpu=%d cctx=%p di_before=%p di_live=%p sink=%p digest=%p len_before=%d len_live=%d etype_before=%d etype_live=%d exact_des3=%d repair_sent=%d repair_make=%d destroy_count=%d\n",
		    (uint64_t)walltimestamp, tid, cpu, precopy_cctx,
		    precopy_di, *(uintptr_t *)(precopy_cctx + 0x30),
		    precopy_sink, precopy_digest, precopy_len,
		    *(uint32_t *)(precopy_cctx + 0x78), precopy_etype,
		    *(uint32_t *)(target_outer + 0x48), exact_des3,
		    repair_signal_sent, repair_make_done,
		    target_destroy_count);
	}
	cchmac_return_barrier_done = 1;
	self->digest_barrier_done = 1;
	self->target_cchmac_final_public = 0;
}

/*
 * The NFS import inlines the HMAC wrapper, so neither public nor internal
 * cchmac_final FBT probes necessarily fire. Count the selected thread's
 * concrete digest callback invocations instead.
 */
fbt:com.apple.kec.corecrypto:cchmac_final_internal:entry
/self->in_krb5 && !self->digest_barrier_done/
{
	printf("%llu cchmac_final_internal_entry tid=%d cpu=%d outer=%p digest=%p arg0=%p arg1=%p arg2=%p output_match=%d len=%d etype=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, target_outer,
	    self->digest_ptr, arg0, arg1, arg2,
	    arg2 == self->digest_ptr,
	    *(uint32_t *)(self->cctx + 0x78),
	    *(uint32_t *)(target_outer + 0x48));
	if (arg2 == self->digest_ptr) {
		self->target_cchmac_final_internal = 1;
		self->hmac_digest_final_count = 0;
	}
}

fbt:com.apple.kec.corecrypto:ccdigest_final_64be:entry
/use_cchmac_return_barrier == 0 &&
  cchmac_return_barrier_done == 0 &&
  self->in_krb5 && !self->digest_barrier_done &&
  self->digest_ptr != 0/
{
	self->hmac_digest_final_entry_count =
	    self->hmac_digest_final_entry_count + 1;
	printf("%llu cchmac_digest_final_entry tid=%d cpu=%d outer=%p digest=%p ordinal=%d arg0=%p arg1=%p arg2=%p arg3=%p len=%d etype=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, target_outer,
	    self->digest_ptr, self->hmac_digest_final_entry_count,
	    arg0, arg1, arg2, arg3,
	    *(uint32_t *)(self->cctx + 0x78),
	    *(uint32_t *)(target_outer + 0x48));
}

fbt:com.apple.kec.corecrypto:ccdigest_final_64be:return
/use_cchmac_return_barrier == 0 &&
  cchmac_return_barrier_done == 0 &&
  self->in_krb5 && !self->digest_barrier_done &&
  self->digest_ptr != 0/
{
	self->hmac_digest_final_count =
	    self->hmac_digest_final_count + 1;
	printf("%llu cchmac_digest_final_return tid=%d cpu=%d outer=%p digest=%p ordinal=%d len=%d etype=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, target_outer,
	    self->digest_ptr, self->hmac_digest_final_count,
	    *(uint32_t *)(self->cctx + 0x78),
	    *(uint32_t *)(target_outer + 0x48));

	if (self->hmac_digest_final_count == 1 &&
	    selected_mic_owner_plus1 != 0) {
		early_continue_barrier_ready = 1;
		printf("%llu HMAC_FIRST_DIGEST_RETURN_CONTINUE_ARMED tid=%d cpu=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d\n",
		    (uint64_t)walltimestamp, tid, cpu, self->cctx,
		    *(uintptr_t *)(self->cctx + 0x30), self->sink,
		    self->digest_ptr, *(uint32_t *)(self->cctx + 0x78),
		    *(uint32_t *)(target_outer + 0x48));
			if (self->candidate != 0 && candidate_is_prime == 0 &&
			    configured_pre_destroy_hold_ns != 0) {
			printf("%llu HMAC_FIRST_DIGEST_RETURN_REBUILD_HOLD tid=%d cpu=%d cctx=%p di=%p holding_ns=400000000\n",
			    (uint64_t)walltimestamp, tid, cpu, self->cctx,
			    *(uintptr_t *)(self->cctx + 0x30));
			chill(400000000);
			printf("%llu HMAC_FIRST_DIGEST_RETURN_REBUILD_RESUME tid=%d cpu=%d cctx=%p di=%p repair_make=%d destroy_count=%d\n",
			    (uint64_t)walltimestamp, tid, cpu, self->cctx,
			    *(uintptr_t *)(self->cctx + 0x30),
			    repair_make_done, target_destroy_count);
		}
	}

	    if (self->hmac_digest_final_count == 2) {
		precopy_tid = tid;
		precopy_len = *(uint32_t *)(self->cctx + 0x78);
		precopy_sink = self->sink;
		precopy_digest = self->digest_ptr;
		precopy_cctx = self->cctx;
		precopy_di = *(uintptr_t *)(self->cctx + 0x30);
		precopy_etype = *(uint32_t *)(target_outer + 0x48);
		precopy_ready = 1;
			this->cchmac_hold_ns = candidate_is_prime ?
			    (uint64_t)20000000 :
			    (configured_pre_destroy_hold_ns != 0 &&
			    configured_cchmac_return_hold_ns > 90000000 ?
			    (uint64_t)90000000 : configured_cchmac_return_hold_ns);
		if (selected_mic_owner_plus1 != 0) {
			continue_barrier_ready = 1;
		}
			printf("%llu HMAC_SECOND_DIGEST_RETURN_HOLD tid=%d cpu=%d cctx=%p di=%p sink=%p digest=%p len=%d etype=%d exact_des3=%d holding_ns=%llu\n",
			    (uint64_t)walltimestamp, tid, cpu, precopy_cctx,
			    precopy_di, precopy_sink, precopy_digest, precopy_len,
			    precopy_etype, exact_des3,
			    this->cchmac_hold_ns);
			/*
			 * Cross-digest repair must happen after both digest callbacks
			 * completed but before krb5_mic reloads cctx->digest_size.
			 * The rebuild wait is split across distinct return probes so each
			 * individual chill remains below DTrace's destructive-action limit.
			 */
			if (this->cchmac_hold_ns != 0) {
				chill(this->cchmac_hold_ns);
			}
		precopy_ready = 0;
		if (repair_make_done != 0) {
			printf("%llu HMAC_SECOND_DIGEST_RETURN_RESUME tid=%d cpu=%d cctx=%p di_before=%p di_live=%p sink=%p digest=%p len_before=%d len_live=%d etype_before=%d etype_live=%d exact_des3=%d repair_sent=%d repair_make=%d destroy_count=%d\n",
			    (uint64_t)walltimestamp, tid, cpu, precopy_cctx,
			    precopy_di,
			    *(uintptr_t *)(precopy_cctx + 0x30),
			    precopy_sink, precopy_digest, precopy_len,
			    *(uint32_t *)(precopy_cctx + 0x78),
			    precopy_etype,
			    *(uint32_t *)(target_outer + 0x48),
			    exact_des3, repair_signal_sent, repair_make_done,
			    target_destroy_count);
		} else {
			printf("%llu HMAC_SECOND_DIGEST_RETURN_RESUME_NO_REPAIR tid=%d cpu=%d cctx=%p di_before=%p sink=%p digest=%p len_before=%d etype_before=%d exact_des3=%d repair_sent=%d repair_make=%d destroy_count=%d\n",
			    (uint64_t)walltimestamp, tid, cpu, precopy_cctx,
			    precopy_di, precopy_sink, precopy_digest,
			    precopy_len, precopy_etype, exact_des3,
			    repair_signal_sent, repair_make_done,
			    target_destroy_count);
		}
		self->target_cchmac_final_internal = 0;
		self->hmac_digest_final_count = 0;
		self->digest_barrier_done = 1;
	}
}

/* Observe the digest-output free without spending a second chill budget. */
fbt:mach_kernel:kfree_ext:entry
/self->in_krb5 && self->digest_barrier_done &&
  arg1 != 0 && arg2 == 20/
{
	self->postcopy_output_free = 1;
	self->postcopy_output_ptr = arg1;
	printf("%llu POSTCOPY_OUTPUT_FREE_ENTRY tid=%d cpu=%d ptr=%p size=%d source=%p count=0x%x inherit_exact=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, arg1, (int)arg2,
	    acl_neighbor_ptr,
	    acl_neighbor_ptr == 0 ? 0 : *(uint32_t *)acl_neighbor_ptr,
	    inherit_exact_seen);
}

fbt:mach_kernel:kfree_ext:return
/self->postcopy_output_free/
{
	printf("%llu POSTCOPY_OUTPUT_FREE_NO_HOLD tid=%d cpu=%d ptr=%p source=%p count=0x%x inherit_exact=%d\n",
	    (uint64_t)walltimestamp, tid, cpu, self->postcopy_output_ptr,
	    acl_neighbor_ptr,
	    acl_neighbor_ptr == 0 ? 0 : *(uint32_t *)acl_neighbor_ptr,
	    inherit_exact_seen);
	printf("%llu POSTCOPY_OUTPUT_FREE_RETURN tid=%d ptr=%p inherit_result=%d fdflags_byte17=0x%x\n",
	    (uint64_t)walltimestamp, tid, self->postcopy_output_ptr,
	    inherit_result_seen, *(uint8_t *)(configured_fdflags_ptr + 17));
	self->postcopy_output_free = 0;
	self->postcopy_output_ptr = (uintptr_t)0;
}

fbt:mach_kernel:krb5_mic:return
/self->in_krb5/
{
	self->return_rawkey = *(uintptr_t *)(self->cctx + 0x28);
	self->return_ckey = *(uintptr_t *)(self->cctx + 0x80);
	printf("%llu return_context_key tid=%d ptr=%p keylen=%d key_q0=0x%llx key_q1=0x%llx key_q2=0x%llx\n",
	    (uint64_t)walltimestamp, tid, self->return_rawkey,
	    *(uint32_t *)(self->cctx + 0x7c),
	    *(uint64_t *)self->return_rawkey,
	    *(uint64_t *)(self->return_rawkey + 8),
	    *(uint64_t *)(self->return_rawkey + 16));
	printf("%llu return_checksum_key tid=%d ptr=%p keylen=%llu key_q0=0x%llx key_q1=0x%llx key_q2=0x%llx\n",
	    (uint64_t)walltimestamp, tid, self->return_ckey,
	    *(uint64_t *)(self->cctx + 0x88),
	    *(uint64_t *)self->return_ckey,
	    *(uint64_t *)(self->return_ckey + 8),
	    *(uint64_t *)(self->return_ckey + 16));
	printf("%llu krb5_mic_return tid=%d outer=%p exact_des3=%d etype=%d digest=%d mic_buf=%p neighbor=%p overflow_dword=0x%x alloc_request=%d alloc_caller=%p\n",
	    (uint64_t)walltimestamp, tid, target_outer, exact_des3,
	    *(uint32_t *)(target_outer + 0x48),
	    *(uint32_t *)(target_outer + 0xc0),
	    self->mic_buf, self->mic_buf + 32,
	    *(uint32_t *)(self->mic_buf + 32),
	    (int)neighbor_alloc_request, neighbor_alloc_caller);
	this->return_neighbor = (uintptr_t)self->mic_buf + 32;
	printf("%llu neighbor_return ptr=%p alloc_request=%d alloc_caller=%p\n",
	    (uint64_t)walltimestamp, this->return_neighbor,
	    (int)neighbor_alloc_request, neighbor_alloc_caller);
	if (acl_ready && acl_neighbor_ptr != 0) {
		printf("%llu acl_at_mic_return ptr=%p count_before=%u count_after=0x%x exact_des3=%d\n",
		    (uint64_t)walltimestamp, acl_neighbor_ptr,
		    acl_neighbor_count_before,
		    *(uint32_t *)acl_neighbor_ptr, exact_des3);
	}
	self->target_cchmac_final_public = 0;
	self->target_cchmac_final_internal = 0;
	self->hmac_digest_final_entry_count = 0;
	self->hmac_digest_final_count = 0;
	self->in_krb5 = 0;
	target_mic_tid = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:return
/self->candidate/
{
	printf("%llu get_mic_return tid=%d outer=%p exact_des3=%d\n",
	    (uint64_t)walltimestamp, tid, target_outer, exact_des3);
	mic_finished = 1;
	if (selected_mic_owner_plus1 == 0) {
		continue_barrier_ready = 1;
	}
	if (candidate_is_prime != 0) {
		printf("%llu PRIME_MIC_COMPLETE tid=%d outer=%p mic=%p owner_pid=%d slot=%d continue_sent=%d\n",
		    (uint64_t)walltimestamp, tid, target_outer,
		    target_mic_buf,
		    selected_mic_owner_plus1 == 0 ?
		    -1 : selected_mic_owner_plus1 - 1,
		    selected_mic_slot_plus1 == 0 ?
		    -1 : selected_mic_slot_plus1 - 1,
		    continue_signal_sent);
		candidate_claimed = 0;
		candidate_is_prime = 0;
		candidate_outer = (uintptr_t)0;
		target_outer = (uintptr_t)0;
		target_nfs_cp = (uintptr_t)0;
		target_mic_buf = (uintptr_t)0;
		target_mic_tid = 0;
		target_digest_ptr = (uintptr_t)0;
		target_alloc_cpu = -1;
		digest_temp_ready = 0;
		mic_finished = 0;
		mic_async_notified = 0;
		precopy_ready = 0;
		precopy_async_notified = 0;
		precopy_tid = 0;
		precopy_len = 0;
		precopy_sink = (uintptr_t)0;
		precopy_digest = (uintptr_t)0;
		precopy_cctx = (uintptr_t)0;
		precopy_di = (uintptr_t)0;
		precopy_etype = 0;
		cchmac_return_barrier_done = 0;
	}
	self->candidate = 0;
}

fbt:mach_kernel:gss_krb5_cfx_get_mic:return
/self->any_aes_cfx/
{
	self->any_aes_cfx = 0;
}

tick-60sec
{
	printf("%llu trace_end target=%p nfs_cp=%p outer_cp_freed=%d exact_des3=%d acl_ready=%d acl_ptr=%p inherit_exact=%d inherit_result=%d\n",
	    (uint64_t)walltimestamp, target_outer, target_nfs_cp,
	    outer_cp_freed, exact_des3, acl_ready, acl_neighbor_ptr,
	    inherit_exact_seen, inherit_result_seen);
	printf("%llu fdflags_end ptr=%p child_pid=%d parent_pid=%d destination_exact=%d inherit_returned=%d close_a_sent=%d close_a_drain=%d close_b_sent=%d close_b_drain=%d waiter_release=%d close_entries=%d fp_close_entries=%d byte17=0x%x\n",
	    (uint64_t)walltimestamp, configured_fdflags_ptr,
	    configured_fdflags_pid, configured_fdflags_parent_pid,
	    fdflags_destination_exact, fdflags_inherit_returned,
	    fd_close_a_signal_sent,
	    fd_close_a_drain_seen, fd_close_b_signal_sent,
	    fd_close_b_drain_seen, fdflags_waiter_release_signal_sent,
	    fd_close_entries, fd_fp_close_entries,
	    *(uint8_t *)(configured_fdflags_ptr + 17));
	exit(0);
}
