	configured_prime_required_frees = configured_prime_target_count *
	    configured_selective_a_frees_per_target -
	    configured_selective_a_free_slack;
