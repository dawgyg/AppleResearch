# NFS/RPCSEC_GSS attempt 2126: controlled fdflags overwrite reaches a double close and stale `fileglob` PAC failure

## Verdict

Attempt 2126 completed the full composed chain on macOS 27 beta 4 build
`26A5388g`:

1. an authenticated uid501 NFS/RPCSEC_GSS request raced an AES digest-size 12
   allocation against a DES3 digest-size 20 copy;
2. the attacker-selected final HMAC dword `0x00000002` changed a live ACL
   count from 1 to 2;
3. `kauth_acl_inherit` allocated a 32-byte destination for count 1, reloaded
   count 2, and copied 64 bytes into it;
4. the second copied ACE landed on the adjacent `fd_ofileflags` element and
   cleared `UF_RESERVED|UF_CLOSING` for fd 17;
5. two threads entered `fp_close_and_unlock_with_action` with the exact same
   `fileproc *` (`0xfffffe2aef6072e0`);
6. after the user-space flock barrier was released, the second closer used its
   stale saved `fileglob *`; PAC authentication of `fileglob->fg_ops` failed in
   the kernel and panicked.

This is no longer only an allocator-detected adjacent write. It is a dynamic
control-flow consequence of the chosen kernel-heap overwrite: the corrupted
descriptor state bypassed the close-in-progress exclusion and produced two
concurrent closes of one live `fileproc`.

## Exact dynamic chain

Selected protocol values:

```text
selected_sequence=1249385819
rpc_sequence=1249385820
hmac_sha1=3a63031d60b5ff01ccf902fda619f86302000000
overwrite_dword=0x00000002
handle=4b242342
```

Allocator geometry:

```text
MIC A       = 0xfffffe31c0f3a1c0
ACL source B= 0xfffffe31c0f3a1e0 = A + 0x20
ACL dest E  = 0xfffffe31c0f3a840
fdflags     = 0xfffffe31c0f3a860 = E + 0x20
owner       = parent pid 684, child pid 760, fd 17
fileproc    = 0xfffffe2aef6072e0
```

The trace recorded all of the following before the panic:

```text
SELECTIVE_MIC_OWNER ... ptr=fffffe31c0f3a1c0 owner_pid=684 slot=4 exact=1
INHERIT_SOURCE_OBSERVED ... source=fffffe31c0f3a1e0 count=1 source_is_b=1
EXACT_INHERIT_DST_ALLOC_RETURN ... dst=fffffe31c0f3a840 request=32 fdflags_exact=1
HMAC_SECOND_DIGEST_RETURN_RESUME ... len_before=12 len_live=20 etype_live=16 exact_des3=1
krb5_mic_return ... mic_buf=fffffe31c0f3a1c0 neighbor=fffffe31c0f3a1e0 overflow_dword=0x2
INHERIT_DIR_COUNT_BRACKET ... count_getattr=1 count_at_alloc_return=1 count_post_hold_pre_copy=2 exact_1_to_2=1
EXACT_INHERIT_RETURN ... dst=fffffe31c0f3a840 product_count=2 overflow_proven=1
FDFLAGS_COUNT2_GEOMETRY ... dst=fffffe31c0f3a840 fdflags=fffffe31c0f3a860 fdflags_q2=0x51 exact=1
FDFLAGS_FP_CLOSE_ENTRY ... tid=4778 ordinal=1 fd=17 fp=fffffe2aef6072e0 byte17=0x0
FDFLAGS_FP_CLOSE_ENTRY ... tid=4779 ordinal=2 fd=17 fp=fffffe2aef6072e0 byte17=0x0
FDFLAGS_SECOND_CLOSE_CLASS=DOUBLE_CLOSE_PATH ... tid=4779 fd=17
```

The first and second close threads were therefore `tid 4778` and `tid 4779`.
Both reached the same `fileproc *`, and both slept in `fileproc_drain` while a
flock waiter kept the object pinned.

## Panic correlation and exact symbolication

Panic artifact:

```text
panic-full-2026-07-31-210629.0002.panic
SHA-256 a7acf4bb16953fdb2d56f4b57b5df82b60f4f01a788e39aad5a7c0c8215b8bc9
Fileset Kernelcache UUID E17FC1E41A81EC3F52F255BE515B96EA
Kernel UUID E324BD2E-ABD7-3384-BFCA-6CFD1435DC72
Boot session UUID 3A7C6996-4D84-4410-9FB3-C3181A83140E
```

The panic states:

```text
Break 0xC472 instruction exception
Ptrauth failure with DA key
runtime pc = 0xfffffe0026392ea8
x19 = 0xfffffe2aef6072e0
x24 = 0xfffffe1a8ff7c748
Panicked task pid 760: v32select
Panicked thread tid 4779
```

`x19` exactly equals the `fileproc *` independently recorded for both close
entries. The panicked thread is exactly the second close thread.

Address mapping for the exact 26A5388g KDK:

```text
runtime PC                              0xfffffe0026392ea8
- KernelCache slide 0x1bf9c000         0xfffffe000a3f6ea8
- com.apple.kernel fileset delta 0x2b38000
= KDK PC                               0xfffffe00078beea8
atos                                   fp_close_and_unlock_with_action
source                                 kern_descrip.c:1867
function offset                        +0x73c
```

Exact KDK instructions:

```text
0xfffffe00078bee88  mov   x17, x24
0xfffffe00078bee8c  ldr   x16, [x17, #0x28]!
0xfffffe00078bee90  movk  x17, #0x853c, lsl #48
0xfffffe00078bee94  autda x16, x17
0xfffffe00078bee98  mov   x17, x16
0xfffffe00078bee9c  xpacd x17
0xfffffe00078beea0  cmp   x16, x17
0xfffffe00078beea4  b.eq  0xfffffe00078beeac
0xfffffe00078beea8  brk   #0xc472
```

KDK DWARF identifies `x24+0x28` exactly:

```text
struct fileglob, size 88
  ...
  ucred *fg_cred;                 // +0x20
  const fileops *fg_ops;          // +0x28, __ptrauth(DA, address, 0x853c)
```

Thus the failed operation is authentication of stale/corrupted
`fileglob->fg_ops`, not a broad nearest-symbol guess.

## Static close-lifetime explanation

The 26A5388g KDK implementation caches the shared objects before checking the
descriptor-state byte:

```text
fp_close_and_unlock_with_action +0x28  x19 = fileproc argument
+0x38  ldr x16, [x19,#0x10]            // fp->fp_glob
+0x64  x24 = authenticated fileglob
+0x70  load fd_ofileflags[fd]
+0x80  tst w9,#0xc                     // UF_RESERVED|UF_CLOSING
+0x84  b.ne panic-in-flux
+0x88  orr w9,w9,#0xc
+0x8c  store fd_ofileflags[fd]
```

Normally the `0x0c` check excludes a second close. The ACL overflow cleared
those bits after close A had set them, allowing close B to pass the same check
and cache the same `fileproc`/`fileglob` pair.

After `fileproc_drain`, the function clears the descriptor table and then:

```text
+0x8ac  decrement fileproc fp_iocount
+0x8e0..+0x948  clear/free fileproc when the last reference is released
+0x954  fg_drop(filedesc, saved_fileglob)
```

The first closer can therefore release the shared objects while the second
closer still holds the same pointers in registers. The second closer then
reaches `+0x71c`, loads `fg_ops` from its stale `fileglob`, and fails DA-key PAC
authentication at `+0x73c`.

## Debugger boundary

The two-close entry and exact kernel overwrite were complete before debugger
use. LLDB was used only after both closer threads were sleeping: it changed the
victim process's user-space `fdflags_release_waiter_requested` flag from 0 to 1
and the process was sent `SIGCONT`. No kernel address or kernel object was read
or modified through LLDB. The immediate post-release panic is the stale-object
consequence above.

A follow-up harness revision explicitly unblocks `SIGUSR1`, `SIGUSR2`, and
`SIGALRM` in the victim so the same barrier can be released without LLDB.

## Artifact hashes

```text
408969ab08e3eb07570b42f2263a0821ad36a49600c07682c90bbd312753cd77  cross_digest_acl_fdflags_beta4_attempt2126.run.log
260beaf0d5ad98650b11feb0324652b96fa77871a69ff44ed782dd01941c1294  voucher_selective_attempt2125.map
8095813523440b4be42cb59ad544f8dbc6c23deff9b0e5276563ac65c0bc1b5b  voucher_selective_attempt2125.map.prefork_rows
a7acf4bb16953fdb2d56f4b57b5df82b60f4f01a788e39aad5a7c0c8215b8bc9  panic-full-2026-07-31-210629.0002.panic
df0de7d63fe9ab0dc2a835f255f1186843d1415d6547ed7672f328f9c02a23f6  voucher32_prearmed_oracle.c
0f9b4a22e55aa1e1275e3da69532a821e0153555bbff0a41e8666efdcb118263  voucher32_prearmed_oracle
3b163be6926cb5aca05203da9d80128f4fe55cc513f9a8c19557109d885f6114  trace_cross_digest_acl_fdflags_beta4_cchmac_return.d
3681d11a61f7a177aa49ab7bb29248b52748fd39c6c28300d3f27139c31f6f4c  cross_digest_acl_fdflags_beta4_attempt2126.generated.d
```

## Claim boundary

Proven:

- uid501-authenticated remote NFS/RPCSEC_GSS reachability;
- chosen 32-bit HMAC tail written beyond the AES-sized MIC allocation;
- live ACL count 1 to 2 corruption;
- 64-byte ACL copy into a 32-byte destination;
- exact overwrite of adjacent live `fd_ofileflags`;
- bypass of the kernel close-in-progress exclusion;
- two kernel close paths for the same exact live `fileproc`;
- stale `fileglob->fg_ops` use by the second closer and a PAC failure panic.

Not yet claimed:

- attacker-selected kernel PC;
- a complete privilege-escalation payload;
- debugger-free reproduction of this final PAC panic (the next run removes the
  user-space release workaround).
