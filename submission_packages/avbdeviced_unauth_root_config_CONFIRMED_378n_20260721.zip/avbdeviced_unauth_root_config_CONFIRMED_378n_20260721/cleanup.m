#import <Foundation/Foundation.h>
@protocol AVBAudioConfigurationServer
- (void)removeCustomVirtualEntityWithUID:(NSString *)uid completion:(void(^)(BOOL,NSError*))c;
@end
int main(){@autoreleasepool{
  NSString *uid=[NSString stringWithContentsOfFile:@"/Users/dawgyg/submission_packages/avbdeviced_20260627/last_uid.txt" encoding:NSUTF8StringEncoding error:nil];
  if(!uid){printf("no uid\n");return 1;}
  NSXPCConnection *c=[[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.avb.audio.configuration" options:0];
  c.remoteObjectInterface=[NSXPCInterface interfaceWithProtocol:@protocol(AVBAudioConfigurationServer)];
  [c resume];
  dispatch_semaphore_t s=dispatch_semaphore_create(0);
  id p=[c remoteObjectProxyWithErrorHandler:^(NSError*e){ printf("err %s\n",[[e description]UTF8String]); dispatch_semaphore_signal(s); }];
  [p removeCustomVirtualEntityWithUID:uid completion:^(BOOL ok,NSError*e){ printf("remove ok=%d err=%s\n",ok,e?[[e description]UTF8String]:"(null)"); dispatch_semaphore_signal(s); }];
  dispatch_semaphore_wait(s,dispatch_time(DISPATCH_TIME_NOW,8LL*NSEC_PER_SEC));
  usleep(600*1000);
  return 0;
}}
