#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
int fs_snapshot_delete(int, const char *, unsigned int);
int fs_snapshot_list(int, struct attrlist *, void *, size_t, unsigned int);
int main(int argc, char **argv){
    const char *mp = argv[1]; const char *name = argv[2];
    int fd = open(mp, O_RDONLY);
    printf("open(%s) fd=%d errno=%d(%s)\n", mp, fd, fd<0?errno:0, fd<0?strerror(errno):"ok");
    if(fd<0) return 1;
    int r = fs_snapshot_delete(fd, name, 0);
    printf("fs_snapshot_delete(fd,%s)=%d errno=%d(%s)\n", name, r, r!=0?errno:0, r!=0?strerror(errno):"ok");
    close(fd);
    return 0;
}
