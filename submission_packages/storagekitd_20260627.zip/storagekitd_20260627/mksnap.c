#include <stdio.h>
#include <fcntl.h>
#include <errno.h>
#include <string.h>
#include <unistd.h>
int fs_snapshot_create(int, const char *, unsigned int);
int main(int argc, char **argv){
    int fd = open(argv[1], O_RDONLY);
    if(fd<0){printf("open fail %d\n",errno);return 1;}
    int r = fs_snapshot_create(fd, argv[2], 0);
    printf("fs_snapshot_create(%s)=%d errno=%d(%s)\n", argv[2], r, r?errno:0, r?strerror(errno):"ok");
    close(fd); return r?1:0;
}
