# Apple Security Bounty — DRAFT (awaiting user review before submission)

**Status:** NOT submitted. Draft for review. Codex lead, Claude dynamically validated.

---

## Title
Unauthenticated local information disclosure and identity lifecycle control in root daemon `remoted` (com.apple.remoted) — missing per-command authorization

## Platform / Version
- macOS 26.5.1 (build 25F80), Apple Silicon (arm64e)
- Component: `/usr/libexec/remoted` (RemoteServiceDiscovery), runs as root
- Mach service: `com.apple.remoted` (LaunchDaemon `/System/Library/LaunchDaemons/com.apple.remoted.plist`)

## Summary
The root daemon `remoted` exposes a libxpc command router on the Mach service `com.apple.remoted`. The router dispatches commands by a `cmd` dictionary key. While the command `list_local_device_services` is gated behind the entitlement `com.apple.private.RemoteServiceDiscovery.device-admin`, the device-**identity** and device-**description** commands are **not** gated. As a result, any unprivileged, non-admin local process (no entitlements, ad-hoc/unsigned binary) can:

1. **Disclose sensitive device identifiers** (`get_local_device_description`): Serial Number, UniqueDeviceID (UDID), UniqueChipID/ECID, Ethernet MAC, ChipID/BoardID, and security-fuse states.
2. **Disclose the device identity** (`get_local_device_identity`): the X.509 device identity certificate and identity attribute metadata, read from the **system keychain** (`kSecUseSystemKeychainAlways`).
3. **Delete and recreate/rotate the device identity** (`delete_local_device_identity` / `create_local_device_identity`): unauthenticated mutation of the root daemon's system-keychain security identity (`kSecClassIdentity`, label `com.apple.remoted.identity`, access group `com.apple.remoted`).

## Steps to reproduce
1. Compile the attached `evidence/remoted_probe.c` (raw libxpc client; no entitlements, ad-hoc):
   `clang -isysroot $(xcrun --show-sdk-path) remoted_probe.c -o remoted_probe`
2. As a **standard, non-admin** local user, run:
   - `./remoted_probe get_local_device_description` → returns `result=OK` plus Serial/UDID/ECID/MAC/etc.
   - `./remoted_probe get_local_device_identity` → returns `result=OK` plus `identity_cert` (X.509 DER) and `identity_key` (identity attribute/token metadata).
   - `./remoted_probe delete_local_device_identity` → `result=OK` (system-keychain identity deleted).
   - `./remoted_probe create_local_device_identity` → `result=OK` (new identity created; cert differs each cycle).
3. See `evidence/poc_run.txt` for full captured output (attacker uid 510, group `staff`, NOT admin).

## Impact
- **Information disclosure:** an unprivileged local process obtains hardware identifiers normally treated as sensitive (device fingerprinting / deanonymization) plus the root daemon's device identity certificate and identity metadata.
- **Integrity / availability:** an unprivileged local process can delete and rotate the root daemon's system-keychain security identity, disrupting RemoteServiceDiscovery trust/pairing for all users without authorization.
- Reachable from any non-sandboxed local user (the service is not in `application.sb`, so this is a non-sandboxed local attacker; no admin, no entitlement, no prompt).

## Root cause
The local XPC command router in `remoted` dispatches on the caller-controlled `cmd` string. Static analysis shows the neighboring `list_local_device_services` path checks `com.apple.private.RemoteServiceDiscovery.device-admin` with `xpc_copy_entitlement_for_token`, while the `get_local_device_description`, `get_local_device_identity`, `delete_local_device_identity`, and `create_local_device_identity` paths do not pass through that entitlement helper before performing device-description or system-keychain identity operations. Dynamic VM evidence confirms those four commands return `result=OK` to a non-admin uid 510 caller.

## Notes / honest scope
- `identity_key` (≈311 bytes) decodes as a DER OCTET STRING → SET of attribute SEQUENCEs (UTF8String keys e.g. `rk`, `pub`), i.e. **identity/token attribute metadata, not exportable raw private-key material** (the private key remains keychain/SEP-resident). This is disclosure of the certificate + identity metadata, **not** device-identity impersonation.
- Tier estimate: sensitive information disclosure + unauthenticated identity lifecycle mutation (medium). Not an LPE on its own.

## Attachments
- `evidence/poc_run.txt` — full PoC output (macOS 26.5.1)
- `evidence/remoted_probe.c` — PoC source
- `evidence/static_context.txt` — LaunchDaemon, entitlement, and string evidence
- `SHA256SUMS.txt` — attachment checksums
