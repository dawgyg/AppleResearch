#include <xpc/xpc.h>
#include <stdio.h>
#include <unistd.h>
#include <dispatch/dispatch.h>
int main(int argc, char**argv){
  const char* cmd = argc>1?argv[1]:"get_local_device_description";
  fprintf(stderr,"[*] euid=%d uid=%d  cmd=%s\n", geteuid(), getuid(), cmd);
  xpc_connection_t c = xpc_connection_create_mach_service("com.apple.remoted", NULL, 0);
  if(!c){ fprintf(stderr,"[!] no connection\n"); return 1; }
  xpc_connection_set_event_handler(c, ^(xpc_object_t e){
    if (xpc_get_type(e)==XPC_TYPE_ERROR){ char*d=xpc_copy_description(e); fprintf(stderr,"[!] conn event: %s\n",d); free(d);} });
  xpc_connection_resume(c);
  xpc_object_t msg = xpc_dictionary_create(NULL,NULL,0);
  xpc_dictionary_set_string(msg, "cmd", cmd);
  dispatch_semaphore_t s = dispatch_semaphore_create(0);
  xpc_connection_send_message_with_reply(c, msg, dispatch_get_global_queue(0,0), ^(xpc_object_t reply){
    char* desc = xpc_copy_description(reply);
    printf("=== REPLY (cmd=%s) ===\n%s\n", cmd, desc);
    free(desc);
    dispatch_semaphore_signal(s);
  });
  if (dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC)))
    fprintf(stderr,"[!] no reply within 8s (timeout)\n");
  return 0;
}
