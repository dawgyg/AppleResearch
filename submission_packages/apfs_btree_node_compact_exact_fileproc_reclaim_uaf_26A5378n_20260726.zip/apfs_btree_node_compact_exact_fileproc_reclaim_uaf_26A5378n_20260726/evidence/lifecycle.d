#pragma D option quiet
#pragma D option switchrate=10ms
uint64_t target_fp;
uint64_t first_tid;
uint64_t second_tid;
int delayed;
int reclaim_count;

fbt::fp_close_and_unlock_with_action:entry
/pid == 2323 && arg2 == 16383/
{
    printf("CLOSE_ENTRY pid=%d flags=0x%x fp=%p fd=%d\n",
        pid, *((unsigned char *)0xfffffe2faae2c000 + 0x3fff), arg3, arg2);
    target_fp = target_fp == 0 ? arg3 : target_fp;
    first_tid = first_tid == 0 ? tid : first_tid;
    second_tid = tid != first_tid ? tid : second_tid;
}
fbt:mach_kernel:_sleep:entry
/pid == 2323 &&
 (*((unsigned char *)0xfffffe2faae2c000 + 0x3fff) & 0xc) == 0xc/
{
    printf("CLOSE_PARKED pid=%d flags=0x%x channel=%p\n",
        pid, *((unsigned char *)0xfffffe2faae2c000 + 0x3fff), arg0);
}
fbt:mach_kernel:lck_mtx_unlock_contended:return
/pid == 2323 && tid == first_tid && delayed == 0 &&
 *((unsigned char *)0xfffffe2faae2c000 + 0x3fff) == 0x40/
{
    delayed = 1;
    printf("FIRST_CLOSE_DELAY pid=%d tid=%d target_fp=%p\n",
        pid, tid, target_fp);
    chill(500000000);
}
fbt:mach_kernel:zfree_ext:entry
/pid == 2323 && target_fp != 0 && arg2 == target_fp/
{
    self->target_free = 1;
    printf("TARGET_ZFREE_ENTRY pid=%d tid=%d target_fp=%p\n",
        pid, tid, target_fp);
}
fbt:mach_kernel:zfree_ext:return
/self->target_free/
{
    printf("TARGET_ZFREE_RETURN pid=%d tid=%d target_fp=%p\n",
        pid, tid, target_fp);
    self->target_free = 0;
}
fbt:mach_kernel:zalloc_ext:return
/pid == 2323 && target_fp != 0 && arg1 == target_fp/
{
    reclaim_count++;
    printf("TARGET_RECLAIM pid=%d tid=%d target_fp=%p count=%d\n",
        pid, tid, target_fp, reclaim_count);
}
fbt:mach_kernel:os_ref_panic_underflow:entry
/pid == 2323/
{
    printf("REFCOUNT_UNDERFLOW pid=%d tid=%d object=%p target_fp=%p reclaims=%d\n",
        pid, tid, arg0, target_fp, reclaim_count);
}
