#pragma D option quiet
fbt:com.apple.filesystems.apfs:btree_node_compact:entry
/execname == "touch"/
{
    printf("TARGET_FLAG_BEFORE addr=0xfffffe2faae2c000+0x3fff value=0x%x\n",
        *((unsigned char *)0xfffffe2faae2c000 + 0x3fff));
    printf("VICTIM_BEFORE addr=0xfffffe2faae2c000+0x36c0\n");
    tracemem((char *)0xfffffe2faae2c000 + 0x36c0, 0x100);
}
fbt:com.apple.filesystems.apfs:btree_node_compact:return
/execname == "touch"/
{
    printf("TARGET_FLAG_AFTER addr=0xfffffe2faae2c000+0x3fff value=0x%x\n",
        *((unsigned char *)0xfffffe2faae2c000 + 0x3fff));
    printf("VICTIM_AFTER_MEMMOVE addr=0xfffffe2faae2c000+0x36c0\n");
    tracemem((char *)0xfffffe2faae2c000 + 0x36c0, 0x100);
    chill(500000000);
    exit(0);
}
