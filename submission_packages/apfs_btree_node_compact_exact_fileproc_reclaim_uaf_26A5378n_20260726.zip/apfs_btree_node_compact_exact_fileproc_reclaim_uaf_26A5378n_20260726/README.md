# Codex -> Claude: APFS fd-state corruption now proves exact fileproc reclaim + UAF

## Result

The 26A5378n reclaim run upgraded the prior `os_refcnt` underflow into a
type-stable, exact-address `fileproc` reuse/UAF affecting an unrelated live
descriptor.

This is no longer only "two stale releases hit refcount hardening."

## Dynamic chain

Run:

- VM: `vm378n-kasan-fresh-20260716`, build `26A5378n`, uid 501
- run dir: `apfs_btree_compact_378n/reclaim_runs/20260726T050300Z/`
- victim PID: 2323
- live fd-flags allocation: `0xfffffe2faae2c000`
- APFS node: `0xfffffe2faae30000`
- original target fd: 16383
- original target `fileproc *`: `0xfffffe28d3d6a020`

Trace before corruption:

```text
CLOSE_ENTRY pid=2323 flags=0x0 fp=fffffe28d3d6a020 fd=16383
```

APFS predecessor write:

```text
TARGET_FLAG_BEFORE ... value=0xc
TARGET_FLAG_AFTER  ... value=0x40
```

That clears `UF_RESERVED|UF_CLOSING` while close #1 is parked. The harness then
starts close #2 and twelve same-process `F_DUPFD`/close churn threads.

## New panic

Panic:

`apfs_btree_compact_378n/panics/panic-full-2026-07-25-220325.0002.panic`

SHA-256:

`eb02c66b9d9d77fc5f9bf3ee3f87daaac01592b9b8d6e59345246708f8ed4663`

The panic is a kernel data abort, not the old refcount guard:

```text
pc  = 0xfffffe002555c25c
far = 0x28
x19 = 0xfffffe28d3d6a020
x23 = 0x17c8
x24 = 0
Panicked task: pid 2323 fdtable_exact_groom
```

Runtime-to-static text-exec delta is `0x1dca4000`, so the fault is:

```text
fp_close_and_unlock_with_action +164
static 0xfffffe00078b825c
kern_descrip.c:1824
```

Relevant current-build instructions:

```text
0xfffffe00078b81e0  mov x19, x3          ; current fileproc *
0xfffffe00078b81e4  mov x23, x2          ; current fd
0xfffffe00078b81f0  ldr x16,[x21,#0x10]! ; fp->fp_glob
0xfffffe00078b8224  mov x24,#0           ; NULL fp_glob path
0xfffffe00078b8258  mov x17,x24
0xfffffe00078b825c  ldr x16,[x17,#0x28]! ; fault at NULL+0x28
```

## Why this proves exact reclaim

At the fault:

- `x19` is exactly the original fd-16383 `fileproc *` captured by DTrace:
  `0xfffffe28d3d6a020`.
- `x23`, which is copied from the current close's fd argument and is unchanged
  before the fault, is `0x17c8` (decimal 6088), not 16383.

Therefore the exact freed target address was reused as the `fileproc` for a new
spray descriptor, fd 6088. A stale close then destroyed/zeroed that replacement
object, and the normal close of fd 6088 dereferenced its now-NULL `fp_glob`.

This establishes:

1. attacker-controlled APFS write clears a live descriptor's close-state bits;
2. duplicate close frees the original typed `fileproc`;
3. same-process allocation reclaims the exact address for a different fd;
4. stale lifetime action corrupts/frees the replacement;
5. a legitimate operation on the replacement performs a kernel UAF dereference.

## Bounded impact statement

Confirmed: deterministic uid-501-triggered kernel write -> exact typed-object
reclaim -> cross-descriptor `fileproc` UAF -> kernel data abort.

Not yet confirmed: cross-type reclaim, controlled pointer contents, controlled
PC, or kernel R/W. `fileproc` allocation remains typed-zone constrained, so the
next exploit question is what useful `fileproc`/`fileglob` state can be retained
or raced before stale destruction.

## Harness

- `codex_lanes/apfs_btree_compact_378n/fdtable_exact_groom.c`
- `codex_lanes/apfs_btree_compact_378n/fdtable_exact_groom.reclaim`
- `codex_lanes/apfs_btree_compact_378n/run_apfs_fd_lifecycle.sh`
- runner now clones the pristine image per attempt

Current hashes:

```text
9c3c93170cd0882eaacf8677f3aebac6b239b0cb42189175d30f987548299fe1  fdtable_exact_groom.reclaim
71d19e490a6fdfa2276cb2ddb17f2161d5bcbeba19a7ca5bbc7810b963d56f04  run_apfs_fd_lifecycle.sh
```

## Beta 4 transition

The user is preparing the new macOS 27 beta 4 update. Bank this 26A5378n
evidence now. Once the new host/VM baseline is available, first priority is:

1. identify the exact beta-4 build and kernel UUID;
2. extract fresh kernel/KDK symbols;
3. verify `_btree_node_compact` sink and `fp_close_and_unlock_with_action`
   lifecycle are unchanged;
4. rerun the pristine-image controlled write and exact-reclaim harness.
