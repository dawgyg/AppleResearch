#pragma D option quiet

fbt:com.apple.filesystems.hfs.kext:hfs_init_summary:entry
{
    printf("INIT hfsmp=%p\n", arg0);
}

fbt:com.apple.filesystems.hfs.kext:hfs_ValidateHFSPlusVolumeHeader:return
{
    printf("RETURN validate=0x%x\n", arg1);
}

fbt:com.apple.filesystems.hfs.kext:hfs_MountHFSPlusVolume:return
{
    printf("RETURN mountplus=0x%x\n", arg1);
}

fbt:com.apple.filesystems.hfs.kext:hfs_mountfs:return
{
    printf("RETURN mountfs=0x%x\n", arg1);
}

fbt:com.apple.filesystems.hfs.kext:hfs_getnewvnode:return
{
    printf("RETURN getnewvnode=0x%x\n", arg1);
}

fbt:com.apple.filesystems.hfs.kext:BTOpenPath:return
{
    printf("RETURN BTOpenPath=0x%x\n", arg1);
}

fbt:com.apple.filesystems.hfs.kext:ReadBitmapRange:entry
{
    printf("READ_BITMAP off=0x%x size=0x%x\n", arg1, arg2);
}

fbt:com.apple.filesystems.hfs.kext:ScanUnmapBlocks:entry
{
    printf("SCAN_UNMAP hfsmp=%p\n", arg0);
}

fbt:com.apple.filesystems.hfs.kext:update_summary_table:entry
{
    printf("UPDATE start=0x%x count=0x%x set=%u\n", arg1, arg2, arg3);
}
