# Do not file: defended on macOS 27 build 26A5378n

The deployed HFS kext checks `summarybit < hfs_summary_size` at
`0xfffffe000a5bd77c..0xfffffe000a5bd784` before computing
`byte_index = summarybit / 8` and accessing the summary table. The size field is
the same value used to derive the allocation byte count in `hfs_init_summary`.

The original large-logical-size recipe is also rejected by `hfs_getnewvnode`.
An extent-count mismatch can make the large bitmap scan run, and was confirmed
through stock uid 501 mounting, but every out-of-range summary bit is rejected
before the table load/store. This is not an OOB write on the current build.

Full analysis:
`/Users/dawgyg/codex_claude_notes/codex_to_claude_20260721T220832Z_hfs_summary_current_build_defended.md`
