#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

#define VH_OFFSET 1024ULL
#define VH_SIZE 512U
#define BLOCK_SIZE 4096U
#define BLOCK_SIZE_OFFSET 40U
#define TOTAL_BLOCKS_OFFSET 44U
#define FREE_BLOCKS_OFFSET 48U
#define ALLOCATION_FORK_OFFSET 112U
#define FORK_LOGICAL_SIZE_OFFSET 0U
#define FORK_TOTAL_BLOCKS_OFFSET 12U
#define FORK_EXTENTS_OFFSET 16U

static uint16_t read_be16(const uint8_t *p) {
    return ((uint16_t)p[0] << 8) | p[1];
}

static uint32_t read_be32(const uint8_t *p) {
    return ((uint32_t)p[0] << 24) | ((uint32_t)p[1] << 16) |
           ((uint32_t)p[2] << 8) | p[3];
}

static void write_be32(uint8_t *p, uint32_t value) {
    p[0] = (uint8_t)(value >> 24);
    p[1] = (uint8_t)(value >> 16);
    p[2] = (uint8_t)(value >> 8);
    p[3] = (uint8_t)value;
}

static void write_be64(uint8_t *p, uint64_t value) {
    write_be32(p, (uint32_t)(value >> 32));
    write_be32(p + 4, (uint32_t)value);
}

static int copy_file(int source_fd, int output_fd) {
    uint8_t buffer[1024 * 1024];
    ssize_t count;
    while ((count = read(source_fd, buffer, sizeof(buffer))) > 0) {
        ssize_t done = 0;
        while (done < count) {
            ssize_t written = write(output_fd, buffer + done, (size_t)(count - done));
            if (written < 0)
                return -1;
            done += written;
        }
    }
    return count < 0 ? -1 : 0;
}

static uint64_t parse_u64(const char *text, const char *name) {
    char *end = NULL;
    errno = 0;
    uint64_t value = strtoull(text, &end, 0);
    if (errno || end == text || *end != '\0') {
        fprintf(stderr, "invalid %s: %s\n", name, text);
        exit(2);
    }
    return value;
}

int main(int argc, char **argv) {
    if (argc < 4 || argc > 7) {
        fprintf(stderr,
                "usage: %s SOURCE OUTPUT TOTAL_BLOCKS [ALLOCATION_START] "
                "[--small-extent] [--small-logical]\n",
                argv[0]);
        return 2;
    }
    if (!strncmp(argv[2], "/dev/", 5)) {
        fprintf(stderr, "refusing to write a device path\n");
        return 2;
    }

    uint64_t parsed_blocks = parse_u64(argv[3], "TOTAL_BLOCKS");
    if (parsed_blocks < 1 || parsed_blocks > UINT32_MAX) {
        fprintf(stderr, "TOTAL_BLOCKS must fit uint32_t\n");
        return 2;
    }
    uint32_t total_blocks = (uint32_t)parsed_blocks;
    uint32_t allocation_start = 0x1000;
    int small_extent = 0;
    int small_logical = 0;
    for (int i = 4; i < argc; i++) {
        if (!strcmp(argv[i], "--small-extent")) {
            small_extent = 1;
        } else if (!strcmp(argv[i], "--small-logical")) {
            small_logical = 1;
        } else {
            uint64_t parsed_start = parse_u64(argv[i], "ALLOCATION_START");
            if (parsed_start > UINT32_MAX) {
                fprintf(stderr, "ALLOCATION_START must fit uint32_t\n");
                return 2;
            }
            allocation_start = (uint32_t)parsed_start;
        }
    }

    uint8_t vh[VH_SIZE];
    uint8_t bitmap[BLOCK_SIZE];
    int source_fd = open(argv[1], O_RDONLY);
    if (source_fd < 0) {
        perror("open source");
        return 1;
    }
    if (pread(source_fd, vh, sizeof(vh), VH_OFFSET) != sizeof(vh) ||
        pread(source_fd, bitmap, sizeof(bitmap), BLOCK_SIZE) != sizeof(bitmap)) {
        perror("read source metadata");
        close(source_fd);
        return 1;
    }
    uint16_t signature = read_be16(vh);
    if ((signature != 0x482b && signature != 0x4858) ||
        read_be32(vh + BLOCK_SIZE_OFFSET) != BLOCK_SIZE) {
        fprintf(stderr, "source is not a 4096-byte-block HFS+/HFSX image\n");
        close(source_fd);
        return 1;
    }

    int output_fd = open(argv[2], O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (output_fd < 0) {
        perror("open output");
        close(source_fd);
        return 1;
    }
    if (copy_file(source_fd, output_fd) != 0) {
        perror("copy source");
        close(source_fd);
        close(output_fd);
        return 1;
    }
    close(source_fd);

    uint64_t bitmap_logical_size = (((uint64_t)total_blocks + 7) / 8 +
                                    BLOCK_SIZE - 1) & ~(uint64_t)(BLOCK_SIZE - 1);
    uint64_t fork_logical_size = small_logical ? BLOCK_SIZE : bitmap_logical_size;
    uint32_t mapped_blocks = (uint32_t)(bitmap_logical_size / BLOCK_SIZE);
    uint32_t extent_blocks = small_extent ? 1 : mapped_blocks;
    uint64_t image_size = (uint64_t)total_blocks * BLOCK_SIZE;
    if ((uint64_t)allocation_start + extent_blocks > total_blocks) {
        fprintf(stderr, "allocation extent exceeds declared volume\n");
        close(output_fd);
        return 2;
    }

    write_be32(vh + TOTAL_BLOCKS_OFFSET, total_blocks);
    write_be32(vh + FREE_BLOCKS_OFFSET,
               total_blocks > 0x2000 ? total_blocks - 0x2000 : 1);
    uint8_t *fork = vh + ALLOCATION_FORK_OFFSET;
    write_be64(fork + FORK_LOGICAL_SIZE_OFFSET, fork_logical_size);
    write_be32(fork + FORK_TOTAL_BLOCKS_OFFSET, 1);
    write_be32(fork + FORK_EXTENTS_OFFSET, allocation_start);
    write_be32(fork + FORK_EXTENTS_OFFSET + 4, extent_blocks);
    memset(fork + FORK_EXTENTS_OFFSET + 8, 0, 7 * 8);

    if (ftruncate(output_fd, (off_t)image_size) != 0 ||
        pwrite(output_fd, vh, sizeof(vh), VH_OFFSET) != sizeof(vh) ||
        pwrite(output_fd, bitmap, sizeof(bitmap),
               (off_t)allocation_start * BLOCK_SIZE) != sizeof(bitmap) ||
        pwrite(output_fd, vh, sizeof(vh), (off_t)(image_size - VH_OFFSET)) != sizeof(vh) ||
        fsync(output_fd) != 0) {
        perror("write output metadata");
        close(output_fd);
        return 1;
    }
    close(output_fd);

    printf("output=%s\n", argv[2]);
    printf("logical_image_size=0x%" PRIx64 "\n", image_size);
    printf("total_blocks=0x%x\n", total_blocks);
    printf("bitmap_logical_size=0x%" PRIx64 "\n", bitmap_logical_size);
    printf("fork_logical_size=0x%" PRIx64 "\n", fork_logical_size);
    printf("allocation_total_blocks=1\n");
    printf("allocation_extent=0x%x+0x%x\n", allocation_start, extent_blocks);
    printf("summary_allocation_bytes=1\n");
    printf("max_summary_byte_index~0x%x\n",
           (total_blocks - 1) / (BLOCK_SIZE * 64));
    return 0;
}
