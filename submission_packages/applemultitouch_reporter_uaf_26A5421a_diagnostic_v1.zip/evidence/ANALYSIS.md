# Codex -> Claude: AppleMultitouch selector-0 reporter UAF CONFIRMED on 26A5421a

## Verdict

Confirmed uid501 kernel use-after-free in
`AppleMultitouchDeviceUserClient::setSendsFrames`. A controlled DTrace schedule
forced `enable -> disable -> enable` across one fresh connection. One enable
released/replaced the `IOSimpleReporter` while the other enable was inside
`IOReporter::addChannel` with the stale reporter. The host panicked in that
consumer, and the full kernel core proves the stale object was freed/zeroed
while the owner field held a distinct live replacement.

This is stronger than the prior static lead, but the current capture used
DTrace `chill()` plus research boot args. Treat it as a deterministic diagnostic
proof, not filing-grade stock evidence. The next requirement is an
uninstrumented race on physical AppleMultitouch hardware, followed by a
stock/SIP-on reproduction. Tart does not expose this device.

## Exact current baseline

- OS: macOS 27.0 `26A5421a`
- XNU: `13432.1.9~3/RELEASE_ARM64_T6000`
- kernelcache UUID: `9FA843C5-948F-7C7D-7B09-9EEA0972B1A5`
- AppleMultitouchDriver UUID: `25E04389-76FA-37DC-B417-F8BC111F1FD3`
- exact extracted kext SHA-256:
  `76282000b0efd56f71712118b8fd67ea63872aeb70dda08520644a33f3400355`
- capture boot args:
  `-zp gzalloc_min=16 gzalloc_max=98304 keepsyms=1 gzalloc_fc_size=8`
- panic reports `OS release type: User`, `secure boot?: YES`,
  `roots installed: 0`; SIP/boot args are nevertheless non-stock.

## Reachability

The panic stackshot records:

```text
procname: mt_reporter_toggle
pid: 88316
userID: 501
threads: 2
panicked tid: 4317127
```

`AppleMultitouchDeviceUserClient::initWithTask` has no entitlement/credential
gate. Selector 0 is scalar-input count 1 / scalar-output count 0. Calls on this
legacy user client are concurrent under XNU's shared default IPC lock.

## Missing lifetime synchronization

Exact current `setSendsFrames @ 0xfffffe0009a58f80`:

```text
0xfffffe0009a58fc4  ldrb w9,[x0,#0x178]     current enabled byte
0xfffffe0009a58fcc  cmp  w8,w9
0xfffffe0009a58fd0  b.eq 0xfffffe0009a591f8
0xfffffe0009a58fdc  strb w24,[x19,#0x178]   racy publish
...
0xfffffe0009a590d4  ldr  x8,[x19,#0x168]    reporter check
0xfffffe0009a590d8  cbnz x8,0xfffffe0009a591f8
0xfffffe0009a590e8  bl   IOSimpleReporter::with
0xfffffe0009a590ec  mov  x20,x0             local reporter
0xfffffe0009a590f0  ldr  x0,[x19,#0x168]    reload shared reporter
0xfffffe0009a590f4  cbz  x0,0xfffffe0009a59114
0xfffffe0009a59110  blraa ...               release old shared reporter
0xfffffe0009a59114  str  x20,[x19,#0x168]   publish replacement
...
0xfffffe0009a591ac  ldr  x0,[x19,#0x168]    borrow without retain
0xfffffe0009a591b4  bl   IOReporter::addChannel
```

No lock or retain covers the shared reporter field. The ordered diagnostic
uses `enable(1)`, `disable(0)`, `enable(1)`. DTrace pauses the first allocation
and first `addChannel` entry so the other enable can allocate, release, and
replace the borrowed reporter.

## Panic proof

Panic:

```text
panic(cpu 3): Kernel data abort
pc  = 0xfffffe0053c79608
lr  = 0x...fe00513251b8
esr = 0x96000006 (read translation fault)
far = 0x8
x20 = 0xfffffe1985323d80
x21 = 0xfffffe1e4929e33c
Panicked task: pid 88316 mt_reporter_toggle
AppleMultitouchDriver in backtrace
```

Kernelcache slide is `0x478cc000`, so the stripped/authenticated LR rebases to
`0xfffffe0009a591b8`, exactly the instruction after the selector-0
`bl IOReporter::addChannel` at `0xfffffe0009a591b4`.

The faulting function rebases to `IOReporter::addChannel @
0xfffffe000c3ad5c0`; the exact fault is:

```text
0xfffffe000c3ad5e8  mov  x20,x0             save stale reporter this
0xfffffe000c3ad5f0  ldr  x0,[x0,#0x70]      stale this+0x70 -> NULL
0xfffffe000c3ad604  add  x10,x0,#8           x10 = 8
0xfffffe000c3ad608  casa x2,x8,[x10]         fault, FAR=0x8
```

The panic registers preserve `x20 = 0xfffffe1985323d80`. The full core shows
that entire stale object body zeroed at panic time, including `+0x70`.

The user-client address is derived from the channel-name pointer:
`x21 - 0xec = 0xfffffe1e4929e250`. Core memory at its reporter field gives:

```text
[0xfffffe1e4929e250 + 0x168] = 0xfffffe1985323380
```

That replacement object is live and populated (nonzero authenticated vtable
and fields), while stale `x20 = 0xfffffe1985323d80` is zeroed. Thus the
consumer is operating on B after the sibling thread released B and published A.

## Evidence

- Panic:
  `/Library/Logs/DiagnosticReports/Retired/panic-full-2026-08-29-171731.0002.panic`
  SHA-256 `cd96c5eda312c7e09764cd10a67c2de5fbc2f9554ad94b2d450524c5ab3b08a5`
- Compressed full kernel core:
  `/private/var/db/DumpPanic/Coredumps/2026-08-29-171731.kernel.core.gz`
  SHA-256 `fe834e2d97b620dded27a655ad4b16a552051ecc1339f0c110f1c0f5ce99f616`
- Decompressed core:
  `/Users/dawgyg/codex_scratch/applemultitouch_reporter_uaf_26A5421a/2026-08-29-171731.kernel.core`
  SHA-256 `3af06069c3b67f5f9a513d1c3062f3d020888db9b53589af6c546f58bcec7735`
- Ordered harness:
  `/Users/dawgyg/codex_scratch/applemultitouch_reporter_race_5421a/mt_reporter_toggle.c`
  SHA-256 `dc68f6fecb66ca2a047677c1afa183563cbd4b29852814ec8d2f8521c5868b46`
- Ordered harness binary SHA-256:
  `c75ce6991aff45efcc1a316118d75b8fe8834fefc683df623ecd7cc3a52a3b98`
- Forced-schedule DTrace:
  `/Users/dawgyg/codex_scratch/applemultitouch_reporter_race_5421a/mt_reporter_force_schedule.d`
  SHA-256 `7ab418fe92420cca44dc4c86801e084768f8790c3cfe1ddb931f1a83ef47f5ce`

## Next exploitation path

1. Build an uninstrumented toggle-storm harness that repeatedly creates a fresh
   connection and sends ordered/concurrent `1,0,1` sequences. The all-enable
   harness targeted only the three-instruction enabled-byte window; toggling
   opens the longer allocation-before-publish window.
2. Reproduce naturally on this physical host under GZAlloc, then on a stock
   physical Apple-silicon Mac with AppleMultitouch hardware.
3. For a Target Flag upgrade, reclaim the stale `IOSimpleReporter` allocation.
   `addChannel` immediately consumes stale `this+0x70` as a pointer and performs
   an atomic access at `pointer+8`. Determine the reporter allocation class and
   identify a uid501 same-zone controlled-content spray before removing GZAlloc.

