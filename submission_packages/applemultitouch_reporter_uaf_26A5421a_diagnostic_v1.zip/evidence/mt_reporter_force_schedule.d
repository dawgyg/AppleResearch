#pragma D option destructive
#pragma D option quiet

BEGIN
{
    first_with = 0;
    first_add = 0;
}

fbt:com.apple.driver.AppleMultitouchDriver:_ZN31AppleMultitouchDeviceUserClient14setSendsFramesEPv:entry
/uid == 501/
{
    self->in_set = 1;
    printf("SET entry ts=%llu tid=%d self=%p desired=%p cpu=%d\n",
        timestamp, tid, arg0, arg1, cpu);
}

fbt:mach_kernel:_ZN16IOSimpleReporter4withEP9IOServicety:entry
/self->in_set && first_with == 0/
{
    first_with = 1;
    printf("WITH first entry: chill 50ms ts=%llu tid=%d cpu=%d\n",
        timestamp, tid, cpu);
    chill(50000000);
    printf("WITH first resume ts=%llu tid=%d cpu=%d\n",
        timestamp, tid, cpu);
}

fbt:mach_kernel:_ZN16IOSimpleReporter4withEP9IOServicety:return
/self->in_set/
{
    printf("WITH return ts=%llu tid=%d reporter=%p cpu=%d\n",
        timestamp, tid, arg1, cpu);
}

fbt:mach_kernel:_ZN10IOReporter10addChannelEyPKc:entry
/self->in_set && first_add == 0/
{
    first_add = 1;
    printf("ADD first entry: reporter=%p chill 100ms ts=%llu tid=%d cpu=%d\n",
        arg0, timestamp, tid, cpu);
    chill(100000000);
    printf("ADD first resume: reporter=%p ts=%llu tid=%d cpu=%d\n",
        arg0, timestamp, tid, cpu);
}

fbt:mach_kernel:_ZN10IOReporter10addChannelEyPKc:entry
/self->in_set && first_add != 0/
{
    printf("ADD entry reporter=%p ts=%llu tid=%d cpu=%d\n",
        arg0, timestamp, tid, cpu);
}

fbt:mach_kernel:_ZN16IOSimpleReporterD0Ev:entry
/self->in_set/
{
    printf("DTOR reporter=%p ts=%llu tid=%d cpu=%d\n",
        arg0, timestamp, tid, cpu);
}

fbt:com.apple.driver.AppleMultitouchDriver:_ZN31AppleMultitouchDeviceUserClient14setSendsFramesEPv:return
/uid == 501/
{
    printf("SET return ts=%llu tid=%d kr=%x cpu=%d\n",
        timestamp, tid, arg1, cpu);
    self->in_set = 0;
}
