#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <mach/mach_error.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct call {
    io_connect_t connection;
    uint64_t value;
    useconds_t delay_us;
    kern_return_t result;
};

static void *
call_selector(void *opaque)
{
    struct call *call = opaque;

    if (call->delay_us != 0) {
        usleep(call->delay_us);
    }
    call->result = IOConnectCallScalarMethod(call->connection, 0,
        &call->value, 1, NULL, NULL);
    return NULL;
}

int
main(int argc, char **argv)
{
    useconds_t step_us = 5000;
    io_service_t service;
    io_connect_t connection = IO_OBJECT_NULL;
    pthread_t threads[3];
    struct call calls[3];
    kern_return_t kr;

    if (argc > 1) {
        step_us = (useconds_t)strtoul(argv[1], NULL, 0);
    }

    service = IOServiceGetMatchingService(kIOMainPortDefault,
        IOServiceMatching("AppleMultitouchDevice"));
    if (service == IO_OBJECT_NULL) {
        fprintf(stderr, "AppleMultitouchDevice not found\n");
        return 1;
    }

    kr = IOServiceOpen(service, mach_task_self(), 0, &connection);
    IOObjectRelease(service);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "IOServiceOpen: %#x (%s)\n", kr,
            mach_error_string(kr));
        return 1;
    }

    calls[0] = (struct call){connection, 1, 0, 0};
    calls[1] = (struct call){connection, 0, step_us, 0};
    calls[2] = (struct call){connection, 1, step_us * 2, 0};

    printf("pid=%d uid=%u step_us=%u connection=%#x\n", getpid(), getuid(),
        step_us, connection);
    fflush(stdout);

    for (unsigned i = 0; i < 3; i++) {
        if (pthread_create(&threads[i], NULL, call_selector, &calls[i]) != 0) {
            fprintf(stderr, "pthread_create failed at %u\n", i);
            _exit(2);
        }
    }
    for (unsigned i = 0; i < 3; i++) {
        pthread_join(threads[i], NULL);
        printf("call[%u] value=%llu delay_us=%u result=%#x (%s)\n", i,
            calls[i].value, calls[i].delay_us, calls[i].result,
            mach_error_string(calls[i].result));
    }

    IOServiceClose(connection);
    return 0;
}
