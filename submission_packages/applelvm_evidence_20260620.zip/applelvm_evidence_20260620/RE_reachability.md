Verdict: AppleLVMGroup is uid501-reachable by image attach on macOS 27 via on-disk AppleRAID-LevelName string "LVG", provided the member is a complete LVG member. The live "unknown raid level LVG" log means the LVG creation helper returned NULL for that image; it does not mean "LVG" is absent from AppleRAID::newMember.

Kernelcache: 26A5353q Mac13,1_2_MacBookPro18,1_2_3_4.

Dispatch facts:
- AppleRAID fileset entry: vmaddr 0xfffffe00076c6d80, fileoff 0x6c2d80.
- AppleRAID::newMember gets the member's "AppleRAID-LevelName" at 0xfffffe0009b58cf0-0xfffffe0009b58d00.
- It casts/uses the level object, then checks these exact strings:
  - "Concat": compare at 0xfffffe0009b58d40/0xfffffe0009b58d44, success calls 0xfffffe0009b69294, which allocates AppleRAIDConcatSet.
  - "Mirror": compare at 0xfffffe0009b58f58/0xfffffe0009b58f5c, success calls 0xfffffe0009b63844, which allocates AppleRAIDMirrorSet.
  - "Stripe": compare at 0xfffffe0009b58f90/0xfffffe0009b58f94, success calls 0xfffffe0009b68344, which allocates AppleRAIDStripeSet.
  - "LVG": compare at 0xfffffe0009b58fc8/0xfffffe0009b58fcc, success calls 0xfffffe0009b6afa4, which allocates AppleLVMGroup.
- If the selected helper returns NULL, newMember drops to the same error path: it stringifies the level at 0xfffffe0009b59020-0xfffffe0009b5903c and logs "AppleRAID::newMember unknown raid level %s" at 0xfffffe0009b59044/0xfffffe0009b59048. That explains the observed "unknown raid level LVG" from an incomplete LVG image.

AppleLVMGroup creation:
- createLVG helper 0xfffffe0009b6afa4 allocates size 0x1f0 from type descriptor 0xfffffe000823b998 at 0xfffffe0009b6afbc-0xfffffe0009b6afc8.
- It uses AppleLVMGroup::gMetaClass at 0xfffffe000c9c1bd8 (0xfffffe0009b6afd0-0xfffffe0009b6afd8) and installs the AppleLVMGroup vtable family at 0xfffffe0009b6afe8-0xfffffe0009b6b000.
- Its init path sets the on-object LevelName property to "LVG" at 0xfffffe0009b6b180-0xfffffe0009b6b19c.
- Failure cleanup is 0xfffffe0009b6b0c4-0xfffffe0009b6b0dc; success returns the AppleLVMGroup object at 0xfffffe0009b6b0e0.

Single-member reach recipe:
1. Attach a GPT disk image as uid501 with an AppleRAID member partition. The live kernel log already proves uid501 image attach reaches AppleRAID::newMember.
2. Use an AppleRAID v2 member header whose set fields are coherent for a one-member set: SetUUID present, MemberUUID present, MemberIndex 0, member count 1, and AppleRAID-LevelName exactly "LVG".
3. Include the primary AppleRAID/LVG metadata area, not just the level-name key. A bare member header can select the LVG branch but still make 0xfffffe0009b6afa4 return NULL, causing the misleading unknown-level log.
4. When the set starts, AppleLVMGroup::startSet at 0xfffffe0009b6b7f0 calls its superclass start at 0xfffffe0009b6b814-0xfffffe0009b6b828, requires the primary member pointer at [this+0x1c8], obtains that member's primary metadata at 0xfffffe0009b6b870-0xfffffe0009b6b894, and then dispatches vtable slot +0x988 at 0xfffffe0009b6b95c-0xfffffe0009b6b970 with x0=this and x1=[this+0x1c8].
5. That slot is AppleLVMGroup::readPrimaryMetaData at 0xfffffe0009b6c4ac. The body starts at 0xfffffe0009b6c4ac and reads/byte-swaps the LVG primary metadata, including the TOC count at [meta+0x38] and the per-entry loop at 0xfffffe0009b6c550-0xfffffe0009b6c578.

Conclusion: not a legacy/CoreStorage-only dead path. AppleRAID member LevelName "LVG" is the on-disk selector for AppleLVMGroup. The toc_nentries site is not killed on reachability grounds; the next dynamic step is to provide a complete one-member LVG primary metadata blob rather than only a header with LevelName="LVG".
