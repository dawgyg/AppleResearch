#!/bin/bash

set -u

image=${1:-./hfs_record_offset_oob.raw}
util=/System/Library/Filesystems/hfs.fs/Contents/Resources/hfs.util
dev=

cleanup() {
    test -n "$dev" && hdiutil detach "$dev" >/dev/null 2>&1
}
trap cleanup EXIT

test -f "$image" || {
    echo "missing image: $image" >&2
    exit 1
}
sudo -v || exit 1

dev=$(hdiutil attach -nomount \
    -imagekey diskimage-class=CRawDiskImage "$image" 2>/dev/null |
    awk 'NR == 1 { print $1 }')
test -n "$dev" || {
    echo "failed to attach raw image" >&2
    exit 1
}

sudo env DYLD_INSERT_LIBRARIES=/usr/lib/libgmalloc.dylib \
    MallocGuardEdges=1 \
    "$util" -p "${dev#/dev/}" removable writable nosuid nodev
