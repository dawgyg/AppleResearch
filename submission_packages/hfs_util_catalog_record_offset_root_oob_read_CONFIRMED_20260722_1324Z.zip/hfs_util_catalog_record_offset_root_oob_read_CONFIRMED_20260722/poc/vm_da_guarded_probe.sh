#!/bin/bash

set +e

image=${1:-/Users/Shared/hfs_record_offset_oob.raw}
if test ! -f "$image"; then
    echo "missing image: $image" >&2
    exit 1
fi

sudo -n true || exit 1

cleanup() {
    sudo -n launchctl unsetenv DYLD_INSERT_LIBRARIES >/dev/null 2>&1
    sudo -n launchctl unsetenv MallocGuardEdges >/dev/null 2>&1
    sudo -n launchctl kickstart -k system/com.apple.diskarbitrationd >/dev/null 2>&1
}
trap cleanup EXIT

before=$(find /Library/Logs/DiagnosticReports -name 'hfs.util*.ips' -type f 2>/dev/null | wc -l | tr -d ' ')

sudo -n launchctl setenv DYLD_INSERT_LIBRARIES /usr/lib/libgmalloc.dylib || exit 2
sudo -n launchctl setenv MallocGuardEdges 1 || exit 3
echo "launchd_DYLD=$(sudo -n launchctl getenv DYLD_INSERT_LIBRARIES)"
echo "launchd_MallocGuardEdges=$(sudo -n launchctl getenv MallocGuardEdges)"
sudo -n launchctl kickstart -k system/com.apple.diskarbitrationd || exit 4
sleep 2

daemon_pid=$(pgrep -x diskarbitrationd | head -1)
echo "diskarbitrationd_pid=$daemon_pid"
sudo -n ps eww -p "$daemon_pid" | tr ' ' '\n' | grep -E '^(DYLD_INSERT_LIBRARIES|MallocGuardEdges)=' || true

rm -f /tmp/hfs_da_attach.out /tmp/hfs_da_attach.rc
(
    hdiutil attach -readonly -noautoopen \
        -imagekey diskimage-class=CRawDiskImage \
        "$image" \
        > /tmp/hfs_da_attach.out 2>&1
    echo $? > /tmp/hfs_da_attach.rc
) &
attach_pid=$!

for _ in $(seq 1 40); do
    kill -0 "$attach_pid" 2>/dev/null || break
    sleep 0.5
done
if kill -0 "$attach_pid" 2>/dev/null; then
    echo "attach_timed_out=1"
    kill "$attach_pid" 2>/dev/null
else
    echo "attach_timed_out=0"
fi
cat /tmp/hfs_da_attach.out
test -f /tmp/hfs_da_attach.rc && echo "attach_rc=$(cat /tmp/hfs_da_attach.rc)"

for _ in $(seq 1 20); do
    after=$(find /Library/Logs/DiagnosticReports -name 'hfs.util*.ips' -type f 2>/dev/null | wc -l | tr -d ' ')
    test "$after" -gt "$before" && break
    sleep 0.5
done
echo "reports=$before-$after"
find /Library/Logs/DiagnosticReports -name 'hfs.util*.ips' -type f -print 2>/dev/null |
    xargs ls -lt 2>/dev/null | head -5
