# Root `hfs.util` heap out-of-bounds read via unchecked HFS+ catalog B-tree record offset

## Summary

The macOS HFS probe utility trusts the final record-offset entry in an attacker-controlled HFS+ catalog B-tree node without checking that the offset lies inside the allocated node buffer. A local unprivileged user can attach a crafted raw disk image; Disk Arbitration then launches `hfs.util -p` as root and feeds it the image. With Guard Malloc enabled for the root probe process, the malformed record offset deterministically causes `EXC_BAD_ACCESS` at the unchecked record-field load.

The current demonstrated primitive is an attacker-directed root-process out-of-bounds read relative to a heap node. No out-of-bounds write or code execution is claimed.

## Tested build

- macOS 27.0 beta, build `26A5378n`
- Architecture: arm64e
- `hfs.util` UUID: `0FEDF7BE-9B60-3C7D-801B-45515BE20D8E`
- Universal binary SHA-256: `be443ec21208b6609ef73c042606a42301af0654269123b332e297e77f87d68a`
- Thin arm64e SHA-256: `885077dabbf976157074b2de90836106bb0efde802aeacb0c89dae8a5f2a34ac`

The current HFS bundle declares `FSProbeExecutable = hfs.util` and `FSProbeArguments = -p` for `Whole`, `Apple_HFS`, `Apple_HFSX`, and related media classes. A copy of the exact current `Info.plist` is included under `static/`.

## Root cause

`GetBTreeNodeInfo` reads a 512-byte B-tree header node and checks only that its node kind is `kBTHeaderNode`:

```text
0x10000292c  ldrb  w8, [x19, #0x8]
0x100002930  cmp   w8, #0x1
0x100002934  b.ne  reject
0x100002938  ldrh  w8, [x19, #0x20]   ; attacker BTHeaderRec.nodeSize
0x10000293c  rev   w8, w8
0x100002940  lsr   w8, w8, #16
0x100002944  str   w8, [x21]          ; returned without range validation
```

The probe allocates and fills exactly that many bytes for the first catalog leaf. It checks only that `numRecords` is nonzero, then treats the final 16-bit offset-table entry as an in-node record pointer:

```text
0x1000013a0  ldr   w27, [sp, #0x8b8]  ; attacker nodeSize
0x1000013a4  mov   x0, x27
0x1000013a8  bl    malloc
...
0x1000013e0  ldrh  w8, [x26, #0xa]    ; attacker numRecords
0x1000013e4  cbz   w8, reject
0x1000013e8  add   x8, x26, x27       ; nodeEnd
0x1000013ec  ldurh w8, [x8, #-0x2]    ; attacker final record offset
0x1000013f0  rev   w8, w8
0x1000013f4  lsr   w8, w8, #16
0x1000013f8  add   x19, x26, x8       ; record = nodeBase + offset
0x1000013fc  ldur  w8, [x19, #0x2]    ; OOB read of parentID, crash PC
```

There is no comparison between the record offset and `nodeSize`, no check that the fixed `parentID` field remains in the node, and no proof that the `2 * numRecords` offset table itself fits. Later key-length and Unicode-length consumers also need validation against the per-record span, not only a global format maximum.

## PoC geometry

The included image starts from a normal 32 MiB HFS+ volume and changes only catalog B-tree metadata:

- Catalog B-tree `nodeSize = 512`
- `leafRecords = 1`
- `firstLeafNode = 1`
- Leaf `kind = kBTLeafNode`
- Leaf `numRecords = 1`
- Final record offset entry = `0xffff`

The resulting sink computes `record = nodeBase + 65535` for a 512-byte allocation, then reads `record->parentID` at `record + 2`.

## Reproduction

Use a disposable macOS 27 VM. The end-to-end script temporarily enables Guard Malloc in the system launchd environment and restarts Disk Arbitration so its child `hfs.util` process inherits the allocator. Its cleanup trap removes both environment variables and restarts Disk Arbitration again.

```sh
cd poc
gunzip -k hfs_record_offset_oob.raw.gz
sudo -v
./vm_da_guarded_probe.sh "$PWD/hfs_record_offset_oob.raw"
```

The attacker action inside the test is the ordinary uid 501 `hdiutil attach` call. Expected output includes `attach failed - no mountable file systems` and one new root `hfs.util-*.ips` report.

For a simpler direct parser confirmation:

```sh
sudo -v
./repro_direct_guardmalloc.sh "$PWD/hfs_record_offset_oob.raw"
```

The stock allocator may leave the invalid address mapped, in which case an uninstrumented probe can read unrelated heap memory and reject the image without a visible crash. The Guard Malloc report is used to make the invalid read deterministic; the crash registers prove the exact attacker offset and allocation geometry.

## Dynamic evidence

Primary report: `evidence/root_da_hfs.util-2026-07-21-202559.ips`

- `userID = 0`
- `parentProc = diskarbitrationd`, parent PID `45523`
- `responsibleProc = diskarbitrationd`
- Exception: `EXC_BAD_ACCESS / KERN_INVALID_ADDRESS`
- Faulting image offset: `0x13fc` in `hfs.util`
- `x8 = 65535` (`0xffff`, the on-disk record offset)
- `x27 = 512` (`0x200`, the on-disk node size / allocation size)
- `x26 = 0x103ff3e00` (node base)
- `x19 = 0x104003dff = x26 + 0xffff` (computed record pointer)
- `far = 0x104003e01 = x19 + 2` (the `parentID` field read)
- ESR: data-abort translation fault on a read

The package also includes matching direct uid 501 and direct root Guard Malloc reports. All three fault at image offset `0x13fc` with the same `base + 0xffff + 2` geometry.

## Security impact

An unprivileged local user can make a root filesystem probe calculate and dereference a heap pointer using an unchecked 16-bit on-disk offset. The demonstrated effect is a root-process heap OOB read and deterministic crash under Guard Malloc. Depending on allocator layout, the same primitive can consume unrelated heap contents. I have not demonstrated a disclosure of useful secrets, an OOB write, or privilege escalation.

## Suggested fix

Before consuming any B-tree record:

1. Validate `nodeSize` against supported HFS B-tree node sizes and the bytes actually read.
2. Prove `sizeof(BTNodeDescriptor) + 2 * (numRecords + 1) <= nodeSize` without overflow.
3. Validate every record offset against the node's data region and the start of the offset table.
4. Derive each record's exact span from adjacent ordered offsets, then validate `keyLength`, fixed fields, and Unicode payload against that per-record span.
5. Apply the same checks to both catalog and extents B-tree consumers.

Merely bounding `nodeSize`, `numRecords`, or the Unicode length independently is insufficient; every operand feeding each pointer must be checked against the same per-node and per-record allocation bounds used by the sink.
