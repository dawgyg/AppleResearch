# Package contents

- `REPORT.md`: current-build root-cause analysis, reproduction, evidence, and bounded impact statement.
- `poc/hfs_record_offset_oob.raw.gz`: crafted 32 MiB raw HFS+ image (compresses to about 32 KiB).
- `poc/make_hfs_record_offset_oob.c`: deterministic patcher used to derive the PoC from a normal HFS+ image.
- `poc/repro_direct_guardmalloc.sh`: direct root parser crash confirmation.
- `poc/vm_da_guarded_probe.sh`: uid 501 attach -> Disk Arbitration -> root `hfs.util` end-to-end confirmation.
- `evidence/root_da_*.ips`: primary root crash with `diskarbitrationd` as parent.
- `evidence/root_direct_*.ips` and `uid501_direct_*.ips`: matching direct confirmations.
- `static/*.txt`: exact current arm64e disassembly excerpts.
- `static/hfs_Info.plist`: exact current filesystem registration showing `hfs.util -p` as the media probe.
- `SHA256SUMS.txt`: hashes for every packaged artifact.

Run only in a disposable VM. The end-to-end script restores the launchd variables and restarts Disk Arbitration through a cleanup trap.
