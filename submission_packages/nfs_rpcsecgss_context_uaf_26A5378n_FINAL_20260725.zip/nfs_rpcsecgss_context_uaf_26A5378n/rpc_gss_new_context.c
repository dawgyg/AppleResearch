#include <GSS/gssapi.h>
#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

enum {
    RPC_CALL = 0,
    RPC_VERSION = 2,
    NFS_PROGRAM = 100003,
    NFS_VERSION = 3,
    NFS_NULL = 0,
    RPCSEC_GSS = 6,
    RPCSEC_GSS_VERSION = 1,
    RPCSEC_GSS_INIT = 1,
    RPCSEC_GSS_SVC_NONE = 1,
};

static void
put_u32(uint8_t **cursor, uint32_t value)
{
    value = htonl(value);
    memcpy(*cursor, &value, sizeof(value));
    *cursor += sizeof(value);
}

static int
get_u32(const uint8_t **cursor, size_t *remaining, uint32_t *value)
{
    uint32_t encoded;

    if (*remaining < sizeof(encoded)) {
        return -1;
    }
    memcpy(&encoded, *cursor, sizeof(encoded));
    *cursor += sizeof(encoded);
    *remaining -= sizeof(encoded);
    *value = ntohl(encoded);
    return 0;
}

static int
skip_opaque(const uint8_t **cursor, size_t *remaining, uint32_t length)
{
    size_t padded = ((size_t)length + 3U) & ~3U;

    if (padded > *remaining) {
        return -1;
    }
    *cursor += padded;
    *remaining -= padded;
    return 0;
}

static void
print_status(const char *label, OM_uint32 major, OM_uint32 minor)
{
    OM_uint32 context = 0;
    OM_uint32 next_minor = 0;
    gss_buffer_desc text = GSS_C_EMPTY_BUFFER;

    fprintf(stderr, "%s: major=0x%08x minor=0x%08x\n",
        label, major, minor);
    do {
        if (gss_display_status(&next_minor, major, GSS_C_GSS_CODE,
            GSS_C_NO_OID, &context, &text) != GSS_S_COMPLETE) {
            break;
        }
        fprintf(stderr, "  GSS: %.*s\n", (int)text.length,
            (const char *)text.value);
        gss_release_buffer(&next_minor, &text);
    } while (context != 0);
    context = 0;
    do {
        if (gss_display_status(&next_minor, minor, GSS_C_MECH_CODE,
            GSS_C_NO_OID, &context, &text) != GSS_S_COMPLETE) {
            break;
        }
        fprintf(stderr, "  mech: %.*s\n", (int)text.length,
            (const char *)text.value);
        gss_release_buffer(&next_minor, &text);
    } while (context != 0);
}

static int
connect_server(const char *host)
{
    struct sockaddr_in address = {
        .sin_family = AF_INET,
        .sin_port = htons(2049),
    };
    struct timeval timeout = {
        .tv_sec = 5,
        .tv_usec = 0,
    };
    int one = 1;
    int fd;

    if (inet_pton(AF_INET, host, &address.sin_addr) != 1) {
        return -1;
    }
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        return -1;
    }
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    if (connect(fd, (const struct sockaddr *)&address, sizeof(address)) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static int
send_all(int fd, const uint8_t *buffer, size_t length)
{
    while (length > 0) {
        ssize_t sent = send(fd, buffer, length, 0);
        if (sent <= 0) {
            return -1;
        }
        buffer += (size_t)sent;
        length -= (size_t)sent;
    }
    return 0;
}

static int
read_all(int fd, uint8_t *buffer, size_t length)
{
    while (length > 0) {
        ssize_t got = recv(fd, buffer, length, 0);
        if (got <= 0) {
            return -1;
        }
        buffer += (size_t)got;
        length -= (size_t)got;
    }
    return 0;
}

static uint8_t *
build_init_request(const gss_buffer_desc *token, uint32_t xid,
    size_t *wire_length)
{
    size_t padded = (token->length + 3U) & ~3U;
    size_t body_length = 68U + padded;
    uint8_t *wire = calloc(1, 4U + body_length);
    uint8_t *cursor;
    uint32_t marker;

    if (wire == NULL || token->length > UINT32_MAX) {
        free(wire);
        return NULL;
    }
    marker = htonl(0x80000000U | (uint32_t)body_length);
    memcpy(wire, &marker, sizeof(marker));
    cursor = wire + 4;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, NFS_NULL);

    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 20);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_INIT);
    put_u32(&cursor, 0);
    put_u32(&cursor, RPCSEC_GSS_SVC_NONE);
    put_u32(&cursor, 0);

    put_u32(&cursor, 0);
    put_u32(&cursor, 0);

    put_u32(&cursor, (uint32_t)token->length);
    memcpy(cursor, token->value, token->length);
    *wire_length = 4U + body_length;
    return wire;
}

static int
read_record(int fd, uint8_t **body, size_t *body_length)
{
    uint32_t marker;
    size_t length;

    if (read_all(fd, (uint8_t *)&marker, sizeof(marker)) < 0) {
        return -1;
    }
    marker = ntohl(marker);
    length = marker & 0x7fffffffU;
    if ((marker & 0x80000000U) == 0 || length > (1U << 20)) {
        return -1;
    }
    *body = malloc(length);
    if (*body == NULL) {
        return -1;
    }
    if (read_all(fd, *body, length) < 0) {
        free(*body);
        *body = NULL;
        return -1;
    }
    *body_length = length;
    return 0;
}

int
main(int argc, char **argv)
{
    const char *host = argc > 1 ? argv[1] : "192.168.64.81";
    const char *service = argc > 2 ? argv[2] :
        "nfs@tests-virtual-machine.local";
    gss_buffer_desc name_buffer = {
        .length = strlen(service),
        .value = (void *)service,
    };
    gss_buffer_desc input_token = GSS_C_EMPTY_BUFFER;
    gss_buffer_desc output_token = GSS_C_EMPTY_BUFFER;
    gss_name_t target = GSS_C_NO_NAME;
    gss_ctx_id_t context = GSS_C_NO_CONTEXT;
    OM_uint32 major;
    OM_uint32 minor = 0;
    OM_uint32 returned_flags = 0;
    uint8_t *request = NULL;
    size_t request_length = 0;
    uint8_t *reply = NULL;
    size_t reply_length = 0;
    const uint8_t *cursor;
    size_t remaining;
    uint32_t xid = 0x4e465343U;
    uint32_t word;
    uint32_t verifier_length;
    uint32_t handle_length;
    uint32_t handle;
    uint32_t server_major;
    uint32_t server_minor;
    uint32_t seq_window;
    uint32_t server_token_length;
    int fd = -1;
    int result = 1;

    major = gss_import_name(&minor, &name_buffer,
        GSS_C_NT_HOSTBASED_SERVICE, &target);
    if (major != GSS_S_COMPLETE) {
        print_status("gss_import_name", major, minor);
        goto out;
    }
    major = gss_init_sec_context(&minor, GSS_C_NO_CREDENTIAL, &context,
        target, GSS_C_NO_OID,
        GSS_C_MUTUAL_FLAG | GSS_C_REPLAY_FLAG | GSS_C_SEQUENCE_FLAG,
        0, GSS_C_NO_CHANNEL_BINDINGS, &input_token, NULL, &output_token,
        &returned_flags, NULL);
    if (major != GSS_S_COMPLETE && major != GSS_S_CONTINUE_NEEDED) {
        print_status("gss_init_sec_context(initial)", major, minor);
        goto out;
    }

    request = build_init_request(&output_token, xid, &request_length);
    if (request == NULL) {
        goto out;
    }
    fd = connect_server(host);
    if (fd < 0 || send_all(fd, request, request_length) < 0 ||
        read_record(fd, &reply, &reply_length) < 0) {
        perror("RPCSEC_GSS INIT");
        goto out;
    }

    cursor = reply;
    remaining = reply_length;
    if (get_u32(&cursor, &remaining, &word) < 0 || word != xid ||
        get_u32(&cursor, &remaining, &word) < 0 || word != 1 ||
        get_u32(&cursor, &remaining, &word) < 0 || word != 0 ||
        get_u32(&cursor, &remaining, &word) < 0 ||
        get_u32(&cursor, &remaining, &verifier_length) < 0 ||
        skip_opaque(&cursor, &remaining, verifier_length) < 0 ||
        get_u32(&cursor, &remaining, &word) < 0 || word != 0 ||
        get_u32(&cursor, &remaining, &handle_length) < 0 ||
        handle_length != sizeof(handle) || remaining < sizeof(handle)) {
        fprintf(stderr, "malformed RPCSEC_GSS INIT reply (%zu bytes)\n",
            reply_length);
        goto out;
    }
    memcpy(&handle, cursor, sizeof(handle));
    cursor += sizeof(handle);
    remaining -= sizeof(handle);
    handle = ntohl(handle);
    if (get_u32(&cursor, &remaining, &server_major) < 0 ||
        get_u32(&cursor, &remaining, &server_minor) < 0 ||
        get_u32(&cursor, &remaining, &seq_window) < 0 ||
        get_u32(&cursor, &remaining, &server_token_length) < 0 ||
        server_token_length > remaining) {
        fprintf(stderr, "truncated RPCSEC_GSS INIT result\n");
        goto out;
    }

    printf("handle=%08x server_major=0x%08x server_minor=0x%08x "
        "seq_window=%u token_len=%u initial_major=0x%08x\n",
        handle, server_major, server_minor, seq_window,
        server_token_length, major);
    result = server_major == GSS_S_COMPLETE ? 0 : 2;

out:
    if (fd >= 0) {
        close(fd);
    }
    free(request);
    free(reply);
    if (output_token.length != 0) {
        gss_release_buffer(&minor, &output_token);
    }
    if (context != GSS_C_NO_CONTEXT) {
        gss_delete_sec_context(&minor, &context, GSS_C_NO_BUFFER);
    }
    if (target != GSS_C_NO_NAME) {
        gss_release_name(&minor, &target);
    }
    return result;
}
