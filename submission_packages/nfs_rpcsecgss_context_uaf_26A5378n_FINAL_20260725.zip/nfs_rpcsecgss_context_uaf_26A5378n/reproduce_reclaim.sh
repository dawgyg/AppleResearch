#!/bin/zsh

set -euo pipefail

NFS_HOST="${NFS_HOST:-192.168.64.81}"
NFS_SERVICE="${NFS_SERVICE:-nfs@tests-virtual-machine.local}"
SERVER_SSH="${SERVER_SSH:-test@192.168.64.81}"
SERVER_PASSWORD="${SERVER_PASSWORD:-}"
SERVER_SUDO_PASSWORD="${SERVER_SUDO_PASSWORD:-}"
HERE="${0:A:h}"
STAMP="$(date -u +%Y%m%dT%H%M%SZ)"
OUTDIR="${HERE}/reclaim_run_${STAMP}"
SSH_OPTS=(
  -o ConnectTimeout=12
  -o NumberOfPasswordPrompts=1
  -o ControlMaster=no
  -o StrictHostKeyChecking=no
  -o UserKnownHostsFile=/dev/null
  -o IdentitiesOnly=yes
  -o PasswordAuthentication=yes
  -o PubkeyAuthentication=no
  -o PreferredAuthentications=password
)

mkdir -p "${OUTDIR}"

server_ssh() {
  if [[ -n "${SERVER_PASSWORD}" ]]; then
    sshpass -p "${SERVER_PASSWORD}" ssh "${SSH_OPTS[@]}" \
      "${SERVER_SSH}" "$1"
  else
    ssh "${SSH_OPTS[@]}" "${SERVER_SSH}" "$1"
  fi
}

server_sudo() {
  if [[ -n "${SERVER_SUDO_PASSWORD}" ]]; then
    server_ssh "printf '%s\\n' '${SERVER_SUDO_PASSWORD}' | sudo -S $1"
  else
    server_ssh "sudo -n $1"
  fi
}

resume_gssd() {
  server_sudo "pkill -CONT -x gssd" >/dev/null 2>&1 || true
}
trap resume_gssd EXIT INT TERM

target_output="$("${HERE}/rpc_gss_new_context" \
  "${NFS_HOST}" "${NFS_SERVICE}")"
printf '%s\n' "${target_output}" >"${OUTDIR}/target_context.log"
target_handle="$(printf '%s\n' "${target_output}" |
  sed -n 's/^handle=\([0-9a-fA-F]*\).*/\1/p' | head -1)"
if [[ -z "${target_handle}" ]]; then
  print -u2 "failed to create target context"
  exit 1
fi

server_sudo "pkill -STOP -x gssd"
sleep 1

typeset -a stale_pids
for worker in {0..6}; do
  "${HERE}/rpc_gss_ctx_race" "${NFS_HOST}" "${target_handle}" \
    probe-valid --token-len 1 --timeout-sec 10 \
    >"${OUTDIR}/stale_${worker}.log" 2>&1 &
  stale_pids+=("$!")
done

sleep 1
"${HERE}/rpc_gss_ctx_race" "${NFS_HOST}" "${target_handle}" \
  probe-invalid --timeout-sec 3 \
  >"${OUTDIR}/delete.log" 2>&1

"${HERE}/rpc_gss_new_context" "${NFS_HOST}" "${NFS_SERVICE}" \
  >"${OUTDIR}/replacement_context.log" 2>&1 &
replacement_pid="$!"

sleep 1
resume_gssd
trap - EXIT INT TERM

wait "${replacement_pid}" || true
for pid in "${stale_pids[@]}"; do
  wait "${pid}" || true
done

printf 'target_handle=%s\n' "${target_handle}"
sed -n '1p' "${OUTDIR}/replacement_context.log"
for worker in {0..6}; do
  printf 'stale_%d: ' "${worker}"
  grep 'reply_words:' "${OUTDIR}/stale_${worker}.log" || true
done
printf 'logs=%s\n' "${OUTDIR}"
