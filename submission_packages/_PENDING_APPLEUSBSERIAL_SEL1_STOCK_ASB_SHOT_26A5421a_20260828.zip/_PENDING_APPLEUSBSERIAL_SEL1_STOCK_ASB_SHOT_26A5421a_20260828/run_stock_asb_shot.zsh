#!/bin/zsh
set -euo pipefail

fire_arg='--fire-live-same-boot-asb-I-accept-kernel-panic'
kit_dir=${0:A:h}
asb_reader=/Users/dawgyg/flagcap/asb_read

if [[ $# -ne 1 || $1 != $fire_arg ]]; then
  print -u2 "Usage: $0 $fire_arg"
  print -u2 'This can corrupt kernel memory or panic the machine.'
  exit 2
fi
if [[ $EUID -eq 0 ]]; then
  print -u2 'REFUSING: run as an ordinary non-root user.'
  exit 3
fi
if [[ ! -x $asb_reader ]]; then
  print -u2 "REFUSING: missing ASB reader: $asb_reader"
  exit 3
fi

out="$kit_dir/stock_asb_shot_$(date -u +%Y%m%dT%H%M%SZ)"
mkdir -m 700 "$out"

/usr/sbin/ioreg -r -c AppleUSBACMData -l > "$out/ioreg_AppleUSBACMData.txt"
if ! /usr/bin/grep -q AppleUSBACMData "$out/ioreg_AppleUSBACMData.txt"; then
  print -u2 'REFUSING: no AppleUSBACMData provider is attached.'
  exit 4
fi

/usr/bin/clang -Wall -Wextra -Werror -O2 \
  -framework IOKit -framework CoreFoundation \
  "$kit_dir/appleusbserial_sel1_asb_shot.c" \
  -o "$out/appleusbserial_sel1_asb_shot"

{
  print -r -- "$0 $fire_arg"
  /usr/bin/shasum -a 256 \
    "$kit_dir/appleusbserial_sel1_asb_shot.c" \
    "$kit_dir/prefire_capture.sh" \
    "$asb_reader" \
    "$out/appleusbserial_sel1_asb_shot"
} > "$out/command_and_initial_hashes.txt"

"$out/appleusbserial_sel1_asb_shot" "$fire_arg" "$out" \
  "$kit_dir/prefire_capture.sh" "$asb_reader" 2>&1 | \
  /usr/bin/tee "$out/run_console.log"

/usr/bin/shasum -a 256 "$out"/* > "$out/SHA256SUMS"
print "Shot returned without a panic. Evidence: $out"
