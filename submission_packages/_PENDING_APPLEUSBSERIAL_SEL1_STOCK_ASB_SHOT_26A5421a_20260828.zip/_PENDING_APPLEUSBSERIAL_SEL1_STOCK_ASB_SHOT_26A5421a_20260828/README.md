# AppleUSBSerial selector-1 stock ASB detector

Status: prepared and compile-verified only. It has not been fired.

This preserves the original `0x41`/DTrace package as mechanism proof and adds
a separate stock-only detector. The source reads both live ASB kernel qwords
through `/Users/dawgyg/flagcap/asb_read`; no target value is compiled in or
accepted on the command line. It captures `prefire.txt`, performs selector 0,
maps client-memory type 2, makes exactly three in-bounds `submit=0x100` calls,
captures `prefire_immediate.txt`, requires the boot UUID and both ASB qwords to
match, refills the full `0x10000` ring with alternating
`KERN_ADDRESS,KERN_VALUE` qwords, and only then submits `0x8000`.

The venue gate refuses root, disabled SIP, and any non-empty NVRAM or live
kernel boot arguments. Therefore the current SIP-disabled/GZAlloc host cannot
fire this probe.

After a clean stock boot on the dedicated research machine with the same USB
CDC ACM provider attached, the deliberately long acknowledgement is:

```sh
./run_stock_asb_shot.zsh \
  --fire-live-same-boot-asb-I-accept-kernel-panic
```

If the call returns, the probe retains the resources for 30 seconds so normal
consumption can run. A result is a kernel Target Flag only if a same-boot panic
has `FAR == KERN_ADDRESS`. Call it a kernel write flag only with `WnR=1`.

Important ceiling: the already demonstrated adjacent victim is a raw USB
output-data backing allocation. Alternating ASB qwords make this shot a useful
stock detector, but they do not themselves prove that the consumer interprets
the overwritten bytes as pointers. A silent return is a negative Target Flag
shot, not a disproof of the underlying controlled heap overwrite.
