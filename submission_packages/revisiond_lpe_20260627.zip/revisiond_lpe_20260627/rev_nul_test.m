// reuse the working chain from revisiond_sibling_lpe2.m but test exotic value strings
