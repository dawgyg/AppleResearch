# CFNetworkAgent accepts arbitrary-length caller audit data, causing a root OOB read and source-application identity spoof

## Summary

The root `CFNetworkAgent` launch daemon accepts an unprivileged PAC-query XPC message
containing an optional `audit` data object. The decoder preserves the caller's data and
length without requiring the 32 bytes needed for an `audit_token_t`. When attacker PAC
JavaScript calls `dnsResolve`, the native callback performs two unconditional 16-byte
loads from that object.

A one-byte `audit` value from uid 501 causes a deterministic GuardMalloc
`EXC_BAD_ACCESS` in root `CFNetworkAgent` at the second load. A full 32-byte value is
accepted as a caller-selected source-application audit token. I separately demonstrated
that a uid501 client can make the root daemon delegate DNS as PID 1.

## Tested version

- macOS 27.0 beta, build `26A5378n`
- Apple Virtualization VM (`VirtualMac2,1`)
- CFNetworkAgent version `3890.100.1`
- Process path: `/System/Library/Frameworks/CFNetwork.framework/Versions/A/Support/CFNetworkAgent`
- Process UID: 0
- Mach service: `com.apple.cfnetwork.cfnetworkagent`
- PoC client: uid 501

## Security impact

1. **Root-process memory safety:** any local user can make the daemon read 32 bytes from
   an allocation whose caller-selected logical length may be 1 byte. GuardMalloc proves
   the read crosses the allocation boundary at the exact native sink.
2. **Cross-process network identity spoofing:** a local user can supply an arbitrary
   32-byte audit token. The root daemon passes it to
   `nw_parameters_set_source_application`, and Network.framework uses the caller-selected
   PID for DNS attribution and delegation. This can misapply per-application NECP, DNS,
   VPN, filtering, and accounting policy.

The demonstrated result is not an LPE: the memory primitive is an OOB read and the
identity primitive is limited to this PAC DNS operation. It nevertheless crosses both a
uid501-to-root memory-safety boundary and a process-identity trust boundary.

## Root cause

The type-1 PAC-query decoder reads `audit` at `CFNetworkAgent+0x1930`:

```text
0x100001930  xpc_dictionary_get_data(message, "audit", &length)
0x10000193c  ldr x2, [sp,#length]
0x100001944  CFDataCreate(NULL, bytes, length)
0x100001950  str x8, [request,#0x38]
```

There is no comparison requiring `length >= 0x20`. The only trusted fallback is bypassed
when caller data is present:

```text
0x100001968  ldp x8,x23,[request,#0x38]  ; audit, bundle
0x10000196c  orr x8,x23,x8
0x100001970  cbnz x8,...                 ; skip authenticated fallback
0x100001988  xpc_connection_get_audit_token  ; only reached if both absent
0x1000019a4  CFDataCreate(...,0x20)
```

The PAC execution path places the audit/bundle pair in the private context attached to
the native `dnsResolve` object (`CFNetworkAgent+0x7a60`, `+0x7abc`, and `+0x7c54`). The
callback begins at `CFNetworkAgent+0x87d0` and retrieves it at `+0x8818`.

The vulnerable sink is:

```text
0x1000089a4  CFDataGetBytePtr(audit)
0x1000089a8  cbz x0,...                  ; pointer check only
0x1000089b0  ldr q0,[x0]                 ; bytes 0..15
0x1000089b8  ldr q1,[x0,#0x10]           ; bytes 16..31, crash PC
0x1000089cc  nw_parameters_set_source_application(parameters, stack_token)
```

No `CFDataGetLength` call or other span check protects either vector load.

## Reproduction

Build the included client on macOS:

```sh
clang -Wall -Wextra -Werror -fblocks \
  poc/cfnetworkagent_audit_trigger.c \
  -o poc/cfnetworkagent_audit_trigger
codesign -s - -f poc/cfnetworkagent_audit_trigger
```

### Baseline

Run as a standard user without an argument:

```sh
./poc/cfnetworkagent_audit_trigger
```

It sends a valid type-1 inline PAC query, invokes `dnsResolve("example.com")`, and receives
a type-2 PAC result.

### OOB-read confirmation

GuardMalloc is only instrumentation; the request itself remains uid501 and requires no
privilege. Configure the next daemon launch, terminate the existing instance, then invoke
the one-byte case as the standard user:

```sh
sudo launchctl debug system/com.apple.cfnetwork.cfnetworkagent \
  --guard-malloc --malloc-stack-logging --stderr /tmp/cfna_gm.err
sudo kill -9 "$(launchctl print system/com.apple.cfnetwork.cfnetworkagent | \
  awk '/pid =/{print $3; exit}')"
./poc/cfnetworkagent_audit_trigger 1
```

The client receives `Connection interrupted`, and a root CFNetworkAgent crash report is
created. In the attached report:

- exception: `EXC_BAD_ACCESS / KERN_INVALID_ADDRESS`
- process `userID`: 0
- faulting queue: `com.apple.cfnetwork.pac`
- crash frame: CFNetworkAgent image offset `0x89b8`
- `x0=0x16bbb3ff0`, fault address `0x16bbb4000`

Thus the first vector load reads the final 16 mapped bytes and the second reaches the
unmapped guard page exactly one allocation boundary later.

### PID 1 identity-spoof confirmation

After launchd has restarted a normal instance, run:

```sh
./poc/cfnetworkagent_audit_trigger pid:1
```

The request completes successfully. The attached unified log contains:

```text
created for ... using: generic, pid: 1, attribution: developer
Delegating DNS service to audit_token_t PID 1
```

The client was uid 501; PID 1 was not the client and did not initiate the request. A
separate `0x41414141` test shows direct value control: Network.framework attempted to use
PID 1094795585 and warned that this could cause incorrect policy and accounting.

## Suggested fix

- Do not accept an audit token from the message body. Derive it only from the peer XPC
  connection with `xpc_connection_get_audit_token`.
- If protocol compatibility requires the field, require an exact 32-byte length before
  any load and verify that it equals the authenticated connection token.
- Apply the same authenticated-token invariant to the caller-supplied `bundle` identity.

## Attachments

- `poc/cfnetworkagent_audit_trigger.c`
- `poc/cfnetworkagent_audit_trigger`
- `evidence/CFNetworkAgent-2026-07-22-073903-short-audit-gmalloc.ips`
- `evidence/guardmalloc_stderr.log`
- `evidence/identity_arbitrary_0x41_pid.log`
- `evidence/identity_pid1.log`
- `binary/CFNetworkAgent.arm64e`
