# Package contents

This package documents an unprivileged-to-root CFNetworkAgent OOB read and a confirmed
source-application audit-token spoof on macOS 27 beta build `26A5378n`.

Start with `REPORT.md`. The `poc/` directory contains source and a signed arm64 build;
`evidence/` contains the root crash report and identity-attribution logs; `binary/`
contains the analyzed current-build arm64e slice.
