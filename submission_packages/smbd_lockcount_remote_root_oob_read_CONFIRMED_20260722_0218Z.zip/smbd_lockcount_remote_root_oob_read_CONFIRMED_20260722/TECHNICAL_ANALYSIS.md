# Technical analysis

## Target

- OS: macOS 27 beta `26A5378n`.
- Binary: `/usr/sbin/smbd`.
- arm64e UUID: `39778c76-324c-3174-a550-e4ead047ebc9`.
- arm64e SHA-256:
  `b2a2e45f49a01e6832a3e0cadaa82b12aa9838af7f651fe8c47b706eead61e7b`.

## Request shape

The crashing SMB2 `LOCK` body is `0x4008` bytes:

- `StructureSize=0x30`;
- `LockCount=0xffff`;
- `LockSequence=0`;
- a valid 16-byte file ID;
- 682 supplied 24-byte lock elements (`0x3ff0` bytes total);
- each supplied element has `Offset=0`, `Length=0`, `Flags=0x4` (unlock),
  and `Reserved=0`.

There are no bytes for elements 682 through 65534.

## Extractor gap

`smb2::extract(lock_request)` at preferred `0x100048260`:

1. Computes `frame_end-current` at `0x100048264..0x100048268`.
2. Requires only 24 bytes at `0x10004826c..0x100048270`.
3. Validates `StructureSize==0x30` at `0x100048284..0x100048288`.
4. Reads and stores `LockCount` at `0x10004828c..0x100048298`.
5. Finishes after the fixed file ID and returns success at
   `0x1000482bc..0x1000482dc`.

There is no check for `24 + 24*LockCount` request bytes. In particular, the
`StructureSize` value describes the protocol structure but does not prove that
even the first 24-byte lock element is physically present.

## Unchecked handler walk

`smb2_dispatch_lock` at preferred `0x1000326dc`:

- loads `LockCount` at `0x100032828`;
- takes the extractor's post-prefix cursor as the first-element pointer in
  `x22` at `0x10003283c`;
- reads the first element flags at `0x100032840`;
- computes `element = x22 + 24*index` at
  `0x10003284c..0x100032850`;
- reads `element->Flags` at `0x100032854`;
- increments the index and decrements only the trusted count at
  `0x100032868..0x100032870`.

No instruction compares the element pointer or `24*LockCount` against the
frame end. The only loop bound is the attacker-provided count.

The later operation loop also copies 16 bytes from each indexed element at
`0x1000328a0..0x1000328ac` before passing the values to `ntvfs::lock_range`.
The native crash occurs in the earlier flags-only preflight loop.

## Rule Zero operand map

Sink: byte read `ldrb w11, [x11,#0x10]` at `0x100032854`.

- Base `x22`: post-prefix request cursor, formed by the extractor after its
  fixed 24-byte check.
- Index `x9`: starts at zero and increments at `0x100032868`.
- Element stride: exact `24*x9`, formed by `3*x9` then `8*` at
  `0x10003284c..0x100032850`.
- Field offset: fixed `+0x10` in the sink instruction.
- Loop upper bound: `LockCount`, loaded at `0x100032828` and decremented at
  `0x10003286c`.
- Missing bound: no comparison proves `x22 + 24*x9 + 0x10 < frame_end`, and no
  overflow-safe precheck proves `LockCount <= remaining/24`.

This is the exact gap: the fixed request prefix is bounded, while the sibling
variable-length element array consumed by the same handler is not.

## Dynamic fault geometry

The included report records root `smbd` PID 44416 and:

- `EXC_BAD_ACCESS / KERN_INVALID_ADDRESS` at `0x7023ab4008`;
- ESR `Data Abort byte read Translation fault`;
- crash frame `smb2_dispatch_lock + 376`, which is preferred
  `0x100032854`;
- `x9=682`, exactly the number of supplied elements;
- `x8=64853`, exactly `65535-682` elements still trusted by the loop;
- `x24=4`, the supplied first-element unlock flag;
- `x22=0x7023ab0008`, the first-element base;
- `far=x22 + 24*682 + 0x10`, exactly the flags byte of the first omitted
  element.

The VM map shows the preceding Guard Malloc allocation ending immediately
before the fault and an unmapped gap afterward. The stack is:

```text
smb2_dispatch_lock + 376
smb2_dispatch_compound + 1932
invocation function for block in smb_transport::dispatch() + 76
libdispatch worker frames
```

## Cross-architecture confirmation

The x86_64 slice has the same source-level gap:

- extractor requires only `0x18` bytes at `0x10004210f..0x100042116` and
  stores `LockCount` without checking the element array;
- handler computes `24*LockCount` at `0x10002e706..0x10002e70d`;
- loop reads each flags byte at `0x10002e716`;
- loop termination at `0x10002e729..0x10002e730` compares only against the
  attacker-derived total, not the frame end.

## Suggested fix

After extracting `LockCount`, reject zero and require an overflow-safe complete
array before returning success:

```text
remaining_after_fixed >= LockCount * sizeof(SMB2_LOCK_ELEMENT)
```

Prefer `LockCount <= remaining_after_fixed / 24` to avoid multiplication
overflow. Carry the validated array end into both handler loops, or use a
bounded iterator whose dereference checks that 24 bytes remain.
