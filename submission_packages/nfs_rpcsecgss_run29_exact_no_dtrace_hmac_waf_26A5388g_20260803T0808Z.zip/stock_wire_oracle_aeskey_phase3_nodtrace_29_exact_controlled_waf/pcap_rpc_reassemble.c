#include <arpa/inet.h>
#include <errno.h>
#include <inttypes.h>
#include <netinet/ip.h>
#include <netinet/tcp.h>
#include <pcap/pcap.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct segment {
    uint32_t seq;
    uint32_t rel;
    size_t len;
    uint8_t *data;
};

struct flow {
    uint32_t src_addr;
    uint32_t dst_addr;
    uint16_t src_port;
    uint16_t dst_port;
    bool syn_seen;
    uint32_t base_seq;
    struct segment *segments;
    size_t segment_count;
    size_t segment_capacity;
};

struct flows {
    struct flow *items;
    size_t count;
    size_t capacity;
};

static void
die(const char *what)
{
    fprintf(stderr, "%s: %s\n", what, strerror(errno));
    exit(1);
}

static void *
xrealloc(void *ptr, size_t size)
{
    void *result = realloc(ptr, size);
    if (result == NULL)
        die("realloc");
    return result;
}

static struct flow *
find_flow(struct flows *flows, uint32_t src_addr, uint32_t dst_addr,
    uint16_t src_port, uint16_t dst_port)
{
    for (size_t i = 0; i < flows->count; i++) {
        struct flow *flow = &flows->items[i];
        if (flow->src_addr == src_addr && flow->dst_addr == dst_addr &&
            flow->src_port == src_port && flow->dst_port == dst_port)
            return flow;
    }

    if (flows->count == flows->capacity) {
        size_t capacity = flows->capacity == 0 ? 8 : flows->capacity * 2;
        flows->items = xrealloc(flows->items,
            capacity * sizeof(*flows->items));
        memset(&flows->items[flows->capacity], 0,
            (capacity - flows->capacity) * sizeof(*flows->items));
        flows->capacity = capacity;
    }

    struct flow *flow = &flows->items[flows->count++];
    memset(flow, 0, sizeof(*flow));
    flow->src_addr = src_addr;
    flow->dst_addr = dst_addr;
    flow->src_port = src_port;
    flow->dst_port = dst_port;
    return flow;
}

static void
add_segment(struct flow *flow, uint32_t seq, const uint8_t *data, size_t len)
{
    if (flow->segment_count == flow->segment_capacity) {
        size_t capacity = flow->segment_capacity == 0 ? 64 :
            flow->segment_capacity * 2;
        flow->segments = xrealloc(flow->segments,
            capacity * sizeof(*flow->segments));
        flow->segment_capacity = capacity;
    }

    struct segment *segment = &flow->segments[flow->segment_count++];
    segment->seq = seq;
    segment->len = len;
    segment->data = malloc(len);
    if (segment->data == NULL)
        die("malloc");
    memcpy(segment->data, data, len);
}

static int
compare_segment(const void *left_ptr, const void *right_ptr)
{
    const struct segment *left = left_ptr;
    const struct segment *right = right_ptr;
    if (left->rel < right->rel)
        return -1;
    if (left->rel > right->rel)
        return 1;
    if (left->len > right->len)
        return -1;
    if (left->len < right->len)
        return 1;
    return 0;
}

static uint32_t
load_be32(const uint8_t *bytes)
{
    uint32_t value;
    memcpy(&value, bytes, sizeof(value));
    return ntohl(value);
}

static void
write_record(const char *prefix, size_t flow_index, uint16_t dst_port,
    size_t record_index, const uint8_t *record, size_t record_len)
{
    char path[1024];
    int count = snprintf(path, sizeof(path),
        "%s.flow%zu.port%u.record%zu.len%zu.bin", prefix, flow_index,
        dst_port, record_index, record_len);
    if (count < 0 || (size_t)count >= sizeof(path)) {
        errno = ENAMETOOLONG;
        die("record output path");
    }

    FILE *output = fopen(path, "wb");
    if (output == NULL)
        die(path);
    if (record_len != 0 && fwrite(record, 1, record_len, output) != record_len)
        die("fwrite");
    if (fclose(output) != 0)
        die("fclose");

    uint32_t xid = record_len >= 4 ? load_be32(record) : 0;
    printf("record flow=%zu dst_port=%u index=%zu len=%zu xid=%" PRIu32
        " path=%s\n", flow_index, dst_port, record_index, record_len, xid,
        path);
}

static void
extract_records(const char *prefix, size_t flow_index, struct flow *flow)
{
    if (flow->segment_count == 0)
        return;

    if (!flow->syn_seen) {
        flow->base_seq = flow->segments[0].seq;
        for (size_t i = 1; i < flow->segment_count; i++) {
            if ((int32_t)(flow->segments[i].seq - flow->base_seq) < 0)
                flow->base_seq = flow->segments[i].seq;
        }
    }

    size_t stream_len = 0;
    for (size_t i = 0; i < flow->segment_count; i++) {
        struct segment *segment = &flow->segments[i];
        segment->rel = segment->seq - flow->base_seq;
        size_t end = (size_t)segment->rel + segment->len;
        if (end > stream_len)
            stream_len = end;
    }
    qsort(flow->segments, flow->segment_count, sizeof(*flow->segments),
        compare_segment);

    uint8_t *stream = calloc(stream_len == 0 ? 1 : stream_len, 1);
    uint8_t *present = calloc(stream_len == 0 ? 1 : stream_len, 1);
    if (stream == NULL || present == NULL)
        die("calloc");

    size_t conflicts = 0;
    for (size_t i = 0; i < flow->segment_count; i++) {
        struct segment *segment = &flow->segments[i];
        for (size_t j = 0; j < segment->len; j++) {
            size_t offset = (size_t)segment->rel + j;
            if (present[offset] && stream[offset] != segment->data[j])
                conflicts++;
            stream[offset] = segment->data[j];
            present[offset] = 1;
        }
    }

    size_t contiguous = 0;
    while (contiguous < stream_len && present[contiguous])
        contiguous++;
    printf("flow=%zu src_port=%u dst_port=%u segments=%zu stream=%zu "
        "contiguous=%zu conflicts=%zu syn=%s\n", flow_index,
        flow->src_port, flow->dst_port, flow->segment_count, stream_len,
        contiguous, conflicts, flow->syn_seen ? "yes" : "no");

    size_t offset = 0;
    size_t record_index = 0;
    uint8_t *record = NULL;
    size_t record_len = 0;
    while (offset + 4 <= contiguous) {
        uint32_t marker = load_be32(&stream[offset]);
        bool last_fragment = (marker & 0x80000000U) != 0;
        size_t fragment_len = marker & 0x7fffffffU;
        offset += 4;
        if (fragment_len > 64U * 1024U * 1024U) {
            fprintf(stderr, "flow=%zu invalid fragment len=%zu offset=%zu\n",
                flow_index, fragment_len, offset - 4);
            break;
        }
        if (fragment_len > contiguous - offset) {
            printf("partial flow=%zu record=%zu fragment_len=%zu "
                "available=%zu\n", flow_index, record_index, fragment_len,
                contiguous - offset);
            break;
        }
        record = xrealloc(record, record_len + fragment_len);
        memcpy(&record[record_len], &stream[offset], fragment_len);
        record_len += fragment_len;
        offset += fragment_len;
        if (last_fragment) {
            write_record(prefix, flow_index, flow->dst_port, record_index,
                record, record_len);
            record_index++;
            free(record);
            record = NULL;
            record_len = 0;
        }
    }
    free(record);
    free(present);
    free(stream);
}

static const uint8_t *
ipv4_from_packet(int datalink, const uint8_t *packet, size_t caplen,
    size_t *available)
{
    size_t offset;
    switch (datalink) {
    case DLT_NULL:
        offset = 4;
        break;
    case DLT_EN10MB:
        if (caplen < 14)
            return NULL;
        offset = 14;
        if (packet[12] == 0x81 && packet[13] == 0x00)
            offset += 4;
        break;
#ifdef DLT_RAW
    case DLT_RAW:
        offset = 0;
        break;
#endif
    default:
        return NULL;
    }
    if (caplen < offset || (packet[offset] >> 4) != 4)
        return NULL;
    *available = caplen - offset;
    return packet + offset;
}

int
main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "usage: %s capture.pcap output-prefix\n", argv[0]);
        return 2;
    }

    char error[PCAP_ERRBUF_SIZE];
    pcap_t *capture = pcap_open_offline(argv[1], error);
    if (capture == NULL) {
        fprintf(stderr, "pcap_open_offline: %s\n", error);
        return 1;
    }
    int datalink = pcap_datalink(capture);
    if (datalink != DLT_NULL && datalink != DLT_EN10MB
#ifdef DLT_RAW
        && datalink != DLT_RAW
#endif
    ) {
        fprintf(stderr, "unsupported pcap datalink %d\n", datalink);
        pcap_close(capture);
        return 1;
    }

    struct flows flows = {0};
    struct pcap_pkthdr *header;
    const uint8_t *packet;
    int status;
    while ((status = pcap_next_ex(capture, &header, &packet)) >= 0) {
        if (status == 0)
            continue;
        size_t ip_available;
        const uint8_t *ip_bytes = ipv4_from_packet(datalink, packet,
            header->caplen, &ip_available);
        if (ip_bytes == NULL || ip_available < sizeof(struct ip))
            continue;
        const struct ip *ip = (const struct ip *)ip_bytes;
        size_t ip_header_len = (size_t)ip->ip_hl * 4;
        if (ip->ip_p != IPPROTO_TCP || ip_header_len < 20 ||
            ip_available < ip_header_len + sizeof(struct tcphdr))
            continue;
        const struct tcphdr *tcp =
            (const struct tcphdr *)(ip_bytes + ip_header_len);
        size_t tcp_header_len = (size_t)tcp->th_off * 4;
        size_t ip_total_len = ntohs(ip->ip_len);
        if (tcp_header_len < 20 || ip_total_len < ip_header_len + tcp_header_len)
            continue;
        size_t payload_len = ip_total_len - ip_header_len - tcp_header_len;
        if (ip_available < ip_header_len + tcp_header_len + payload_len)
            continue;
        uint16_t src_port = ntohs(tcp->th_sport);
        uint16_t dst_port = ntohs(tcp->th_dport);
        if (src_port != 2049)
            continue;

        struct flow *flow = find_flow(&flows, ip->ip_src.s_addr,
            ip->ip_dst.s_addr, src_port, dst_port);
        uint32_t seq = ntohl(tcp->th_seq);
        if ((tcp->th_flags & TH_SYN) != 0) {
            flow->syn_seen = true;
            flow->base_seq = seq + 1;
        }
        if (payload_len != 0) {
            add_segment(flow, seq,
                ip_bytes + ip_header_len + tcp_header_len, payload_len);
        }
    }
    if (status == PCAP_ERROR)
        fprintf(stderr, "pcap read: %s\n", pcap_geterr(capture));
    pcap_close(capture);

    for (size_t i = 0; i < flows.count; i++)
        extract_records(argv[2], i, &flows.items[i]);

    for (size_t i = 0; i < flows.count; i++) {
        for (size_t j = 0; j < flows.items[i].segment_count; j++)
            free(flows.items[i].segments[j].data);
        free(flows.items[i].segments);
    }
    free(flows.items);
    return status == PCAP_ERROR ? 1 : 0;
}
