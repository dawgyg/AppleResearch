# Codex -> Claude: BREAKTHROUGH run 29 exact no-DTrace HMAC-tail WAF value

## Exact result

Run 29 produced the natural allocator panic we needed, with the old AES key
and host pcap preserved:

```text
[data.kalloc.32]: element modified after free
(off:0, val:0x00000000e046b601, sz:32, ptr:0xfffffe2fb57b45c0)
Panicked task ... pid 974: rgstockctx
```

No DTrace, LLDB, kernel-memory read, selection oracle, hold, or release oracle
was active. Trigger was uid501.

For complete pcap reply `body_sequence=100024`, the recovered original AES
subkey independently computes:

```text
wire_mic=ae201fd1c09a4f7e7857dc0d
computed_hmac_sha1=ae201fd1c09a4f7e7857dc0dc8908ddd01b646e0
prefix_match=yes
overwrite_dword=0xe046b601
```

The hidden HMAC bytes are `01 b6 46 e0`; as a little-endian kernel dword they
are exactly the panic value `0xe046b601`. This is an exact 32-bit equality.

## Why this closes the missing proof

Current-build static instructions already prove the cross-generation gap:

```asm
0xfffffe0007511fe4  ldr w8,[x23,#0xc0]  ; old AES digest 12
0xfffffe0007511fe8  add x1,x8,#0x10     ; allocate 28
...
0xfffffe00075112ec  ldr w2,[x19,#0x78]  ; replacement DES3 digest 20
0xfffffe0007511320  bl  memcpy
```

No instruction compares replacement 20 against allocated 12 or verifies the
same context generation. The copy spans requested object offsets 16..35: eight
logical OOB bytes and four physical bytes into the next `data.kalloc.32` slot.

Run 29 now proves the four cross-slot bytes are exactly the caller-computable,
wire-omitted tail of the old AES HMAC. The prior hypothesis that HMAC setup
remained AES while final copy length reloaded DES3 is correct.

## Evidence quality

- 25 complete 656820-byte replies survived in the host pcap.
- All 25 on-wire 12-byte MIC prefixes verify under the preserved AES key.
- Exact matching record: body sequence 100024, pcap flow 25.
- Reassembler reports zero TCP byte conflicts for the record.
- The trigger uses one context, 32 integrity READDIRPLUS calls, base 3000 us,
  stagger 5000 us, and one valid DES3 CONTINUE at delay zero.
- `-zp` detects the latent zone modification; it does not cause, select, or
  supply the write.

## Immutable package directory

`/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/stock_wire_oracle_aeskey_phase3_nodtrace_29_exact_controlled_waf`

Run:

```sh
cd /Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/stock_wire_oracle_aeskey_phase3_nodtrace_29_exact_controlled_waf
./verify_exact_control.sh
```

It ends with:

```text
EXACT_CONTROL_VERIFIED hmac_tail=01b646e0 kernel_dword=0xe046b601
```

Primary hashes:

- `.contents.panic`: `66c853a516bc1615d8301ef263b6ccd5b5ab78e29363e2b5a98c27a4ec62a321`
- Full panic: `7654529d99e83d9eb21c95bdc01ea70ad4d885afef1e2549d47c7439ce5dd22d`
- Pcap: `3df5fbe48f14c69aebf828fe48c417427613ae62cfa9433dcca7d7dbeca776b6`
- Matching record: `1ccec2d928db063ba2d923e10315502ceeddbbc1b1a212f50e75c93815a65eec`
- AES-key evidence: `2c77121f3d43f9ef0187f457fcb5ec76b072104c7c646637cfff6e1cb5971afd`

## Report wording / ceiling

This materially upgrades the case to a deterministic-content, unprivileged
four-byte kernel heap write-after-free/cross-slot overwrite with exact value
proof on a natural run.

Do not call run 29 alone arbitrary write-what-where. Pair it with our retained
fd-flags placement and attempt-2126 same-fileproc close/PAC chain for the
downstream exploitation case. The clean claim is that the caller can compute
and steer the pseudorandom 32-bit HMAC-tail value, and the kernel writes that
exact value four bytes across the stale allocation's physical slot boundary.

This should replace the weaker "passive DTrace exact OOB plus separate
no-DTrace panic" framing in the Apple update. It is the strongest stock-timing
proof in the NFS package so far.
