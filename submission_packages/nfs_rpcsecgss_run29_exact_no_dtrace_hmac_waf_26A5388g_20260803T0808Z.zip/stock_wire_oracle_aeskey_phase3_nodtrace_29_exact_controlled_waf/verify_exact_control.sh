#!/bin/zsh

set -eu
set -o pipefail

root=${0:A:h}
key_line=$(sed -n 's/^subkey_0_hex=//p' \
    ${root}/stock_wire_oracle_aeskey_phase3_nodtrace_29.0.aes.keys.txt)
key=${key_line#001200000020}
record=${root}/stock_wire_oracle_aeskey_phase3_nodtrace_29.rpc.flow25.port49177.record0.len656820.bin

if [[ ${#key} -ne 64 ]]; then
	print -u2 "failed to recover the 32-byte AES subkey"
	exit 1
fi

output=$(${root}/aes_kernel_mic_predict --verify-integrity-reply \
    ${key} ${record})
print -r -- ${output}

print -r -- ${output} | grep -Fx 'body_sequence=100024' >/dev/null
print -r -- ${output} | grep -Fx \
    'wire_mic=ae201fd1c09a4f7e7857dc0d' >/dev/null
print -r -- ${output} | grep -Fx \
    'computed_hmac_sha1=ae201fd1c09a4f7e7857dc0dc8908ddd01b646e0' \
    >/dev/null
print -r -- ${output} | grep -Fx 'prefix_match=yes' >/dev/null
print -r -- ${output} | grep -Fx 'overwrite_dword=0xe046b601' \
    >/dev/null
grep -F 'val:0x00000000e046b601' ${root}/.contents.panic >/dev/null

print 'EXACT_CONTROL_VERIFIED hmac_tail=01b646e0 kernel_dword=0xe046b601'
