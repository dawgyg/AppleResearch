# LIVE: stock RPCSEC_GSS integrity MIC completes cross-generation heap OOB

Build: macOS 27 beta 4 `26A5388g`, kernel KDK UUID
`E324BD2E-ABD7-3384-BFCA-6CFD1435DC72`.

Verdict: uid501 authenticated RPCSEC_GSS traffic naturally completed the
exact AES digest-12 allocation to DES3 digest-20 copy after same-address
context teardown/replacement. The outer MIC operation returned success. This
is an 8-byte logical OOB from a 28-byte request and a 4-byte physical
cross-slot overwrite from its `data.kalloc.32` slot.

Non-obvious invariant failure: both digest sizes are individually legal, but
they belong to different object generations. Allocation uses the old load at
`0xfffffe0007511fe4`; `memcpy` length independently reloads the replacement
field at `0xfffffe00075112ec` and reaches the sink at
`0xfffffe0007511320`. No instruction compares the two values, carries
`mic->length-16` to the sink, retains/locks the context, or verifies the same
generation.

Exact passive trace tuple:

```text
cctx=fffffe1d4e3f2248 entry_digest=12 alloc_length=28
destroy_gen=0->1 while active_mbuf=1
same cctx make_gen=1->2 digest=20 while active_mbuf=1
krb5_mic_mbuf return=0 entry_digest=12 live_digest=20
gss_krb5_cfx_get_mic_mbuf return=0 entry_digest=12 live_digest=20
```

Instrumentation boundary: passive read/print DTrace only; no hold, signal,
selection oracle, rejection, LLDB, or kernel mutation. DTrace can perturb
scheduling. The separate no-DTrace stock active-HMAC panic proves unaided
reachability; attempt 63 proves exact HMAC-dword prediction/live ACL
corruption; attempt 2126 proves the downstream same-fileproc double-close/PAC
failure chain. Present those as separate corroborating results.

Primary trace SHA-256:
`9c671430c23abd862c5cef041488192d7e5e404f63d716013a1efe087ae4bcca`.

Full analysis and artifacts:
`/Users/dawgyg/codex_scratch/nfs_beta4_static_20260727/stock_rdp_integrity_24ctx_stride4_8data_656k_stream_1_exact_oob`.

Owner/next step: Codex refreshes and verifies the submission package; Claude
uses the bounded claim in portal/report drafting.
