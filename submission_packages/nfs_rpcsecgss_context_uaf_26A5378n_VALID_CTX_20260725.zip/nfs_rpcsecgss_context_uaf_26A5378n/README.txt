NFS RPCSEC_GSS server context UAF - macOS 27 beta 26A5378n

This package documents a remote authenticated kernel use-after-free in the
macOS NFS server's RPCSEC_GSS context handling.

Confirmed results:

- a context is freed while active requests still hold references;
- seven stale requests deterministically operate on a replacement context;
- structured gssd output is written after the 192-byte context is freed;
- the allocator detects the post-free writes and panics;
- mixed request lengths cross between concurrent requests and trigger a
  distinct kernel IPC invariant panic;
- concurrent auth-error cleanups trigger a stale LIST_REMOVE panic;
- valid concurrent setup requests double-destroy a live 232-byte kernel GSS
  crypto context; and
- a minimized two-request run consumes a corrupted stale ctx_id value and
  dereferences it in the kernel crypto destructor.

Preconditions:

- NFS server enabled with an export using sec=krb5;
- a remote client with a valid Kerberos principal and an established
  RPCSEC_GSS context;
- network access to the NFS service.

The PoC's stop/resume or bootout of gssd and enlarged NFS worker count are
race-widening instruments for deterministic laboratory reproduction. They are
not claimed attack prerequisites.

Build:

macOS 27.0 beta, 26A5378n
Darwin xnu-13432.0.50.501.3~1/RELEASE_ARM64_VMAPPLE
Fileset kernelcache UUID 516E4823-2312-7325-7A76-DF6959CB27E1

Build the clients:

clang -O2 -Wall -Wextra -pthread rpc_gss_ctx_race.c -o rpc_gss_ctx_race
clang -O2 -Wall -Wextra rpc_gss_new_context.c \
  -framework GSS -o rpc_gss_new_context

The client machine must already have valid Kerberos credentials for the NFS
service. No KDC database, keytab, password, or credential cache is included.

See:

- PORTAL_FIELDS.txt for the report text;
- EVIDENCE.txt for the root cause, exact current-build sites, and panic map;
- reproduce_reclaim.sh for the deterministic reclaim sequence;
- reproduce_valid_ctx_race.sh for the valid-token crypto-context race;
- SHA256SUMS.txt for artifact hashes.

Honest ceiling:

This package proves a remote authenticated kernel UAF with post-free writes,
a stale nested-pointer dereference, and five kernel panic signatures. It does
not claim arbitrary read/write,
control-flow hijack, local privilege escalation, remote code execution, or a
Target Flag.
