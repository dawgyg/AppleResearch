# APFS keybag matching-record span bypass discloses kernel heap through an unprivileged user-client method

## Summary

An ordinary local user can attach a crafted APFS disk image and call
`AppleAPFSUserClient` selector `0x0d` (`methodVolumeGetRecord`) to read kernel
heap data beyond a 16 KiB container-keybag allocation.

The APFS keybag parser validates `record + aligned_record_size <= bag_end` while
walking nonmatching records. If a record's UUID and type match the query,
however, the parser branches around that validation. The read operation later
copies the matching record's full attacker-declared aligned size into a stack
query. It checks that the destination query is large enough, but never checks
that the matching source record fits inside the keybag allocation.

The supplied image places a matching record at offset `0x3f60` of a 0x4000-byte
keybag object. Its complete valid 124-byte wrapped-key DER and a 12-byte marker
remain in-bounds, but its `ke_keylen` is `0x200`. Selector `0x0d` consequently
returns the 136 known bytes followed by 376 bytes from beyond the allocation.

On a stock SIP-enabled macOS 27 beta 4 VM, the returned tail contained
`com.apple.DADaemonSubCal`. Three independent allocations on a diagnostic VM
returned three different tails, including `com.apple.callverificationd` and
`com.apple.SystemProfiler.SPThunderboltReporter`. When the allocation ended at
a guard boundary, the same read produced two APFS kernel panics in `memmove`.

## Impact

- Unprivileged local user to kernel heap information disclosure.
- No `sudo`, root credential, private entitlement, or authorization prompt is
  used by the final attach-and-read reproducer.
- The attacker controls the read length and placement of the matching record.
- The disclosed tail is runtime kernel data, not bytes from the disk image.
- Guarded layouts produce a kernel data-abort panic at the exact allocation
  boundary.

The disclosure can expose kernel runtime state and can assist exploitation of
a separate kernel memory-corruption vulnerability. This report does not claim
that the observed tail contains a kernel pointer or that this issue alone
achieves privilege escalation.

## Tested configurations

### Stock confirmation

```text
ProductName: macOS
ProductVersion: 27.0
BuildVersion: 26A5388g
Darwin Kernel Version 27.0.0: Tue Jul 14 21:39:48 PDT 2026;
root:xnu-13432.0.94.501.4~1/RELEASE_ARM64_VMAPPLE
System Integrity Protection status: enabled.
boot-args: empty
uid=501(testtest) gid=20(staff)
```

The stock run used only the prebuilt image and `apfs_get_record`. The client is
not signed with a private entitlement.

### Guard-boundary confirmation

The same build was also tested in a disposable VM with `-zp`. Three allocations
returned kernel data and two allocations reached a guard boundary and panicked.
The APFS kext in both reports is:

```text
com.apple.filesystems.apfs 3283.0.13
UUID 1074E10D-0746-39D5-B212-9508F7FEBC82
```

## Reproduction

Run only on a disposable test system because the malformed case can panic the
kernel.

1. Extract the attachment.
2. Ensure no other copy of the supplied APFS images is attached.
3. Run as a logged-in non-root local user:

```sh
cd poc
chmod +x run_apfs_keybag_getrecord.sh apfs_get_record
./run_apfs_keybag_getrecord.sh malicious
```

No `sudo` is required. The wrapper verifies the image and client hashes,
attaches the raw image without mounting a volume, calls selector `0x0d`, prints
the returned bytes, and ejects the image if the kernel remains alive.

The in-bounds one-field control is:

```sh
./run_apfs_keybag_getrecord.sh control
```

The control image differs semantically only in the target `ke_keylen`:

```text
malicious ke_keylen = 0x200
control   ke_keylen = 0x088
```

The APFS object checksum necessarily differs as a consequence.

## Observed result

### Stock SIP-enabled malformed run

```text
index=0 kr=0 length=0x200 reply_size=0x208
```

The first 136 bytes are the valid wrapped-key DER and the in-bounds marker. The
bytes beginning at output offset `0x88` are outside the keybag allocation:

```text
00000070: 68 ce 50 be 3c d3 03 3e 95 84 23 46 43 4f 44 58
00000080: 42 4f 55 4e 44 41 52 59 fa de 0c c0 00 00 14 3c
00000090: 00 00 00 03 00 00 00 00 00 00 00 24 00 00 00 02
...
00000100: 00 00 00 00 63 6f 6d 2e 61 70 70 6c 65 2e 44 41
00000110: 44 61 65 6d 6f 6e 53 75 62 43 61 6c 00 54 c0 7b
```

`com.apple.DADaemonSubCal` appears entirely after the `CODXBOUNDARY` marker.

Stock output SHA-256:

`3759ed27ea5bf8b86603518b6a40c662244ece281c61faa67935271283765695`

### Stock SIP-enabled control

```text
index=0 kr=0 length=0x88 reply_size=0x208
```

The output ends exactly at the marker:

```text
00000070: 68 ce 50 be 3c d3 03 3e 95 84 23 46 43 4f 44 58
00000080: 42 4f 55 4e 44 41 52 59
```

Control output SHA-256:

`08d6ad24becf0d0230cd039b21685e390c615eaf04b8668e9a8fa6585a29e9d9`

### Repeatability

Three successful malformed runs had an identical 136-byte prefix and three
distinct 376-byte tails:

```text
run1 leak SHA256 5ccf4344675d21e7cdf1ab185ebe1d813296c765f2f3b032e9877da90965b38b
     string      com.apple.callverificationd
run2 leak SHA256 dc8f0fe8bb676d1eb6934db1e83a8c944b3fcd43210d4803348d5c6258be47ac
     string      com.apple.SystemProfiler.SPThunderboltReporter
run3 leak SHA256 a194b6dac603b716b177381d157b2e7bc479eb92fdbb349a526817a5aa62d536
```

The changing post-boundary tails prove that the returned bytes are live
allocation-adjacent state rather than data supplied by the image.

## Root cause

### User-client method

`AppleAPFSUserClient::uc_methods @ 0xfffffe0007f4ce30` entry `0x0d` resolves to
`methodVolumeGetRecord @ 0xfffffe0009af1a8c`.

```text
selector          0x0d
scalar input      0
structure input   0x18
scalar output     0
structure output  variable; handler requires at least 0x208
```

The input consists of a 32-bit volume index at `+0`, UUID at `+4`, and 16-bit
record type at `+0x14`. The only index check is `volume_index < 100` at
`0xfffffe0009af1ad0..0xfffffe0009af1ad8`. Type 2 reaches
`_container_keybag_lookup_record` at `0xfffffe0009af1b48..0xfffffe0009af1b74`.
There is no entitlement or credential check in this method.

### Missing source-span check

The vulnerable parser is `_keybag_operation @ 0xfffffe0009ac439c`.

It computes `bag_end` from the declared keybag length:

```text
0xfffffe0009ac44f0  ldr  w8,[bag,#4]
0xfffffe0009ac4500  add  x26,x20,x8
```

For a nonmatching record, it computes the aligned span and checks the next
record pointer against `bag_end`:

```text
0xfffffe0009ac4544  add  x9,x25,x8
0xfffffe0009ac4548  cmp  x9,x26
0xfffffe0009ac4550  b.lo 0xfffffe0009ac4508
```

The matching UUID/type branches skip that check:

```text
0xfffffe0009ac4518  cbz  w23,0xfffffe0009ac4558
0xfffffe0009ac4524  b.eq 0xfffffe0009ac4558
```

The read branch then checks only source-span versus destination capacity:

```text
0xfffffe0009ac45d8  cmp  x2,x8       ; source span <= query capacity
0xfffffe0009ac45dc  b.hi error
0xfffffe0009ac45e0  mov  x0,x27      ; destination stack query
0xfffffe0009ac45e4  mov  x1,x25      ; matching keybag record
0xfffffe0009ac45e8  bl   memmove
```

There is no instruction requiring `x25 + x2 <= x26` on the matching path. The
existing check at `0x...4548` bounds the same span only on a sibling path.

### Crafted geometry

```text
keybag object size          0x4000
bag base                    0x0020
declared bag end            0x4000
matching record header      0x3f60
matching payload start      0x3f78
valid DER                   0x007c bytes
boundary marker             0x000c bytes
known in-object payload     0x0088 bytes
declared payload length     0x0200 bytes
aligned record span         0x0220 bytes
payload beyond allocation   0x0178 bytes
```

`_container_keybag_lookup_record @ 0xfffffe0009ac7530` supplies a 0x228-byte
stack query with 0x200 bytes of payload capacity, so the destination-capacity
check passes and the source over-read occurs.

## Panic evidence

The two supplied reports show the same APFS path. In the first report:

```text
ESR = 0x96000007             read translation fault
x25 = 0xfffffe2fb059ff60     matching record start
x26 = 0xfffffe2fb05a0000     keybag allocation end
x1  = 0xfffffe2fb059fff0     advanced memmove source
x2  = 0x170                  bytes still to copy
far = 0xfffffe2fb05a0000     exactly allocation end
panicked task: apfs_get_record
```

The APFS frames rebase to:

```text
0xfffffe0009ac45ec  _keybag_operation, after memmove
0xfffffe0009ac3e48  generic container-keybag operation
0xfffffe0009ac75b0  _container_keybag_lookup_record
0xfffffe0009af1b78  AppleAPFSUserClient::methodVolumeGetRecord
```

The second report classifies the guard hit as `out-of-bounds (high confidence)`
and again names `apfs_get_record` as the panicked task.

## Expected result

Before accepting a matching record, APFS should require the complete aligned
record span to be inside the declared keybag and its backing allocation. The
user-client must never return bytes beyond the validated record.

## Suggested fix

Apply the same `current + aligned_span <= bag_end` validation before taking the
matching-record branch. Perform the addition with checked arithmetic, validate
against both the declared keybag end and the backing allocation size, and keep
the destination-capacity check as a separate invariant.
