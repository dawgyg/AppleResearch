#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <mach/mach_error.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <uuid/uuid.h>

struct get_record_request {
    uint32_t volume_index;
    uuid_t record_uuid;
    uint16_t record_type;
    uint16_t reserved;
};

struct get_record_reply {
    uint64_t payload_length;
    uint8_t payload[0x200];
};

_Static_assert(sizeof(struct get_record_request) == 0x18,
               "selector 0x0d request must be 24 bytes");
_Static_assert(sizeof(struct get_record_reply) == 0x208,
               "selector 0x0d reply must be 520 bytes");

static unsigned long parse_index(const char *value) {
    char *end = NULL;
    unsigned long result = strtoul(value, &end, 0);
    if (!value[0] || !end || *end || result >= 100) {
        fprintf(stderr, "invalid volume index: %s\n", value);
        exit(2);
    }
    return result;
}

static unsigned long parse_type(const char *value) {
    char *end = NULL;
    unsigned long result = strtoul(value, &end, 0);
    if (!value[0] || !end || *end || result > UINT16_MAX) {
        fprintf(stderr, "invalid record type: %s\n", value);
        exit(2);
    }
    return result;
}

static int save_payload(const char *path, const struct get_record_reply *reply) {
    size_t length = reply->payload_length;
    if (length > sizeof(reply->payload)) {
        length = sizeof(reply->payload);
    }
    FILE *file = fopen(path, "wb");
    if (!file) {
        perror(path);
        return -1;
    }
    if (fwrite(reply->payload, 1, length, file) != length || fclose(file) != 0) {
        perror(path);
        return -1;
    }
    return 0;
}

static void print_prefix(const struct get_record_reply *reply) {
    size_t length = reply->payload_length;
    if (length > sizeof(reply->payload)) {
        length = sizeof(reply->payload);
    }
    size_t shown = length < 32 ? length : 32;
    for (size_t i = 0; i < shown; i++) {
        printf("%02x", reply->payload[i]);
    }
    if (length > shown) {
        printf("...");
    }
}

int main(int argc, char **argv) {
    if (argc < 5 || argc > 6) {
        fprintf(stderr,
                "usage: %s container-UUID record-UUID type index|scan [output]\n",
                argv[0]);
        return 2;
    }

    uuid_t container_uuid;
    struct get_record_request request = {0};
    if (uuid_parse(argv[1], container_uuid) != 0 ||
        uuid_parse(argv[2], request.record_uuid) != 0) {
        fprintf(stderr, "invalid UUID\n");
        return 2;
    }
    request.record_type = (uint16_t)parse_type(argv[3]);
    int scan = strcmp(argv[4], "scan") == 0;
    unsigned long first = scan ? 0 : parse_index(argv[4]);
    unsigned long last = scan ? 99 : first;

    io_iterator_t iterator = IO_OBJECT_NULL;
    kern_return_t kr = IOServiceGetMatchingServices(
        kIOMainPortDefault, IOServiceMatching("AppleAPFSContainer"), &iterator);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "IOServiceGetMatchingServices: %#x (%s)\n", kr,
                mach_error_string(kr));
        return 1;
    }

    char expected_uuid[37];
    uuid_unparse_upper(container_uuid, expected_uuid);
    int matched = 0;
    int success = 0;
    io_service_t service;
    while ((service = IOIteratorNext(iterator)) != IO_OBJECT_NULL) {
        char service_uuid[64] = {0};
        CFTypeRef property = IORegistryEntryCreateCFProperty(
            service, CFSTR("UUID"), kCFAllocatorDefault, 0);
        int matches = property && CFGetTypeID(property) == CFStringGetTypeID() &&
            CFStringGetCString((CFStringRef)property, service_uuid,
                               sizeof(service_uuid), kCFStringEncodingUTF8) &&
            strcmp(expected_uuid, service_uuid) == 0;
        if (property) {
            CFRelease(property);
        }
        if (!matches) {
            IOObjectRelease(service);
            continue;
        }

        matched = 1;
        io_connect_t connection = IO_OBJECT_NULL;
        kr = IOServiceOpen(service, mach_task_self(), 0, &connection);
        IOObjectRelease(service);
        if (kr != KERN_SUCCESS) {
            fprintf(stderr, "IOServiceOpen: %#x (%s)\n", kr,
                    mach_error_string(kr));
            break;
        }

        for (unsigned long index = first; index <= last; index++) {
            struct get_record_reply reply = {0};
            size_t reply_size = sizeof(reply);
            request.volume_index = (uint32_t)index;
            kr = IOConnectCallStructMethod(connection, 0x0d, &request,
                                           sizeof(request), &reply, &reply_size);
            if (kr != KERN_SUCCESS) {
                if (!scan) {
                    printf("index=%lu kr=%#x (%s) reply_size=%#zx\n", index, kr,
                           mach_error_string(kr), reply_size);
                }
                continue;
            }
            printf("index=%lu kr=0 length=%#llx reply_size=%#zx prefix=",
                   index, (unsigned long long)reply.payload_length, reply_size);
            print_prefix(&reply);
            putchar('\n');
            success = 1;
            if (argc == 6 && save_payload(argv[5], &reply) != 0) {
                success = 0;
            }
        }
        IOServiceClose(connection);
        break;
    }
    IOObjectRelease(iterator);

    if (!matched) {
        fprintf(stderr, "container UUID %s not found\n", expected_uuid);
    } else if (!success && scan) {
        fprintf(stderr, "no volume index returned the requested record\n");
    }
    return success ? 0 : 1;
}
