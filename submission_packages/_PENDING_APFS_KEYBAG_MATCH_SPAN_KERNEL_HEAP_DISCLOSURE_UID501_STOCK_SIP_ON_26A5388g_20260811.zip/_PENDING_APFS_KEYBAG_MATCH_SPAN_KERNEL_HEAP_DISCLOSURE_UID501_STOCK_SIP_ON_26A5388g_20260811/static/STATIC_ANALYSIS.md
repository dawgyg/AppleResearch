# Static analysis: APFS matching-record source span is unchecked

## Selector map

`AppleAPFSUserClient::externalMethod @ 0xfffffe0009adf008` accepts selectors
through `0x50` and selects a 0x18-byte dispatch entry from
`AppleAPFSUserClient::uc_methods @ 0xfffffe0007f4ce30`.

Entry `0x0d`:

```text
function            AppleAPFSUserClient::methodVolumeGetRecord
function address    0xfffffe0009af1a8c
scalarInputCount    0
structureInputSize  0x18
scalarOutputCount   0
structureOutputSize 0xffffffff (variable)
```

The handler requires a 0x208-byte output at `0x...1ab0..1ab8`, checks only that
the 32-bit volume index is less than 100 at `0x...1ad0..1ad8`, and reads the
16-bit type at input offset `0x14`. Type 2 calls
`_container_keybag_lookup_record` at `0x...1b48..1b74`.

No entitlement, audit-token, credential, or superuser check precedes that
call. A uid501 client succeeded on a stock SIP-enabled system.

## Parser walk

`_keybag_operation @ 0xfffffe0009ac439c` calculates the declared bag end:

```text
0xfffffe0009ac44f0  ldr  w8,[x20,#4]  ; kb_locker.kl_nbytes
0xfffffe0009ac4500  add  x26,x20,x8   ; bag_end
```

The keybag record header is 0x18 bytes. Its 16-bit payload length is at
`record+0x12`; its aligned span is `align16(payload_length + 0x18)`.

For nonmatches, every span operand reaches the bound:

```text
0xfffffe0009ac4528  ldrh w8,[x25,#0x12]
0xfffffe0009ac452c  add  x9,x8,#0x18
0xfffffe0009ac4530  ands x10,x9,#0xf
0xfffffe0009ac4534  sub  x8,x8,x10
0xfffffe0009ac4538  tst  x9,#0xf
0xfffffe0009ac453c  add  x8,x8,#0x28
0xfffffe0009ac4540  csel x8,x9,x8,eq
0xfffffe0009ac4544  add  x9,x25,x8
0xfffffe0009ac4548  cmp  x9,x26
0xfffffe0009ac454c  mov  x25,x9
0xfffffe0009ac4550  b.lo 0xfffffe0009ac4508
```

For a matching UUID and type, the branches skip the entire span calculation
and `cmp`:

```text
0xfffffe0009ac4518  cbz  w23,0xfffffe0009ac4558
0xfffffe0009ac451c  ldrh w8,[x25,#0x10]
0xfffffe0009ac4520  cmp  w23,w8
0xfffffe0009ac4524  b.eq 0xfffffe0009ac4558
```

## Read sink and every operand

On a lookup, `x27` is the stack query and `x25` is the matched keybag record.

Destination/query span:

```text
0xfffffe0009ac45a0  ldrh w8,[x27,#0x12]
0xfffffe0009ac45a4..45b0  align16(query_length + 0x18) -> x8
```

Source/matched-record span:

```text
0xfffffe0009ac45b4  ldrh w10,[x25,#0x12]
0xfffffe0009ac45b8..45d4  align16(source_length + 0x18) -> x2
```

The only check before the copy is source span versus destination capacity:

```text
0xfffffe0009ac45d8  cmp  x2,x8
0xfffffe0009ac45dc  b.hi 0xfffffe0009ac47c4
0xfffffe0009ac45e0  mov  x0,x27
0xfffffe0009ac45e4  mov  x1,x25
0xfffffe0009ac45e8  bl   memmove
```

Operand accounting:

```text
destination pointer x27   points to a 0x228 stack query
destination capacity x8   derived from query ke_keylen=0x200
source pointer x25        points below declared bag_end
copy length x2            derived from matched source ke_keylen=0x200
declared bag end x26      bag + kl_nbytes
```

The `cmp x2,x8` establishes only `copy_length <= destination_capacity`.
There is no check establishing `source + copy_length <= bag_end`, and there is
no checked-addition equivalent. The only source-end comparison is the skipped
nonmatch-path `cmp x9,x26 @ 0x...4548`.

## Copyout

`_container_keybag_lookup_record @ 0xfffffe0009ac7530` initializes a 0x228-byte
query with 0x200-byte payload capacity. After `_keybag_operation` copies the
record, it returns the copied payload and length. `methodVolumeGetRecord`
stores the result length in the 0x208-byte user output at
`0xfffffe0009af1bb8..0xfffffe0009af1bbc`.

## Panic rebase

The first panic loads APFS at `0xfffffe0030150750`; the static image base is
`0xfffffe0009a98750`. Subtracting the kext slide gives:

```text
panic frame             static address         symbol
0xfffffe003017c5ec      0xfffffe0009ac45ec     _keybag_operation after memmove
0xfffffe003017be48      0xfffffe0009ac3e48     container-keybag operation
0xfffffe003017f5b0      0xfffffe0009ac75b0     _container_keybag_lookup_record
0xfffffe00301a9b78      0xfffffe0009af1b78     methodVolumeGetRecord
```

The fault address equals `x26`, the keybag allocation end. The advanced source
is 16 bytes below it and 0x170 bytes remain to copy.
