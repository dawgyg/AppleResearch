#!/usr/bin/env python3
"""Regression tests for the post-capture AppleAVE2 package finalizer."""

import tempfile
import unittest
from pathlib import Path
import shutil
import zipfile

import finalize_stock_capture as finalizer


PROOF = {
    "build": "26A5421a",
    "boot_session_uuid": "3A4330A7-A208-432A-AB5C-D35174C848F0",
    "asb_target_kern_address": "0xc7df4666456a598b",
    "far": "0xc7df4666456a598b",
    "esr": "0x0000000096000044",
    "destination_x8": "0xc7df4666456a598b",
    "stored_command_node_x1": "0xfffffe0012345000",
    "access": "WRITE",
    "runtime_pc": "0xfffffe0008de5c58",
    "kernelcache_slide": "0x0000000000100000",
    "static_pc": "0xfffffe0008ce5c58",
    "panicked_task": "ave2_direct_replay",
    "verdict": "WRITE_AT_SAME_BOOT_ASB_FROM_GATED_AVE2_PUSHBACK",
}

VERIFIER_OUTPUT = "VERIFY=PASS\n" + "\n".join(
    f"{key}={value}" for key, value in PROOF.items()
) + "\n"


class FinalizerTests(unittest.TestCase):
    def make_synthetic_capture(self, root):
        source = finalizer.SOURCE_KIT
        kit = root / "kit"
        evidence = kit / "evidence" / "stock-fire-live-asb-write-test"
        evidence.mkdir(parents=True)
        for filename in sorted(set(finalizer.PREFIRE_ARTIFACTS.values())):
            shutil.copy2(source / filename, kit / filename)
            shutil.copy2(source / filename, evidence / filename)
        for filename in finalizer.SOURCE_ONLY_HASHES:
            shutil.copy2(source / filename, kit / filename)

        request = evidence / "selector5-live-asb-input-list-tail.bin"
        request.write_bytes(b"synthetic request for finalizer integration test")
        request_sha = finalizer.sha256(request)
        artifact_fields = "\n".join(
            f"{key}={finalizer.sha256(evidence / filename)}"
            for key, filename in finalizer.PREFIRE_ARTIFACTS.items()
        )
        common = f"""PREFIRE_SCHEMA=2
BUILD=26A5421a
BOOTSESSION={PROOF['boot_session_uuid']}
KERN_ADDRESS={PROOF['asb_target_kern_address']}
BOOTARGS_RAW=
KERN_BOOTARGS=
NVRAM_BOOTARGS_NORMALIZED=
SIP_STATUS=System Integrity Protection status: enabled.
AUTH_ROOT_STATUS=Authenticated Root status: enabled
HW_MODEL=MacBookPro18,2
ARCH=arm64
CALLER_RUID=501
CALLER_EUID=501
HV_VMM_PRESENT=0
AMFI_KEXT_LOADED=YES
TRIGGER_CODESIGN_VERIFY=PASS
VENUE_GATE=PASS
"""
        (evidence / "prefire.txt").write_text("PREFIRE_KIND=initial\n" + common)
        (evidence / "prefire_immediate.txt").write_text(
            "PREFIRE_KIND=immediate\n"
            + common
            + f"GENERATED_REQUEST_SHA256={request_sha}\n"
            + artifact_fields
            + "\n"
        )
        (evidence / "run.log").write_text(
            f"ASB_TRIGGER_IMMEDIATE={PROOF['asb_target_kern_address']}\n"
        )
        (evidence / "synthesis.txt").write_text("synthetic synthesis record\n")
        panic = evidence / "panic-full.panic"
        panic.write_text(
            f"""OS version: 26A5421a
Boot session UUID: {PROOF['boot_session_uuid']}
KernelCache slide: 0x100000
secure boot?: YES
roots installed: 0
Panicked task 0xfffffe0011110000: pid 123: ave2_direct_replay
pc: {PROOF['runtime_pc']} esr: {PROOF['esr']} far: {PROOF['far']}
x1: {PROOF['stored_command_node_x1']} x8: {PROOF['destination_x8']}
com.apple.driver.AppleAVE2 EC06EADA-5FFB-3D64-A203-814754F1D5AA
"""
        )
        safe_control = root / "safe-control"
        shutil.copytree(finalizer.SAFE_CONTROL, safe_control)
        return kit, safe_control, evidence, panic

    def test_exactly_one_rejects_conflicting_duplicate(self):
        with self.assertRaisesRegex(finalizer.FinalizationError, "found 2"):
            finalizer.exactly_one("KEY=a\nKEY=b\n", r"^KEY=(\S+)$", "KEY", flags=8)

    def test_parse_verifier_output_requires_all_fields(self):
        parsed = finalizer.parse_verifier_output(VERIFIER_OUTPUT)
        self.assertEqual(parsed, PROOF)
        with self.assertRaisesRegex(finalizer.FinalizationError, "static_pc"):
            finalizer.parse_verifier_output(
                VERIFIER_OUTPUT.replace(f"static_pc={PROOF['static_pc']}\n", "")
            )

    def test_render_final_report_removes_every_pending_marker(self):
        pending = finalizer.PENDING_REPORT.read_text()
        rendered = finalizer.render_final_report(
            pending,
            PROOF,
            "stock-fire-live-asb-write-test",
            "panic-full.panic",
            "b" * 64,
            "a" * 64,
            VERIFIER_OUTPUT,
        )
        self.assertNotIn("[PENDING]", rendered)
        self.assertNotIn("DO NOT SUBMIT", rendered)
        self.assertIn("Final physical stock capture verified", rendered)
        self.assertIn(PROOF["asb_target_kern_address"], rendered)
        self.assertIn("Panic SHA-256: " + "b" * 64, rendered)
        self.assertIn("not being filed separately", rendered)
        self.assertEqual(rendered.count("## Final stock Target Flag evidence"), 1)

    def test_copy_source_kit_excludes_runtime_evidence_and_pycache(self):
        with tempfile.TemporaryDirectory() as directory:
            destination = Path(directory) / "kit"
            finalizer.copy_source_kit(destination)
            self.assertTrue((destination / "ave2_direct_replay").is_file())
            self.assertTrue((destination / "run_once_stock_write_capture.zsh").is_file())
            self.assertFalse((destination / "evidence").exists())
            self.assertFalse((destination / "__pycache__").exists())

    def test_hash_manifest_is_sorted_and_does_not_hash_itself(self):
        with tempfile.TemporaryDirectory() as directory:
            package = Path(directory)
            (package / "b").write_text("b")
            (package / "a").write_text("a")
            manifest = finalizer.write_hash_manifest(package)
            lines = manifest.read_text().splitlines()
            self.assertEqual([line.split("  ", 1)[1] for line in lines], ["a", "b"])
            self.assertNotIn("SHA256SUMS", manifest.read_text())

    def test_full_synthetic_package_flow(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            kit, safe_control, evidence, panic = self.make_synthetic_capture(root)
            original_kit = finalizer.SOURCE_KIT
            original_safe = finalizer.SAFE_CONTROL
            try:
                finalizer.SOURCE_KIT = kit
                finalizer.SAFE_CONTROL = safe_control
                package, archive, archive_sha = finalizer.build_package(
                    evidence,
                    panic,
                    root / "output",
                    "20260827T000000Z",
                )
            finally:
                finalizer.SOURCE_KIT = original_kit
                finalizer.SAFE_CONTROL = original_safe

            self.assertTrue(package.is_dir())
            self.assertTrue(archive.is_file())
            self.assertEqual(finalizer.sha256(archive), archive_sha)
            report = (package / "APPLE_REPORT.md").read_text()
            self.assertNotIn("[PENDING]", report)
            self.assertIn("Final physical stock capture verified", report)
            self.assertFalse((package / "stock_write_capture_26A5421a/evidence").exists())
            self.assertFalse((package / "stock_write_capture_26A5421a/__pycache__").exists())
            for line in (package / "SHA256SUMS").read_text().splitlines():
                expected, relative = line.split("  ", 1)
                self.assertEqual(finalizer.sha256(package / relative), expected)
            with zipfile.ZipFile(archive) as handle:
                self.assertIn(
                    f"{package.name}/APPLE_REPORT.md",
                    handle.namelist(),
                )

    def test_unexpected_firing_evidence_file_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            kit, _, evidence, panic = self.make_synthetic_capture(root)
            (evidence / "research-panic.panic").write_text("must not ship\n")
            original_kit = finalizer.SOURCE_KIT
            try:
                finalizer.SOURCE_KIT = kit
                with self.assertRaisesRegex(finalizer.FinalizationError, "unexpected files"):
                    finalizer.validate_capture(evidence, panic)
            finally:
                finalizer.SOURCE_KIT = original_kit


if __name__ == "__main__":
    unittest.main()
