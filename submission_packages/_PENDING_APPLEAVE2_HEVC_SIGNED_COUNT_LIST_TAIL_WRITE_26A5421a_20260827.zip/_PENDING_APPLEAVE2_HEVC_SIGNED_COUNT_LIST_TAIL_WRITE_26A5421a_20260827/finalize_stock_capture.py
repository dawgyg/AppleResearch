#!/usr/bin/env python3
"""Build the final AppleAVE2 submission package from a verified stock capture."""

from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import zipfile


ROOT = Path(__file__).resolve().parent
PENDING_REPORT = ROOT / "APPLE_REPORT_DRAFT.md"
SOURCE_KIT = Path(
    "/Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5421a/"
    "stock_write_capture_26A5421a"
)
SAFE_CONTROL = Path(
    "/Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5421a/evidence/"
    "stock-source-exact-safe-control-20260827T144316Z"
)
DEFAULT_OUTPUT_ROOT = Path("/Users/dawgyg/submission_packages")
FINAL_PREFIX = "APPLEAVE2_HEVC_SIGNED_COUNT_LIST_TAIL_WRITE_26A5421a_"
EXPECTED_PENDING_REPORT_SHA256 = (
    "d87696a30bf9ca2deb3454d4212e857b69e9d534334fbab7bb1df54581d50d10"
)

SOURCE_ONLY_HASHES = {
    "README.md": "1603017d08e2697b5904eb97d58475bfed856294417a8f6bbf253aa7f4e76bb0",
    "run_once_stock_write_capture.zsh": (
        "f530f373d4d4860ebce85ee14cbb1e73ce8533d8c7396085e3bd58c1887cf070"
    ),
}

SAFE_CONTROL_HASHES = {
    "analysis.md": "05e33ebed4bf8441024af473e252a4f61ae698c814df2bb26c36d96c964ee3dd",
    "dtrace.err": "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855",
    "dtrace.out": "2f1c05e2352c165127b71ff2fc72cce1f356311629469498ec0a2fec0f98fe5a",
    "replay.log": "1abd458a9fd3bead9cde813fb4f9221b0ed18336ae74b470b9d18b3897f44f97",
}

PREFIRE_ARTIFACTS = {
    "GATED_BINARY_SHA256": "ave2_direct_replay",
    "GATED_SOURCE_SHA256": "ave2_direct_replay_write.c",
    "ASB_READER_SHA256": "asb_read",
    "ASB_READER_SOURCE_SHA256": "asb_read.c",
    "SELECTOR1_INPUT_SHA256": "selector1-input.bin",
    "SELECTOR3_INPUT_SHA256": "selector3-input.bin",
    "SELECTOR4_INPUT_SHA256": "selector4-stock-prior.bin",
    "TEMPLATE_SHA256": "selector5-field2d0-redirect60.bin",
    "MODEL_SHA256": "model_hevc_timing_pointer.py",
    "SYNTHESIZER_SHA256": "synthesize_live_asb_write_request.py",
    "MODEL_TEST_SHA256": "test_model_hevc_timing_pointer.py",
    "PANIC_VERIFIER_SHA256": "verify_stock_write_panic.py",
    "PREFIRE_CAPTURE_SHA256": "prefire_capture.sh",
    "FLAGCHECK_SHA256": "flagcheck.py",
    "VERIFIER_TEST_SHA256": "test_verify_stock_write_panic.py",
}

VERIFIER_FIELDS = (
    "build",
    "boot_session_uuid",
    "asb_target_kern_address",
    "far",
    "esr",
    "destination_x8",
    "stored_command_node_x1",
    "access",
    "runtime_pc",
    "kernelcache_slide",
    "static_pc",
    "panicked_task",
    "verdict",
)


class FinalizationError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise FinalizationError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def exactly_one(text: str, pattern: str, label: str, flags: int = 0) -> str:
    matches = re.findall(pattern, text, flags)
    require(len(matches) == 1, f"expected exactly one {label}, found {len(matches)}")
    return matches[0]


def replace_section(text: str, start: str, end: str, replacement: str) -> str:
    start_index = text.find(start)
    require(start_index >= 0, f"missing report marker {start!r}")
    end_index = text.find(end, start_index + len(start))
    require(end_index >= 0, f"missing report marker {end!r}")
    require(text.find(start, start_index + len(start)) < 0, f"duplicate marker {start!r}")
    return text[:start_index] + replacement.rstrip() + "\n\n" + text[end_index:]


def parse_verifier_output(output: str) -> dict[str, str]:
    require(output.startswith("VERIFY=PASS\n"), "specialized verifier did not print VERIFY=PASS")
    values: dict[str, str] = {}
    for field in VERIFIER_FIELDS:
        values[field] = exactly_one(
            output,
            rf"^{re.escape(field)}=(\S+)$",
            f"verifier field {field}",
            re.M,
        )
    require(values["access"] == "WRITE", "verifier output is not write-side")
    require(
        values["verdict"] == "WRITE_AT_SAME_BOOT_ASB_FROM_GATED_AVE2_PUSHBACK",
        "unexpected specialized-verifier verdict",
    )
    return values


def render_final_report(
    pending: str,
    proof: dict[str, str],
    evidence_name: str,
    panic_name: str,
    panic_sha: str,
    request_sha: str,
    verifier_output: str,
) -> str:
    status = """## Submission status

Final physical stock capture verified. The specialized verifier accepted the
same-boot write panic and the complete prefire venue record. The attached
evidence shows `WnR=1` and `FAR == x8 ==` the immediate same-boot
`_COMM_PAGE_ASB_TARGET_KERN_ADDRESS`."""
    rendered = replace_section(pending, "## Submission status", "## Summary", status)

    capture = f"""## Final stock Target Flag evidence

The one-shot ran as uid 501 on the stock physical `26A5421a` venue. The
specialized verifier accepted the write at `_AVE_DLList_PushBack`:

```text
Boot session UUID: {proof['boot_session_uuid']}
Immediate ASB kernel-address target: {proof['asb_target_kern_address']}
Panic FAR: {proof['far']}
Panic x8: {proof['destination_x8']}
Stored command-node x1: {proof['stored_command_node_x1']}
Panic ESR: {proof['esr']}
Runtime PC: {proof['runtime_pc']}
Kernelcache slide: {proof['kernelcache_slide']}
Static PC: {proof['static_pc']}
Panicked task: {proof['panicked_task']}
Access: {proof['access']}
Generated request SHA-256: {request_sha}
Panic SHA-256: {panic_sha}
Evidence directory: {evidence_name}
Panic file: {panic_name}
```

Verifier output:

```text
{verifier_output.rstrip()}
```
"""
    rendered = replace_section(
        rendered,
        "## Final stock Target Flag evidence",
        "## Reproduction",
        capture,
    )
    require("[PENDING]" not in rendered, "rendered report still contains pending fields")
    require("DO NOT SUBMIT" not in rendered, "rendered report still contains hold text")
    return rendered


def reject_symlinks(root: Path) -> None:
    for path in (root, *root.rglob("*")):
        require(not path.is_symlink(), f"refusing symlink in evidence: {path}")


def validate_exact_files(root: Path, expected: dict[str, str], label: str) -> None:
    require(root.is_dir(), f"missing {label} directory: {root}")
    reject_symlinks(root)
    actual_names = {path.name for path in root.iterdir()}
    require(actual_names == set(expected), f"unexpected files in {label}: {sorted(actual_names)}")
    for filename, expected_sha in expected.items():
        path = root / filename
        require(path.is_file(), f"missing {label} artifact: {filename}")
        require(sha256(path) == expected_sha, f"{label} hash mismatch: {filename}")


def copy_source_kit(destination: Path) -> None:
    destination.mkdir(parents=True)
    for source in sorted(SOURCE_KIT.iterdir()):
        if source.name in {"__pycache__", "evidence"} or source.name.endswith(".dSYM"):
            continue
        require(source.is_file() and not source.is_symlink(), f"unexpected kit entry: {source}")
        shutil.copy2(source, destination / source.name)


def write_hash_manifest(package: Path) -> Path:
    manifest = package / "SHA256SUMS"
    lines = []
    for path in sorted(package.rglob("*")):
        if path.is_file() and path != manifest:
            lines.append(f"{sha256(path)}  {path.relative_to(package).as_posix()}")
    manifest.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return manifest


def run_specialized_verifier(panic: Path, prefire: Path) -> str:
    verifier = SOURCE_KIT / "verify_stock_write_panic.py"
    result = subprocess.run(
        [
            sys.executable,
            str(verifier),
            str(panic),
            "--prefire-immediate",
            str(prefire),
        ],
        capture_output=True,
        text=True,
        check=False,
    )
    require(
        result.returncode == 0,
        "specialized verifier rejected capture:\n" + result.stdout + result.stderr,
    )
    return result.stdout


def validate_capture(evidence: Path, panic: Path) -> tuple[dict[str, str], str, str]:
    require(evidence.is_dir(), f"missing evidence directory: {evidence}")
    require(
        evidence.parent.resolve() == (SOURCE_KIT / "evidence").resolve(),
        "evidence directory is not under the authoritative stock kit",
    )
    require(
        evidence.name.startswith("stock-fire-live-asb-write-"),
        "evidence directory is not a firing-run directory",
    )
    require(panic.is_file(), f"missing panic: {panic}")
    require(panic.parent.resolve() == evidence.resolve(), "panic must be inside evidence directory")
    reject_symlinks(evidence)

    prefire_path = evidence / "prefire.txt"
    immediate_path = evidence / "prefire_immediate.txt"
    run_log_path = evidence / "run.log"
    request_path = evidence / "selector5-live-asb-input-list-tail.bin"
    for required in (prefire_path, immediate_path, run_log_path, request_path):
        require(required.is_file(), f"missing capture artifact: {required.name}")

    allowed_names = set(PREFIRE_ARTIFACTS.values()) | {
        "prefire.txt",
        "prefire_immediate.txt",
        "run.log",
        "selector5-live-asb-input-list-tail.bin",
        "synthesis.txt",
        panic.name,
    }
    actual_names = {path.name for path in evidence.iterdir()}
    require(
        actual_names == allowed_names,
        "unexpected files in firing evidence directory: " + repr(sorted(actual_names)),
    )

    prefire = prefire_path.read_text(encoding="utf-8", errors="replace")
    immediate = immediate_path.read_text(encoding="utf-8", errors="replace")
    run_log = run_log_path.read_text(encoding="utf-8", errors="replace")
    initial_boot = exactly_one(
        prefire, r"^BOOTSESSION=([0-9A-Fa-f-]{36})$", "initial boot UUID", re.M
    )
    immediate_boot = exactly_one(
        immediate, r"^BOOTSESSION=([0-9A-Fa-f-]{36})$", "immediate boot UUID", re.M
    )
    initial_asb = exactly_one(
        prefire, r"^KERN_ADDRESS=(0x[0-9a-fA-F]{1,16})$", "initial ASB", re.M
    )
    immediate_asb = exactly_one(
        immediate, r"^KERN_ADDRESS=(0x[0-9a-fA-F]{1,16})$", "immediate ASB", re.M
    )
    request_sha = exactly_one(
        immediate,
        r"^GENERATED_REQUEST_SHA256=([0-9a-f]{64})$",
        "generated request SHA",
        re.M,
    )
    require(initial_boot.lower() == immediate_boot.lower(), "prefire boot UUIDs differ")
    require(initial_asb.lower() == immediate_asb.lower(), "prefire ASB reads differ")
    require(sha256(request_path) == request_sha, "generated request file hash mismatch")
    marker = f"ASB_TRIGGER_IMMEDIATE={immediate_asb}".lower()
    require(marker in run_log.lower(), "run log lacks the flushed same-boot trigger marker")

    for key, filename in PREFIRE_ARTIFACTS.items():
        expected = exactly_one(
            immediate, rf"^{key}=([0-9a-f]{{64}})$", key, re.M
        )
        captured = evidence / filename
        authoritative = SOURCE_KIT / filename
        require(captured.is_file(), f"missing copied artifact: {filename}")
        require(authoritative.is_file(), f"missing authoritative artifact: {filename}")
        require(sha256(captured) == expected, f"captured {filename} hash mismatch")
        require(sha256(authoritative) == expected, f"authoritative {filename} hash mismatch")

    verifier_output = run_specialized_verifier(panic, immediate_path)
    proof = parse_verifier_output(verifier_output)
    require(proof["boot_session_uuid"].lower() == immediate_boot.lower(), "verifier boot mismatch")
    require(proof["asb_target_kern_address"].lower() == immediate_asb.lower(), "verifier ASB mismatch")
    return proof, verifier_output, request_sha


def build_package(
    evidence: Path,
    panic: Path,
    output_root: Path,
    timestamp: str,
) -> tuple[Path, Path, str]:
    proof, verifier_output, request_sha = validate_capture(evidence, panic)
    require(
        sha256(PENDING_REPORT) == EXPECTED_PENDING_REPORT_SHA256,
        "pending report hash mismatch",
    )
    for filename, expected_sha in SOURCE_ONLY_HASHES.items():
        require(
            sha256(SOURCE_KIT / filename) == expected_sha,
            f"source-kit hash mismatch: {filename}",
        )
    validate_exact_files(SAFE_CONTROL, SAFE_CONTROL_HASHES, "safe control")
    pending = PENDING_REPORT.read_text(encoding="utf-8")
    panic_sha = sha256(panic)
    report = render_final_report(
        pending,
        proof,
        evidence.name,
        panic.name,
        panic_sha,
        request_sha,
        verifier_output,
    )

    require(re.fullmatch(r"\d{8}T\d{6}Z", timestamp) is not None, "invalid timestamp")
    output_root.mkdir(parents=True, exist_ok=True)
    final = output_root / f"{FINAL_PREFIX}{timestamp}"
    archive = output_root / f"{FINAL_PREFIX}{timestamp}.zip"
    require(not final.exists(), f"final package already exists: {final}")
    require(not archive.exists(), f"final archive already exists: {archive}")
    with tempfile.TemporaryDirectory(prefix=f".{FINAL_PREFIX}", dir=output_root) as tmp:
        staging = Path(tmp) / final.name
        staging.mkdir()
        (staging / "APPLE_REPORT.md").write_text(report, encoding="utf-8")
        copy_source_kit(staging / "stock_write_capture_26A5421a")
        evidence_root = staging / "evidence"
        shutil.copytree(evidence, evidence_root / "final-stock-capture", copy_function=shutil.copy2)
        shutil.copytree(
            SAFE_CONTROL,
            evidence_root / "safe-selector7-control",
            copy_function=shutil.copy2,
        )
        record = f"""# Finalization record

Source evidence: `{evidence}`

Panic: `{panic}`

Boot session UUID: `{proof['boot_session_uuid']}`

Same-boot ASB kernel address: `{proof['asb_target_kern_address']}`

Panic SHA-256: `{panic_sha}`

Generated request SHA-256: `{request_sha}`

Specialized verdict: `{proof['verdict']}`
"""
        (staging / "FINALIZATION_RECORD.md").write_text(record, encoding="utf-8")
        write_hash_manifest(staging)
        staging.rename(final)

    with zipfile.ZipFile(archive, "w", compression=zipfile.ZIP_DEFLATED) as handle:
        for path in sorted(final.rglob("*")):
            if path.is_file():
                handle.write(path, arcname=(Path(final.name) / path.relative_to(final)).as_posix())
    return final, archive, sha256(archive)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("evidence_dir", type=Path)
    parser.add_argument("panic", type=Path)
    parser.add_argument("--output-root", type=Path, default=DEFAULT_OUTPUT_ROOT)
    parser.add_argument(
        "--timestamp",
        default=datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ"),
    )
    parser.add_argument(
        "--check-only",
        action="store_true",
        help="verify the capture and renderability without writing a package",
    )
    args = parser.parse_args()

    try:
        evidence = args.evidence_dir.resolve()
        panic = args.panic.resolve()
        if args.check_only:
            proof, verifier_output, request_sha = validate_capture(evidence, panic)
            render_final_report(
                PENDING_REPORT.read_text(encoding="utf-8"),
                proof,
                evidence.name,
                panic.name,
                sha256(panic),
                request_sha,
                verifier_output,
            )
            print("FINALIZE_CHECK=PASS")
            print(f"boot_session_uuid={proof['boot_session_uuid']}")
            print(f"asb_target_kern_address={proof['asb_target_kern_address']}")
            print(f"panic_sha256={sha256(panic)}")
            return 0
        final, archive, archive_sha = build_package(
            evidence, panic, args.output_root.resolve(), args.timestamp
        )
    except (FinalizationError, OSError) as error:
        print(f"FINALIZE=FAIL: {error}", file=sys.stderr)
        return 2

    print("FINALIZE=PASS")
    print(f"package={final}")
    print(f"archive={archive}")
    print(f"archive_sha256={archive_sha}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
