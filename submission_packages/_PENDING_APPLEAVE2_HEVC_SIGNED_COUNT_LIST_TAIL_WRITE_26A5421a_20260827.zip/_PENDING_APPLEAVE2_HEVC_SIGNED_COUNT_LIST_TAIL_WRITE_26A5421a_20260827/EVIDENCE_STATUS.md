# AppleAVE2 evidence status

## Submission gate

Status: **HOLD**

Do not file until the final physical stock capture satisfies all of:

- uid 501
- SIP enabled
- authenticated root enabled
- empty runtime and NVRAM boot arguments
- physical Apple Silicon, not `VirtualMac`
- `AppleAVE2Driver` present
- build `26A5421a`
- `ESR.WnR == 1`
- static PC `0xfffffe0008ce5c58`
- `x8 == FAR ==` the immediate same-boot ASB kernel-address target
- no GZAlloc report
- `verify_stock_write_panic.py` prints `VERIFY=PASS`

## Authoritative source kit

```text
/Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5421a/stock_write_capture_26A5421a/
```

Do not copy the source kit into this pending package until the stock evidence
exists; this avoids creating a stale second copy before the final capture.

## Complete evidence

1. Current-build static signed-count root and both missing lower bounds.
2. Full-qword list-tail composition modeled and C/Python byte-identical. The
   complete post-timing path ends at `client+0x291`, 63 bytes before the
   pipeline pointer, and its only later write touches a list field not read
   before the target `PushBack` store.
3. Exact-source safe selector sequence reaches command 8 and
   `_AVE_DLList_PushBack(client+0x280, node)`.
4. Research-boot chosen-index/chosen-byte writes dynamically observed.
5. Research-boot canonical pointer corruption and dereference dynamically
   observed.
6. The 20:59 research stack-loop panic is classified as a downstream
   manifestation of the same signed-index corruption; independent selector
   control of the DLB record count has not been demonstrated.
7. Vulnerable invariant and direct-write consumer persist from `25G72` through
   `26A5421a`.
8. Hash-pinned stock runner and strict panic verifier are ready.
9. Sixteen verifier regressions cover the positive case plus dirty boot args,
   uid/euid, hypervisor state, duplicate evidence fields, GZAlloc, write-side
   ESR, exact PC, same-boot ASB/FAR/x8, task identity, and safe runner ordering.

## Missing evidence

1. One stock physical firing run.
2. Panic and immediate prefire artifact from the same boot.
3. `VERIFY=PASS` output.
4. Final replacement of the pending block in `APPLE_REPORT_DRAFT.md`.
5. Final immutable attachment archive and archive SHA-256.

## Safe next command

After the physical host has been restored to stock:

```sh
cd /Users/dawgyg/lpe_hunt/appleave2_signed_bitcount_26A5421a/stock_write_capture_26A5421a
./run_once_stock_write_capture.zsh --preflight-only
```

This mode exits before opening `AppleAVE2Driver`. Run the no-argument firing
mode exactly once only after this command prints `PREFLIGHT-ONLY PASSED`.

## Post-reboot finalization

Place the resulting `panic-full-*.panic` inside the generated
`stock-fire-live-asb-write-*` evidence directory. First verify without writing
a package:

```sh
cd /Users/dawgyg/submission_packages/_PENDING_APPLEAVE2_HEVC_SIGNED_COUNT_LIST_TAIL_WRITE_26A5421a_20260827
python3 finalize_stock_capture.py /absolute/path/to/stock-fire-live-asb-write-TIMESTAMP \
  /absolute/path/to/stock-fire-live-asb-write-TIMESTAMP/panic-full.panic \
  --check-only
```

Only after this prints `FINALIZE_CHECK=PASS`, run the same command without
`--check-only`. The finalizer reruns the specialized verifier, verifies both
same-boot prefire records, the generated request, every copied artifact, the
flushed trigger marker, the report draft, and the safe-control evidence. It
rejects unexpected files, removes every pending report marker, generates a
clean `SHA256SUMS`, and writes the final ZIP under `submission_packages/`.
