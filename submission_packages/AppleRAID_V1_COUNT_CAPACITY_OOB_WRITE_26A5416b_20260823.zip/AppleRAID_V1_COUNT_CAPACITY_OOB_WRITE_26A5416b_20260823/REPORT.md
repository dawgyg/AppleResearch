# AppleRAID V1 sequence refresh causes a uid501 kernel heap OOB pointer write

## Summary

On macOS 27.0 beta build `26A5416b`, AppleRAID trusts a newer V1 member's
on-disk `AppleRAID-MemberCount` and replaces the set's logical member count
without resizing its existing `AppleRAIDMember **` array. A subsequent member
whose on-disk index is below the refreshed logical count but beyond the old
physical capacity causes `AppleRAIDSet::addMember` to write a live
`AppleRAIDMember *` past the kernel allocation.

The supplied three-image sequence is reachable through stock `hdiutil attach`
as uid 501. It changes the set from logical count/capacity `8/8` to `9/8`, then
inserts a member at index 8. A live trace captured the exact 64-byte allocation,
the exact first OOB destination, and the exact pointer written. A separate run
produced `kalloc.type.var2.64: element modified after free` with the same live
member pointer at offset 0 of the adjacent freed element.

The written qword is a kernel-created object pointer selected by the attacker's
member/index sequence; it is not an arbitrary 64-bit user value. I am reporting
this as unprivileged kernel memory corruption and denial of service, without a
code-execution claim.

## Current-release status

Static comparison against the stock macOS 27 release KDK confirms that the
same count/capacity split and both pointer-write sinks remain present in build
`26A428` (`com.apple.driver.AppleRAID` UUID
`4A01509A-4C02-3E53-A64F-D45A2FE08FE9`, SHA-256
`49ee5937174cc666e2dc089e3d9437c19cbfaa2c979a83e50ad3a9f2b6120486`).
See `CURRENT_RELEASE_26A428_STATIC_ADDENDUM.md` for the release addresses and
complete operand audit. Runtime evidence below remains from `26A5416b`; no
runtime reproduction on `26A428` is claimed.

## Tested configuration

- Product: macOS 27.0 beta
- Build: `26A5416b`
- Kernel: `xnu-13432.1.9~3/RELEASE_ARM64_VMAPPLE`
- Kext: `com.apple.driver.AppleRAID` 5.1.0
- arm64e UUID: `89968407-AD30-356B-9896-7D9B02F62B83`
- Caller: uid 501, no sudo
- Stock qualification: SIP enabled, secure boot enabled, no boot arguments,
  no custom kernel code

## Reproduction

Copy the `poc` directory to a disposable `26A5416b` VM and change `D` in
`repro_v1_stripe_seqgap_oob_write.sh` to that directory. Run the script as an
ordinary logged-in user:

```sh
./repro_v1_stripe_seqgap_oob_write.sh
```

The script performs:

1. Attach A1: V1 Stripe, member count 8, member index 0, sequence 1. This
   creates an eight-pointer `arMembers` allocation.
2. Attach A2: same set UUID, member count 9, member index 1, sequence 2. The
   newer sequence refreshes `arMemberCount` to 9 but leaves capacity 8 and the
   original allocation unchanged.
3. Attach A3: same set UUID, member count 9, member index 8, sequence 2. Index 8
   passes the logical `index < 9` check and is stored one qword beyond the
   eight-pointer allocation.

Before A3, `diskutil appleRAID list` reports logical index 8 as
`Missing/Damaged`. After A3, it reports the crafted member at index 8 as
`Online`. See `evidence/stripe_seqgap_uid501_before_after_20260822.txt`.

Depending on allocator state, the kernel may detect the corrupted adjacent
element later rather than during the third attach. The supplied panic records:

```text
[kalloc.type.var2.64]: element modified after free
(off:0, val:0xfffffe2fb3f2ef60, sz:64, ptr:0xfffffe29e7bf5640)
    0: 0xfffffe2fb3f2ef60
```

## Root cause and complete sink-bound audit

The vulnerable state variables in `AppleRAIDSet` are:

- `[set+0x15c]`: logical `arMemberCount`
- `[set+0x160]`: physical `arLastAllocCount`
- `[set+0x168]`: `arMembers` allocation base

The initial set creation calls `resizeSet(8)`, so all three agree. In the
newer-sequence path, `AppleRAIDSet::addMember` calls
`initWithHeader(newHeader, true)`. That method stores the attacker-supplied
count 9 to `arMemberCount`, but this path does not call `resizeSet`, update
`arLastAllocCount`, or replace `arMembers`.

For the final insertion in `AppleRAIDSet::addMember`:

```text
0xfffffe0009bc9d84  ldr  w28,[x19,#0xc4]       ; member index from A3 = 8
0xfffffe0009bc9d88  ldr  w25,[x20,#0x15c]      ; refreshed logical count = 9
0xfffffe0009bc9d8c  cmp  w28,w25
0xfffffe0009bc9d90  b.hs reject                ; checks 8 < 9 only
...
0xfffffe0009bca0cc  ldr  x9,[x20,#0x168]       ; old 8-entry allocation
0xfffffe0009bca0d0  lsl  x10,x28,#3            ; byte offset 0x40
0xfffffe0009bca0d4  cmp  x10,w10,sxtw          ; signed-width check only
0xfffffe0009bca0d8  add  x8,x9,w10,sxtw
0xfffffe0009bca0dc  add  x16,x9,x10
0xfffffe0009bca0e4  csel x8,x8,x16,eq
0xfffffe0009bca0e8  ldr  x9,[x8]               ; OOB slot probe
0xfffffe0009bca0ec  cbz  x9,write
...
0xfffffe0009bca170  str  x19,[x8]               ; OOB AppleRAIDMember * write
```

Every sink operand is accounted for:

- Destination base: `[set+0x168]`, allocated for eight qwords.
- Destination index: `w28=8`, supplied by A3 metadata.
- Existing bound: `cmp w28,w25; b.hs` at `0xfffffe0009bc9d8c..d90`
  compares only against the refreshed logical count 9.
- Missing bound: no instruction loads or compares the physical capacity at
  `[set+0x160]=8` before the probe or store.
- The `cmp/csel` at `0xfffffe0009bca0d4..e4` checks only that the scaled index
  is representable after the width/sign conversion. It is not a capacity check.
- Stored qword: `x19`, the live `AppleRAIDMember *` created for A3.

Thus the exact missing invariant is:

```text
memberIndex < arLastAllocCount
```

or, earlier on refresh:

```text
new arMemberCount <= arLastAllocCount, otherwise resizeSet(new count)
```

## Dynamic proof of the write

The live FBT trace in `evidence/stripe_seqgap_fbt_geometry_20260822.txt`
captured immediately before A3:

```text
set=fffffe1e48650800
member=fffffe28dddb7e40
logical=9 capacity=8
base=fffffe29e02a49c0
slot8=0
addMember return rc=1
```

The only successful insertion store therefore performed:

```text
*(uint64_t *)0xfffffe29e02a4a00 = 0xfffffe28dddb7e40
```

`0xfffffe29e02a4a00 == base + 8*8`, the first qword beyond the 64-byte
allocation. The independent allocator panic named the exact pointer written in
that run, corroborating the semantic index-8 transition and live geometry.

## Stock reachability

The research trace used DTrace only to record operands. Stock reachability was
then qualified independently in a fresh VM with SIP and secure boot enabled,
empty boot arguments, and no research kernel configuration. uid501 attached a
benign RAID image, which auto-loaded AppleRAID 5.1.0, then ran the malformed
count-refresh sequence. The kernel panicked in AppleRAID asynchronous recovery.

Artifacts:

- `evidence/stock_uid501_20260822_225121.log`
- `evidence/stock_panic-full-2026-08-22-195128.0002.panic`

The stock panic is reachability corroboration. The exact write proof is the
separate live geometry plus modified-after-free evidence above.

## Security impact

A local unprivileged user can use crafted V1 AppleRAID metadata to violate a
kernel count/capacity invariant and write a valid live kernel object pointer at
an attacker-selected array index beyond a typed kernel allocation. Confirmed
effects are cross-object kernel heap corruption and kernel panic. Because the
pointer value is kernel-generated rather than arbitrary user-controlled data,
this report does not claim an arbitrary write or privilege escalation.

## Suggested fix

Do not let `initWithHeader` change `arMemberCount` independently of the
allocation capacity. In the newer-sequence refresh path, validate the new count
and call `resizeSet` before publishing it. Independently, bound every
`arMembers[memberIndex]` access against `arLastAllocCount`, not only
`arMemberCount`. Apply the same cached-count-versus-live-count invariant to
arrays owned by `AppleRAIDStorageRequest` and filled by
`AppleRAIDMirrorSet::activeReadMembers`.
