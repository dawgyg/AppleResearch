# Qualification and duplicate check

- Exact current-build binary: KDK `27.0_26A5416b`, AppleRAID 5.1.0, arm64e UUID
  `89968407-AD30-356B-9896-7D9B02F62B83`.
- The same UUID was observed auto-loaded in the stock SIP-on VM.
- Current-build disassembly contains the logical-count-only check and OOB store
  documented in `REPORT.md`.
- The same count/capacity gap was instruction-verified on earlier beta
  `26A5388g`, so this is persistent rather than a one-build code-generation
  regression.
- Search of the local filed-case set found no AppleRAID case for this bug.
- Search of Apple's public security material and public AppleRAID history found
  no exact published fix/CVE for this V1 sequence-refresh count/capacity bug.
- Apple's public `AppleRAID-26` source contains the same structural invariant:
  the newer-sequence branch calls `initWithHeader(..., true)`, which assigns
  `arMemberCount`, and later writes `arMembers[memberIndex]` without invoking
  `resizeSet` on that path. The current binary, not the old source, is the
  freshness authority for this report.

Verdict as of 2026-08-23: not already fixed in the exact tested current build;
no known local duplicate. Apple may still identify a private duplicate.

