# Suggested Apple Security Bounty portal fields

## Title

AppleRAID V1 sequence refresh causes uid501 kernel heap OOB pointer write

## Product

macOS

## Component

AppleRAID / `com.apple.driver.AppleRAID`

## Version and build

macOS 27.0 beta `26A5416b`, AppleRAID 5.1.0, arm64e UUID
`89968407-AD30-356B-9896-7D9B02F62B83`

Static current-release confirmation: macOS 27 build `26A428`, AppleRAID UUID
`4A01509A-4C02-3E53-A64F-D45A2FE08FE9`, SHA-256
`49ee5937174cc666e2dc089e3d9437c19cbfaa2c979a83e50ad3a9f2b6120486`.
Runtime evidence remains from `26A5416b`; no `26A428` runtime claim is made.

## Attack vector

Local unprivileged user attaches three crafted raw disk images with V1
AppleRAID metadata using stock `hdiutil attach`.

## Impact

Kernel memory corruption and denial of service. The attacker controls the OOB
array index and which live `AppleRAIDMember *` is written; the pointer qword is
kernel-generated, so no arbitrary-write or code-execution claim is made.

## Reproduction

Run `poc/repro_v1_stripe_seqgap_oob_write.sh` as uid501 in a disposable
`26A5416b` VM after adjusting its `D` path to the packaged `poc` directory.

## Key evidence

- `CURRENT_RELEASE_26A428_STATIC_ADDENDUM.md`: exact release-build sequence
  refresh, direct member-array pointer store, and stale request-array store.
- `evidence/stripe_seqgap_fbt_geometry_20260822.txt`: exact logical count 9,
  physical capacity 8, base, member pointer, zero slot 8, and successful return.
- `evidence/panic-full-2026-08-22-135159.0002.panic`: adjacent 64-byte element
  modified after free with the exact live member pointer at offset 0.
- `evidence/stock_uid501_20260822_225121.log` and matching stock panic: SIP-on,
  secure-boot, no-boot-args uid501 reachability.
