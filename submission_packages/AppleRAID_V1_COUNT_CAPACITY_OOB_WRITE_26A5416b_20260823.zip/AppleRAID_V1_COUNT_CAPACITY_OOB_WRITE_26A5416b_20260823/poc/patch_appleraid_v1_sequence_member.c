#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <unistd.h>

enum {
    kHeaderSize = 0x1000,
    kHeaderVersionV1 = 0x00010000,
    kStripeLevel = 0,
    kMirrorLevel = 1,
    kConcatLevel = 2,
};

static void
usage(const char *prog)
{
    fprintf(stderr,
        "usage: %s image partition_start partition_size uuid_hex "
        "member_count member_index sequence [raid_level]\n",
        prog);
}

static int
parse_u64(const char *text, uint64_t *value)
{
    char *end = NULL;
    errno = 0;
    unsigned long long parsed = strtoull(text, &end, 0);
    if (errno || end == text || *end != '\0') {
        return -1;
    }
    *value = (uint64_t)parsed;
    return 0;
}

static int
parse_uuid_hex(const char *text, unsigned char uuid[16])
{
    if (strlen(text) != 32) {
        return -1;
    }
    for (unsigned i = 0; i != 16; ++i) {
        char byte_text[3] = { text[i * 2], text[i * 2 + 1], '\0' };
        char *end = NULL;
        errno = 0;
        unsigned long value = strtoul(byte_text, &end, 16);
        if (errno || end != byte_text + 2 || value > 0xff) {
            return -1;
        }
        uuid[i] = (unsigned char)value;
    }
    return 0;
}

static void
store_be32(unsigned char *dst, uint32_t value)
{
    for (unsigned i = 0; i != 4; ++i) {
        dst[i] = (unsigned char)(value >> (24 - i * 8));
    }
}

int
main(int argc, char **argv)
{
    static const uint32_t chunk_size = 4096;
    static const uint32_t chunk_count = 2048;
    unsigned char set_uuid[16];
    uint64_t partition_start;
    uint64_t partition_size;
    uint64_t member_count;
    uint64_t member_index;
    uint64_t sequence;
    uint64_t raid_level = kMirrorLevel;

    if ((argc != 8 && argc != 9) ||
        parse_u64(argv[2], &partition_start) ||
        parse_u64(argv[3], &partition_size) ||
        parse_uuid_hex(argv[4], set_uuid) ||
        parse_u64(argv[5], &member_count) ||
        parse_u64(argv[6], &member_index) ||
        parse_u64(argv[7], &sequence) ||
        partition_size < kHeaderSize ||
        member_count == 0 || member_count > UINT32_MAX ||
        member_index >= member_count || member_index > UINT32_MAX ||
        sequence == 0 || sequence > UINT32_MAX ||
        (argc == 9 && parse_u64(argv[8], &raid_level)) ||
        (raid_level != kStripeLevel && raid_level != kMirrorLevel &&
            raid_level != kConcatLevel)) {
        usage(argv[0]);
        return 2;
    }

    if (partition_start > UINT64_MAX - partition_size) {
        fprintf(stderr, "partition range overflows\n");
        return 2;
    }
    uint64_t end_offset = partition_start + partition_size;
    uint64_t v2_offset = end_offset - kHeaderSize;
    if (end_offset > (uint64_t)INT64_MAX) {
        fprintf(stderr, "partition range is not representable as off_t\n");
        return 2;
    }

    int fd = open(argv[1], O_RDWR);
    if (fd < 0) {
        perror("open");
        return 1;
    }

    struct stat st;
    if (fstat(fd, &st) != 0) {
        perror("fstat");
        close(fd);
        return 1;
    }
    if ((uint64_t)st.st_size < end_offset) {
        fprintf(stderr, "image is too small for the declared partition\n");
        close(fd);
        return 2;
    }

    unsigned char header[kHeaderSize];
    memset(header, 0, sizeof(header));
    memcpy(header, "AppleRAIDHeader", sizeof("AppleRAIDHeader"));
    store_be32(header + 0x10, kHeaderSize);
    store_be32(header + 0x14, kHeaderVersionV1);
    store_be32(header + 0x18, (uint32_t)sequence);
    store_be32(header + 0x1c, (uint32_t)raid_level);
    memcpy(header + 0x20, set_uuid, sizeof(set_uuid));
    snprintf((char *)header + 0x30, 0x20, "seq-gap-%" PRIu64, sequence);
    store_be32(header + 0x50, (uint32_t)member_count);
    store_be32(header + 0x54, (uint32_t)member_index);
    store_be32(header + 0x58, chunk_size);
    store_be32(header + 0x5c, chunk_count);

    unsigned char zero[kHeaderSize];
    memset(zero, 0, sizeof(zero));
    if (pwrite(fd, zero, sizeof(zero), (off_t)v2_offset) !=
        (ssize_t)sizeof(zero)) {
        perror("pwrite v2 invalidation");
        close(fd);
        return 1;
    }
    if (pwrite(fd, header, sizeof(header), (off_t)partition_start) !=
        (ssize_t)sizeof(header)) {
        perror("pwrite v1 header");
        close(fd);
        return 1;
    }
    if (fsync(fd) != 0) {
        perror("fsync");
        close(fd);
        return 1;
    }
    close(fd);

    printf("patched %s: count=%" PRIu64 " index=%" PRIu64
        " sequence=%" PRIu64 " level=%" PRIu64 "\n",
        argv[1], member_count, member_index, sequence, raid_level);
    return 0;
}
