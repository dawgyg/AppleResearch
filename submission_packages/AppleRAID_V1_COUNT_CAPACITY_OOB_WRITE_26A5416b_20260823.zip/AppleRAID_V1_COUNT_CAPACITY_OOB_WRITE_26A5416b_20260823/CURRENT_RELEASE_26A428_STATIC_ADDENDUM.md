# Current-release static addendum: macOS 27 build 26A428

The same V1 sequence-refresh count/capacity bug remains present in the stock
macOS 27 release KDK binary. This addendum is a static current-build
confirmation; the packaged runtime traces and stock SIP-on reproduction were
captured on `26A5416b`.

## Binary identity

- Binary: `com.apple.driver.AppleRAID`
- Build: `26A428`
- UUID: `4A01509A-4C02-3E53-A64F-D45A2FE08FE9`
- SHA-256: `49ee5937174cc666e2dc089e3d9437c19cbfaa2c979a83e50ad3a9f2b6120486`

## Current direct-write path

The initial resize allocates `count * 8` bytes and records physical capacity
at `[set+0x160]` (`AppleRAIDSet::resizeSet @0xdcc8`, stores at
`0xdd94..0xdd98`). A newer member sequence calls
`initWithHeader(header,true) @0xd598..0xd5d0`. The incoming
`appleraid-MemberCount` is then stored only to logical `[set+0x15c] @0xcb08`;
physical `[set+0x160]` is not updated.

`AppleRAIDSet::addMember` subsequently executes:

```text
0xd2b8  ldr w28,[member+0xc4]      ; attacker-controlled index
0xd2bc  ldr w25,[set+0x15c]       ; widened logical bound
0xd2c0  cmp w28,w25
0xd2c4  b.hs reject
0xd600  ldr x9,[set+0x168]        ; old physical allocation
0xd604..0xd618                    ; members + index*8
0xd6a4  str x19,[destination]     ; live AppleRAIDMember *
```

There is no load or comparison against physical capacity `[set+0x160]` before
the store. The arithmetic `cmp x10,w10,sxtw @0xd608` is only a width/sign
assertion and does not bound the offset to allocated bytes.

## Current stale-output path

`AppleRAIDStorageRequest::initWithAppleRAIDSet` caches the old member count at
`request+0x54 @0x1abb0..0x1abb4`, allocates `old_count * 8` at
`0x1ac9c..0x1acb0`, and stores the output pointer at `request+0x88`.
`AppleRAIDStorageRequest::read @0x1ae90..0x1aedc` later passes that old array to
`AppleRAIDMirrorSet::activeReadMembers`. The callee reloads current logical
count at `0x14928`, writes a live member pointer at `0x14a20`, and loops only
against current count at `0x14a6c..0x14a70`. It receives no old capacity and
performs no capacity comparison.

For the proven `8 -> 9` sequence, both paths can write one valid kernel object
pointer at offset `0x40`, immediately beyond a 64-byte allocation.
