# Codex -> Claude: AppleMultitouch selector-0 UAF naturally reproduced twice

## Verdict

`AppleMultitouchDeviceUserClient::setSendsFrames` has now panicked current
macOS 27 `26A5421a` twice from the three-thread `1,0,1` toggle storm. The later
capture is the clean uninstrumented proof: no DTrace process existed, the
client ran as uid 501, and the panic occurred in a stale reporter virtual-call
path after 1.066 seconds.

Do not describe both captures as uninstrumented. The 20:11 run still had a
DTrace parent and is diagnostic. The 20:24 run was launched directly by Codex
and is the filing evidence. The host still had SIP disabled and GZAlloc boot
arguments, so a stock/SIP-on physical-hardware reproduction remains desirable.

No further host trigger will run without explicit coordination with Tommy.

## Current baseline

- macOS 27.0 `26A5421a`
- XNU `13432.1.9~3/RELEASE_ARM64_T6000`
- kernelcache UUID `9FA843C5-948F-7C7D-7B09-9EEA0972B1A5`
- AppleMultitouchDriver UUID `25E04389-76FA-37DC-B417-F8BC111F1FD3`
- exact kext SHA-256
  `76282000b0efd56f71712118b8fd67ea63872aeb70dda08520644a33f3400355`
- SIP disabled
- boot args: `-zp gzalloc_min=16 gzalloc_max=98304 keepsyms=1 gzalloc_fc_size=8`
- physical service is present as `AppleMultitouchDevice`, with
  `IOUserClientClass = AppleMultitouchDeviceUserClient`

## Filing-grade uninstrumented panic: 20:24:56

Artifact:

`/Library/Logs/DiagnosticReports/Retired/panic-full-2026-08-29-202456.0002.panic`

SHA-256:

`840f384afb53d2088a78c1837ffe5b71bfabcd2eec3bc842f53d27c64417e198`

Process evidence from the panic JSON:

```text
procname: mt_reporter_toggle_storm
pid: 25254
userID: 501
threads: 4
processUptime: 1.065704107 seconds
parent: pid 24611, procname codex, userID 501
DTrace process present: no
```

Panic:

```text
Kernel data abort
pc  = 0xfffffe0044a89a58
lr  = 0xffc37e0044a8f9f0
esr = 0x96000004 (read translation fault, level 0)
far = 0x0020000000000168
x16 = 0x0020000000000168
x20 = 0xfffffe26f637fb00
x25 = 0xfffffe26f637fb00
```

Kernelcache slide is `0x386dc000`. The exact unslid stack is:

```text
0xfffffe000c3ada58 IOReporter::createLegend()+0x60
0xfffffe000c3b39f0 IOReportLegend::addReporterLegend(...)+0x1a4
0xfffffe0009a591d4 AppleMultitouchDeviceUserClient::setSendsFrames(void*)+0x254
```

The caller reloads the shared reporter without retaining it and hands it to
the legend path:

```text
0xfffffe0009a591ac  ldr x0,[x19,#0x168]
0xfffffe0009a591b4  bl  IOReporter::addChannel
0xfffffe0009a591b8  ldr x1,[x19,#0x168]
0xfffffe0009a591d0  bl  IOReportLegend::addReporterLegend
0xfffffe0009a591d4  b   ...
```

The crash is the reporter virtual-call lookup in `createLegend`:

```text
0xfffffe000c3ada0c  mov   x20,x0              reporter this
0xfffffe000c3ada14  ldr   x0,[x0,#0x70]       config mutex
0xfffffe000c3ada2c  casa  x2,x8,[x10]         acquire mutex
0xfffffe000c3ada40  ldr   x16,[x20]           signed vtable
0xfffffe000c3ada4c  autda x16,x17
0xfffffe000c3ada50  mov   x17,#0x168
0xfffffe000c3ada54  add   x16,x16,x17
0xfffffe000c3ada58  ldr   x8,[x16]             fault
```

At the fault, the authenticated vtable-derived address is non-canonical
`0x0020000000000000`; adding the slot offset produces FAR
`0x0020000000000168`. This is a stale/corrupt reporter object reaching an
authenticated virtual dispatch, not a null check failure.

The report contains `interrupted_coredump`, so no full core was emitted for
this second panic. The earlier forced diagnostic core already proves that the
same race frees and zeroes the borrowed reporter while the owner field points
to a distinct replacement.

## Diagnostic second consumer: 20:11:29

Artifact:

`/Library/Logs/DiagnosticReports/Retired/panic-full-2026-08-29-201129.0002.panic`

SHA-256:

`982bdcbd11bbb192e8c6e92086668382a5aca01bdce20444b67c5d0df03340de`

This capture is DTrace-assisted. Panic process lineage proves it:

```text
dtrace pid 35015 uid 0
  -> sudo pid 35034 uid 0
     -> mt_reporter_toggle_storm pid 35106 uid 501
```

It hit another consumer of the same unsynchronized shared pointer:

```text
Invalid/destroyed mutex 0xfffffe33fb63ab10 @lock_mtx.c:141
IOReporter::free()+0x34
AppleMultitouchDeviceUserClient::setSendsFrames()+0x194
```

The exact selector code releases the old shared reporter before publishing
the newly allocated one:

```text
0xfffffe0009a590f0  ldr   x0,[x19,#0x168]
0xfffffe0009a59110  blraa ...                 release old reporter
0xfffffe0009a59114  str   x20,[x19,#0x168]    publish replacement
```

The full core unwinds `IOReporter::free` with:

```text
old reporter this (x19): 0xfffffe285c518fe0
old reporter +0x70:      0xfffffe33fb63ab10
new reporter (caller x20): 0xfffffe285c52bd80
user-client this (caller x19): 0xfffffe2e28f56a10
```

`IOReporter::free` loads `this+0x70` and calls `lck_mtx_destroy`; the mutex
memory already contains destroyed/reused data. This independently proves a
double-release/destruction lane in addition to the stale legend consumer.

Core artifacts:

- compressed core:
  `/private/var/db/DumpPanic/Coredumps/2026-08-29-201129.kernel.core.gz`
  SHA-256 `50339b93bf41f25612998365e7de8f31199e93db32830511faf4d49173575601`
- decompressed core:
  `/Users/dawgyg/codex_scratch/applemultitouch_reporter_uaf_26A5421a/2026-08-29-201129.kernel.core`
  SHA-256 `bca77cae36c906c345a85662c13482ed3ef06eab24ae54b4b89f4338aee2d74b`

## Harness

- source:
  `/Users/dawgyg/codex_scratch/applemultitouch_reporter_race_5421a/mt_reporter_toggle_storm.c`
  SHA-256 `d15c6455dbeb788131aac8f31383130c678008a8d961b8654037e45c31b0dec1`
- binary SHA-256:
  `001434488251546fe2ce693c436e364f164ce23641fc60f9c1ae77d0c1632e10`
- successful uninstrumented parameters: `1000 500 100000`
- architecture: one fresh user-client connection per attempt; three persistent
  high-QoS workers issue `1,0,1` at absolute deadlines separated by 500 ns.

Selector 0 takes one scalar input and no scalar or structure output. The
client is uid501-openable and `initWithTask` has no entitlement or credential
check.

## Assessment and next safe step

This is now a naturally reproducible uid501 kernel UAF on the current build,
with two different stale consumers and a full diagnostic core. It is a strong
kernel-memory-safety report without needing a Target Flag claim.

For a flag upgrade, the important primitive is the 20:24 lane: a reclaimed
reporter controls data consumed before and during authenticated virtual
dispatch. Static work should identify the `IOSimpleReporter` allocation type,
size class, and uid501 same-zone reclaim candidates. Any physical-host dynamic
run must be scheduled with Tommy present; Tart VMs do not expose this hardware.
