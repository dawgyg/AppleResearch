#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#include <mach/mach_error.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

struct shared_state {
    _Atomic unsigned phase;
    _Atomic unsigned done;
    _Atomic int stop;
    io_connect_t connection;
    uint64_t deadline;
    uint64_t delta_ticks;
};

struct worker {
    struct shared_state *shared;
    unsigned index;
    uint64_t value;
    kern_return_t result;
};

static inline void
spin_hint(void)
{
    __asm__ volatile("yield");
}

static void *
worker_main(void *opaque)
{
    struct worker *worker = opaque;
    struct shared_state *shared = worker->shared;
    unsigned seen = 0;

    pthread_set_qos_class_self_np(QOS_CLASS_USER_INTERACTIVE, 0);

    for (;;) {
        unsigned phase;
        do {
            phase = atomic_load_explicit(&shared->phase,
                memory_order_acquire);
            spin_hint();
        } while (phase == seen);
        seen = phase;

        if (atomic_load_explicit(&shared->stop, memory_order_relaxed)) {
            break;
        }

        mach_wait_until(shared->deadline +
            (uint64_t)worker->index * shared->delta_ticks);
        worker->result = IOConnectCallScalarMethod(shared->connection, 0,
            &worker->value, 1, NULL, NULL);
        atomic_fetch_add_explicit(&shared->done, 1, memory_order_release);
    }
    return NULL;
}

static uint64_t
ns_to_ticks(uint64_t ns)
{
    mach_timebase_info_data_t timebase;
    mach_timebase_info(&timebase);
    return (uint64_t)(((__uint128_t)ns * timebase.denom) / timebase.numer);
}

int
main(int argc, char **argv)
{
    unsigned attempts = 100000;
    uint64_t delta_ns = 500;
    uint64_t lead_ns = 100000;
    io_service_t service;
    struct shared_state shared = {0};
    struct worker workers[3];
    pthread_t threads[3];
    unsigned completed = 0;

    if (argc > 1) {
        attempts = (unsigned)strtoul(argv[1], NULL, 0);
    }
    if (argc > 2) {
        delta_ns = strtoull(argv[2], NULL, 0);
    }
    if (argc > 3) {
        lead_ns = strtoull(argv[3], NULL, 0);
    }
    if (attempts == 0 || delta_ns > 1000000 || lead_ns < 10000) {
        fprintf(stderr, "usage: %s [attempts] [delta_ns] [lead_ns]\n",
            argv[0]);
        return 2;
    }

    service = IOServiceGetMatchingService(kIOMainPortDefault,
        IOServiceMatching("AppleMultitouchDevice"));
    if (service == IO_OBJECT_NULL) {
        fprintf(stderr, "AppleMultitouchDevice not found\n");
        return 1;
    }

    shared.delta_ticks = ns_to_ticks(delta_ns);
    workers[0] = (struct worker){&shared, 0, 1, 0};
    workers[1] = (struct worker){&shared, 1, 0, 0};
    workers[2] = (struct worker){&shared, 2, 1, 0};
    for (unsigned i = 0; i < 3; i++) {
        if (pthread_create(&threads[i], NULL, worker_main, &workers[i]) != 0) {
            fprintf(stderr, "pthread_create failed at %u\n", i);
            _exit(3);
        }
    }

    printf("pid=%d uid=%u attempts=%u delta_ns=%llu lead_ns=%llu\n",
        getpid(), getuid(), attempts, delta_ns, lead_ns);
    fflush(stdout);

    for (unsigned attempt = 0; attempt < attempts; attempt++) {
        kern_return_t kr = IOServiceOpen(service, mach_task_self(), 0,
            &shared.connection);
        if (kr != KERN_SUCCESS || shared.connection == IO_OBJECT_NULL) {
            fprintf(stderr, "attempt=%u IOServiceOpen=%#x (%s)\n", attempt,
                kr, mach_error_string(kr));
            break;
        }

        atomic_store_explicit(&shared.done, 0, memory_order_relaxed);
        shared.deadline = mach_absolute_time() + ns_to_ticks(lead_ns);
        atomic_fetch_add_explicit(&shared.phase, 1, memory_order_release);

        while (atomic_load_explicit(&shared.done, memory_order_acquire) != 3) {
            spin_hint();
        }

        unsigned failures = 0;
        for (unsigned i = 0; i < 3; i++) {
            if (workers[i].result != KERN_SUCCESS) {
                failures++;
            }
        }
        IOServiceClose(shared.connection);
        shared.connection = IO_OBJECT_NULL;
        completed++;

        if ((attempt % 1000) == 0 || failures != 0) {
            printf("attempt=%u failures=%u results=%#x,%#x,%#x\n", attempt,
                failures, workers[0].result, workers[1].result,
                workers[2].result);
            fflush(stdout);
        }
    }

    atomic_store_explicit(&shared.stop, 1, memory_order_relaxed);
    atomic_fetch_add_explicit(&shared.phase, 1, memory_order_release);
    for (unsigned i = 0; i < 3; i++) {
        pthread_join(threads[i], NULL);
    }
    IOObjectRelease(service);
    printf("completed=%u\n", completed);
    return completed == attempts ? 0 : 1;
}
