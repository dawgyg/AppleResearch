# Technical analysis

## Target

- OS: macOS 27 beta `26A5378n`.
- Binary: `/usr/sbin/smbd`, arm64e UUID
  `39778c76-324c-3174-a550-e4ead047ebc9`.
- Extracted arm64e SHA-256:
  `b2a2e45f49a01e6832a3e0cadaa82b12aa9838af7f651fe8c47b706eead61e7b`.

## Request extraction

`smb2::extract(set_info_request)` at preferred `0x100048774` validates the
outer `BufferOffset` and `BufferLength` against the SMB2 frame at
`0x100048824..0x10004884c`. That protects the source pointer but does not size
the separate native destination correctly.

For `InfoType=3`, `smb2_dispatch_set_file_information`:

1. Loads attacker input length into `w23` at `0x10002bb3c`.
2. Calls `platform::heap_buffer::grow_atleast(input_len)` at
   `0x10002bb50..0x10002bb64`. The helper rounds the requested allocation to a
   page boundary.
3. Loads the heap pointer into `x2` at `0x10002bb68` and reloads the same input
   length into `x1` at `0x10002bb6c`.
4. Copies `x1` to `x3` at `0x10002bbb8`, then calls the converter at
   `0x10002bbbc`.

The effective call is:

```text
ConvertWireSecurityDescriptorToSecurityDescriptor(
    wire, input_len, output_heap, input_len)
```

## Destination-size mismatch

`ConvertWireSecurityDescriptorToSecurityDescriptor` at `0x10003ffc4`:

- checks only `x3 >= x1` at `0x100040014..0x100040018`;
- computes `x23 = 40*x3` at `0x10004001c..0x100040020`;
- treats `output_heap + 40*input_len` as the destination end;
- initializes the fixed 40-byte native descriptor at
  `0x100040078..0x100040084`.

The actual caller allocation is only the page-rounded `input_len`. All nested
destination checks therefore compare against an end up to 40 times beyond the
real allocation.

The same mismatch is present in the x86_64 slice. At preferred
`0x10003a743..0x10003a74f`, it computes `40*x3`; at
`0x10003a756..0x10003a75e`, it only checks `x3 >= input_len`; and at
`0x10003a7b5..0x10003a7c7`, it clears and initializes the 40-byte native
descriptor. This is not arm64e-only code generation.

## Aliased ACL expansion

The proof input is exactly `0x4000` bytes:

- 20-byte self-relative descriptor;
- control `0x8014` (`SELF_RELATIVE | SACL_PRESENT | DACL_PRESENT`);
- both SACL and DACL offsets are `20`;
- one 8-byte ACL header at offset 20;
- ACL revision `2`, `AclSize=0x3fec`, `AceCount=0`;
- zero padding to the declared ACL end.

Each offset is independently less than the global input length, so both pass.
No check requires the two source components to be disjoint and no check limits
total native output to the caller's allocation.

For each ACL, `InitializeAclFromWire` validates `AclSize` against the remaining
global source at `0x100040368..0x10004037c`, then compares destination space
against the inflated converter end at `0x100040380..0x10004039c`. It calls
`InitializeAcl` at `0x1000403f0`.

`InitializeAcl` executes `bzero(destination, AclSize)` at
`0x10003d5f4..0x10003d5f8`. The first ACL begins at native offset `0x28`; the
second begins after the first declared ACL span. The second zeroing operation
therefore runs outside the true output allocation.

## Structured OOB write after zeroing

The optional `--fill-aces` form uses a single DACL and fills its declared span
with 1,022 valid 16-byte access-allowed ACEs. The destination geometry is:

```text
native descriptor       0x28 bytes
ACL header              0x08 bytes
1022 ACEs * 0x10        0x3fe0 bytes
final ACE start         0x4000 bytes from allocation base
```

After `InitializeAcl` performs the OOB zeroing, the last call to
`AddAccessAllowedAceEx` writes the 16-byte sequence
`00 1b 10 00 43 43 43 43 01 00 43 4f 44 45 58 21` beginning exactly at the
caller's tracked `0x4000` heap-buffer capacity end. The controllable operands
are ACE flags, access mask, and SID identifier authority/subauthorities; ACE
type, derived size, SID revision, and SID count impose structure. This is a
structured contiguous heap overflow, not an arbitrary-address write.

The production parser accepted this full 1,022-ACE request and proceeded to
the backend, which returned `STATUS_NOT_SUPPORTED`. The Guard Malloc crash uses
the simpler aliased empty-ACL form because its earlier `bzero` reaches the
guard page before ACE insertion.

## Sibling entry points

The same vulnerable forward converter is also called by the legacy SMB1
`NT_TRANSACT_SET_SECURITY` handler `nttrans_set_file_security`:

- the wire data length is loaded from the request fixed buffer at
  `0x100023058`;
- `platform::heap_buffer::grow_atleast(data_len)` is called at
  `0x100023064..0x100023068`;
- the resulting heap capacity and pointer are loaded into `x3` and `x20` at
  `0x100023078`;
- the wire pointer and byte length are loaded into `x0` and `x1` at
  `0x100023088`;
- `x2` receives the heap pointer at `0x10002308c`, followed by the vulnerable
  converter call at `0x100023090`.

This supplies the same effective `(wire, byte_len, output_heap, heap_capacity)`
shape. It is a second protocol entry point to the same defect, not a separate
bug. Dynamic reproduction in this package uses SMB2; SMB1 reachability depends
on legacy SMB1 service configuration.

The SMB1 and SMB2 query-security handlers call the reverse converter
`ConvertSecurityDescriptorToWireSecurityDescriptor` at `0x100022edc` and
`0x10002ae54`, respectively. Those paths do not contain the forward
converter's 40x error:

- SMB1 passes the actual remaining response span `x24-x25`, computed at
  `0x100022e94..0x100022e9c`, as the byte capacity.
- SMB2 grows its response heap to the client maximum-output byte count at
  `0x10002ae38..0x10002ae48` and passes that same count by reference at
  `0x10002ae50..0x10002ae54`.
- the reverse converter forms its byte end as `output + *length` at
  `0x10004061c..0x100040640`.
- fixed descriptor insertion requires 20 remaining bytes at
  `0x10004d624..0x10004d630`;
- ACL-header insertion requires eight remaining bytes at
  `0x10004d5a0..0x10004d5b0`;
- ACE insertion requires ten remaining bytes at
  `0x10004d508..0x10004d518`, then SID insertion independently requires its
  fixed eight bytes and `4*SubAuthorityCount` remaining at
  `0x10004d434..0x10004d4cc`.

All reverse-path destination writes are therefore checked against the real
byte end. A short buffer can cause bounded partial serialization before the
helper returns failure, but no write exceeds the supplied response span.

## Rule Zero operand map

Sink: `bzero(x0=destination, x1=AclSize)` at `0x10003d5f8`.

- `AclSize`: attacker u16 from wire ACL offset `+2`.
  Source-side bound: `cmp remaining, AclSize` at `0x100040378`, branch reject
  `b.lt` at `0x10004037c`.
- ACL source offset: attacker u32 SACL/DACL field.
  Lower and upper bound: `cmp offset,input_len`, reject `b.hs` at
  `0x100040324..0x100040328`; nested extractor also checks eight header bytes.
- Destination base: caller heap pointer plus a 40-byte native header and prior
  converted components.
- Destination upper bound: `cmp output_end-current, AclSize+10` at
  `0x100040394..0x10004039c`.
- Gap: `output_end` is formed as `heap_ptr + 40*input_len`, while the real heap
  allocation is page-rounded `input_len`. There is no comparison against the
  actual heap-buffer capacity.
- Sibling gap: SACL and DACL offsets are checked independently against the
  global input span, but their combined destination expansion is not bounded;
  both may alias the same source ACL.

## Dynamic evidence

The included `.ips` report records:

- process `smbd`, PID 43941, root launch daemon;
- `EXC_BAD_ACCESS / KERN_INVALID_ADDRESS` at `0x70221f8000`;
- ESR: `Data Abort byte write Translation fault`;
- `x21=0x3fec`, exactly the attacker ACL size;
- `x24=0x8014`, exactly the attacker descriptor control flags;
- current memset destination `x0=0x70221f4028`;
- first unmapped byte `far=0x70221f8000`;
- VM map: preceding `Malloc Small` region ends at the fault address.

Faulting stack:

```text
_platform_memset
InitializeAcl(_ACL*, unsigned long, unsigned int) + 68
InitializeAclFromWire(...) + 260
ConvertWireSecurityDescriptorToSecurityDescriptor(...) + 364
smb2_dispatch_set_file_information(...) + 632
smb2_dispatch_compound(...) + 1932
```

The client received a connection-read error during the `SET_INFO`, and the
daemon exited with `SIGSEGV`.

## Suggested fix

Treat the fourth converter argument as a byte capacity throughout. Compute the
destination end as `output_heap + output_capacity`, require at least 40 bytes
before the fixed native descriptor stores, and account for the sum of all
converted owner, group, SACL, and DACL components. Source offsets should be
validated against their component-local declared spans; independently valid
overlapping offsets must not allow cumulative destination output to exceed the
real heap-buffer capacity.
