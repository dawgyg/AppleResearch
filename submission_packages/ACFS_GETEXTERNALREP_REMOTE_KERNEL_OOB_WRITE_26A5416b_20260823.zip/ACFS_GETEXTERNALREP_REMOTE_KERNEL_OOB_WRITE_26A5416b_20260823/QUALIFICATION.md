# Qualification and duplicate check

- Exact tested binary: ACFS 589.0 from macOS 27 beta `26A5416b`, arm64e UUID
  `94BBB8F1-4CA9-3D69-A684-6B71FF5E2172`, SHA-256
  `c4324fa80f5864a2167d96067abe7a9be6293f938e9537d8173e188cf81a05a5`.
- The panic names the same kext version and UUID.
- Current-build disassembly contains the unchecked `t`/`s` field loads,
  derived `count`/`offset`, and the exact faulting store documented in
  `REPORT.md`.
- The same parser shape was instruction-verified in archived macOS 27 beta
  images `26A5353q`, `26A5368g`, `26A5378j`, `26A5378n`, `26A5388g`, and
  `26A5416b`; it is persistent rather than a one-build regression.
- Search of the local filed-case and coordination-note set found no previous
  submission for `_FsmGetExternalRep`, command `0x20000d32`, or opcode `0x42`.
- Apple's public security content includes older generic Xsan buffer-overflow
  and OOB-read entries (including CVE-2025-24157, CVE-2025-24265, and
  CVE-2025-24266), but those entries do not identify this function, opcode, or
  invariant. The exact current binary remains vulnerable.
- ACFS is closed source, so there is no public upstream commit history to use
  for an exact function-level fixed/known comparison.

Verdict as of 2026-08-23: not fixed in the exact tested current beta and no
known local duplicate. Apple may still identify a private duplicate.
