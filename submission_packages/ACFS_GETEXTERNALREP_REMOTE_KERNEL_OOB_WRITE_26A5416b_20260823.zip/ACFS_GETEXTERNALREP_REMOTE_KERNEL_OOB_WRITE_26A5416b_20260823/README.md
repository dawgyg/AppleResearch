# ACFS GetExternalRep remote kernel OOB-write package

This is the consolidated Apple Security Bounty package for the current-build
ACFS `_FsmGetExternalRep` reply-parser bug.

Use `REPORT.md` as the report body and `PORTAL_FIELDS.md` for the short portal
fields. The primary artifact is
`evidence/panic-full-2026-08-23-072214.0002.panic`: a release-kernel data abort
at the exact `str q0, [x9]` destination store, with `FAR == x9 ==
allocation_base + attacker-derived_offset`.

The supported claim is deliberately bounded:

- a malicious or compromised Xsan metadata controller can send a crafted TCP
  FSM reply to an already configured ACFS client;
- two server-controlled fields drive an unchecked record count and destination
  offset in the client kernel;
- the current-build release kernel directly faulted on the resulting OOB write;
- the attacker controls one dword in the first OOB 16-byte store and controls
  the repeated destination offsets/count.

Do not claim uid501 initiation, an unconfigured-client attack, zero click,
arbitrary-address write, remote code execution, or privilege escalation. The
laboratory client request was root-authorized and the server response was
modified under LLDB to emulate a malicious controller.

All package files are covered by `SHA256SUMS.txt`. Filing remains user-only.
