# Suggested Apple Security Bounty portal fields

## Title

Malicious Xsan metadata controller reply causes ACFS kernel heap OOB write

## Product

macOS

## Component

Xsan / `com.apple.filesystems.acfs`

## Version and build

macOS 27.0 beta `26A5416b`, ACFS 589.0, arm64e UUID
`94BBB8F1-4CA9-3D69-A684-6B71FF5E2172`

## Attack vector

A malicious or compromised Xsan metadata controller sends a crafted TCP FSM
`GetExternalRep` reply to an already configured ACFS client. The diagnostic
client request was root-authorized; inducing an unconfigured client to connect
was not demonstrated.

## Impact

Remote-server-controlled kernel heap corruption and denial of service. The
server controls the record count and repeated OOB destination offsets and
controls one dword in the first OOB 16-byte store. No arbitrary-address write,
RCE, LPE, zero-click, or uid501 claim is made.

## Reproduction

In a disposable configured Xsan lab, build `poc/acfs_getexternalrep_trigger.c`,
intercept the metadata controller's `VopGetExternalRep` response, set
`B=0x800`, `s=0`, `t=0x20000`, and transmitted reply length `0x824`, then run
the trigger as root against a path on the mounted ACFS volume.

## Key evidence

- `evidence/panic-full-2026-08-23-072214.0002.panic`: release-kernel direct
  write fault with `FAR == x9 == allocation_base + offset`.
- `static/FsmGetExternalRep_and_caller_26A5416b.txt`: exact missing bounds and
  direct stores.
- `static/TCP_transport_26A5416b.txt`: socket imports and explicit
  `SOCK_STREAM`/`IPPROTO_TCP` construction.
- `evidence/dynamic_recipe_and_symbolication.txt`: crafted fields, registers,
  and runtime-to-static PC mapping.
