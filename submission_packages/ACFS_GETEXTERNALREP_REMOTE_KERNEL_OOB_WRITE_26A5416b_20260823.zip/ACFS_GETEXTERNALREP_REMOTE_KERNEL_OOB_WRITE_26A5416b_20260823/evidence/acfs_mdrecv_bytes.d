fbt:com.apple.filesystems.acfs:MdSockRecv:entry
/arg2 > 0x100000/
{
    self->mdrecv = 1;
    self->outp = arg3;
    printf("MDRECV tid=%d sock=%p dst=%p req=0x%lx outp=%p\n",
        tid, arg0, arg1, arg2, arg3);
}

fbt:com.apple.filesystems.acfs:MdSockRecv:return
/self->mdrecv/
{
    printf("MDRET tid=%d errno=0x%lx bytes=%u\n",
        tid, arg1, *(uint32_t *)self->outp);
    self->mdrecv = 0;
    self->outp = 0;
}
