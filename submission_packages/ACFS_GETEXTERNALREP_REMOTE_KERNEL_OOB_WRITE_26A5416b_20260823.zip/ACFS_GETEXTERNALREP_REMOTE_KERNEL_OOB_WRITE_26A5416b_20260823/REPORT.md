# Malicious Xsan metadata controller reply causes a controlled-offset kernel heap OOB write

## Summary

On macOS 27.0 beta build `26A5416b`, the ACFS/Xsan client kernel extension
trusts two 32-bit fields in an FSM `GetExternalRep` reply when copying a record
array into a caller-sized kernel allocation. The reply's total byte count `t`
and per-record variable size `s` determine the record stride, record count, and
per-record destination offset. Neither field is checked against the caller's
allocation size or the received reply length.

A malicious or compromised Xsan metadata controller can therefore make a
configured client execute repeated 16-, 8-, and 2-byte stores beyond the end
of a kernel heap allocation. In the supplied current-build run, a crafted TCP
FSM reply caused a release-kernel data abort exactly at `_FsmGetExternalRep`'s
16-byte destination store. The panic records a write translation fault with
`FAR == x9 == allocation_base + attacker-derived_offset`.

The laboratory request that elicited opcode `0x42` was issued by root. I have
not shown that an unprivileged local user can trigger this command or that an
unconfigured client can be induced to connect to an attacker. The security
claim is a malicious or compromised metadata controller attacking an already
configured Xsan client, not arbitrary Internet reachability or uid501 access.

## Tested configuration

- Product: macOS 27.0 beta
- Build: `26A5416b`
- Kernel: `xnu-13432.1.9~3/RELEASE_ARM64_VMAPPLE`
- Kext: `com.apple.filesystems.acfs` 589.0
- Kext UUID: `94BBB8F1-4CA9-3D69-A684-6B71FF5E2172`
- Kext SHA-256:
  `c4324fa80f5864a2167d96067abe7a9be6293f938e9537d8173e188cf81a05a5`
- Client volume: configured and mounted ACFS/Xsan volume
- Boot used for the direct-write run: release kernel, no `-zp`; the diagnostic
  VM still had `keepsyms=1 amfi_get_out_of_my_way=1`
- Server instrumentation: LLDB modified the legitimate FSM reply to emulate a
  malicious metadata controller

## Network attack surface

ACFS communicates with the FSM over the socket KPI. The exact current kext
imports `sock_socket_internal`, `sock_bind`, `sock_connect`,
`sock_connectwait`, `sock_accept_internal`, `sock_send`, `sock_receive`,
`sock_getpeername`, `sock_setsockopt`, `sock_shutdown`, and `sock_close`, plus
the mbuf routines used to carry socket data.

The concrete call sites include:

```text
0xfffffe000b6d2d18  _MdSockCreate+0x80  -> sock_socket_internal
0xfffffe000b6d2e68  _MdSockCreate+0x1d0 -> sock_bind
0xfffffe000b6d3118  _MdSockConnect+0x17c -> sock_connect
```

`_MdSockAccept` creates a stream/TCP socket explicitly:

```text
0xfffffe000b7146ec  mov  w1,#1       ; SOCK_STREAM
0xfffffe000b7146f8  ldr  w0,[x24,#0x10] ; configured domain
0xfffffe000b714700  mov  w2,#6       ; IPPROTO_TCP
0xfffffe000b71470c  bl   _sock_socket_internal
```

`IPPROTO_TCP` identifies an IP stream socket rather than an AF_UNIX socket.
During the configured mount, FBT also observed `_MdSockRecv` servicing the live
FSM channel. The kext embeds the source paths
`XsanFS/snfs/client/net/fsmcom.c`, `fsm_proxy.c`, and `cvportmap.c`.

This proves that the reply parser consumes data delivered over the Xsan FSM
network channel. It does not prove the configured domain's runtime value in
every deployment or a way to redirect an unconfigured client to an attacker.

## Local request and exact destination allocation

The diagnostic client uses the ACFS VFS sysctl bridge to route private command
`0x20000d32` to `_ExtApiGetExternalRepCmd`. The command copies a 0x60-byte
request. The caller's capacity `B` is at request offset `+0x3c`, and the output
pointer is at `+0x48`.

```text
0xfffffe000b68b744  add  x1,sp,#0x10
0xfffffe000b68b748  mov  x0,x22
0xfffffe000b68b74c  mov  w2,#0x60
0xfffffe000b68b750  bl   _copyin
0xfffffe000b68b760  ldr  w20,[sp,#0x4c]  ; B
0xfffffe000b68b764  cmp  w20,#0x800
0xfffffe000b68b768  b.ls accepted
0xfffffe000b68b774  mov  x0,x20
0xfffffe000b68b780  bl   _cvZoneAlloc
0xfffffe000b68b788  mov  x21,x0           ; exact B-byte allocation
...
0xfffffe000b68b800  bl   _FsmGetExternalRep
```

The `B <= 0x800` check bounds only the allocation request. It does not bound
any server field later used as a record count, stride, or destination offset.

Dynamic authorization testing also corrected the local reachability claim.
The command passes through `_VerifyCvp(cvp, 4, 1, context)`, which produces a
vnode authorization mask of `0xc00`. uid501 received `EPERM` even for a
uid501-owned mode-0777 ACFS file; root advanced to the FSM request. The supplied
trigger must therefore be run as root in this setup.

## Root cause and complete sink-bound audit

`_FsmGetExternalRep` sends request opcode `0x42`. On a successful reply, the
server controls two big-endian fields:

```text
s = bswap32(*(D + 0x1c))
r = ((s + 7) & ~7) + 0x20
t = bswap32(*(D + 0x18))
count = t / r
```

The function then performs one fixed header copy plus an `s`-byte `memmove`
for each record at offset `n*r`:

```text
0xfffffe000b6743e8  ldr  w8,[x24,#0x1c]    ; server s
0xfffffe000b6743ec  rev  w22,w8
0xfffffe000b6743f0  add  w8,w22,#7
0xfffffe000b6743f4  and  w8,w8,#0xfffffff8
0xfffffe000b6743f8  add  w23,w8,#0x20      ; r
0xfffffe000b674400  ldr  w8,[x24,#0x18]    ; server t
0xfffffe000b674404  rev  w8,w8
0xfffffe000b674408  udiv w21,w8,w23         ; count
...
0xfffffe000b674438  add  x8,x24,w20,uxtw   ; source + offset
0xfffffe000b67443c  add  x9,x19,w20,uxtw   ; destination + offset
0xfffffe000b674440  ldr  q0,[x8]
0xfffffe000b674444  rev64.16b v0,v0
0xfffffe000b674448  str  q0,[x9]            ; 16-byte sink
0xfffffe000b67444c  ldr  x10,[x8,#0x10]
0xfffffe000b674454  str  x10,[x9,#0x10]     ; 8-byte sink
0xfffffe000b674458  ldrh w10,[x8,#0x18]
0xfffffe000b674464  strh w10,[x9,#0x18]     ; 2-byte sink
0xfffffe000b674468  add  x0,x9,#0x20
0xfffffe000b67446c  add  x1,x8,#0x20
0xfffffe000b674470  mov  x2,x22             ; s
0xfffffe000b674474  bl   _memmove
0xfffffe000b67447c  add  w20,w20,w23         ; offset += r
0xfffffe000b674480  cmp  x25,x21
0xfffffe000b674484  b.lo loop
```

Every operand of the write sinks is accounted for:

- Destination base `x19`: points to the exact `B`-byte `_cvZoneAlloc`
  allocation. The only bound is `cmp w20,#0x800; b.ls` at
  `0xfffffe000b68b764..0xfffffe000b68b768`, which caps `B` itself.
- Destination offset `w20`: starts at zero and increments by `w23`. No
  instruction compares `w20` to `B` before any store.
- Stride `w23`: derived solely from server `s`. No instruction bounds `s`,
  `s+7`, or the derived stride against `B` or the received payload.
- Loop count `x21`: `t/r`, with `t` supplied independently by the server. No
  instruction bounds `t` or `count` against `B` or actual reply length.
- Store widths: constants 16, 8, and 2. There is no
  `offset+0x1a <= B` check and no aggregate `count*r <= B` check.
- Source base/offset: the same unchecked offset is applied to the reply source.
  There is no per-record source bound against the received reply length.
- Stored value: loaded from the server reply and endian-transformed. In the
  first OOB record of the supplied construction, four accepted wire bytes
  become a fully server-controlled dword in the 16-byte OOB store.

The bug is the gap between the bound on the caller's global allocation size
and the independent, server-controlled fields that actually drive each source
and destination access.

## Exact crafted reply

The direct-write run used:

```text
caller capacity B = 0x800
FSM opcode         = 0x42
s                  = 0
t                  = 0x20000
r                  = 0x20
count              = 0x1000 records
transmitted length = 0x824, the maximum accepted for B=0x800
```

Records 0 through 63 fill the 0x800-byte destination. Record 64 begins at
`output+B`. Four accepted reply bytes (`46 4c 41 47`, ASCII `FLAG`) were placed
at the source location for this record. After `rev64.16b`, they form one fully
server-controlled dword at offsets `+4..+7` of the first 16-byte OOB store.

The high `t` makes the loop continue independently of the short reply. Later
iterations copy adjacent reply-allocation contents as well. That is kernel
memory corruption in addition to the initial partially controlled OOB store;
I do not claim that every byte of every later store is attacker-selected.

## Direct dynamic proof

The primary panic is
`evidence/panic-full-2026-08-23-072214.0002.panic` (SHA-256
`5b91eca70f3a6a3e59a7560837ee083e91e23ee45eac2937be6a6cd590ce5aaf`).

The decisive registers are:

```text
pc   = 0xfffffe001b4e8a68
far  = 0xfffffe2fb9aac000
x9   = 0xfffffe2fb9aac000  ; destination == FAR
x19  = 0xfffffe2fb9aaa800  ; B-byte allocation base
x20  = 0x1800              ; attacker-derived record offset
x21  = 0x1000              ; attacker-derived record count
x23  = 0x20                ; attacker-derived stride
x25  = 0xc0                ; record index 192
x28  = 0x800               ; caller capacity B
esr  = 0x96000047           ; WnR=1, translation fault on write
```

`x19 + x20 == x9 == FAR`. The preceding source `ldr q0,[x8]` completed, and
the destination store faulted. Using the ACFS slide `0xfe74620`:

```text
runtime PC  0xfffffe001b4e8a68
- slide     0x000000000fe74620
= static PC 0xfffffe000b674448
```

Static `0xfffffe000b674448` is exactly `str q0,[x9]` in
`_FsmGetExternalRep`. The panic names ACFS 589.0 with the same kext UUID, and
the panicked task is `acfs_getexternalrep_trigger`.

The first OOB record was index 64. Records 64 through 191 completed before
record 192 hit the unmapped page, so 128 OOB records executed. Each completed
record performs 26 fixed-store bytes across a 32-byte stride, for 0xd00 bytes
written outside the original object across that span.

## Reproduction

Use only a disposable Xsan/ACFS laboratory. A configured client volume and a
metadata-controller process that can return a crafted opcode-`0x42` response
are required.

1. Build the client trigger:

   ```sh
   clang -Wall -Wextra -O2 poc/acfs_getexternalrep_trigger.c \
     -o acfs_getexternalrep_trigger
   ```

2. Mount the configured ACFS volume and identify a path on it.
3. On the metadata controller, intercept `VopGetExternalRep`. The supplied run
   changed the normal lookup result to success at `VopGetExternalRep+0x170`,
   set `t=0x20000`, `s=0`, filled the reply payload, placed `FLAG` at the first
   OOB record's accepted source bytes, and changed the transmitted length to
   `0x824` immediately before `Server_comm_put_message` at
   `VopGetExternalRep+0x230`.
4. On the client, invoke the root-authorized request with `B=0x800`:

   ```sh
   sudo ./acfs_getexternalrep_trigger /Volumes/<volume>/<file> 0x800
   ```

The packaged run immediately panicked at the 16-byte store described above.
The server-side LLDB mutation is diagnostic scaffolding, not a claim that LLDB
is required by a real malicious or compromised controller; such a controller
can construct its own reply bytes before transmission.

## Persistence and duplicate boundary

The same unchecked field loads, division, direct stores, and attacker-sized
`memmove` were verified in archived macOS 27 beta ACFS images from `26A5353q`,
`26A5368g`, `26A5378j`, `26A5378n`, `26A5388g`, and `26A5416b`. This is not a
single-build code-generation regression.

Public Apple security notes contain older Xsan memory-safety CVEs with generic
descriptions, but they do not identify this function, opcode, or count/capacity
invariant. The exact tested current binary remains vulnerable. Apple may still
identify a private or non-public duplicate.

## Security impact

A malicious or compromised Xsan metadata controller can corrupt kernel heap
memory on a configured macOS client by returning an opcode-`0x42` reply whose
record count and stride are inconsistent with the caller's allocation. The
controller selects the repeated destination offsets/count and controls one
dword in the first OOB fixed store in the demonstrated geometry. Confirmed
impact is remote-server-controlled kernel memory corruption and kernel panic.

I do not claim arbitrary-address write, arbitrary 16-byte payload control,
kernel code execution, privilege escalation, uid501 initiation, zero-click
reachability, or a way to force an unconfigured client to connect.

## Suggested fix

Before processing any record or copying data to the caller allocation:

1. validate `s` and the rounded `r` without integer overflow;
2. validate `t` against the actual received reply payload;
3. require the claimed record layout to be internally consistent;
4. require `count*r <= B` (or equivalently bound each record destination);
5. require every source record header and variable body to fit in the received
   payload; and
6. validate the final copyout length against `B` before calling `_copyout`.

The destination checks must use the caller's actual per-request allocation
size, not only the global `B <= 0x800` maximum.
