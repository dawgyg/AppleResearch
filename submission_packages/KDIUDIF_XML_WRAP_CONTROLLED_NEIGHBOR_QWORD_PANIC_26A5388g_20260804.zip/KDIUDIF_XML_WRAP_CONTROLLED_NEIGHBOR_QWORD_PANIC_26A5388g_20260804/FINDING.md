# KDIUDIF XML-length wrap: controlled adjacent qword write and delayed zone panic

## Verdict

On macOS 27 beta 4 `26A5388g`, a uid501-crafted UDIF caused the root kernel
to copy `0x20` attacker-controlled bytes into an `IOMallocData(0)` destination
backed by a 16-byte `data.kalloc.16` element. DTrace observed the controlled
second qword in the immediately adjacent element, and the kernel later panicked
with the zone detector naming that exact adjacent address, offset, and value.

This is direct evidence of an attacker-controlled cross-object kernel heap
write. It is separate from the queued-kmsg UAF proof and from the two already
filed KDIUDIF issues. It is not a completed PC-control exploit.

## Environment

- VM: `vm388g-apfs`, uid501 `testtest`, SIP off / DTrace enabled
- Build: macOS 27.0 `26A5388g`
- Vulnerable boot: `EF7BC708-2F7A-49A8-A907-CB8F103FC908`
- Run: `tail32_kmsg_subst_EF7BC708_r51`
- Full artifacts:
  `/Users/dawgyg/re_work/kdiudif_fixdiff/credlabel_valid_free_runs/20260804T-current-r51-controlled-neighbor-qword-delayed-panic/`

## Exact correlation

The crafted payload selected the live kernel pointer:

```text
P = 0xfffffe2fae84a000
```

The patch record proves that `P` was placed in the attacker-controlled second
qword of the 16-byte overflow tail:

```text
pattern_relative=0x10 qword0=0x0 qword1=0xfffffe2fae84a000
```

For malformed read sequence 7, the vulnerable parser allocated:

```text
D = 0xfffffe2facb73990
allocation size = 0 (IOMallocData(0) -> data.kalloc.16)
backing read length = 0x20
```

DTrace captured both sides of the sink:

```text
1785613698872704874 DESTINATION_READY seq=7
  destination=0xfffffe2facb73990 neighbor0=0x0 neighbor1=0x0

1785613698872722416 READ_RETURN seq=7
  destination=0xfffffe2facb73990 bytes_read=0x20
  neighbor0=0x0 neighbor1=0xfffffe2fae84a000
```

Thus the read wrote:

```text
D + 0x10 = 0x0000000000000000
D + 0x18 = P
```

The immediately adjacent 16-byte element starts at `D + 0x10`:

```text
N = 0xfffffe2facb739a0
N + 8 = 0xfffffe2facb739a8
```

About 164.987 seconds later, the kernel zone detector reported exactly that
object and value:

```text
[data.kalloc.16]: element modified after free
off:8
val:0xfffffe2fae84a000
sz:16
ptr:0xfffffe2facb739a0
```

The address arithmetic closes the attribution:

```text
panic ptr - vulnerable destination = 0x10
panic off 8 address               = D + 0x18
panic value                       = attacker-selected qword1 P
```

The chain log called this `RECYCLE_MISS` only because `D` did not equal the
planned ASP target slot. That does not negate the overflow: the malformed read
still wrote its controlled tail into the actual adjacent `data.kalloc.16`
object, which the delayed panic then detected.

## Root-context consumer

The panicked task was root `opendirectoryd` (pid 143). The kext frames
symbolicate in `AppleVPKeyStore` as:

```text
_find_user_slot_with_ps + 220
ipc_identity_operation + 908
compact_bag_unlock_with_bag_if_necessary + 336
passcode_cache_if_enabled + 196
ipc_perform_operation + 2572
fv_create_pdk + 4
_operation_ref_key_ecies_op + 712
fv_unwrap_and_migrate_vek + 488
fv_stash_reboot + 60
```

This shows an unrelated privileged subsystem later touched allocator state
corrupted by the uid501-triggered KDIUDIF write.

## Key evidence hashes

```text
349e7e59a674e142c63e03e45e02c12709c9aa53d9424d3f9682e5f8c4f20757  panic-full-2026-08-01-125111.0002.panic
064713ecdb2ec5ad0c4f2ee0355ece742046c76b56727f85979d85cb6b54e279  current.contents.panic
81bfbd9f8c5ff27b707ebb79dd25eb38060b1f89f8434a51422918d414deb5c1  tail32_kmsg_subst_EF7BC708_r51.chain.log
77a238c7d9e594235bc1ef288f8e143ddb710cc3d046604fa6ab0ab28bef8987  tail32_kmsg_subst_EF7BC708_r51.labels.log
5dd87d5ae83107e8921f76b1091216049f19e71b35401d453b85b36e4790e5d8  tail32_kmsg_subst_EF7BC708_r51.preflight.log
a5cfcd75b6c396e9f2c3c627d6180c580bfd431757c4e77679030d96cd292e5a  tail32_kmsg_subst_EF7BC708_r51.summary.log
```

## Related evidence

- Strict queued-kmsg UAF:
  `vrp_kernel_kdiudif_xml_wrap_strict_queued_kmsg_uaf_26A5388g_20260804.md`
- Earlier queued-kmsg panic:
  `vrp_kernel_kdiudif_xml_wrap_queued_kmsg_uaf_panic_26A5388g_20260804.md`
- Base XML-length-wrap analysis:
  `vrp_kernel_kdiudif_xml_length_wrap_toctou_heap_corruption_26A5388g_20260803.md`
