#include <mach/mach.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

static volatile sig_atomic_t receive_requested;
static volatile sig_atomic_t send_requested;
static volatile sig_atomic_t replacement_requested;
static volatile sig_atomic_t stop_requested;

static void
handle_signal(int signo)
{
    if (signo == SIGUSR1) {
        receive_requested = 1;
    } else if (signo == SIGUSR2) {
        send_requested = 1;
    } else if (signo == SIGHUP) {
        replacement_requested = 1;
    } else {
        stop_requested = 1;
    }
}

static int
install_handler(int signo)
{
    struct sigaction action;

    memset(&action, 0, sizeof(action));
    action.sa_handler = handle_signal;
    sigemptyset(&action.sa_mask);
    return sigaction(signo, &action, NULL);
}

static void
prepare_message(uint8_t *buffer, mach_msg_size_t size, mach_port_t port,
    uint64_t marker, mach_msg_id_t message_id)
{
    mach_msg_header_t *header = (mach_msg_header_t *)buffer;
    size_t offset;

    memset(buffer, 0, size);
    header->msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, 0);
    header->msgh_size = size;
    header->msgh_remote_port = port;
    header->msgh_local_port = MACH_PORT_NULL;
    header->msgh_voucher_port = MACH_PORT_NULL;
    header->msgh_id = message_id;
    for (offset = sizeof(*header); offset + sizeof(marker) <= size;
        offset += sizeof(marker)) {
        memcpy(buffer + offset, &marker, sizeof(marker));
    }
}

int
main(int argc, char **argv)
{
    mach_msg_size_t size = 0x3d4;
    mach_msg_size_t receive_size;
    mach_port_t port = MACH_PORT_NULL;
    mach_port_limits_t limits;
    uint8_t *send_buffer = NULL;
    uint8_t *receive_buffer = NULL;
    mach_msg_header_t *header;
    uint64_t marker;
    uint64_t replacement_marker = 0;
    uint64_t first_payload = 0;
    kern_return_t kr;
    size_t marker_matches = 0;
    size_t marker_total = 0;
    size_t offset;
    unsigned int replacement_sequence = 0;
    int deferred = 0;
    int arg_index = 1;
    int status = 0;

    if (arg_index < argc && strcmp(argv[arg_index], "--deferred") == 0) {
        deferred = 1;
        arg_index++;
    }
    if (arg_index < argc) {
        size = (mach_msg_size_t)strtoul(argv[arg_index], NULL, 0);
        arg_index++;
    }
    if (arg_index != argc) {
        fprintf(stderr, "usage: %s [--deferred] [message-size]\n", argv[0]);
        return 64;
    }
    if (size < sizeof(mach_msg_header_t) || size > 0x4000) {
        fprintf(stderr, "invalid message size 0x%x\n", size);
        return 64;
    }
    if (install_handler(SIGUSR1) != 0 || install_handler(SIGUSR2) != 0 ||
        install_handler(SIGHUP) != 0 ||
        install_handler(SIGINT) != 0 || install_handler(SIGTERM) != 0) {
        perror("sigaction");
        return 1;
    }
    setvbuf(stdout, NULL, _IOLBF, 0);

    receive_size = size + (mach_msg_size_t)sizeof(mach_msg_max_trailer_t);
    send_buffer = calloc(1, size);
    receive_buffer = calloc(1, receive_size);
    if (send_buffer == NULL || receive_buffer == NULL) {
        perror("calloc");
        status = 1;
        goto out;
    }

    kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE, &port);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "mach_port_allocate: %s\n", mach_error_string(kr));
        status = 1;
        goto out;
    }
    kr = mach_port_insert_right(mach_task_self(), port, port,
        MACH_MSG_TYPE_MAKE_SEND);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "mach_port_insert_right: %s\n", mach_error_string(kr));
        status = 1;
        goto out;
    }
    limits.mpl_qlimit = MACH_PORT_QLIMIT_LARGE;
    kr = mach_port_set_attributes(mach_task_self(), port,
        MACH_PORT_LIMITS_INFO, (mach_port_info_t)&limits,
        MACH_PORT_LIMITS_INFO_COUNT);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "mach_port_set_attributes: %s\n",
            mach_error_string(kr));
        status = 1;
        goto out;
    }

    header = (mach_msg_header_t *)send_buffer;
    marker = 0x4b4d534700000000ULL | (uint64_t)size;
    prepare_message(send_buffer, size, port, marker,
        0x4b4d0000 | (mach_msg_id_t)size);

    if (deferred) {
        printf("ARMED pid=%d size=0x%x marker=0x%llx port=0x%x\n",
            getpid(), size, (unsigned long long)marker, port);
        while (!stop_requested && !send_requested) {
            pause();
        }
        if (stop_requested) {
            goto out;
        }
    }

    printf("SEND_BEGIN pid=%d size=0x%x marker=0x%llx port=0x%x\n",
        getpid(), size, (unsigned long long)marker, port);
    kr = mach_msg(header, MACH_SEND_MSG, size, 0, MACH_PORT_NULL,
        MACH_MSG_TIMEOUT_NONE, MACH_PORT_NULL);
    printf("SEND_END pid=%d size=0x%x kr=0x%x\n", getpid(), size, kr);
    if (kr != KERN_SUCCESS) {
        status = 1;
        goto out;
    }
    printf("READY pid=%d size=0x%x marker=0x%llx port=0x%x\n",
        getpid(), size, (unsigned long long)marker, port);

    for (;;) {
        while (!stop_requested && !receive_requested &&
            !replacement_requested) {
            pause();
        }
        if (stop_requested || receive_requested) {
            break;
        }

        replacement_requested = 0;
        replacement_sequence++;
        replacement_marker = 0x52504c4700000000ULL |
            (uint64_t)replacement_sequence;
        prepare_message(send_buffer, size, port, replacement_marker,
            0x52500000 | (mach_msg_id_t)(replacement_sequence & 0xffff));
        printf(
            "REPLACEMENT_SEND_BEGIN pid=%d seq=%u size=0x%x "
            "marker=0x%llx port=0x%x\n",
            getpid(), replacement_sequence, size,
            (unsigned long long)replacement_marker, port);
        kr = mach_msg(header, MACH_SEND_MSG | MACH_SEND_TIMEOUT, size, 0,
            MACH_PORT_NULL, 0, MACH_PORT_NULL);
        printf(
            "REPLACEMENT_SEND_END pid=%d seq=%u size=0x%x kr=0x%x\n",
            getpid(), replacement_sequence, size, kr);
        if (kr != KERN_SUCCESS) {
            status = 1;
            goto out;
        }
        printf(
            "REPLACEMENT_READY pid=%d seq=%u size=0x%x marker=0x%llx "
            "port=0x%x\n",
            getpid(), replacement_sequence, size,
            (unsigned long long)replacement_marker, port);
    }
    if (receive_requested && !stop_requested) {
        mach_msg_header_t *received = (mach_msg_header_t *)receive_buffer;

        printf("RECV_BEGIN pid=%d size=0x%x port=0x%x\n",
            getpid(), size, port);
        kr = mach_msg(received, MACH_RCV_MSG | MACH_RCV_TIMEOUT, 0,
            receive_size, port, 2000, MACH_PORT_NULL);
        if (kr == KERN_SUCCESS) {
            mach_msg_size_t received_size = received->msgh_size;

            if (sizeof(*received) + sizeof(first_payload) <= received_size) {
                memcpy(&first_payload, receive_buffer + sizeof(*received),
                    sizeof(first_payload));
            }

            for (offset = sizeof(*received);
                offset + sizeof(marker) <= received_size;
                offset += sizeof(marker)) {
                uint64_t value;

                memcpy(&value, receive_buffer + offset, sizeof(value));
                marker_total++;
                if (value == marker) {
                    marker_matches++;
                }
            }
            printf(
                "RECV_END pid=%d kr=0x%x received_size=0x%x id=0x%x "
                "marker_matches=%zu marker_total=%zu first_payload=0x%llx\n",
                getpid(), kr, received_size, received->msgh_id,
                marker_matches, marker_total,
                (unsigned long long)first_payload);
        } else {
            printf("RECV_END pid=%d kr=0x%x error=%s\n",
                getpid(), kr, mach_error_string(kr));
            status = 1;
        }
    }

    while (!stop_requested) {
        pause();
    }

out:
    if (port != MACH_PORT_NULL) {
        mach_port_destruct(mach_task_self(), port, -1, 0);
    }
    free(receive_buffer);
    free(send_buffer);
    return status;
}
