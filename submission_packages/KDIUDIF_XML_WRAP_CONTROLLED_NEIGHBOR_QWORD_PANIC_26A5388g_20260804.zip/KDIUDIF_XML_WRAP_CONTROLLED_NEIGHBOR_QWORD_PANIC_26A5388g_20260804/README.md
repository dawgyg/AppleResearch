# KDIUDIF controlled adjacent-qword write addendum

This addendum contains the strongest direct cross-object write evidence from
run `tail32_kmsg_subst_EF7BC708_r51` on macOS 27 beta 4 `26A5388g`.

Start with `FINDING.md`. The essential proof is:

1. The crafted UDIF placed `0xfffffe2fae84a000` in its second overflow qword.
2. DTrace captured a `0x20` read into the 16-byte allocation at
   `0xfffffe2facb73990` and observed that value at destination `+0x18`.
3. The delayed panic named the adjacent object at destination `+0x10`, offset
   `+8`, with exactly the same value.

`evidence/` contains the full panic, DTrace log, chain log, patch record,
manifest, preflight, and summary. `poc/` contains the exact helper and harness
versions used by the continuing exploit-development campaign.

This proves an attacker-controlled kernel heap write into an adjacent object.
It does not claim completed PC control.
