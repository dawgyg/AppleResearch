#include <dispatch/dispatch.h>
#include <mach/mach_time.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/attr.h>
#include <time.h>
#include <unistd.h>
#include <xpc/xpc.h>

struct request_state {
    xpc_connection_t connection;
    const char *path;
    atomic_bool started;
    bool success;
    uint64_t elapsed_ticks;
};

static void
sleep_ns(uint64_t nanoseconds)
{
    if (nanoseconds == 0)
        return;

    struct timespec delay = {
        .tv_sec = (time_t)(nanoseconds / 1000000000ULL),
        .tv_nsec = (long)(nanoseconds % 1000000000ULL),
    };
    nanosleep(&delay, NULL);
}

static void *
send_request(void *opaque)
{
    struct request_state *state = opaque;
    xpc_object_t request = xpc_dictionary_create(NULL, NULL, 0);
    xpc_dictionary_set_string(request, "op", "SynchronizeUsers");
    xpc_dictionary_set_string(request, "path", state->path);

    atomic_store_explicit(&state->started, true, memory_order_release);
    uint64_t start = mach_absolute_time();
    xpc_object_t reply = xpc_connection_send_message_with_reply_sync(
        state->connection, request);
    state->elapsed_ticks = mach_absolute_time() - start;
    state->success = reply && xpc_get_type(reply) == XPC_TYPE_DICTIONARY &&
        xpc_dictionary_get_bool(reply, "status");
    if (reply)
        xpc_release(reply);
    xpc_release(request);
    return NULL;
}

int
main(int argc, char **argv)
{
    if (argc != 7) {
        fprintf(stderr,
            "usage: %s link-path target-a target-b attempts "
            "switch-delay-ns b-hold-ns\n", argv[0]);
        return 64;
    }

    const char *current = argv[1];
    const char *target_a = argv[2];
    const char *target_b = argv[3];
    char *end = NULL;
    unsigned long attempts = strtoul(argv[4], &end, 0);
    if (!end || *end != '\0' || attempts == 0)
        return 64;
    uint64_t switch_delay_ns = strtoull(argv[5], &end, 0);
    if (!end || *end != '\0')
        return 64;
    uint64_t hold_ns = strtoull(argv[6], &end, 0);
    if (!end || *end != '\0')
        return 64;

    size_t alternate_len = strlen(current) + sizeof(".alternate");
    char *alternate = malloc(alternate_len);
    if (!alternate)
        return 1;
    snprintf(alternate, alternate_len, "%s.alternate", current);

    unlink(current);
    unlink(alternate);
    if (symlink(target_a, current) != 0 || symlink(target_b, alternate) != 0) {
        perror("symlink");
        return 1;
    }

    xpc_connection_t connection = xpc_connection_create_mach_service(
        "com.apple.corestorage.corestoragehelperd", NULL, 0);
    if (!connection)
        return 1;
    xpc_connection_set_event_handler(connection, ^(xpc_object_t event) {
        if (xpc_get_type(event) == XPC_TYPE_ERROR) {
            const char *description = xpc_dictionary_get_string(
                event, XPC_ERROR_KEY_DESCRIPTION);
            fprintf(stderr, "connection event: %s\n",
                description ? description : "unknown error");
        }
    });
    xpc_connection_resume(connection);

    mach_timebase_info_data_t timebase;
    mach_timebase_info(&timebase);
    unsigned long success = 0;
    unsigned long failure = 0;
    uint64_t total_ns = 0;

    for (unsigned long i = 0; i < attempts; i++) {
        struct request_state state = {
            .connection = connection,
            .path = current,
        };
        atomic_init(&state.started, false);

        pthread_t thread;
        if (pthread_create(&thread, NULL, send_request, &state) != 0) {
            perror("pthread_create");
            return 1;
        }
        while (!atomic_load_explicit(&state.started, memory_order_acquire))
            sched_yield();
        sleep_ns(switch_delay_ns);
        if (renameatx_np(AT_FDCWD, current, AT_FDCWD, alternate,
                         RENAME_SWAP) != 0) {
            perror("swap-to-b");
            return 1;
        }
        sleep_ns(hold_ns);
        if (renameatx_np(AT_FDCWD, current, AT_FDCWD, alternate,
                         RENAME_SWAP) != 0) {
            perror("swap-to-a");
            return 1;
        }
        pthread_join(thread, NULL);

        uint64_t elapsed_ns = state.elapsed_ticks * timebase.numer /
            timebase.denom;
        total_ns += elapsed_ns;
        if (state.success)
            success++;
        else
            failure++;
    }

    printf("uid=%u attempts=%lu success=%lu failure=%lu "
           "switch_delay_ns=%llu hold_ns=%llu average_request_ns=%llu\n",
        getuid(), attempts, success, failure,
        (unsigned long long)switch_delay_ns,
        (unsigned long long)hold_ns,
        (unsigned long long)(total_ns / attempts));
    return failure ? 2 : 0;
}
