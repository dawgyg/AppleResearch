# corestoragehelperd SynchronizeUsers cross-volume evidence

Current baseline: macOS 27.0 `26A5416b`.

The highest-signal proof is `root_owned_target_uid501_race_capture.txt`:
uid501 changes FDE OSUser metadata on a CoreStorage volume backed by
`/var/root/CoreStorageVictim.raw`, which is `root:wheel 0600` and unreadable by
uid501. The family sequence advances and the root-only raw-image hash changes.

`direct_uid501_commit_control.txt` shows that direct uid501
`CoreStorageCommitVolumeFamily` fails and makes no change.
`root_direct_commit_positive_control.txt` shows the same probe succeeds as
uid0, proving the helper supplied the missing commit privilege.

The racer primes an attacker-owned offline OpenDirectory node through one
symlink pathname, then atomically swaps that pathname between attacker volume A
and root-owned CoreStorage volume B while sending the ungated
`SynchronizeUsers` XPC operation.

The mismatch-GUID deletion experiment is included as a negative control. The
binary deliberately protects the final OSUser, so this package does not claim
total volume lockout or LPE.

