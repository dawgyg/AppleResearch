# Codex -> Claude: uid501 persistent write to root-owned CoreStorage FDE metadata

## Verdict

**PROVEN current-build cross-privilege write, separate report candidate.**

On macOS 27.0 `26A5416b`, uid501 can call root
`/usr/libexec/corestoragehelperd` operation `SynchronizeUsers` without an
authorization or entitlement check. A symlink/path-identity race makes the
helper bind OpenDirectory records from attacker volume A, then freshly resolve
the same submitted path to root-owned CoreStorage volume B. The helper commits
A-controlled OSUser metadata into B as root.

This was repeated against a target whose backing image was
`/var/root/CoreStorageVictim.raw`, `root:wheel 0600`. uid501 could neither list
nor read that file, but the helper advanced B's CoreStorage family sequence
from `5` to `6`, replaced the FDE hint/full-name/user-name data, and changed the
root-only backing file's SHA-256.

This is not yet LPE or a target flag. It is a persistent root storage
permission-bypass/integrity bug. The final-user deletion lane is deliberately
defended, described below.

## Current baseline

- Host and VM: macOS 27.0 build `26A5416b`.
- Host kernel: xnu `13432.1.9~3`, `RELEASE_ARM64_T6000`.
- Matching KDK installed: `KDK_27.0_26A5416b.kdk`.
- `softwareupdate --list` on 2026-08-20: no newer software available.
- `corestoragehelperd` SHA-256:
  `63c169686ed4c8627a5d650a57b17034a801e46fca244b2f3f2fad69ae640a60`.

## Exact static mechanism

Binary vaddrs below are unslid arm64e addresses.

### Ungated XPC dispatch

- `0x100001734` loads literal `SynchronizeUsers`.
- `0x100001740` calls `strcmp`.
- `0x100001744` branches directly to the handler at `0x1000018c0`.
- No audit-token, euid, authorization, entitlement, or sandbox check is made
  on this branch. Dynamic caller identity was uid501.

### Path check validates a transient name, not an identity

- `0x1000018cc`: `xpc_dictionary_get_string(request, "path")`.
- `0x1000018dc..0x1000018e4`: only length `1..1023` is accepted.
- `0x1000018ec`: calls validator `0x1000022d8`.
- Validator `0x100002358`: `statfs(submitted_path, &sfs)`.
- `0x100002364..0x100002370`: accepts when the resolved mount-point string at
  `statfs+0x58` has length greater than one, excluding only root mount `/`.
- It retains no fd, vnode, device ID, mount ID, or canonical path.

### First resolution: attacker OpenDirectory node A

- `0x100001a0c`: calls synchronization routine `0x1000009d0` with the original
  submitted C-string path.
- `0x100000a04..0x100000a20`: constructs
  `<path>/var/db/dslocal/nodes/Default`.
- `0x100000a2c..0x100000a68`: builds an `ODSession` with
  `kODSessionLocalPath`.
- `0x100000a94`: `ODNodeCreateWithNodeType` binds the offline node.
- The resulting node is retained in the synchronization block.

### Second resolution: root-owned CoreStorage volume B

- `0x100000b14`: passes the original submitted path plus the already-created
  OD-backed block to routine `0x100001ec8`.
- `0x100001f30..0x100001f34`:
  `CoreStorageCopyFamilyPropertiesForMount(original_path)` freshly resolves
  the mutable path and obtains B's family.
- `0x100001f50..0x100001f5c`: invokes the block, which reads A's OD records and
  updates B's encryption context.
- The update block reads `AuthenticationHint`, `FullName`, `JPEGPhoto`, record
  names, and related display data, then calls `CSFDEAddOSUserEntry` at
  `0x100001e48` for an existing matching FDE user.
- `0x100001f64..0x100001f68`: `CSFDEUpdateTimeStamp(B.context)`.
- `0x100001f70..0x100001f78`: `CoreStorageCommitVolumeFamily(B.family, ...)`.
- `0x100001f80..0x100001fb0`: then spawns root
  `/usr/sbin/kextcache -quiet -update-volume <original_path>` using the same
  still-mutable path. This is an open upgrade lane, not claimed as exploited.

## Dynamic proof: root-owned target

Target before:

- Backing path: `/var/root/CoreStorageVictim.raw`.
- Owner/mode: `root:wheel 0600`.
- uid501 `ls` and `dd` both returned `Permission denied`.
- SHA-256 before:
  `5ac6a037f22f6a3135e36c356d96340b87236468b8dcf10cc3478655b20f62e4`.
- CoreStorage family sequence: `5`.
- FDE metadata: `UID501-CONTROLLED-HINT` / `UID 501 Controlled`.

Attacker source A:

- Image file is owned by uid501.
- uid501 mounts it with `--mountOptions noowners`, edits the plist record,
  then remounts with `--mountOptions owners`.
- The latter exposes the image-encoded local node as `root:wheel`, with no
  sudo used for either attach.
- Chosen values:
  `ROOT-TARGET-WRITTEN-BY-UID501` /
  `Root Target Written By UID 501`.

Race:

- Caller/racer process: user `testtest`, uid `501`.
- Prime the symlink path once while it points to A, then atomically
  `RENAME_SWAP` it between A and B while issuing `SynchronizeUsers`.
- The root-owned target changed by poll 4 (about 200 ms in this run).

Target after:

- Family sequence: `6`.
- `PassphraseHint = ROOT-TARGET-WRITTEN-BY-UID501`.
- `UserFullName = Root Target Written By UID 501`.
- `UserNamesData` also contains the attacker record/name values.
- `LastUpdateTime` advanced to `1787218989`.
- SHA-256 after:
  `cdd2a531b5c1d80208ae190695b3748dee045b79ec84d4e845a409c4e226facf`.
- Backing file remained `root:wheel 0600` and unreadable by uid501.

## Direct-API controls prove the helper supplies privilege

The same `corestorage_direct_commit_probe` was run against the root-owned B:

- uid501: `CSFDEUpdateTimeStamp=1`, but
  `CoreStorageCommitVolumeFamily=0`; sequence and timestamp did not change.
- uid0 positive control: the same probe returned commit `1`; sequence advanced
  `6 -> 7` and timestamp changed.

Thus the successful uid501 write is not ordinary public CoreStorage commit
access. It crosses the commit permission through root `corestoragehelperd`.

## Honest deletion ceiling

`SynchronizeUsers` imports `CSFDERemoveUserEntry`, but it will not remove the
last OSUser unless another unlock-class entry exists:

- `0x100000f94..0x100000fa0`: computes remaining OSUsers and branches to
  removal only when more than one remains.
- `0x100000fa8..0x100000fac`: otherwise removal requires the auxiliary-entry
  boolean.
- `0x100000fb0..0x100000fc8`: logs `Did not remove orphaned OSUser` and skips
  the removal when both conditions are false.
- Actual removal call is `0x100000fd4`.

Dynamic mismatch-GUID testing left the sole OSUser and family sequence intact,
matching the static guard. Do not claim total encrypted-volume lockout from
this build.

## Evidence and PoC

Primary evidence directory:

`/Users/dawgyg/codex_scratch/corestoragehelperd_26A5416b/evidence/sync_race/`

Ready evidence zip:

`/Users/dawgyg/submission_packages/_PENDING_CORESTORAGEHELPERD_26A5416b_UID501_ROOT_OWNED_FDE_METADATA_WRITE_20260820.zip`

ZIP SHA-256:

`4c33667bb74684727e2cb38210bc15f3fa21db2975d4cdb25d8a2a87be2e999c`

Highest-signal files:

- `root_target_preparation.txt`
- `root_target_mounted_before_race.txt`
- `root_owned_target_uid501_race_capture.txt`
- `uid501_edit_and_ownership_remount.txt`
- `direct_uid501_commit_control.txt`
- `root_direct_commit_positive_control.txt`
- `corestoragehelperd_sync_race.c`
- `corestorage_direct_commit_probe.c`

## Recommendation / next owner

This is ready to package as a separate current-build logic/TOCTOU report, with
impact framed as persistent unauthorized modification of root-owned encrypted
storage metadata. The best upgrade lane is the post-commit root `kextcache`
path reuse at `0x100001f90`: determine whether a later swap can make it perform
a security-significant host write or consume attacker-controlled extension
content outside the already-modified volume. Avoid claiming LPE until that
consumer produces code execution or a host-root write.
