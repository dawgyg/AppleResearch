#include <CoreFoundation/CoreFoundation.h>

#include <dlfcn.h>
#include <stdio.h>

typedef CFMutableDictionaryRef (*create_default_context_fn)(void);
typedef Boolean (*add_volume_encryption_fn)(
    CFMutableDictionaryRef, CFStringRef, CFStringRef *);
typedef Boolean (*add_os_user_entry_fn)(
    CFMutableDictionaryRef, CFStringRef, CFStringRef, CFStringRef,
    CFStringRef, CFTypeRef, CFStringRef, CFDataRef, CFTypeRef);
typedef CFStringRef (*store_passphrase_fn)(const char *);
typedef void (*remove_secret_fn)(CFStringRef);
typedef CFArrayRef (*copy_user_entries_fn)(CFDictionaryRef, uint32_t);

static void print_cf(const char *label, CFTypeRef value) {
    fprintf(stderr, "%s type=%lu value=", label,
            value ? (unsigned long)CFGetTypeID(value) : 0UL);
    if (value) {
        CFShow(value);
    } else {
        fprintf(stderr, "(null)\n");
    }
}

int main(void) {
    void *handle = dlopen("/usr/lib/libcsfde.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!handle) {
        fprintf(stderr, "dlopen: %s\n", dlerror());
        return 1;
    }

    create_default_context_fn create_default =
        (create_default_context_fn)dlsym(handle, "CSFDECreateDefaultContext");
    add_volume_encryption_fn add_volume_encryption =
        (add_volume_encryption_fn)dlsym(
            handle, "CSFDEAddVolumeEncryption");
    add_os_user_entry_fn add_os_user_entry =
        (add_os_user_entry_fn)dlsym(handle, "CSFDEAddOSUserEntry");
    store_passphrase_fn store_passphrase =
        (store_passphrase_fn)dlsym(handle, "CSFDEStorePassphrase");
    remove_secret_fn remove_passphrase =
        (remove_secret_fn)dlsym(handle, "CSFDERemovePassphrase");
    remove_secret_fn remove_key =
        (remove_secret_fn)dlsym(handle, "CSFDERemoveKey");
    copy_user_entries_fn copy_entries =
        (copy_user_entries_fn)dlsym(handle, "CSFDECopyUserEntriesOfType");
    if (!create_default || !add_volume_encryption || !add_os_user_entry ||
        !store_passphrase || !remove_passphrase || !remove_key ||
        !copy_entries) {
        fprintf(stderr, "dlsym: %s\n", dlerror());
        return 2;
    }

    CFMutableDictionaryRef context = create_default();
    if (!context) {
        fprintf(stderr, "CSFDECreateDefaultContext returned NULL\n");
        return 3;
    }

    print_cf("context.before", context);

    CFStringRef kek = NULL;
    Boolean added_volume = add_volume_encryption(
        context, CFSTR("AES-XTS"), &kek);
    fprintf(stderr, "add-volume=%d\n", added_volume);
    print_cf("kek", kek);
    print_cf("context.after-volume", context);

    Boolean added_user = false;
    CFStringRef passphrase_handle = NULL;
    if (added_volume && kek)
        passphrase_handle = store_passphrase("codex-test-passphrase");
    print_cf("passphrase-handle", passphrase_handle);
    if (passphrase_handle) {
        added_user = add_os_user_entry(
            context,
            kek,
            CFSTR("AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"),
            passphrase_handle,
            CFSTR("codex-hint"),
            NULL,
            CFSTR("Codex Test User"),
            NULL,
            NULL);
    }
    fprintf(stderr, "add-user=%d\n", added_user);
    print_cf("context.after-user", context);

    const uint32_t types[] = {
        0x10000001U,
        0x10000002U,
        0x10060002U,
    };
    for (size_t i = 0; i < sizeof(types) / sizeof(types[0]); ++i) {
        CFArrayRef entries = copy_entries(context, types[i]);
        char label[64];
        snprintf(label, sizeof(label), "entries-0x%08x", types[i]);
        print_cf(label, entries);
        if (entries) {
            CFRelease(entries);
        }
    }

    if (passphrase_handle) {
        remove_passphrase(passphrase_handle);
        CFRelease(passphrase_handle);
    }
    if (kek) {
        remove_key(kek);
        CFRelease(kek);
    }
    CFRelease(context);
    dlclose(handle);
    return 0;
}
