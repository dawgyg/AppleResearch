#include <CoreFoundation/CoreFoundation.h>

#include <dlfcn.h>
#include <stdio.h>
#include <unistd.h>

typedef CFMutableDictionaryRef (*copy_family_for_mount_fn)(const char *);
typedef Boolean (*update_timestamp_fn)(CFMutableDictionaryRef);
typedef Boolean (*commit_family_fn)(CFDictionaryRef, uint8_t *);

int
main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s mount-path\n", argv[0]);
        return 64;
    }

    void *core = dlopen(
        "/usr/lib/libCoreStorage.dylib", RTLD_NOW | RTLD_LOCAL);
    void *fde = dlopen("/usr/lib/libcsfde.dylib", RTLD_NOW | RTLD_LOCAL);
    copy_family_for_mount_fn copy_family = core ?
        (copy_family_for_mount_fn)dlsym(
            core, "CoreStorageCopyFamilyPropertiesForMount") : NULL;
    update_timestamp_fn update_timestamp = fde ?
        (update_timestamp_fn)dlsym(fde, "CSFDEUpdateTimeStamp") : NULL;
    commit_family_fn commit_family = core ?
        (commit_family_fn)dlsym(core, "CoreStorageCommitVolumeFamily") : NULL;
    if (!copy_family || !update_timestamp || !commit_family) {
        fprintf(stderr, "symbol lookup failed: %s\n", dlerror());
        return 1;
    }

    CFMutableDictionaryRef family = copy_family(argv[1]);
    if (!family) {
        fprintf(stderr, "family lookup failed\n");
        return 2;
    }
    CFMutableDictionaryRef context = (CFMutableDictionaryRef)
        CFDictionaryGetValue(
            family, CFSTR("com.apple.corestorage.lvf.encryption.context"));
    if (!context) {
        fprintf(stderr, "encryption context missing\n");
        CFRelease(family);
        return 3;
    }

    Boolean updated = update_timestamp(context);
    uint8_t changed = 0;
    Boolean committed = updated ? commit_family(family, &changed) : false;
    printf("uid=%u update_timestamp=%d commit=%d changed=%u\n",
        getuid(), updated, committed, changed);
    CFRelease(family);
    return committed ? 0 : 4;
}
