#include <CoreFoundation/CoreFoundation.h>

#include <dlfcn.h>
#include <errno.h>
#include <inttypes.h>
#include <stdio.h>
#include <stdlib.h>

typedef CFMutableDictionaryRef (*create_family_dict_fn)(CFStringRef);
typedef CFMutableDictionaryRef (*create_volume_dict_fn)(
    CFStringRef, CFStringRef, uint64_t);
typedef CFStringRef (*create_volume_fn)(CFDictionaryRef, CFDictionaryRef);

typedef CFMutableDictionaryRef (*create_default_context_fn)(void);
typedef Boolean (*add_volume_encryption_fn)(
    CFMutableDictionaryRef, CFStringRef, CFStringRef *);
typedef Boolean (*add_os_user_entry_fn)(
    CFMutableDictionaryRef, CFStringRef, CFStringRef, CFStringRef,
    CFStringRef, CFTypeRef, CFStringRef, CFDataRef, CFTypeRef);
typedef CFStringRef (*store_passphrase_fn)(const char *);
typedef void (*remove_secret_fn)(CFStringRef);

static void
print_cf(const char *label, CFTypeRef value)
{
    fprintf(stderr, "%s type=%lu value=", label,
        value ? (unsigned long)CFGetTypeID(value) : 0UL);
    if (value)
        CFShow(value);
    else
        fprintf(stderr, "(null)\n");
}

static void *
load_symbol(void *handle, const char *name)
{
    void *symbol = dlsym(handle, name);
    if (!symbol)
        fprintf(stderr, "dlsym(%s): %s\n", name, dlerror());
    return symbol;
}

int
main(int argc, char **argv)
{
    if (argc != 3) {
        fprintf(stderr, "usage: %s group-uuid size-bytes\n", argv[0]);
        return 64;
    }

    errno = 0;
    char *end = NULL;
    uint64_t size = strtoull(argv[2], &end, 0);
    if (errno || !end || *end != '\0' || size < (64ULL << 20)) {
        fprintf(stderr, "invalid size: %s\n", argv[2]);
        return 64;
    }

    void *core = dlopen(
        "/usr/lib/libCoreStorage.dylib", RTLD_NOW | RTLD_LOCAL);
    void *fde = dlopen("/usr/lib/libcsfde.dylib", RTLD_NOW | RTLD_LOCAL);
    if (!core || !fde) {
        fprintf(stderr, "dlopen: %s\n", dlerror());
        return 1;
    }

    create_family_dict_fn create_family = (create_family_dict_fn)
        load_symbol(core, "CoreStorageCreateDictForFamily");
    create_volume_dict_fn create_volume_dict = (create_volume_dict_fn)
        load_symbol(core, "CoreStorageCreateDictForVolume");
    create_volume_fn create_volume =
        (create_volume_fn)load_symbol(core, "CoreStorageCreateVolume");

    create_default_context_fn create_context = (create_default_context_fn)
        load_symbol(fde, "CSFDECreateDefaultContext");
    add_volume_encryption_fn add_encryption = (add_volume_encryption_fn)
        load_symbol(fde, "CSFDEAddVolumeEncryption");
    add_os_user_entry_fn add_user = (add_os_user_entry_fn)
        load_symbol(fde, "CSFDEAddOSUserEntry");
    store_passphrase_fn store_passphrase = (store_passphrase_fn)
        load_symbol(fde, "CSFDEStorePassphrase");
    remove_secret_fn remove_passphrase = (remove_secret_fn)
        load_symbol(fde, "CSFDERemovePassphrase");
    remove_secret_fn remove_key =
        (remove_secret_fn)load_symbol(fde, "CSFDERemoveKey");
    if (!create_family || !create_volume_dict || !create_volume ||
        !create_context || !add_encryption || !add_user ||
        !store_passphrase || !remove_passphrase || !remove_key)
        return 2;

    CFStringRef group = CFStringCreateWithCString(
        kCFAllocatorDefault, argv[1], kCFStringEncodingUTF8);
    CFMutableDictionaryRef family = group ? create_family(group) : NULL;
    CFStringRef family_uuid = family ? CFDictionaryGetValue(
        family, CFSTR("com.apple.corestorage.lvf.uuid")) : NULL;
    CFMutableDictionaryRef volume = family_uuid ?
        create_volume_dict(group, family_uuid, size) : NULL;
    if (!group || !family || !family_uuid || !volume) {
        fprintf(stderr, "failed to create CoreStorage property dictionaries\n");
        return 3;
    }
    CFDictionarySetValue(
        volume, CFSTR("com.apple.corestorage.lv.name"),
        CFSTR("Codex FDE Volume"));
    print_cf("family.before", family);
    print_cf("volume.before", volume);

    CFMutableDictionaryRef context = create_context();
    CFStringRef kek = NULL;
    CFStringRef passphrase = NULL;
    Boolean encryption_ok = context ?
        add_encryption(context, CFSTR("AES-XTS"), &kek) : false;
    if (encryption_ok && kek)
        passphrase = store_passphrase("codex-test-passphrase");
    Boolean user_ok = passphrase ? add_user(
        context,
        kek,
        CFSTR("AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA"),
        passphrase,
        CFSTR("before-synchronize"),
        NULL,
        CFSTR("Before Synchronize"),
        NULL,
        NULL) : false;
    fprintf(stderr, "encryption-ok=%d user-ok=%d\n",
        encryption_ok, user_ok);
    print_cf("context", context);
    if (!encryption_ok || !user_ok) {
        fprintf(stderr, "failed to construct FDE context\n");
        return 4;
    }

    CFDictionarySetValue(
        family, CFSTR("com.apple.corestorage.lvf.encryption.context"),
        context);
    print_cf("family.final", family);
    print_cf("volume.final", volume);

    CFStringRef volume_uuid = create_volume(volume, family);
    print_cf("create-volume.result", volume_uuid);

    if (passphrase) {
        remove_passphrase(passphrase);
        CFRelease(passphrase);
    }
    if (kek) {
        remove_key(kek);
        CFRelease(kek);
    }
    if (volume_uuid)
        CFRelease(volume_uuid);
    CFRelease(context);
    CFRelease(volume);
    CFRelease(family);
    CFRelease(group);
    dlclose(fde);
    dlclose(core);
    return volume_uuid ? 0 : 5;
}
