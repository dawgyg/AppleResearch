#include <CoreFoundation/CoreFoundation.h>
#include <OpenDirectory/OpenDirectory.h>

#include <stdio.h>
#include <stdlib.h>

extern const CFStringRef kODSessionLocalPath;

static void print_cf_error(const char *where, CFErrorRef error) {
    if (!error) {
        fprintf(stderr, "%s failed without CFError\n", where);
        return;
    }

    CFStringRef description = CFErrorCopyDescription(error);
    char buffer[2048];
    if (description && CFStringGetCString(description, buffer, sizeof(buffer),
                                          kCFStringEncodingUTF8)) {
        fprintf(stderr, "%s: %s\n", where, buffer);
    } else {
        fprintf(stderr, "%s failed (CFError code %ld)\n", where,
                (long)CFErrorGetCode(error));
    }
    if (description) {
        CFRelease(description);
    }
}

static void print_record(ODNodeRef node, const char *record_name) {
    CFStringRef name = CFStringCreateWithCString(
        kCFAllocatorDefault, record_name, kCFStringEncodingUTF8);
    CFErrorRef error = NULL;
    ODRecordRef record = ODNodeCopyRecord(
        node, kODRecordTypeUsers, name, NULL, &error);

    if (!record) {
        printf("RECORD %s ABSENT\n", record_name);
        if (error) {
            print_cf_error("ODNodeCopyRecord", error);
            CFRelease(error);
        }
        CFRelease(name);
        return;
    }

    CFTypeRef values = ODRecordCopyValues(record, kODAttributeTypeGUID, &error);
    if (values && CFGetTypeID(values) == CFArrayGetTypeID() &&
        CFArrayGetCount(values) > 0) {
        CFStringRef guid = (CFStringRef)CFArrayGetValueAtIndex(values, 0);
        char guid_buffer[256];
        if (CFStringGetCString(guid, guid_buffer, sizeof(guid_buffer),
                               kCFStringEncodingUTF8)) {
            printf("RECORD %s PRESENT GUID=%s\n", record_name, guid_buffer);
        } else {
            printf("RECORD %s PRESENT GUID=<conversion-failed>\n", record_name);
        }
    } else {
        printf("RECORD %s PRESENT GUID=<missing>\n", record_name);
    }

    if (error) {
        CFRelease(error);
    }
    if (values) {
        CFRelease(values);
    }
    CFRelease(record);
    CFRelease(name);
}

int main(int argc, char **argv) {
    if (argc != 4) {
        fprintf(stderr,
                "usage: %s <local-node-path> <record-a> <record-b>\n",
                argv[0]);
        return 2;
    }

    CFStringRef local_path = CFStringCreateWithCString(
        kCFAllocatorDefault, argv[1], kCFStringEncodingUTF8);
    const void *keys[] = {kODSessionLocalPath};
    const void *values[] = {local_path};
    CFDictionaryRef options = CFDictionaryCreate(
        kCFAllocatorDefault, keys, values, 1,
        &kCFCopyStringDictionaryKeyCallBacks,
        &kCFTypeDictionaryValueCallBacks);

    CFErrorRef error = NULL;
    ODSessionRef session = ODSessionCreate(kCFAllocatorDefault, options, &error);
    if (!session) {
        print_cf_error("ODSessionCreate", error);
        if (error) {
            CFRelease(error);
        }
        CFRelease(options);
        CFRelease(local_path);
        return 1;
    }

    ODNodeRef node = ODNodeCreateWithNodeType(
        kCFAllocatorDefault, session, kODNodeTypeLocalNodes, &error);
    if (!node) {
        print_cf_error("ODNodeCreateWithNodeType", error);
        if (error) {
            CFRelease(error);
        }
        CFRelease(session);
        CFRelease(options);
        CFRelease(local_path);
        return 1;
    }

    printf("READY node-created path=%s\n", argv[1]);
    fflush(stdout);
    if (getchar() == EOF) {
        fprintf(stderr, "stdin closed before query\n");
        return 1;
    }

    print_record(node, argv[2]);
    print_record(node, argv[3]);

    CFRelease(node);
    CFRelease(session);
    CFRelease(options);
    CFRelease(local_path);
    return 0;
}
