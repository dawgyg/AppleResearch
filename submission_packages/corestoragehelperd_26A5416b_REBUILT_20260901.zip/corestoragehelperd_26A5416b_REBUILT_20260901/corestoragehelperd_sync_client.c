#include <dispatch/dispatch.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <xpc/xpc.h>

int
main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s mount-path\n", argv[0]);
        return 64;
    }

    xpc_connection_t connection = xpc_connection_create_mach_service(
        "com.apple.corestorage.corestoragehelperd", NULL, 0);
    if (!connection) {
        fprintf(stderr, "connection creation failed\n");
        return 1;
    }
    xpc_connection_set_event_handler(connection, ^(xpc_object_t event) {
        if (xpc_get_type(event) == XPC_TYPE_ERROR) {
            const char *description = xpc_dictionary_get_string(
                event, XPC_ERROR_KEY_DESCRIPTION);
            fprintf(stderr, "connection event: %s\n",
                description ? description : "unknown error");
        }
    });
    xpc_connection_resume(connection);

    xpc_object_t request = xpc_dictionary_create(NULL, NULL, 0);
    xpc_dictionary_set_string(request, "op", "SynchronizeUsers");
    xpc_dictionary_set_string(request, "path", argv[1]);
    xpc_object_t reply = xpc_connection_send_message_with_reply_sync(
        connection, request);
    char *description = reply ? xpc_copy_description(reply) : NULL;
    printf("uid=%u path=%s reply=%s\n", getuid(), argv[1],
        description ? description : "(null)");
    if (description)
        free(description);
    return reply && xpc_get_type(reply) == XPC_TYPE_DICTIONARY &&
        xpc_dictionary_get_bool(reply, "status") ? 0 : 2;
}
