#include <CoreFoundation/CoreFoundation.h>

#include <dlfcn.h>
#include <stdio.h>

typedef CFDictionaryRef (*copy_family_for_mount_fn)(const char *);
typedef CFArrayRef (*copy_user_entries_fn)(CFDictionaryRef, uint32_t);

int
main(int argc, char **argv)
{
    if (argc != 2) {
        fprintf(stderr, "usage: %s mount-path\n", argv[0]);
        return 64;
    }

    void *core = dlopen(
        "/usr/lib/libCoreStorage.dylib", RTLD_NOW | RTLD_LOCAL);
    void *fde = dlopen("/usr/lib/libcsfde.dylib", RTLD_NOW | RTLD_LOCAL);
    copy_family_for_mount_fn copy_family = core ?
        (copy_family_for_mount_fn)dlsym(
            core, "CoreStorageCopyFamilyPropertiesForMount") : NULL;
    copy_user_entries_fn copy_entries = fde ?
        (copy_user_entries_fn)dlsym(
            fde, "CSFDECopyUserEntriesOfType") : NULL;
    if (!core || !fde || !copy_family || !copy_entries) {
        fprintf(stderr, "load failed: %s\n", dlerror());
        return 1;
    }

    CFDictionaryRef family = copy_family(argv[1]);
    fprintf(stderr, "family=");
    if (family)
        CFShow(family);
    else
        fprintf(stderr, "(null)\n");

    CFDictionaryRef context = family ? CFDictionaryGetValue(
        family, CFSTR("com.apple.corestorage.lvf.encryption.context")) : NULL;
    CFArrayRef entries = context ?
        copy_entries(context, 0x10060002U) : NULL;
    fprintf(stderr, "os-user-entries=");
    if (entries)
        CFShow(entries);
    else
        fprintf(stderr, "(null)\n");

    if (entries)
        CFRelease(entries);
    if (family)
        CFRelease(family);
    dlclose(fde);
    dlclose(core);
    return family ? 0 : 2;
}
