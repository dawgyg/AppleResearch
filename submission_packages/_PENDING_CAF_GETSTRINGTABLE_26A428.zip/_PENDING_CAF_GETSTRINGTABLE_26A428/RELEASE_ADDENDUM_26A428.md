# CAF GetStringTable — shipping-release addendum (macOS 27.0, 26A428)

The original analysis was performed on 26A5416b. This addendum confirms the
defect is present and unmodified in the shipping macOS 27.0 release.

## Binary identity (release)

| field | value |
|---|---|
| build | `26A428` (macOS 27.0 release) |
| binary | `/System/Library/PrivateFrameworks/AudioToolboxCore.framework/Versions/A/AudioToolboxCore` |
| LC_UUID | `49229A03-C7B7-38DE-99D1-C8A923169FAB` |
| LC_SOURCE_VERSION | `1638.104.3` |
| symbol | `__ZN12CAFAudioFile14GetStringTableEP17CAFStringsWrapper` @ `0x18379cd90` |

`LC_SOURCE_VERSION` is identical to the 416b build; the differing `LC_UUID`
reflects a rebuild. The instruction sequence below is unchanged.

## The defect, on the release binary

The `strg` chunk entry COUNT is clamped; the 64-bit big-endian
`mStringStartByteOffset` is not bounded at all.

```
0x18379cea0  csel w21, w9, w8, lo   ; count = min(mNumEntries, capacity)  -- CLAMPED
0x18379cf40  madd w8, w21, w8, w9   ; stringDataBase = buf + 4 + count*12
0x18379cf68  ldur x8, [x9, 4]       ; mStringStartByteOffset, full s64 from the file
0x18379cf6c  add  x1, x21, x8       ; *** no cmp/branch between load and use ***
0x18379cf74  bl   std::string::__assign_external   ; strlen + copy
0x18379cf80  bl   vector<CAFStringWrapper>::push_back  ; returned to the caller
```

No instruction compares the offset against the string-data length, the
allocation, or zero.

## Reproduction method (unchanged from the original report)

`AudioFileOpenURL` -> `AudioFileGetProperty(kAudioFilePropertyMarkerList)` ->
read `AudioFileMarker.mName`.

## Scope note

The original capture was taken on an Apple Virtual Machine (VMAPPLE) guest with
SIP enabled, empty boot-args, uid 501. It has not been re-run on physical
hardware. The static analysis above is from the physical host's shipping
release binary.
