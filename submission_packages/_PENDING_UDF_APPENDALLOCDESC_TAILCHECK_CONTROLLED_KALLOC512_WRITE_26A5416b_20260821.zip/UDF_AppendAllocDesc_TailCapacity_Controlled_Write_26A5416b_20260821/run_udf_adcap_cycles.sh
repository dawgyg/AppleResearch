#!/bin/zsh

set -u

pristine=${1:-/Users/testtest/udf_adcap_firstfree40.pristine.raw.dmg}
cycles=${2:-50}

for i in $(seq 1 "$cycles"); do
    run="/Users/testtest/udf_adcap_firstfree40.run-${i}.raw.dmg"
    cp "$pristine" "$run" || exit 10
    attach=$(hdiutil attach -readwrite "$run" 2>&1)
    rc=$?
    print -r -- "cycle=$i attach_rc=$rc $attach"
    (( rc == 0 )) || exit 11

    dev=$(mount | awk '/\/Volumes\/UDFEMBED/ { print $1; exit }')
    [[ -n "$dev" ]] || exit 12
    truncate -s 4097 /Volumes/UDFEMBED/target
    rc=$?
    print -r -- "cycle=$i truncate_rc=$rc dev=$dev"
    (( rc == 0 )) || exit 13
    sync
    sleep 0.2
    diskutil unmount force "$dev" >/dev/null 2>&1 || exit 14
    hdiutil detach "$dev" -force >/dev/null 2>&1 || exit 15
    rm -f "$run"
done

print -r -- "completed=$cycles"
