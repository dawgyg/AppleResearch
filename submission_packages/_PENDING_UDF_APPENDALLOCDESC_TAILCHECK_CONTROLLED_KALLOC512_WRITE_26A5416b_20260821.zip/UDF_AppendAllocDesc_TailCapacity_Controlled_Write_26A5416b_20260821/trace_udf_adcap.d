#!/usr/sbin/dtrace -s

#pragma D option quiet

fbt:com.apple.filesystems.udf:_ZN12UDFAllocDesc15AppendAllocDescEtjxjPi:entry
{
    self->in_append = 1;
    self->append_data = (uintptr_t)0;
}

fbt:com.apple.filesystems.udf:_ZN8UDFBlock9ReadBlockEP8UDFMountP5vnodexjb19UDFBlockReleaseHint:entry
/arg3 == 291/
{
    self->udf_block = arg0;
    printf("READBLOCK entry obj=%p vnode=%p diskblk=%lld io_size=%u release=%u\n",
        arg0, arg2, arg3, arg4, arg6);
}

fbt:com.apple.filesystems.udf:_ZN8UDFBlock9ReadBlockEP8UDFMountP5vnodexjb19UDFBlockReleaseHint:return
/self->udf_block != 0/
{
    this->bp = *(uintptr_t *)(self->udf_block + 0x18);
    this->data = *(uintptr_t *)(self->udf_block + 0x20);
    printf("READBLOCK return obj=%p err=%d bp=%p data=%p buf_size=%u buf_count=%u data_page_off=%#x\n",
        self->udf_block, arg1, this->bp, this->data,
        this->bp != 0 ? *(uint32_t *)(this->bp + 0x58) : 0,
        this->bp != 0 ? *(uint32_t *)(this->bp + 0x5c) : 0,
        this->data & 0x3fff);
    self->append_data = self->in_append ? this->data : self->append_data;
    self->udf_block = 0;
}

fbt:com.apple.filesystems.udf:_ZN12UDFAllocDesc15AppendAllocDescEtjxjPi:entry
{
    this->mount = *(uintptr_t *)(arg0 + 0x10);
    printf("APPEND entry this=%p part=%u lbn=%u bytes=%llu flag=%u adtype=%u ad_start=%#x total_bytes=%llu block_size=%u\n",
        arg0, arg1, arg2, (uint64_t)arg3, arg4,
        *(uint32_t *)(arg0 + 0x24),
        *(uint32_t *)(arg0 + 0x30),
        *(uint64_t *)(arg0 + 0x70),
        *(uint32_t *)(this->mount + 0x30));
}

fbt:com.apple.filesystems.udf:_ZN12UDFAllocDesc15AppendAllocDescEtjxjPi:return
{
    printf("APPEND return err=%d data=%p dword0=%#x dword1=%#x\n",
        arg1, self->append_data,
        self->append_data != 0 ? *(uint32_t *)(self->append_data + 0x1fc) : 0,
        self->append_data != 0 ? *(uint32_t *)(self->append_data + 0x200) : 0);
    self->append_data = (uintptr_t)0;
    self->in_append = 0;
}
