# cryptexd UPGRADE_LOCK disconnect race DoS

This package captures a reproducible unprivileged crash of root `cryptexd` on
macOS 26.5.1 (25F80).

## Summary

An unprivileged client connects to `com.apple.security.cryptex.xpc`, sends a
minimal `SUBSYSTEM=UPGRADE_LOCK` message, and immediately disconnects. Repeating
this race reaches `upgrade_sub_lock_for_client` and crashes root `cryptexd` in
`xpc_connection_get_pid`, which traps through `_xpc_api_misuse`.

Observed crash signature:

```text
proc=cryptexd userID=0
exception=EXC_BREAKPOINT signal=SIGTRAP
queue=com.apple.security.cryptexd.upgrade_sequencer_lock_acquire
_xpc_api_misuse
xpc_connection_get_pid
__58-[UpgradeSequencer lockInterfaceForClient:withCompletion:]_block_invoke
-[UpgradeSequencer lockInterfaceForClient:withCompletion:]
upgrade_lock_interface
upgrade_sub_lock_for_client
_xpc_connection_call_event_handler
```

## Reproduction

Build on the target macOS system:

```sh
clang -framework Foundation -framework XPC -fblocks cryptex_lockdos.c -o cryptex_lockdos
```

Run as an unprivileged user:

```sh
./cryptex_lockdos 80
```

In the captured run, the PoC executed as effective uid 501 and produced fresh
root `cryptexd` crash reports:

```text
cryptexd-2026-06-12-225750.ips
cryptexd-2026-06-12-225750.000.ips
```

## Package Contents

```text
cryptex_lockdos.c
evidence/cryptex_lockdos
evidence/cryptex_lockdos_repro_codex_0558.out
evidence/cryptexd-2026-06-12-225750.ips
evidence/cryptexd-2026-06-12-225750.000.ips
SHA256SUMS.txt
```

## Notes

This is currently DoS-tier evidence. It demonstrates an unprivileged client can
crash a root daemon through a race in the UPGRADE_LOCK handler, but this package
does not show code execution, privilege escalation, or controlled memory
corruption.

The evidence VM had SIP disabled and Developer Mode enabled. The trigger itself
is an ordinary XPC client pattern; confirm on a stock SIP-on system before
submitting stronger reachability claims.
