# Unprivileged client can crash root cryptexd through UPGRADE_LOCK disconnect race

## Summary

An unprivileged process can repeatedly crash root `cryptexd` by sending a
minimal `UPGRADE_LOCK` request to `com.apple.security.cryptex.xpc` and
immediately disconnecting. The daemon reaches the upgrade lock path and calls
`xpc_connection_get_pid` on a connection state that libxpc treats as invalid,
causing `_xpc_api_misuse` and terminating `cryptexd` with SIGTRAP.

## Affected Component

- Component: `cryptexd`
- Service: `com.apple.security.cryptex.xpc`
- Tested build: macOS 26.5.1 (25F80)

## Security Impact

This is currently demonstrated as a local denial of service against a root
system daemon. The trigger is reachable from an unprivileged user account.

## Reproduction

Build:

```sh
clang -framework Foundation -framework XPC -fblocks cryptex_lockdos.c -o cryptex_lockdos
```

Run as an unprivileged user:

```sh
./cryptex_lockdos 80
```

The PoC loops over this sequence:

1. Connect to `com.apple.security.cryptex.xpc`.
2. Send an XPC dictionary containing `SUBSYSTEM="UPGRADE_LOCK"`.
3. Immediately cancel the connection.

## Observed Result

The captured run was executed as effective uid 501 and produced fresh root
`cryptexd` crash reports. The parsed crash signature was:

```text
proc=cryptexd uid=0 pid=42830
exception=EXC_BREAKPOINT signal=SIGTRAP
faultingThread=2
queue=com.apple.security.cryptexd.upgrade_sequencer_lock_acquire
_xpc_api_misuse
xpc_connection_get_pid
__58-[UpgradeSequencer lockInterfaceForClient:withCompletion:]_block_invoke
-[UpgradeSequencer lockInterfaceForClient:withCompletion:]
upgrade_lock_interface
upgrade_sub_lock_for_client
_xpc_connection_call_event_handler
```

The included evidence contains:

```text
evidence/cryptex_lockdos_repro_codex_0558.out
evidence/cryptexd-2026-06-12-225750.ips
evidence/cryptexd-2026-06-12-225750.000.ips
```

## Expected Result

`cryptexd` should validate client connection lifetime/state before using the
connection object in the UPGRADE_LOCK path. A client disconnect should not crash
the daemon.

## Caveats

The evidence VM had SIP disabled and Developer Mode enabled, as reflected in
the attached crash report. I have not yet confirmed whether the same behavior
reproduces on a stock SIP-on installation.
