# DisabledTag False-Positive Logic Gadget Static Notes

Date: 2026-06-12T0338Z
Scope: static-only refinement of `_odauthauthorities_disabledtag` after a
`DisabledTags` overflow. No host OpenDirectory, ActiveDirectory, LDAP, `dscl`,
lldb, or VM dynamic trigger was run for this note.

## Bottom Line

`_odauthauthorities_disabledtag` trusts the corrupted `DisabledTags` count and
scans that many dwords starting at the six-entry inline list. Because the
overflow writes small auth-authority enum values past the inline list, an
attacker-shaped word outside the intended six entries can make the helper
return "disabled" for `SecureToken`, `OTI`, `ShadowHash`, or another target.

This is a logic/control-flow gadget, not memory safety by itself:

```text
parse overfull DisabledTags
  -> overflow word at list[index >= 6] equals queried tag
  -> _odauthauthorities_disabledtag returns true
  -> caller takes "tag is disabled" branch
```

The useful connection is `PlistFile.bundle`:

```text
__plistfile_attrs_add_sepCredential
  -> _odauthauthorities_disabledtag(type=4/5)
  -> if true and caller w2 bit 0 is set:
       _odauthauthorities_remove_disabledtag(type=4/5)
```

So a fake disabled-tag match beyond the six-entry list can be the gate into the
already-documented count-derived `remove_disabledtag` memmove lane.

## Helper Behavior

`_odauthauthorities_disabledtag` first finds a type-9 `DisabledTags` slot by
scanning the ten fixed authority slots. Once found, it loads `slot+0x18` as the
entry count and scans `count` dwords from `slot+0x20`:

```text
0x100031fd0  x8 = aggregate + 0x28       ; slot0 list base
0x100031fd4  w9 = 0xa                    ; ten-slot scan
0x100031fd8  w10 = [x8 - 0x20]           ; slot type
0x100031fdc  cmp w10, 9                  ; DisabledTags
0x100031ff4  x9 = [x8 - 0x8]             ; DisabledTags count
0x100031ff8  x9 = count - 1
0x100031ffc  if count < 1 return false
0x100032000  w10 = *x8; x8 += 4          ; entry scan
0x100032004  cmp w10, w1                 ; queried tag
0x100032008  w0 = (entry == tag)
0x10003200c  exit on match or last entry
```

There is no visible cap forcing `count <= 6` before this scan.

## Overflow Geometry

For the first real `DisabledTags` slot:

```text
aggregate base       = A
slot0 base           = A + 0x08
DisabledTags count   = A + 0x20
DisabledTags list    = A + 0x28
list index n writes  = A + 0x28 + 4*n
first fake slot base = A + 0x40
```

Useful list indexes outside the valid six-entry list:

```text
index 6   -> first fake slot type dword
index 8   -> first fake slot slot+0x08 low dword
index 9   -> first fake slot slot+0x08 high dword
index 10  -> first fake slot slot+0x10 low dword
index 11  -> first fake slot slot+0x10 high dword
index 12  -> first fake slot slot+0x18 low dword
index 13  -> first fake slot slot+0x18 high dword
```

Since each overflow dword is the parsed token enum, putting `SecureToken` at
index `6` makes both statements true:

```text
first fake slot type == 4
_odauthauthorities_disabledtag(type=4) returns true if count >= 7
```

Likewise, putting `OTI` at index `6` makes the fake slot type `5` and can make
`_odauthauthorities_disabledtag(type=5)` return true.

## PlistFile Gate

`__plistfile_attrs_add_sepCredential` parses the record's
`AuthenticationAuthority`, checks disabled tags, and only calls
`_odauthauthorities_remove_disabledtag` when the disabledtag predicate returns
true and caller flag bit 0 is set:

```text
0x1e3d8  bzero(sp+0x8, 0x238)
0x1e420  odproplist_get_array(authentication_authority)
0x1e42c  _odauthauthorities_parse
0x1e438  _odauthauthorities_disabledtag(type=w24)       ; SecureToken/OTI
0x1e440  if false, skip to add
0x1e444  if caller w2 bit 0 clear, fail
0x1e450  _odauthauthorities_remove_disabledtag(type=w24)
...
0x1e4a4  _odauthauthorities_disabledtag(type=4)         ; OTI secondary
0x1e4ac  if caller w2 bit 0 clear, fail
0x1e4b8  _odauthauthorities_remove_disabledtag(type=4)
```

Known `w2=1` callers from the current PlistFile disassembly:

```text
__plistfile_verify_password_and_update_record
____SecureTokenSupportEnable_block_invoke
```

The `w2=0` password-change caller can still exercise the false-positive
disabledtag scan, but it should fail instead of calling
`_odauthauthorities_remove_disabledtag`.

## Why This Matters

Earlier notes treated the `remove_disabledtag` memmove as requiring the target
tag to appear in the legitimate inline list. It does not. The precondition for
the PlistFile memmove lane can be satisfied by an overflow word beyond the
six-entry list:

```text
count >= 7
list[6] == queried tag
_odauthauthorities_disabledtag returns true
caller w2 bit 0 set
_odauthauthorities_remove_disabledtag runs on the same overfull slot
```

For count `c` and found index `j`, the removal helper's memmove length remains:

```text
length = 4 * (c - 1 - j)
```

So a fake match at index `6` gives:

```text
count 7   -> length 0, count decremented
count 8   -> length 4, one dword shifted from list[7] to list[6]
count 64  -> length 228, adjacent slot/aggregate bytes shifted left
```

The copied bytes are still aggregate/fake-slot bytes shaped by enum dword
writes and zero-initialized fields, not arbitrary user-supplied bytes.

## VM Test Suggestion

Use only a disposable VM snapshot.

High-signal pattern:

```text
list[0..5] do not contain SecureToken or OTI
list[6] is SecureToken or OTI
count is 7, 8, and a larger value such as 32/64
```

Breakpoints:

```text
__plistfile_attrs_add_sepCredential
_odauthauthorities_disabledtag
_odauthauthorities_remove_disabledtag
_odauthauthorities_attribute_create
```

At `_odauthauthorities_disabledtag`:

```text
record queried tag w1
record slot+0x18 count
record the matching list index
require match index >= 6 for the false-positive case
```

At `_odauthauthorities_remove_disabledtag`:

```text
require it fires only after the false-positive disabledtag result
record found index j and x2 memmove length
check x2 == 4 * (count - 1 - j)
```

Expected honest outcome:

```text
count-derived disabledtag false positive can route PlistFile into the
count-derived memmove helper when an authorized w2=1 workflow processes the
record.
```

Not proven:

```text
non-admin reachability
policy bypass by itself
arbitrary write
LPE
code execution
```

## Reporting Implication

This should be framed as a second-stage upgrade lane:

```text
The same overfull DisabledTags count is trusted by a predicate helper. Overflow
words past the six-entry inline list can satisfy disabled-tag checks and route
authorized PlistFile workflows into the remove-disabledtag memmove consumer.
```

Do not present it as a new standalone vulnerability until VM reachability and
caller privilege context are proven.
