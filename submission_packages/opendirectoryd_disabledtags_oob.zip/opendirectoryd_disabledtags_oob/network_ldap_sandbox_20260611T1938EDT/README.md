# opendirectoryd DisabledTags LDAP Sandbox Reachability

Date: 2026-06-11 19:38 EDT

## Safety

Do not run additional crash triggers casually. `/System/Library/LaunchDaemons/com.apple.opendirectoryd.plist` contains:

```text
_PanicOnCrash => {
  PanicOnConsecutiveCrash => true
}
```

After the sandboxed LDAP trigger, `launchctl print system/com.apple.opendirectoryd` showed:

```text
runs = 12
successive crashes = 11
pid = 89292
last terminating signal = Segmentation fault: 11
```

Further consecutive `opendirectoryd` crashes may kernel panic the machine.

## Result

A stock, sandboxed, non-root `/usr/bin/dscl` client triggered the root `opendirectoryd` crash through the explicit LDAP node path `/LDAPv3/127.0.0.1`:

```text
sandbox dscl rc=62
od before=77590 runs=11 crashes=10
od after=89292 runs=12 crashes=11 signal=Segmentation fault: 11
<dscl_cmd> DS Error: -14910 (eServerError)
Authentication for node /LDAPv3/127.0.0.1 failed. (-14910, eServerError)
```

The sandbox profile allowed process operations, file reads/maps, `sysctl-read`, self-signal, and Mach lookup for `com.apple.system.opendirectoryd.api`. It did not grant network access; the sandboxed process only asked root `opendirectoryd` to open/use the explicit LDAP node.

## Caveat

This originally proved sandbox reachability to the parser through the stock OpenDirectory daemon. Follow-up filesystem/static checks in `../DYNAMIC_LDAP_REACHABILITY.md` and `../REACHABILITY_DYNAMIC_NODE.md` show that `/LDAPv3/127.0.0.1` was not backed by a host-specific persistent LDAP configuration and is consistent with Apple's dynamic LDAPv3 node template.

## Files

- `victim_ldap_entry.txt`: LDAP record with OD-mapped object classes and the long `authAuthority`.
- `sandbox_dscl_auth_output.txt`: sandboxed `dscl -authonly` output.
- `opendirectoryd_launchctl_after_sandbox_crash.txt`: post-crash daemon state.
- `slapd.conf`, `custom.schema`, `slapd_debug_fg389.log`: LDAP fixture and debug log.
