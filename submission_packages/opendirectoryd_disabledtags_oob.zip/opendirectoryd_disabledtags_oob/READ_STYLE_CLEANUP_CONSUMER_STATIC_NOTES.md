# Read-Style Cleanup Consumer Static Notes

Date: 2026-06-12T0355Z
Scope: static-only follow-up after the confirmed PlistFile controlled invalid
free. Codex did not run host OpenDirectory, LDAP, `dscl`, lldb, or VM dynamic
triggers for this note.

## Bottom Line

The confirmed `RecordDelete` controlled-free lane should not be treated as the
only possible PlistFile cleanup trigger. Static review found read/auth-style
entrypoints that parse a record's `AuthenticationAuthority` and then call
`_odauthauthorities_free_contents` on the parsed aggregate.

Best lower-privilege VM probes:

```text
1. ODNodeCustomFunction / HasSecureToken
2. ODRecordAuthenticationAllowed
3. GetSEPCredentialLockoutState, lower priority because it has a custom-function
   rights gate
```

If any of these can be invoked by a non-admin or sandboxed client against a
toxic local record, the same fake-slot primitive should reach:

```text
_odauthauthorities_free_contents
  -> _odauthauthority_free_contents(fake slot)
  -> free(fake slot+0x10)
```

with the already-observed `free(0x800000008)` pattern when indexes `10/11` are
`DisabledUser`.

Update 2026-06-12T0403Z: Claude reports that priority 1 is now dynamically
confirmed. A uid 501 non-root client called
`ODNodeCustomFunction("HasSecureToken", {"Recordname": victim})` and root
`opendirectoryd` crashed with:

```text
opendirectoryd malloc: *** error for object 0x800000008:
pointer being freed was not allocated
```

So non-admin trigger reachability to the cleanup/free consumer is now proven for
an already-toxic local record. The remaining LPE gate is toxic-record
placement/control and conversion from enum-composed invalid free to stronger
heap corruption.

Reported full chain:

```text
_odrequest_api_process
  odm_NodeCustomFunction
    HasSecureToken
      _plistfile_attrs_is_sepCredentialUser
        odauthauthorities_free_contents
          odauthauthority_free_contents
            free(0x800000008)
```

## Candidate 1: HasSecureToken

`_HasSecureToken` is an exported PlistFile symbol and is part of the module's
SecureToken custom-function surface. Prior OpenDirectory reversing notes list
`HasSecureToken` under advertised `ODNodeCustomFunction` names.

Static path:

```text
0x8738  _HasSecureToken
0x879c    __plistfile_get_command_ctx(...)
0x87a4    _sepCredential_context_is_valid(...)
0x87e8    _odproplist_get_string(payload, "Recordname")
0x8808    __fetch_and_retain_record(..., "users", Recordname)
0x8814    record->queue/context
0x8894    dispatch_sync(record queue, ___HasSecureToken_block_invoke)

0x8b9c  ___HasSecureToken_block_invoke
0x8c2c    attrs = [record+0x48]
0x8c38    __plistfile_attrs_is_sepCredentialUser(attrs, ...)
```

The callee is the same cleanup consumer that fired in the `RecordDelete` crash:

```text
0x8c70  __plistfile_attrs_is_sepCredentialUser
0x8e38    _odauthauthorities_parse(sp+0x8, AuthenticationAuthority)
0x8e50    __plistfile_is_sepCredentialUser(...)
0x8ef4    _odauthauthorities_free_contents(sp+0x8)
```

Notable local-gate observation:

```text
_HasSecureToken does not call __validateCustomFunction.
_HasSecureToken does not call __session_has_privilege in the reviewed window.
```

That does not prove public/unprivileged reachability, because dispatch and
policy may be enforced before the module function is called. It does make this
the highest-value VM trigger candidate: it is read-style, fetches the target
record by name, and then reaches the confirmed cleanup function.

Dispatch update:

```text
opendirectoryd ___odm_NodeCustomFunction_block_invoke
  -> _odmodule_supports_customfunction(module, requested_name)
  -> CFBundleGetFunctionPointerForName(module_bundle, requested_name)
  -> call resolved PlistFile export
```

`_odmodule_supports_customfunction` checks the module `Info.plist`
`ODCustomFunctions` dictionary. `PlistFile.bundle` advertises
`HasSecureToken`, so this daemon-level whitelist passes for the tested name.

Payload key:

```text
CFString @ 0x6e1c8 -> "Recordname"
```

Expected VM test shape:

```text
ODNodeCustomFunction(node, "HasSecureToken", { "Recordname": toxic_user })
```

Try as:

```text
root/admin client
same unprivileged user
sandboxed same unprivileged user with only OD Mach lookup
```

High-signal breakpoint/trace:

```text
_HasSecureToken
___HasSecureToken_block_invoke
__plistfile_attrs_is_sepCredentialUser
_odauthauthorities_free_contents
_odauthauthority_free_contents
free / malloc_error_break
```

If the toxic record's auth authority contains:

```text
index 6  = SecureToken
index 10 = DisabledUser
index 11 = DisabledUser
```

then the expected controlled-free result is:

```text
free(0x800000008)
```

## Candidate 2: RecordAuthenticationAllowed

`_odm_RecordAuthenticationAllowed` is an exported PlistFile record operation and
corresponds to the OpenDirectory API surface `ODRecordAuthenticationAllowed`.
Prior strings/reversing also showed:

```text
mapping ODRecordCopyEffectivePolicies to ODRecordAuthenticationAllowed
```

Static path:

```text
0x17c28  _odm_RecordAuthenticationAllowed
0x17c9c    __fetch_and_retain_record(record type/name)
0x17cb0    __recordentry_copy_attributes
0x17cc0    bzero(sp+0x58, 0x238)
0x17cd0    __plistfile_attrs_authenticationAllowedAdministratively(...)
0x17cec    x0 = sp+0x58
0x17cf0    _odauthauthorities_parse(AuthenticationAuthority)
0x17d58    __plistfile_is_sepCredentialUser(sp+0x58, ...)
...
0x17fbc    _odauthauthorities_free_contents(sp+0x58)
```

Unlike the `RecordDelete` trigger, the reviewed function body does not show a
`__session_has_privilege` call before parsing and cleanup. It is therefore a
strong read/auth-check reachability candidate, but dynamic testing must confirm
actual client access and record-read authorization.

Expected VM test shape:

```text
ODRecordAuthenticationAllowed(toxic_user_record)
ODRecordCopyEffectivePolicies(toxic_user_record)  ; if it maps to auth allowed
```

Run with breakpoints on:

```text
_odm_RecordAuthenticationAllowed
_odauthauthorities_parse
__plistfile_is_sepCredentialUser
_odauthauthorities_free_contents
_odauthauthority_free_contents
free / malloc_error_break
```

Useful result classes:

```text
non-root reaches _odauthauthorities_free_contents and free(0x800000008):
  strong LPE/sandbox-escape reachability upgrade

non-root denied before _odm_RecordAuthenticationAllowed:
  gate remains privileged/local-record-only

non-root can call but record read denied before parse:
  useful authorization boundary, but not the controlled-free trigger
```

## Candidate 3: GetSEPCredentialLockoutState

`_GetSEPCredentialLockoutState` reaches the same
`__plistfile_attrs_is_sepCredentialUser` helper:

```text
0xb6a8  _GetSEPCredentialLockoutState
0xb738    __validateCustomFunction(...)
0xb768    _odproplist_get_string(payload, "Recordname")
0xb784    __fetch_and_retain_record(..., "users", Recordname)
0xb80c    dispatch_sync(...)

0xbbd4  ___GetSEPCredentialLockoutState_block_invoke
0xbc64    attrs = [record+0x48]
0xbc70    __plistfile_attrs_is_sepCredentialUser(attrs, ...)
```

The lower priority is the explicit custom-function gate:

```text
0x1eb0  __validateCustomFunction
0x1ed4    __plistfile_has_rights(..., 1)
```

If this function is only callable by privileged/custom-function clients, it is
less useful for LPE reachability. If the rights check is permissive for the same
user or for read-only SecureToken state, it becomes another direct cleanup
consumer.

## Why This Matters For LPE

The controlled-free primitive itself is real but value-limited:

```text
free(0x0000000H_0000000L)
```

The current obstacle is not proving corruption anymore; it is proving a
low-privilege trigger and finding a way past enum-limited invalid pointers. The
read/auth-style paths above attack the first obstacle.

Best VM priority:

```text
1. Seed toxic local record exactly as in the confirmed RecordDelete free.
2. Trigger HasSecureToken as non-root and sandboxed non-root.
3. Trigger ODRecordAuthenticationAllowed / ODRecordCopyEffectivePolicies as
   non-root and sandboxed non-root.
4. Only then spend time on GetSEPCredentialLockoutState.
5. For any hit, bank full .ips + malloc bad object + triggering UID/EUID/PID
   and sandbox profile.
```

Do not claim LPE from this static note alone. The upgrade happens only if the
VM shows non-admin/sandboxed reachability to the same root `free()` consumer, or
if a stronger valid-pointer/allocator-state effect appears.
