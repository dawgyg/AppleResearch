# Daemon Heap Serializer Gates Static Notes

Date: 2026-06-12T0257Z
Scope: static-only review of `opendirectoryd` daemon call sites that can
serialize auth-authority aggregates after parsing.
No host or VM OpenDirectory activity was run for this note.

## Bottom Line

The daemon has two important auth-authority serializer gates:

```text
___odcredential_copy_details_block_invoke  -> _odauthauthorities_attribute_create
__create_connection_with_options           -> _odauthauthorities_attribute_create
```

Both serialize a heap credential object's aggregate at `credential + 0x90`.
They do not serialize the stack aggregate used by the already-proven LDAP auth
crash path.

This tightens the exploitability map:

```text
proven LDAP auth path:
  attacker authAuthority -> stack aggregate -> __find_mechanisms crash

heap serializer upgrade path:
  attacker authAuthority must first reach _odcredential_set_authentication_authority
  then credential+0x90 can be serialized by copy-details or connection setup
```

I did not find direct daemon call sites to `_odauthauthorities_disabledtag`
outside the helper definition itself. The direct `disabledtag` / `remove_disabledtag`
consumer route found so far is in `PlistFile.bundle`, documented separately in
`PLISTFILE_SECURETOKEN_DISABLEDTAG_CONSUMERS_STATIC_NOTES.md`.

## Proven Auth Stack Path Still Hits `_find_mechanisms`

`___odm_handle_api_authentication_block_invoke_2` parses the record's
`authentication_authority` into a stack aggregate and calls `__find_mechanisms`
before later account checks:

```text
0x100004f80  bzero(sp+0x78, 0x238)
0x100004f98  odproplist_get_array(authentication_authority)
0x100004fa0  x0 = sp+0x78
0x100004fa4  _odauthauthorities_parse
0x100004fbc  x0 = sp+0x78
0x100004fc0  __find_mechanisms
0x100004fe8  __account_is_disabled(..., sp+0x78)
```

There is no `_odauthauthorities_attribute_create` call on this stack aggregate
before `__find_mechanisms`.

`___odm_record_account_policy_request_block_invoke` has the same basic shape:

```text
0x10000a8d4  bzero(sp+0x58, 0x238)
0x10000a8e8  odproplist_get_array(authentication_authority)
0x10000a8f4  _odauthauthorities_parse
0x10000a900  __find_mechanisms
0x10000a934  __account_is_disabled(..., sp+0x58)
```

So for the stock LDAP-auth stack repro, a serializer-before-find claim should
not be made unless VM evidence shows a different path or a way to skip
`__find_mechanisms` while preserving an overfull aggregate.

## Credential Details Serializer

`_odcredential_copy_details` dispatches to
`___odcredential_copy_details_block_invoke`. That block serializes the
credential object's auth-authority aggregate:

```text
0x100034554  ldr x8, [x19, #0x28]      ; credential object
0x100034558  add x0, x8, #0x90         ; auth-authority aggregate
0x10003455c  _odauthauthorities_attribute_create
0x100034580  CFDictionarySetValue(AuthenticationAuthority, serialized array)
```

Visible callers:

```text
0x100003f54  _odm_handle_api_authentication
0x10000a04c  __record_policy_find_user_addinfo
0x10000af74  _odm_RecordDelete
```

In `_odm_handle_api_authentication`, the copied details are for the connection
credential (`_odconnection_copy_credential`) while building module request
metadata. This is a useful serializer breakpoint if the heap credential has
already been corrupted, but it does not serialize the malicious stack aggregate
from `___odm_handle_api_authentication_block_invoke_2`.

## Connection-Options Serializer

`__create_connection_with_options` packages an existing credential-like object
into XPC connection options and serializes `x21 + 0x90`:

```text
0x100058f10  xpc_dictionary_set_cftype(..., [x21+0x2c8])
0x100058f24  xpc_dictionary_set_cftype(..., [x21+0x70])
0x100058f3c  xpc_dictionary_set_cftype(..., [x21+0x80])
0x100058f54  xpc_dictionary_set_cftype(..., [x21+0x88])
0x100058f78  add x0, x21, #0x90
0x100058f7c  _odauthauthorities_attribute_create
0x100058f98  xpc_dictionary_set_cftype(AuthenticationAuthority, serialized array)
```

This is another heap-credential serialization gate. It becomes interesting
only if the object at `x21` contains attacker-shaped auth-authority data at
`+0x90`.

## Direct `disabledtag` Check

Address-based and name-based checks found the daemon's
`_odauthauthorities_disabledtag` helper definition, but no direct daemon branch
to it:

```text
_odauthauthorities_disabledtag:
  0x100031fd0  helper definition
```

This means the currently known `disabledtag` consumers live in `PlistFile.bundle`,
not in the daemon's own LDAP-auth stack path.

## VM Gates

If Claude is testing the heap-setter path, use this breakpoint order:

```text
_odcredential_set_authentication_authority
  prove x2 is attacker-controlled AuthenticationAuthority

___odcredential_copy_details_block_invoke
  at 0x10003455c, confirm credential object and credential+0x90 count

__create_connection_with_options
  at 0x100058f7c, confirm x21+0x90 count

_odauthauthorities_attribute_create
_odauthauthority_attribute_create
  watch fake slots and type-9 count > 6
```

Safe wording:

```text
Daemon-side serializers exist, but they serialize heap credential aggregates.
For the proven LDAP auth stack path, static review still shows
__find_mechanisms as the first consumer of the parsed malicious aggregate.
```

