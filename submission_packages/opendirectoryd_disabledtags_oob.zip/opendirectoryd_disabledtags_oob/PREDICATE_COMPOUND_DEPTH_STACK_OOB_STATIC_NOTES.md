# opendirectoryd legacy compound predicate depth stack OOB - static notes

Date: 2026-06-12T0230Z
Binary: `reboot_preserve_20260611T2359Z/od_arm64e`
Status: static-only sibling candidate; likely crash/DoS-class, not an LPE
primitive by itself.

## Bottom line

`opendirectoryd` has a separate off-by-one-looking stack write in the legacy
compound predicate parser used by query creation. The parent block allocates a
128-entry qword vector on its stack and stores the stack guard immediately after
that vector. The child parser checks current depth against `0x80` before
incrementing depth and writing `vector[new_depth]`.

That means a depth of `127` passes the `< 128` check, increments to `128`, and
writes `vector[128]`, which is exactly one qword past the 128-entry vector. In
this frame, that address is the saved stack canary slot. The expected dynamic
effect is a deterministic `___stack_chk_fail` abort in root `opendirectoryd`.

This is useful as a sibling bug candidate and a parser-quality signal, but it
looks weaker than the `DisabledTags` candidate because the obvious corruption is
the stack canary.

## Static evidence

Parent block:

```text
____predicate_create_compound_block_invoke

1000144f8  sub sp, sp, #0x4b0
10001450c  ldr x8, [___stack_chk_guard]
100014510  stur x8, [x29, #-0x38]     ; stack guard at sp+0x4a8
10001451c  add x22, sp, #0xa8
100014520  add x0, sp, #0xa8
100014524  mov w1, #0x400
100014528  bzero(sp+0xa8, 0x400)      ; 128 qword vector
...
100014604  mov w8, #0x80              ; depth cap captured by block
...
100014660  ldur x8, [x29, #-0x38]
100014670  cmp x9, x8
100014674  b.ne 0x100014698
100014698  ___stack_chk_fail
```

Address math:

```text
vector base  = sp + 0xa8
vector size  = 0x400 bytes = 128 qwords
vector[128]  = sp + 0xa8 + 0x400 = sp + 0x4a8
stack guard  = [x29 - 0x38] = sp + 0x4a8
```

Child parser depth check and write:

```text
____predicate_from_compoundExpression_block_invoke_2

100014a74  ldr x8, [x20, #0x28]
100014a78  ldr x8, [x8, #0x8]
100014a7c  ldr x8, [x8, #0x18]        ; current depth
100014a80  ldr x9, [x20, #0x38]        ; cap = 0x80
100014a84  cmp x8, x9
100014a88  b.ge 0x100014d60           ; reject only current depth >= 128
...
100014bd8  ldp x9, x8, [x20, #0x28]
100014bdc  ldr x8, [x8, #0x8]
100014be0  ldr x8, [x8, #0x18]        ; vector base
100014be4  ldr x9, [x9, #0x8]
100014be8  ldr x10, [x9, #0x18]       ; current depth
100014bec  add x10, x10, #0x1
100014bf0  str x10, [x9, #0x18]       ; depth = current + 1
100014bf4  str x0, [x8, x10, lsl #3]  ; vector[depth] = new CFArray
```

The error target is the expected depth guard:

```text
compound expression error more than 128 deep subexpressions
```

Because indexing starts at one for this opening-subexpression write, the guard
should be `current_depth >= 127` or the vector should contain 129 entries.

## Reachability notes

Static strings and request registration show this parser is associated with the
stock query API path:

```text
ODQueryCreateWithNode
query_predicates
kODKeyQueryPredicate
kODKeyQueryPredicateList
invalid type passed for legacy compound expression query
```

`__predicates_create` routes match type `0x200b` through the compound-expression
path:

```text
100014020  ldr w8, [x19, #0x10]
100014024  mov w9, #0x200b
100014028  cmp w8, w9
10001402c  b.ne ...
...
10001409c  _odarray_enumerate(..., ____predicate_create_compound_block_invoke)
```

This still needs VM-only dynamic confirmation. I did not run a host query or
touch host OpenDirectory services.

## Suggested VM check

If this is easy to exercise in Claude's existing VM setup, try legacy compound
query predicates at depths around the boundary:

```text
depth 126
depth 127
depth 128
depth 129
```

Expected result if the static read is right:

```text
126/127-ish: either succeeds or reaches ordinary parser errors
128 boundary: opendirectoryd .ips with ___stack_chk_fail or
              ____predicate_create_compound_block_invoke in the crashing thread
129: should hit the explicit "more than 128" parser error if it reaches the guard
```

The exact public construction likely goes through `ODQueryCreateWithNode` with
match type `0x200b` and a legacy compound-expression value/list. If building
that path is nontrivial, this should stay lower priority than the `DisabledTags`
LPE candidate because the apparent primitive is only canary clobber.

## Assessment

Classify this as:

```text
root opendirectoryd stack OOB write / stack-cookie abort candidate
stock query API reachable statically, dynamic reachability unproven
likely DoS-class unless VM evidence shows controllable corruption before return
```

It is a useful sibling to hand to Claude for a quick VM boundary test, but it
should not dilute the main `DisabledTags` report wording.
