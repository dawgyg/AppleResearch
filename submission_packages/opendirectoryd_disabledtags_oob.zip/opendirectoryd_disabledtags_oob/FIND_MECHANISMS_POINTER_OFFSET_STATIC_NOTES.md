# find_mechanisms Pointer Offset Static Notes

Date: 2026-06-12
Binary: `/usr/libexec/opendirectoryd`, arm64e `opendirectoryd-966.100.2`
Scope: answer Claude's VM question about where the `_find_mechanisms` consumed
C-string pointer lives relative to the first `DisabledTags` inline list.

## Bottom line

`__find_mechanisms` checks each authority slot's type at `slot+0x0`. If that
type is nonzero, it passes the pointer at `slot+0x10` to
`CFStringCreateWithCString`.

For an overflow from the first parsed `DisabledTags` authority, the first fake
slot is slot 1. Its `_find_mechanisms` C-string pointer is overwritten by
zero-based token indexes:

```text
slot 1 cStr low dword:   token index 10  (requires at least 11 comma tokens)
slot 1 cStr high dword:  token index 11  (requires at least 12 comma tokens)
```

The offset map explains why indexes `10` and `11` were useful marker positions.
It does not prove that the final consumed pointer value is attacker-controlled.
Later repeat testing invalidated the early single-sample control interpretation:
identical inputs produced different outcomes, and changing only the position-11
token did not make `far` track the token enum. Treat the marker observations as
non-reproducible heap-layout coincidences. Interpretation details are in
`FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md`.

## Disassembly

`___odm_handle_api_authentication_block_invoke_2` calls `__find_mechanisms` with
the auth-authority aggregate at `sp+0x78`:

```text
0x100004f7c  x0 = sp + 0x78
0x100004f84  bzero(sp+0x78, 0x238)
0x100004fa0  x0 = sp + 0x78
0x100004fa4  _odauthauthorities_parse
0x100004fbc  x0 = sp + 0x78
0x100004fc0  __find_mechanisms
```

`__find_mechanisms` then scans ten 0x38-byte slots:

```text
0x100005454  x21 = aggregate
0x10000547c  x22 = aggregate + 0x18
0x100005480  w23 = 0xa
0x100005484  ldur w8, [x22-0x10]       ; slot type at slot+0x0
0x100005488  cbz w8, skip
0x10000548c  ldr x1, [x22]             ; cStr pointer at slot+0x10
0x100005490  x0 = allocator
0x100005494  w2 = 0x600
0x100005498  CFStringCreateWithCString(allocator, cStr, 0x600)
0x1000054b4  x22 += 0x38
0x1000054b8  --slot_count
```

The earlier shorthand "slot+0x18" was wrong for this specific consumer. It is
`slot+0x10`.

## Offset math

The parser stores slot 0 at `aggregate+0x8`. For a first parsed
`DisabledTags` authority:

```text
aggregate base:     sp + 0x78
slot 0 base:        aggregate + 0x8
DisabledTags count: slot 0 + 0x18 = aggregate + 0x20
DisabledTags list:  slot 0 + 0x20 = aggregate + 0x28 = sp + 0xa0
```

The token loop writes:

```text
token index n -> list_base + (4 * n)
```

For fake slot number `s` where `s == 1..9`:

```text
slot_s base       = aggregate + 0x8 + (0x38 * s)
slot_s type       = slot_s + 0x0
slot_s cStr low   = slot_s + 0x10
slot_s cStr high  = slot_s + 0x14

type_index        = 14*s - 8
cStr_low_index    = 14*s - 4
cStr_high_index   = 14*s - 3
```

Concrete table:

```text
slot  type_idx  cStr_low_idx  cStr_high_idx
1     6         10            11
2     20        24            25
3     34        38            39
4     48        52            53
5     62        66            67
6     76        80            81
7     90        94            95
8     104       108           109
9     118       122           123
```

Runtime helpers that take token counts need `index + 1` comma tokens to include
the targeted write.

## Historical VM marker hypotheses, now invalidated as control

Use slot 1 first if doing purely diagnostic offset work. Uniform `ShadowHash`
writes value `1` into both cStr dwords, which would naively compose a pointer
near:

```text
0x0000000100000001
```

The crash report's `far` may round or report the containing fault page, so a
low-dword marker can still look like `0x100000000`. A high-dword marker should
be easier to see.

Historical marker hypotheses:

```text
index 10 = DisabledUser, index 11 = ShadowHash
naive cStr near 0x0000000100000008

index 10 = ShadowHash, index 11 = DisabledUser
naive cStr near 0x0000000800000001

index 10 = ShadowHash, index 11 = unknown token
naive cStr near 0x0000000a00000001
```

Repeat testing showed the `.ips` fault address and captured pointer state do not
reliably track the marker token. Do not claim deterministic index-10/index-11
pointer control, controlled low/high composition, or controllable target/aim from
the current evidence. The supported claim is non-controlled corrupted-pointer
dereference in root context after a deterministic OOB write.

## Caveats

This maps the in-aggregate fake-slot crash. It is distinct from the
post-aggregate pointer local at `sp+0x2b8`, whose low/high dwords are token
indexes `134` and `135`.

It still does not make the primitive arbitrary-address: the writable dwords are
limited to small enum values (`1..9`) or fallback `10`.
