# PlistFile SecureToken custom-function authorization audit (unprivileged uid501, macOS 26.5.1)

Goal: find an ungated/bypassable state-changing SecureToken custom function to chain into LPE.
Result: state-changers are properly authorization-gated. No logic-bug LPE found.

Unprivileged (uid 501) ODNodeCustomFunction on /Local/Default:

```
READS (ungated, errcode 0):
  HasSecureToken           -> {Result=0/1}   (is target a SEP user)
  SecureTokenAllowed       -> {Result=1}      (policy read)
  SecureTokenGetRecovery   -> {Result=()}     (empty without a recovery key set; no auth error)

STATE-CHANGERS (gated):
  SecureTokenSetRecovery       -> 4001 credentials not authorized
  SecureTokenRemoveRecovery    -> 4001 credentials not authorized
  SecureTokenAddSmartCardToken -> 4001 credentials not authorized
  SecureTokenSupport(enabled)  -> 5101 credentials not authorized (param-check precedes auth-check)
  SecureTokenResetPassword     -> 5102/gated
  GetSEPCredentialLockoutState -> 5100 (__validateCustomFunction/__plistfile_has_rights)
  SecureTokenPurgeOrphaned     -> errcode 0 but no-op / no mutation observed on clean system
```

Note: error 4001/5101 = "credentials are not authorized" (NOT a bad-parameter error). The earlier
5102 on SecureTokenSupport was a missing-param error emitted before the auth check; once the param is
supplied the call returns 5101 (not authorized). So Support is gated.

Conclusion: the SecureToken custom-function family does not provide an unprivileged state-changing
LPE primitive. Only read-style functions are ungated (minor SEP-state disclosure; GetRecovery would
need a populated recovery key to assess disclosure value). The DisabledTags controlled-free remains
the strong finding; a clean self-contained unprivileged LPE chain is not available on this surface.
