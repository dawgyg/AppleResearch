# PlistFile Reachability Callgraph Static Notes

Date: 2026-06-12T0319Z
Scope: static-only refinement of `PlistFile.bundle` reachability for
`AuthenticationAuthority`, `DisabledTags`, `_odauthauthorities_add_disabledtag`,
and `_odauthauthorities_remove_disabledtag`.
No host OpenDirectory, ActiveDirectory, LDAP, `dscl`, lldb, or VM dynamic
trigger was run for this note.

Update: `WHOLE_SLOT_REMOVE_FAKE_FREE_STATIC_NOTES.md` adds a fourth VM lane:
whole-slot `_odauthauthorities_remove(type=4/5)` can select a fake
SecureToken/OTI slot and run `_odauthauthority_free_contents` on enum-composed
fake pointer fields.

## Bottom Line

The PlistFile routes split into three different lanes:

```text
1. Direct record mutation:
   _odm_RecordSetValue / _odm_RecordAddValue / _odm_RecordRemoveValue
   Useful for prefill and authorization probes, but not a second-stage helper
   consumer. These paths do not call add_disabledtag, remove_disabledtag, or
   the auth-authority serializer directly.

2. Node creation:
   _odm_NodeCreateRecord -> __create_record
   Parses and may serialize AuthenticationAuthority, but normalizes
   SecureToken with whole-slot add/remove helpers. It does not call
   add_disabledtag or remove_disabledtag.

3. SEP/SecureToken helpers:
   __plistfile_attrs_add_sepCredential
     -> remove_disabledtag memmove lane when caller passes w2=1

   __plistfile_attrs_remove_sepCredential
     -> add_disabledtag append lane followed by serializer
```

That means VM time should not be spent expecting ordinary RecordSet/Add/Remove
operations to hit the helper bugs directly. Use them to test whether a lower
privilege client can seed a malformed local `AuthenticationAuthority`; then
trigger the mapped SecureToken/password workflows.

## Helper Consumer Map

### `__plistfile_attrs_add_sepCredential` - memmove lane

Function:

```text
0x1e3a4  __plistfile_attrs_add_sepCredential
```

Static shape:

```text
0x1e420  odproplist_get_array(authentication_authority)
0x1e42c  _odauthauthorities_parse
0x1e438  _odauthauthorities_disabledtag(type=w24)
0x1e450  _odauthauthorities_remove_disabledtag(type=w24)  ; if caller w2 bit 0 set
0x1e4a4  _odauthauthorities_disabledtag(type=4)            ; OTI secondary check
0x1e4b8  _odauthauthorities_remove_disabledtag(type=4)     ; if caller w2 bit 0 set
0x1e58c  _odauthauthorities_add(type=w24, authdata=0)
0x1e5f0  _odauthauthorities_add(type=4, authdata=0)        ; OTI secondary add
0x1e60c  _odauthauthorities_attribute_create
0x1e624  CFDictionarySetValue(authentication_authority)
0x1e644  CFSetAddValue(modified_attributes, authentication_authority)
```

Direct callers:

```text
0xdc04   __plistfile_verify_password_and_update_record -> w2=1
0x1dfa8  ____SecureTokenSupportEnable_block_invoke     -> w2=1
0x13044  __do_change_password                          -> w2=0
```

The `w2=1` callers are the high-value gate for the count-derived memmove
primitive in `_odauthauthorities_remove_disabledtag`. The `w2=0` caller can
still exercise the count-derived `_odauthauthorities_disabledtag` scan, but
should fail rather than remove the disabled tag.

### `__plistfile_attrs_remove_sepCredential` - append lane

Function:

```text
0x1132c  __plistfile_attrs_remove_sepCredential
```

Static shape:

```text
0x113b4  _odauthauthorities_parse
0x113c0  _odauthauthorities_remove(type=w26)
0x11454  _odauthauthorities_remove(type=4)               ; OTI/SecureToken path
0x114ac  _odauthauthorities_add_disabledtag(type=w26)
0x11510  _odauthauthorities_add_disabledtag(type=4)
0x11564  _odauthauthorities_attribute_create
0x1157c  CFDictionarySetValue(authentication_authority)
0x1159c  CFSetAddValue(modified_attributes, authentication_authority)
```

Direct callers:

```text
0x10ddc  _odm_NodeReplaceUserRecord
0x12e8c  __do_change_password
0x1ee98  __plistfile_record_remove_sepCredential
```

Higher-level callers of `__plistfile_record_remove_sepCredential` include:

```text
0x1eddc  ____SecureTokenSupportDisable_block_invoke
0x1f59c  ____SecureTokenResetPasswordNoExistingRemoveUnlockRecords_block_invoke.878
```

This lane is the seventh-append variant: if the parsed record already contains
a real type-9 `DisabledTags` slot with count six, `_odauthauthorities_add_disabledtag`
writes the next dword at `slot+0x38`, which is the adjacent authority slot's
type field.

## Direct Mutation Prefill Gates

### `_odm_RecordSetValue`

Function:

```text
0x13698  _odm_RecordSetValue
```

Relevant static gates and checks:

```text
0x13760  __fetch_and_retain_record
0x13770  __recordentry_copy_attributes
0x1380c  __session_has_privilege
0x138a0  __plistfile_attrs_modification_allowed_by_sandbox
0x13b48  compare requested attribute with authentication_authority
0x13b70  __plistfile_attrs_is_sepCredentialUser(existing attrs)
0x13bc4  _odauthauthorities_parse(proposed AuthenticationAuthority)
0x13bd8  _odauthauthorities_find(type=5)  ; OTI
0x13be8  _odauthauthorities_find(type=4)  ; SecureToken
```

This path is useful to test whether a client can seed an overfull
`DisabledTags` value, but the helper bugs are not called here. The visible
`AuthenticationAuthority` parsing is for SEP/SecureToken consistency checks,
and the final mutation is a CFArray/CFDictionary update.

### `_odm_RecordAddValue`

Function:

```text
0x150c0  _odm_RecordAddValue
```

Relevant gates:

```text
0x151f0  __session_has_privilege
0x1527c  __plistfile_attrs_modification_allowed_by_sandbox
```

This is another prefill probe. Static review did not find calls from this path
to `add_disabledtag`, `remove_disabledtag`, or the auth-authority serializers.

### `_odm_RecordRemoveValue`

Function:

```text
0x15b30  _odm_RecordRemoveValue
```

Relevant gates and `AuthenticationAuthority` special case:

```text
0x15c74  __session_has_privilege
0x15d08  __plistfile_attrs_modification_allowed_by_sandbox
0x16000  compare requested attribute with authentication_authority
0x16020  __plistfile_attrs_is_sepCredentialUser
0x16398  reject removal of SEP credential auth authority
```

This path can remove CFArray values from `AuthenticationAuthority`, but it is
not the same as calling `_odauthauthorities_remove_disabledtag`.

## NodeCreate Parser/Serializer Lane

Functions:

```text
0xee24   _odm_NodeCreateRecord
0xf53c   __create_record
```

Static shape:

```text
0xee6c   __session_has_privilege
0xee90   __plistfile_validate_creation_attributes
0xef74   _odconnection_operation
0xfc98   _odauthauthorities_parse(authentication_authority)
0xfdc4   _odauthauthorities_remove(type=4)   ; whole SecureToken slot
0xfe5c   _odauthauthorities_add(type=4)
0xfe64   _odauthauthorities_attribute_create
```

This is still worth testing as a stock parser/serializer consumer if record
creation accepts a malicious `AuthenticationAuthority`, but it is not an
`add_disabledtag` or `remove_disabledtag` helper route.

## Policy And Authorization Gates

`__session_has_privilege` and `__user_has_privilege` are real gates, not stubs:

```text
0xef9c   __session_has_privilege
         odconnection_copy_credential
         odrequest_verify_access
         odcredential_copy_recordname
         __user_has_privilege

0x225e8  __user_has_privilege
         odrequest_verify_access
         root/admin-style fast path
         per-record Users / Groups privilege arrays
```

`__plistfile_attrs_modification_allowed_by_sandbox` can also gate local user
attribute writes:

```text
0x14020  __plistfile_attrs_modification_allowed_by_sandbox
         sandbox_check_by_audit_token("opendirectory-user-modify", ...)
```

`__SecureTokenSupportEnable` has visible admin/credential checks before the
block reaches `__plistfile_attrs_add_sepCredential(..., w2=1)`:

```text
0x2068   __SecureTokenSupportEnable
0x20fc   __plistfile_attrs_is_eligible_for_sepCredential
0x2108   odcredential_has_user
0x2118   odcredential_copy_recordname
0x212c   __plistfile_user_is_an_admin
0x1df1c  ____SecureTokenSupportEnable_block_invoke
0x1dfa8  __plistfile_attrs_add_sepCredential(..., w2=1)
```

`__SecureTokenSupportDisable` has its own last-token/admin/self-disable gates
before the remove-credential block:

```text
0x2b14   __SecureTokenSupportDisable
0x2b8c   __plistfile_last_sepCredentialUser
0x2c08   __plistfile_user_is_an_admin
0x2c18   CFEqual(target user, credential user)  ; own-disable check
0x1eddc  ____SecureTokenSupportDisable_block_invoke
0x1ee98  __plistfile_record_remove_sepCredential
```

Relevant strings observed in the binary include:

```text
Session does not have privileges
Disallowed by sandbox
Not allowed to remove SEP credential auth authority
Failed to enable SEP credential... No credential set and not root
Failed to enable SEP credential... Credential is not an admin
User cannot disable their own SEP credential
```

## VM Priority From This Map

Use a disposable VM snapshot only.

Highest-signal order:

```text
1. Prefill authorization matrix:
   Test whether RecordSetValue/AddValue/NodeCreate can seed overfull
   DisabledTags as non-admin, sandboxed client, admin, or root. Break only the
   privilege/sandbox/consistency gates first. Do not expect these direct paths
   to call the helper bugs.

2. Memmove lane:
   Target SecureTokenSupportEnable and post-auth
   __plistfile_verify_password_and_update_record. Break at
   __plistfile_attrs_add_sepCredential and the two
   _odauthauthorities_remove_disabledtag call sites (0x1e450, 0x1e4b8). Record
   DisabledTags count, found index, and memmove length.

3. Append lane:
   Target SecureTokenSupportDisable, NodeReplaceUserRecord, and password-change
   paths that reach __plistfile_attrs_remove_sepCredential. Break at
   _odauthauthorities_add_disabledtag call sites (0x114ac, 0x11510) and watch
   whether count six writes slot+0x38 before serialization.

4. NodeCreate serializer:
   Treat __create_record as parser/serializer-only. It may help prove stock
   serializer consumption of a malicious AuthenticationAuthority, but it is not
   the add/remove-disabledtag helper route.
```

Reporting implication:

```text
Static proof now separates the helper bugs from authorization. The current
root-daemon crash/corrupted-pointer evidence is real; the PlistFile helper lanes become
LPE-grade only if VM testing proves a lower-privilege prefill plus a stock
authorized/system trigger. If only admin/root can seed and trigger them, keep
the helper lanes as second-stage/local-record-integrity evidence.
```
