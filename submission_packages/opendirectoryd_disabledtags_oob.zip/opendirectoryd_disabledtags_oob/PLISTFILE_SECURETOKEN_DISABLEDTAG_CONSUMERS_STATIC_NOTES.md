# PlistFile SecureToken DisabledTags Consumer Notes

Date: 2026-06-12T0252Z
Scope: static-only review of `PlistFile.bundle` consumers that call
`_odauthauthorities_disabledtag` and `_odauthauthorities_remove_disabledtag`
after parsing `authentication_authority`.
No host or VM OpenDirectory activity was run for this note.

Update: `PLISTFILE_REACHABILITY_CALLGRAPH_STATIC_NOTES.md` adds the broader
PlistFile callgraph split: direct record mutation is a prefill/authorization
probe, `NodeCreate` is parser/serializer-only, and this helper remains the
memmove lane.

## Bottom Line

`__plistfile_attrs_remove_sepCredential` is not the
`_odauthauthorities_remove_disabledtag` route. A different PlistFile helper is:

```text
__plistfile_attrs_add_sepCredential
```

This helper parses the record's `authentication_authority`, checks whether
SecureToken or OTI is disabled via `_odauthauthorities_disabledtag`, optionally
removes the disabled tag via `_odauthauthorities_remove_disabledtag`, adds the
real auth authority, then serializes through
`_odauthauthorities_attribute_create`.

That gives a real static second-stage consumer chain:

```text
parse overfull DisabledTags
  -> disabledtag(count-derived OOB scan)
  -> remove_disabledtag(count-derived memmove when removal is enabled)
  -> attribute_create(serializes all ten slots)
```

The reachability caveat is important. The visible callers are SecureToken,
password-update, and SEP-credential workflows with eligibility/admin checks.
This is a VM upgrade lane and local-record integrity lead, not a proven
unprivileged LPE path by itself.

## `__plistfile_attrs_add_sepCredential` Consumer Shape

Relevant arm64e disassembly shape:

```text
0x1e3d8  add x0, sp, #0x8
0x1e3dc  mov w1, #0x238
0x1e3e0  bzero
0x1e3e4  _sepCredential_usingOTI
0x1e3f0  mov w8, #0x4
0x1e3f4  w24 = OTI ? 5 : 4
0x1e41c  x0 = attrs
0x1e420  odproplist_get_array(authentication_authority)
0x1e428  x0 = sp+0x8
0x1e42c  _odauthauthorities_parse
0x1e430  x0 = sp+0x8
0x1e434  x1 = w24
0x1e438  _odauthauthorities_disabledtag
0x1e440  if not disabled, branch toward add
0x1e444  if remove_disabled_flag bit is clear, fail
0x1e448  x0 = sp+0x8
0x1e44c  x1 = w24
0x1e450  _odauthauthorities_remove_disabledtag
...
0x1e498  if OTI mode not active, branch toward add
0x1e49c  x0 = sp+0x8
0x1e4a0  x1 = 4
0x1e4a4  _odauthauthorities_disabledtag
0x1e4ac  if remove_disabled_flag bit is clear, fail
0x1e4b0  x0 = sp+0x8
0x1e4b4  x1 = 4
0x1e4b8  _odauthauthorities_remove_disabledtag
...
0x1e580  x0 = sp+0x8
0x1e584  x1 = w24
0x1e588  x2 = 0
0x1e58c  _odauthauthorities_add
0x1e5e4  if OTI mode, add SecureToken too
0x1e5f0  _odauthauthorities_add(type=4)
0x1e604  if modified:
0x1e60c  _odauthauthorities_attribute_create
0x1e624  CFDictionarySetValue(authentication_authority, new array)
0x1e644  CFSetAddValue(modified_attributes, authentication_authority)
```

Interpretation:

```text
w24 is the primary SEP auth type: SecureToken(4) or OTI(5)
w25 bit 0 is the caller-controlled "remove disabled tag first" flag
when OTI mode is active, the helper also checks/removes SecureToken(4)
```

If the parsed `DisabledTags` count is over six, both the pre-check and the
removal helper trust the overfull count. `disabledtag` performs a count-derived
scan; `remove_disabledtag` can perform the count-derived memmove documented in
`SECOND_STAGE_CONSUMER_REFINEMENT_NOTES.md`.

## Caller Map

Observed direct callers and the remove-disabled flag:

```text
__plistfile_verify_password_and_update_record
  0xdc04: __plistfile_attrs_add_sepCredential(..., w2=1, ...)
  This path can remove disabled tags before adding SEP credential.

____SecureTokenSupportEnable_block_invoke
  0x1dfa8: __plistfile_attrs_add_sepCredential(..., w2=1, ...)
  This path can remove disabled tags before adding SEP credential.

__do_change_password
  0x13044: __plistfile_attrs_add_sepCredential(..., w2=0, ...)
  This path checks disabled tags but should fail rather than remove them.
```

The `w2=1` callers are the high-value VM gates for the memmove primitive.
The `w2=0` caller can still exercise the count-derived `disabledtag` OOB scan,
but should not reach `_odauthauthorities_remove_disabledtag` from this helper.

## Reachability And Policy Caveat

`__SecureTokenSupportEnable` shows a visible admin-style gate before the block
that calls `__plistfile_attrs_add_sepCredential`:

```text
0x20fc  __plistfile_attrs_is_eligible_for_sepCredential
0x2108  odcredential_has_user
0x2118  odcredential_copy_recordname
0x212c  __plistfile_user_is_an_admin
0x213c  if not admin, error path
```

Relevant error string:

```text
Failed to enable SEP credential for %@ (...): Credential is not an admin
```

So the static posture is:

```text
proven statically: PlistFile has a real remove_disabledtag consumer chain
not proven: non-admin can prefill and trigger this local-record path
likely gate: authorized SecureToken/password workflows
```

## Additional DisabledTag-Only Consumers

PlistFile has several parse-then-`_odauthauthorities_disabledtag` checks in
SecureToken eligibility and account-policy flows. These calls do not memmove,
but they still trust the overfull count as a scan bound.

Examples visible in arm64e disassembly:

```text
0x3b20  SecureTokenResetPassword: disabledtag(type=4)
0x3dc4  SecureTokenResetPassword: disabledtag(type=4/5 path)
0x96b4  SecureTokenAllowed/eligibility path: disabledtag(type=5)
0x97ac  SecureTokenAllowed/eligibility path: disabledtag(type=4)
0x9828  SecureTokenAllowed/eligibility path: disabledtag(type=4)
0x10ce4 connection options path: disabledtag(type=4)
0x10d04 connection options path: disabledtag(type=5)
0x20c50 SecureToken user checks: disabledtag(type=1)
0x20e48 SecureToken user checks: disabledtag(type=5)
0x210bc SecureToken user checks: disabledtag(type=4)
0x23e78 login-hash eligibility: disabledtag(type=1)
0x23f18 login-hash eligibility: disabledtag(type=5)
```

These are useful VM probes if a local record can be seeded with an overfull
`DisabledTags` value and a stock local-record operation reaches them before a
serializer or policy error.

## VM Gates

Use only in a disposable VM snapshot.

High-signal breakpoints:

```text
__plistfile_attrs_add_sepCredential
_odauthauthorities_disabledtag
_odauthauthorities_remove_disabledtag
_odauthauthorities_attribute_create
_odauthauthority_attribute_create
```

For the memmove route:

```text
seed a throwaway local record with overfull DisabledTags
place SecureToken(4) or OTI(5) early in the list
trigger an authorized SecureToken-enable or password-update path
record __plistfile_attrs_add_sepCredential w2/x25 bit 0
record DisabledTags count, found index, and remove_disabledtag x2
verify x2 == 4*(count - 1 - found_index)
watch whether attribute_create serializes fake/nonzero slots afterward
```

For bounty framing:

```text
If only admin/root can seed and trigger this path, it is a second-stage
consumer proof and local-record integrity issue, not standalone LPE.

If a non-admin or sandboxed client can prefill the local record and cause an
authorized/system workflow to process it, this becomes a much stronger LPE or
sandbox-escape upgrade path.
```
