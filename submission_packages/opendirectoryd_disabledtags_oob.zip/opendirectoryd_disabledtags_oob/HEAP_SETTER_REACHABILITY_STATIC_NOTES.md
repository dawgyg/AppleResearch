# Heap Setter Reachability Static Notes

Date: 2026-06-12T0114Z
Binary: `/usr/libexec/opendirectoryd` arm64e, macOS 26.5.1 25F80

## Scope

Static-only notes for `_odcredential_set_authentication_authority` reachability. These notes do not run `dscl`, LDAP, lldb, or any `opendirectoryd` crash trigger on the host.

## Bottom Line

`_odcredential_set_authentication_authority` is not dead code, but the visible direct caller is a narrower trust-credential population path, not automatically the already-proven malicious user-record auth path.

The proven dynamic LDAP PoC still reaches the stack parse in `___odm_handle_api_authentication_block_invoke_2`. The heap setter should be treated as a VM-only upgrade lead until a breakpoint shows the attacker-controlled `authAuthority` array is passed as the setter's `x2` argument.

## Static Call Chain

There is one direct static call to `_odcredential_set_authentication_authority` in the preserved arm64e binary:

```text
0x100011b58  ____populate_credential_authentication_authority_block_invoke
0x100011b7c  loads dsAttrTypeStandard:AuthenticationAuthority key
0x100011b80  _odproplist_get_array(record_properties, AuthenticationAuthority)
0x100011b8c  x0 = credential
0x100011b90  x1 = node/request context
0x100011b94  _odcredential_set_authentication_authority(credential, context, authAuthorityArray)
```

The parent helper builds a one-item attribute request for `AuthenticationAuthority`, searches for the credential's own record name/type, waits for the asynchronous result, and lets the block above update the existing credential:

```text
0x100004c60  _odcredential_copy_recordname
0x100004c6c  _odcredential_copy_recordtype
0x100004ce4  CFArrayCreate(... AuthenticationAuthority ...)
0x100004d68  _od_find_record(... recordType, recordName, [AuthenticationAuthority], block)
0x100004d78  dispatch_semaphore_wait
```

The authentication handler calls this helper after copying a node trust credential and checking whether it already has parsed authentication authorities:

```text
0x100003dd0  _odnodeconfig_copy_trustcredential
0x100003dd8  _odcredential_has_authentication_authority
0x100003de8  __populate_credential_authentication_authority

0x1000041f0  _odnodeconfig_copy_trustcredential
0x1000041f8  _odcredential_has_authentication_authority
0x100004208  __populate_credential_authentication_authority
```

`_odnodeconfig_copy_trustcredential` returns `rootconfig + 0x98` under the root node-config queue:

```text
0x100042f20  _odnodeconfig_copy_rootconfig
0x100042fa0  x8 = [rootconfig + 0x98]
0x100042fb8  _od_retain
```

## Interpretation

This suggests the heap setter path populates missing authorities for a node trust credential, using the credential object's record name/type as the lookup key. It does not by itself prove that the malicious LDAP user record from the stock `/LDAPv3/<host>` auth PoC reaches the heap setter.

The system dynamic LDAPv3 template and Open Directory Server template do not show an obvious trust-credential field. They configure the dynamic node, module list, and LDAP/OpenDirectory mappings, including `AuthenticationAuthority -> authAuthority`, but no visible credential record that a client controls through the explicit node name.

## VM Confirmation Gate

In the VM, set a breakpoint on `_odcredential_set_authentication_authority` before running the dynamic LDAP PoC.

Classify the result as:

```text
breakpoint not hit:
  ordinary malicious user authAuthority path is stack-only for this trigger

breakpoint hit before crash:
  capture backtrace, x0 credential, x2 authAuthority array, record name/type, and whether x2 is the attacker LDAP array

breakpoint hit from __populate_credential_authentication_authority:
  determine whether the lookup is for the trust credential record or the victim user record
```

Only call this a heap-triggered primitive if the breakpoint proves attacker-controlled `authAuthority` reaches `x2` for `_odcredential_set_authentication_authority`.

## Exploitability Implication

The setter remains the most interesting heap path because it frees and reparses into `object + 0x90` without immediately rewriting the post-aggregate fields in the inspected block. But the reachability claim should be:

```text
static lead: trust-credential population can call the heap setter with AuthenticationAuthority fetched from a record lookup
not yet proven: the dynamic LDAP user-record PoC drives attacker data into that heap setter
proven: the dynamic LDAP user-record PoC drives attacker data into the stack auth-authority parse
```

Follow-up static narrowing: daemon-side serializer gates do exist, but they
serialize heap credential aggregates at `credential+0x90`, not the stack
aggregate used by the proven LDAP auth crash. See
`DAEMON_HEAP_SERIALIZER_GATES_STATIC_NOTES.md`.
