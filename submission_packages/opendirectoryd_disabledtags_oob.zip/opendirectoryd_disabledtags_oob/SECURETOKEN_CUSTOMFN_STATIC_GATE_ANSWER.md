# SecureToken custom-function static gate answer

Date: 2026-06-12T0434Z
Scope: static review of PlistFile SecureToken custom-function authorization gates on macOS 26.5.1.

## Bottom line

I do not see an ungated state-changing SecureToken custom function to chain with the
DisabledTags memory corruption. `HasSecureToken` remains the valuable ungated read-style
trigger, but the state-changing SecureToken functions either call `__validateCustomFunction`
or explicitly call `__plistfile_has_rights` / private entitlement checks before mutation.

Treat unprivileged `4001` and `5101` results on these functions as authorization failures,
not as bad-parameter evidence.

## Key static gates

`__validateCustomFunction` is at `PlistFile+0x1eb0`. It calls
`__plistfile_has_rights` with `w2=1` at `0x1ed4`, then validates the payload shape.

Function gate summary:

```text
SecureTokenSupport
  0x18a8  __validateCustomFunction
  enable path later checks caller/admin/root/recovery credential state
  disable path checks caller/admin/root, self-disable, and last-token constraints

SecureTokenPurgeOrphaned
  0x2ff8  __plistfile_has_rights(request, connection, 1)
  no private entitlement seen, but deletion/purge happens only after this rights check

SecureTokenResetPassword
  0x3860  __validateCustomFunction
  no-existing-password path requires com.apple.private.opendirectoryd.ResetPassword
  existing-password path verifies the prior SEP credential/password before mutation

SecureTokenVerify
  0x4fb4  __validateCustomFunction
  0x4fbc..0x5000  requires com.apple.private.opendirectoryd.securetoken

SecureTokenRemoveRecovery
  0x5aa0  __validateCustomFunction
  0x5aa8..0x5ae8  requires com.apple.private.opendirectoryd.securetoken

SecureTokenSetRecovery
  0x6390  __validateCustomFunction
  0x6398..0x63d8  requires com.apple.private.opendirectoryd.securetoken

SecureTokenAddSmartCardToken
  0xacfc  __validateCustomFunction
  0xad04..0xad14  requires com.apple.private.opendirectoryd.securetoken
```

## Payload keys decoded during review

These are useful for interpreting VM probes and failure modes:

```text
Recordname
Enabled
Password
UUID
ExpectedPassword
PreviousPassword
RecoveryPassword
ACMData
VolumePath
Passphrase
External Data
External UUID
UserName
UserPassword
Data
smartCardSecureTokenUUID
smartCardSecureTokenData

com.apple.private.opendirectoryd.securetoken
com.apple.private.opendirectoryd.ResetPassword
```

## Interpretation for the LPE campaign

The SecureToken custom-function family does not currently provide the missing logic-bug
step. Keep `HasSecureToken` for the proven non-root trigger into
`_plistfile_attrs_is_sepCredentialUser`, but do not spend VM cycles trying to turn the
state-changing SecureToken functions into an auth bypass unless dynamic evidence contradicts
the static gate order above.
