# OD Update Authority and Parse Sibling Static Notes

Date: 2026-06-12T0305Z
Scope: static-only review of `_od_update_authenticationauthority`, OpenDirectory
module imports, and nearby `_odauthauthority_parse` sibling shapes.
No host or VM OpenDirectory activity was run for this note.

## Bottom Line

`_od_update_authenticationauthority` is not the next useful second-stage
consumer for the `DisabledTags` OOB candidate.

Static review shows it builds or submits generic record update requests around
`AuthenticationAuthority`, but it does not directly call:

```text
_odauthauthorities_parse
_odauthauthorities_add_disabledtag
_odauthauthorities_remove_disabledtag
_odauthauthorities_attribute_create
_odauthauthority_attribute_create
```

The OpenDirectory module import check also keeps `PlistFile.bundle` as the only
module importing the auth-authority parse/mutation helpers.

The parser sibling review keeps the main root cause narrow: inside
`__authauthority_parse_authdata`, type `9` (`DisabledTags`) is the same-shape
unbounded comma-token append into an inline list. Other visible auth types parse
fixed fields, bitmasks, UUIDs, or heap strings rather than an unbounded inline
array.

## `_od_update_authenticationauthority`

The helper begins by requiring an async callback and a node config module slot,
then builds retained blocks and either copies an existing attribute array or
searches for a record with a fixed requested-attribute list:

```text
0x10001e800  cbz x6, return
0x10001e834  ldr x8, [x1, #0xe8]
0x10001e838  ldr x8, [x8, #0x90]
0x10001e83c  cbz x8, no-module path
...
0x10001e964  CFArrayGetCount(existing array)
0x10001e974  CFArrayCreateMutableCopy
0x10001e988  call nested updater block
...
0x10001ea84  call _od_find_record
```

The one-time attribute initializer creates a four-item requested-attribute
array:

```text
0x10001f220  load kCFAllocatorDefault
0x10001f234  count = 4
0x10001f238  CFArrayCreate
```

The decoded entries are:

```text
dsAttrTypeStandard:AuthenticationAuthority
dsAttrTypeStandard:RecordType
dsAttrTypeStandard:RecordName
dsAttrTypeStandard:AppleMetaRecordName
```

Nested blocks then enumerate arrays and perform CFArray operations:

```text
0x10001ef10  CFStringHasPrefix
0x10001ef2c  CFEqual
0x10001ef6c  CFArrayReplaceValues
0x10001efa0  CFArrayRemoveValueAtIndex
0x10001f2a0  odproplist_get_array
0x10001f3dc  CFArrayCreateMutable
```

I did not find a direct branch from this helper family into the auth-authority
parser, `DisabledTags` add/remove helpers, or serializers.

## Caller / Import Check

`opendirectoryd` has no direct `bl _od_update_authenticationauthority` xref in
the static text disassembly checked here. A module import sweep over
`/System/Library/OpenDirectory/Modules/*.bundle/Contents/MacOS/*` found no
module importing `_od_update_authenticationauthority`.

The same sweep found only `PlistFile.bundle` importing the auth-authority helper
family relevant to this bug:

```text
PlistFile imports:
  _odauthauthorities_parse
  _odauthauthorities_add_disabledtag
  _odauthauthorities_remove_disabledtag
  _odauthauthorities_disabledtag
  _odauthauthorities_attribute_create
```

This supports the existing triage: second-stage `DisabledTags` add/remove and
serializer VM work should stay on the PlistFile paths already mapped, not
`_od_update_authenticationauthority`.

## Parser Sibling Review

The generic auth-authority parser maps the authority type string to an enum and
then calls `__authauthority_parse_authdata`:

```text
0x1000310bc  default type value = 0xa
0x1000310c8  compare against 9-entry auth type table
0x1000310e8  store selected type
0x100031104  __authauthority_parse_authdata
```

The type-9 `DisabledTags` branch zeroes the count/list area, splits authdata on
commas, and appends each token's enum value using the current count with no
visible six-entry capacity check:

```text
0x100031bd0  type == 9
0x100031bdc  x21 = slot+0x18, zero count/list area
0x100031be4  delimiter = ","
0x100031c40  count = [slot+0x18]
0x100031c44  str enum -> [slot+0x20 + count*4]
0x100031c48  reload count
0x100031c4c  count++
0x100031c50  store count
0x100031c64  loop while strsep returns another token
```

The nearby sibling branches do not show the same shape:

```text
type 1 ShadowHash:
  parses HASHLIST/BLOCKED lists into bitmasks at slot+0x18 and slot+0x1c

type 2:
  splits into up to three heap strings at slot+0x18, +0x20, +0x28

type 3:
  splits into four heap strings at slot+0x18, +0x20, +0x28, +0x30

type 6:
  splits two heap strings and parses a UUID into slot+0x28

type 7 and default:
  duplicate a single heap string
```

So this pass did not find a new same-root-cause inline-array sibling in
`__authauthority_parse_authdata`; `DisabledTags` remains the parser-side
outlier.

## VM Implication

Recommended priority remains:

```text
1. Proven LDAP stack path:
   __find_mechanisms pointer composition / fake-slot boundary sweeps.

2. Heap lane:
   _odcredential_set_authentication_authority first, then heap serializers
   only if x2 is attacker-controlled AuthenticationAuthority.

3. PlistFile lane:
   __plistfile_attrs_add_sepCredential and __plistfile_attrs_remove_sepCredential
   for remove_disabledtag/add_disabledtag plus serializer behavior.
```

Do not spend VM time on `_od_update_authenticationauthority` unless a separate
runtime trace shows it feeds one of the auth-authority parse/mutation helpers.

