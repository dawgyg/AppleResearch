# PlistFile Sibling Reachability Static Notes

Date: 2026-06-12
Scope: static-only reachability review for the `_odauthauthorities_add_disabledtag`
variant lead

Update: `PLISTFILE_REACHABILITY_CALLGRAPH_STATIC_NOTES.md` adds the broader
PlistFile callgraph split: direct record mutation is a prefill/authorization
probe, `NodeCreate` is parser/serializer-only, and
`__plistfile_attrs_remove_sepCredential` remains the append-helper lane.

## Bottom Line

The single-tag append helper remains a plausible same-root-cause variant:

```text
_odauthauthorities_add_disabledtag
```

The important new caveat is reachability. Static review of
`PlistFile.bundle` shows several guardrails around direct local-record mutation,
including privilege, sandbox, and SEP-auth-authority consistency checks. This
does not disprove the helper bug, but it means the variant should not be called
unprivileged or sandbox-reachable without a VM authorization proof.

## Confirmed Append Consumer

`__plistfile_attrs_remove_sepCredential`:

```text
0x11360  x0 = sp
0x11364  w1 = 0x238
0x11368  bzero
0x1136c  _sepCredential_usingOTI
0x11378  w8 = 4
0x1137c  w26 = OTI ? 5 : 4
0x113a8  odproplist_get_array(authentication_authority)
0x113b4  odauthauthorities_parse
0x113c0  odauthauthorities_remove(type=w26)
...
0x114ac  odauthauthorities_add_disabledtag(type=w26)
...
0x11510  odauthauthorities_add_disabledtag(type=w26)
...
0x11564  odauthauthorities_attribute_create
0x1157c  CFDictionarySetValue(authentication_authority, new_array)
0x1159c  CFSetAddValue(modified_attributes, authentication_authority)
```

This confirms the shape: parse existing local-record
`authentication_authority`, remove SecureToken/OTI, append a DisabledTags entry
for the removed type, serialize, and mark the attribute modified.

Refinement: the removal calls above are `_odauthauthorities_remove`, meaning
whole auth-authority slot removal. This inspected path does not call
`_odauthauthorities_remove_disabledtag`; its bug lane is
`_odauthauthorities_add_disabledtag` followed by aggregate serialization.

Separate note: `__plistfile_attrs_add_sepCredential` is a different PlistFile
path that does call `_odauthauthorities_remove_disabledtag` before adding
SecureToken/OTI auth authority. That second-stage consumer is tracked in
`PLISTFILE_SECURETOKEN_DISABLEDTAG_CONSUMERS_STATIC_NOTES.md`.

## Callers

Static xrefs to `__plistfile_attrs_remove_sepCredential`:

```text
_odm_NodeReplaceUserRecord                         0x10ddc
__do_change_password                               0x12e8c
__plistfile_record_remove_sepCredential            0x1ee98
```

Static xrefs to `__plistfile_record_remove_sepCredential`:

```text
____SecureTokenSupportDisable_block_invoke                         0x1edfc
____SecureTokenResetPasswordNoExistingRemoveUnlockRecords_block_invoke.878 0x1f72c
```

The higher-level routes are SEP/SecureToken-sensitive flows, not ordinary
attribute serialization.

## Direct RecordSetValue Prefill Notes

`_odm_RecordSetValue` fetches the existing record and copies attributes before
mutation:

```text
0x13760  __fetch_and_retain_record
0x13770  __recordentry_copy_attributes
0x13780  odproplist_get_array(...)
0x1380c  __session_has_privilege
0x138a0  __plistfile_attrs_modification_allowed_by_sandbox
```

The helper functions are real gates, not no-ops:

```text
__session_has_privilege:
  odconnection_copy_credential
  odrequest_verify_access
  odcredential_copy_recordname
  __user_has_privilege

__user_has_privilege:
  odrequest_verify_access
  odcache_is_member_of_group
```

`__plistfile_attrs_modification_allowed_by_sandbox` can also call:

```text
sandbox_check_by_audit_token
```

String evidence in `PlistFile.bundle` includes explicit failure paths:

```text
Session does not have privileges
Disallowed by sandbox
SmartCard attributes cannot be set
Not allowed to remove SEP credential auth authority
```

For the `authentication_authority` attribute specifically, `_odm_RecordSetValue`
has SEP consistency logic:

```text
0x13b48  compare requested attribute with authentication_authority
0x13b70  __plistfile_attrs_is_sepCredentialUser(existing_attrs)
0x13bc4  parse proposed/new auth_authority
0x13bd8  find OTI when OTI mode is enabled
0x13be8  find SecureToken
0x13c78  free parsed auth authorities
```

This path appears designed to reject direct removal of SecureToken/OTI from a
SEP user, matching the string:

```text
Not allowed to remove SEP credential auth authority
```

It is therefore not currently proven that an unprivileged client can use
`RecordSetValue` to prefill an overfull `;DisabledTags;` list on a local record.

## NodeReplaceUserRecord Notes

`_odm_NodeReplaceUserRecord` also parses `authentication_authority` values:

```text
0x1091c  odproplist_get_array(authentication_authority)
0x10984  odauthauthorities_parse(existing/current attrs)
0x10b40  odauthauthorities_parse(replacement attrs)
0x10ddc  __plistfile_attrs_remove_sepCredential
```

Relevant string evidence shows this route has substantial policy checks:

```text
Failed to replace user record: Cannot preserve SEP credential for a non-root user.
Failed to replace user record: Password attribute allows login, Auth Authority attribute has SEP credential, but no new password was provided.
Failed to replace user record: Failed to remove SEP credential auth authority.
```

This route remains worth VM testing, but static evidence does not support a
simple non-admin prefill/trigger claim.

## VM-Only Test Matrix

Use a disposable VM snapshot. Do not run these on the host.

First, non-crashing authorization probes:

```text
non-admin set own AuthenticationAuthority with six DisabledTags entries
non-admin add one AuthenticationAuthority value with DisabledTags
non-admin NodeReplaceUserRecord preserving custom AuthenticationAuthority
non-admin SecureToken/SEP disable path against own record
admin same operations on a throwaway user
root same operations on a throwaway user
```

Record the exact OD error codes and unified-log strings. A permission failure
demotes the sibling to admin/local-integrity unless another stock workflow can
produce the state.

Second, only after confirming an allowed prefill path in VM:

```text
seed a throwaway local record with exactly six non-duplicate DisabledTags values
trigger __plistfile_attrs_remove_sepCredential
capture whether the seventh append corrupts the next slot, crashes, or serializes
capture fresh .ips if it crashes
```

If only admin/root can seed and trigger the condition, keep this as a variant
bug but not a bounty-grade LPE claim.
