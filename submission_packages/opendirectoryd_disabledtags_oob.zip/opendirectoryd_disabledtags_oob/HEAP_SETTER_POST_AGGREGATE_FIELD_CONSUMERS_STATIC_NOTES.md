# Heap Setter Post-Aggregate Field Consumers Static Notes

Date: 2026-06-12T0343Z
Scope: static-only refinement of the `_odcredential_set_authentication_authority`
heap lane. No host OpenDirectory, ActiveDirectory, LDAP, `dscl`, lldb, or VM
dynamic trigger was run for this note.

## Bottom Line

If VM testing proves attacker-controlled `AuthenticationAuthority` reaches
`_odcredential_set_authentication_authority`, the overflow is more interesting
than the normal credential-creation paths. The setter reparses into
`credential+0x90` and does not immediately rewrite the post-aggregate
credential fields.

Those post-aggregate fields are later consumed by credential methods and the
credential finalizer:

```text
credential + 0x2c8  CFRelease / CFRetain / kerberos principal use
credential + 0x2d0  CFRelease / password-fetch nodename argument
credential + 0x2d8  AuthorizationFree / AuthorizationCopyRights
credential + 0x2e0  od_release / password-fetch node/config argument
credential + 0x2e8  krb5_cc_destroy gate
credential + 0x2f0  krb5 context
credential + 0x2f8  free / kerberos cache name
credential + 0x310  CFRelease / SEP credential data
credential + 0x318  flags used by copy_password and has_global_rights
```

This is still not arbitrary pointer control. The written dwords are
`DisabledTags` enum values `1..10`. But if the heap setter is reachable, the
post-aggregate corruption can persist into multiple root-context consumers,
including finalizer cleanup and flag-gated credential operations.

## Setter Behavior

`_odcredential_set_authentication_authority` wraps a barrier block over the
credential's queue:

```text
0x100034268  _odcredential_set_authentication_authority
0x10003427c  x8 = [credential+0x28]         ; queue/context
0x1000342c4  block captures credential and x2 authAuthority array
0x1000342d0  dispatch_barrier_sync
```

The block frees existing authority contents and reparses the caller-provided
array into `credential+0x90`:

```text
0x1000342fc  credential = [block+0x20]
0x100034300  x0 = credential + 0x90
0x100034304  _odauthauthorities_free_contents
0x100034308  credential = [block+0x20]
0x10003430c  x1 = [block+0x28]             ; authAuthority array
0x100034310  x0 = credential + 0x90
0x100034314  _odauthauthorities_parse
```

Unlike `_odcredential_create` and `_odcredential_create_with_details`, this
visible setter path does not immediately rewrite fields such as `+0x2c8`,
`+0x2d0`, `+0x2e0`, or `+0x318` after parsing.

Reachability remains the gate. The visible static caller is still
`__populate_credential_authentication_authority`, which fetches
`AuthenticationAuthority` for the credential object's own record name/type. Do
not conflate this with the proven dynamic LDAP user-record auth stack path
unless a VM breakpoint proves the setter's `x2` is attacker-controlled.

## Token Index To Field Map

For a first-slot `DisabledTags` value parsed into a credential object:

```text
aggregate base       = credential + 0x90
DisabledTags list    = credential + 0xb8
aggregate end        = credential + 0x2c8
index n writes       = credential + 0xb8 + 4*n
```

Post-aggregate field dword map:

```text
index 132/133 -> +0x2c8 qword  CF object / Kerberos principal
index 134/135 -> +0x2d0 qword  CF nodename / password-fetch arg
index 136/137 -> +0x2d8 qword  AuthorizationRef
index 138/139 -> +0x2e0 qword  node/config object
index 140/141 -> +0x2e8 qword  krb5 credential-cache handle/gate
index 142/143 -> +0x2f0 qword  krb5 context
index 144/145 -> +0x2f8 qword  heap string/cache name
index 150/151 -> +0x310 qword  SEP credential CF object
index 152     -> +0x318 low dword flags
```

The first post-aggregate write needs 133 comma tokens. Reaching `+0x318` needs
153 comma tokens.

## Finalizer Consumers

`__odcredential_finalize` frees the authority aggregate and then consumes the
post-aggregate fields:

```text
0x100035c20  _odauthauthorities_free_contents(credential+0x90)
0x100035c38  CFRelease([credential+0x2d0]) if non-null
0x100035c48  CFRelease([credential+0x2c8]) if non-null
0x100035c58  CFRelease([credential+0x310]) if non-null
0x100035c68  od_release([credential+0x2e0])
0x100035c74  free([credential+0x2f8]) if non-null
0x100035c84  AuthorizationFree([credential+0x2d8], 0) if non-null
0x100035c94  if [credential+0x2e8] non-null:
0x100035c9c      krb5_cc_destroy([credential+0x2f0], [credential+0x2e8])
0x100035ca8  if [credential+0x2f0] non-null:
0x100035cb0      krb5_free_context([credential+0x2f0])
```

If the setter is reachable, indexes `132..145` can place enum-composed nonzero
qwords into these finalizer fields. Expected effects are low-pointer
`CFRelease`, `od_release`, `free`, `AuthorizationFree`, or `krb5_*` crashes,
unless heap layout or another object effect turns one of the values into a
valid pointer. That latter condition is not proven.

## Flag Consumers

`credential+0x318` is a flags field. The low byte is checked by credential
helpers:

```text
0x1000348b4  _odcredential_copy_password block:
              ldrb flags, [credential+0x318]
              if bit 1 set:
                _od_fetch_password([+0x2d0], [+0x2e0], 0, [+0x70])
              else:
                CFRetain([+0x88])

0x100033c54  _odcredential_has_global_rights:
              ldrb flags, [credential+0x318]
              if bit 3 set:
                AuthorizationCopyRights([+0x2d8], ...)
```

Since enum values include bit-setting values:

```text
bit 1 set by enum values 2, 3, 6, 7, 10
bit 3 set by enum values 8, 9, 10
```

an attacker can choose a token at index `152` that flips these paths if the
credential survives long enough for those methods to run. The pointer arguments
remain enum-composed unless other heap effects intervene.

## VM Test Suggestion

Use only a disposable VM snapshot.

First gate:

```text
break _odcredential_set_authentication_authority
require x2 == attacker-controlled AuthenticationAuthority array
record credential x0 and authAuthority x2
```

If that gate passes, classify with three token-count classes:

```text
133..145 tokens:
  corrupt finalizer / krb5 / Authorization pointer fields

153 tokens:
  corrupt +0x318 flags

combined 153+ tokens:
  set +0x318 flags and earlier pointer arguments together
```

High-signal breakpoints:

```text
_odcredential_set_authentication_authority
___odcredential_set_authentication_authority_block_invoke
__odcredential_finalize
_odcredential_copy_password
_odcredential_has_global_rights
CFRelease
free
AuthorizationFree
AuthorizationCopyRights
krb5_cc_destroy
krb5_free_context
```

Record:

```text
credential pointer
[credential+0x2c8..0x318] after parse
whether finalizer or a credential method consumes the corrupted values
fault address and backtrace if a low-pointer crash occurs
```

## Reporting Implication

Safe wording:

```text
If attacker-controlled authAuthority reaches the heap setter, the same
DisabledTags overflow can corrupt persistent credential fields after the
auth-authority aggregate. Static consumers include finalizer release/free paths
and flag-gated Authorization/password paths.
```

Unsafe wording until VM proof:

```text
heap setter is reachable from the dynamic LDAP PoC
post-aggregate corruption gives arbitrary free
credential flags bypass authorization
LPE or code execution
```
