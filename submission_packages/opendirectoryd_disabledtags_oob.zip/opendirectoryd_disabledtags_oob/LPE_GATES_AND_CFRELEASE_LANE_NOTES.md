# LPE Gates And CFRelease Lane Notes

Date: 2026-06-12T0412Z
Scope: static/package triage after the unprivileged HasSecureToken controlled-free proof.
No host OpenDirectory, LDAP, dscl, lldb, or VM dynamic trigger was run for this note.

## Current Security Tier

Current evidence is strong enough for:

```text
non-root/sandboxed -> root opendirectoryd memory corruption
```

The strongest dynamic result is now:

```text
uid 501 -> ODNodeCustomFunction(/Local/Default, "HasSecureToken",
{"Recordname": victim}) -> root opendirectoryd free(0x800000008)
```

That proves an unprivileged trigger for a deterministic, attacker-composed
invalid free in root `opendirectoryd`, assuming the named local PlistFile record
already contains the toxic `AuthenticationAuthority`.

Claude's token sweep confirms the bad-free value tracks the enum selected at
DisabledTags indexes 10/11:

```text
AppleID(7)         -> free(0x700000007)
Kerberosv5(3)      -> free(0x300000003)
LocalCachedUser(6) -> free(0x600000006)
DisabledUser(8)    -> free(0x800000008)
```

It is not yet a complete LPE or Target Flag proof because:

```text
1. the direct fake-slot free value is enum-composed, not an arbitrary pointer
2. the observed value 0x800000008 is invalid and libmalloc aborts
3. non-root placement of the toxic local PlistFile record is not proven
4. LDAP supply reaches the base auth parser, but not yet this PlistFile cleanup consumer
5. no arbitrary read/write, PC control, valid object free, or Target Flag write is proven
```

## The Two Missing LPE Bridges

To honestly call this LPE-grade, we need at least one complete bridge in both
columns:

```text
attacker supply/placement:
  A. non-root can create or modify the toxic local PlistFile AuthenticationAuthority
  B. LDAP-supplied AuthenticationAuthority reaches the same cleanup/finalizer consumer
  C. another public API fetches attacker-controlled AA and reaches the heap setter

primitive upgrade:
  A. corrupt a valid heap/CF/OD/Kerberos object pointer, not 0x0000000H0000000L
  B. convert enum-composed field corruption into useful method dispatch or flags
  C. get arbitrary read/write, PC control, or Apple Target Flag write
```

The `HasSecureToken` proof solved trigger reachability for one cleanup consumer.
It did not solve local toxic-record placement or pointer usefulness.

## CFRelease / Credential Finalizer Lane

This is the best current primitive-upgrade lead, but only after one dynamic gate.

Static consumer map:

```text
_odcredential_set_authentication_authority
  -> _odauthauthorities_free_contents(credential+0x90)
  -> _odauthauthorities_parse(credential+0x90, attackerAA?)

__odcredential_finalize
  -> CFRelease([credential+0x2d0]) if non-null
  -> CFRelease([credential+0x2c8]) if non-null
  -> CFRelease([credential+0x310]) if non-null
  -> od_release([credential+0x2e0])
  -> free([credential+0x2f8])
  -> AuthorizationFree([credential+0x2d8], 0)
  -> krb5_cc_destroy([+0x2f0], [+0x2e8])
```

Post-aggregate index map if the parse happens inside `credential+0x90`:

```text
index 132/133 -> credential+0x2c8 qword
index 134/135 -> credential+0x2d0 qword
index 136/137 -> credential+0x2d8 qword
index 138/139 -> credential+0x2e0 qword
index 144/145 -> credential+0x2f8 qword
index 150/151 -> credential+0x310 qword
index 152     -> credential+0x318 flags
```

Critical VM gate:

```text
break _odcredential_set_authentication_authority
require x2 == attacker-controlled AuthenticationAuthority array
capture x0 credential, x2 authAuthority, backtrace, record name/type
after parse, inspect [credential+0x2c8..0x318]
```

If the breakpoint does not hit, or `x2` is not attacker-controlled, the
CFRelease/finalizer lane should stay as a static lead.

If the gate passes, CFRelease crashes are stronger evidence than malloc invalid
free because CFRelease dereferences object internals before allocator provenance
checks. The ceiling is still limited by enum-composed qwords unless another
heap effect gives a valid object address or controllable object contents.

## What Counts As The $500k-Grade Upgrade

High-confidence upgrade evidence would be one of:

```text
1. Apple Target Flag captured from root opendirectoryd.
2. Arbitrary read/write in root opendirectoryd.
3. Reliable PC control or code execution in root opendirectoryd.
4. Valid heap/CF object corruption that survives libmalloc checks and produces
   a controlled call, controlled object release, or write primitive.
5. A full unprivileged chain where the same non-root client both supplies the
   toxic AuthenticationAuthority and triggers a stronger-than-abort consumer.
```

Useful but not enough alone:

```text
1. More deterministic aborts at enum-composed low pointers.
2. CFRelease/AuthorizationFree/krb5 crashes where fault address is still
   0x0000000H0000000L and no object control follows.
3. Root/admin seeded toxic local records without a non-root placement or supply path.
```

## Immediate VM Questions For Claude

```text
1. Does _odcredential_set_authentication_authority fire during the dynamic LDAP auth PoC?
2. If yes, is x2 the attacker LDAP AuthenticationAuthority array or a trust credential lookup result?
3. Can any public non-root custom function or auth API force finalization after indexes 132..152 corrupt credential fields?
4. Does any CFRelease crash fault on a value tracking indexes 132/133, 134/135, or 150/151?
5. Can a non-root user create/modify the toxic local PlistFile AuthenticationAuthority, or is local placement privilege-gated?
6. Is there any LDAP/module custom function that reaches a PlistFile-like cleanup path, instead of the base auth stack only?
```
