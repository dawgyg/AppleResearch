# Non-Control Wording Cleanup Notes

Date: 2026-06-12T0329Z
Scope: package consistency update after repeat VM testing invalidated the
earlier p10/p11 consumed-pointer control interpretation.
No host OpenDirectory, ActiveDirectory, LDAP, `dscl`, lldb, or VM dynamic
trigger was run for this note.

## Bottom Line

The current package should use this wording:

```text
Root opendirectoryd memory corruption with a later root-context corrupted
C-string pointer dereference is proven.
Deterministic p10/p11 pointer control is not proven and was invalidated by
repeat testing.
```

Older handoff snippets that mention "p10/p11 control", "two-dword
composition", or "controllable root-daemon crash" are superseded by:

```text
FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md
vm_dynamic_evidence/SWEEP_RESULTS.md
vm_dynamic_evidence/DYNAMIC_CRASH_ANALYSIS.md
```

The static offset map is still useful for geometry and breakpoint placement:
indexes `10/11` land on the first fake slot's `slot+0x10` field. The dynamic
faulting pointer value, however, did not reliably track those token values.

## Remaining Valid Upgrade Lanes

VM time should stay on second-stage effects:

```text
1. _odcredential_set_authentication_authority
   Prove whether x2 is attacker-controlled AuthenticationAuthority, then inspect
   heap aggregate post-boundary corruption and finalizers.

2. Trusted-count consumers
   _odauthauthorities_remove_disabledtag
   _odauthauthorities_attribute_create
   _odauthauthority_attribute_create

3. PlistFile helper paths
   __plistfile_attrs_add_sepCredential    -> remove_disabledtag memmove lane
   __plistfile_attrs_remove_sepCredential -> add_disabledtag append lane

4. Whole-slot selected-free lane
   _odauthauthorities_remove(type=4/5)
   _odauthauthority_free_contents(fake SecureToken/OTI slot)
```

## Files Touched

This cleanup patched stale support wording in:

```text
AUTH_PATH_PRIMITIVE_MAP.md
REACHABILITY_DYNAMIC_NODE.md
STATIC_HUNT_CONTINUATION_NOTES.md
STRSEP_SIBLING_AND_ADD_HELPER_STATIC_NOTES.md
PLISTFILE_REACHABILITY_CALLGRAPH_STATIC_NOTES.md
```

The main report and exploitability notes were already mostly using the corrected
non-control framing.
