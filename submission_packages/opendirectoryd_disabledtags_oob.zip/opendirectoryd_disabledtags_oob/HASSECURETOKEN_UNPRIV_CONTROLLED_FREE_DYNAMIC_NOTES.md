# HasSecureToken Unprivileged Controlled-Free Notes

Date: 2026-06-12T0403Z
Scope: Claude/user-reported VM dynamic result plus Codex static dispatch
mapping. Codex did not run host OpenDirectory, LDAP, `dscl`, lldb, or VM
dynamic triggers for this note.

## Bottom Line

Claude reports the key reachability upgrade:

```text
uid=501 (non-root)
  -> ODNodeCustomFunction("HasSecureToken", { "Recordname": victim })
  -> root opendirectoryd crashed
  -> opendirectoryd malloc: *** error for object 0x800000008:
     pointer being freed was not allocated
```

This removes the `RecordDelete` operation gate for the confirmed cleanup
consumer. A non-root client can trigger the same root-daemon controlled invalid
free through the read-style `HasSecureToken` custom function, provided the named
record already contains the toxic `AuthenticationAuthority`.

Claude later provided the full reported backtrace:

```text
_odrequest_api_process
  odm_NodeCustomFunction
    HasSecureToken
      _plistfile_attrs_is_sepCredentialUser
        odauthauthorities_free_contents
          odauthauthority_free_contents
            free(0x800000008)
              libmalloc abort
```

Current classification:

```text
unprivileged trigger -> root opendirectoryd controlled invalid free
```

This is a major upgrade over the previous root/admin `RecordDelete` trigger.
It is still not, by itself, a proven LPE or Target Flag primitive because the
freed value is enum-composed and the attacker-controlled toxic-record placement
gate still needs a clean non-admin story.

Raw artifact status:

```text
vm_dynamic_evidence/opendirectoryd_UNPRIV_HasSecureToken_free_0x800000008.ips:
  copied into the package
vm_dynamic_evidence/malloc_error_freed_pointer.txt:
  contains the malloc bad-free object line
vm_dynamic_evidence/odtest_client.c:
  public OpenDirectory ODNodeCustomFunction trigger source
vm_dynamic_evidence/UNPRIV_CONTROLLED_FREE_HasSecureToken.md:
  Claude dynamic analysis note
vm_dynamic_evidence/hassecuretoken_unprivileged_controlled_free_report.txt:
  text banked from Claude/user report
```

## Static Dispatch Confirmation

Daemon-side dispatch for `ODNodeCustomFunction` performs a module-advertised
custom-function whitelist check and then resolves the requested function name
from the module bundle:

```text
0x100009574  ___odm_NodeCustomFunction_block_invoke
0x100009598    x22 = [moduleconfig+0x88]                  ; module
0x1000095a4    function_name = request custom function
0x1000095ac    _odmodule_supports_customfunction(module, function_name)
0x1000095b4    bundle = [module+0x78]
0x1000095bc    function_name = request custom function
0x1000095c0    CFBundleGetFunctionPointerForName(bundle, function_name)
0x1000095fc    x0 = module
0x100009600    x3 = moduleconfig
0x100009604    blraaz resolved_function
```

The whitelist helper reads the module `Info.plist` `ODCustomFunctions`
dictionary:

```text
0x1000385c4  _odmodule_supports_customfunction
0x1000385dc    bundle = [module+0x78]
0x1000385e0    CFBundleGetInfoDictionary(bundle)
0x1000385ec    _odproplist_get_dictionary(..., "ODCustomFunctions")
0x1000385f8    CFDictionaryContainsKey(ODCustomFunctions, requested_name)
```

`PlistFile.bundle/Contents/Info.plist` advertises:

```text
ODCustomFunctions => {
  "HasSecureToken" => "Dictionary"
  "GetSEPCredentialLockoutState" => "Dictionary"
  "SecureTokenAllowed" => "Dictionary"
  ...
}
```

Therefore the daemon-side custom-function whitelist should pass for
`HasSecureToken`, and the requested name resolves directly to the exported
PlistFile `_HasSecureToken` function.

## Vulnerable Call Chain

The relevant PlistFile path is read-style and reaches the same cleanup helper:

```text
0x8738  _HasSecureToken
0x879c    __plistfile_get_command_ctx(...)
0x87a4    _sepCredential_context_is_valid(...)
0x87e8    _odproplist_get_string(payload, "Recordname")
0x8808    __fetch_and_retain_record(..., "users", Recordname)
0x8894    dispatch_sync(record queue, ___HasSecureToken_block_invoke)

0x8b9c  ___HasSecureToken_block_invoke
0x8c38    __plistfile_attrs_is_sepCredentialUser(attrs, ...)

0x8c70  __plistfile_attrs_is_sepCredentialUser
0x8e38    _odauthauthorities_parse(sp+0x8, AuthenticationAuthority)
0x8e50    __plistfile_is_sepCredentialUser(...)
0x8ef4    _odauthauthorities_free_contents(sp+0x8)
```

`_HasSecureToken` itself does not show a local call to
`__validateCustomFunction` or `__session_has_privilege` in the reviewed static
path. The new VM result confirms that non-root can reach the cleanup/free path.

## Controlled Free Composition

The observed bad free is the same fake-slot primitive as the earlier
`RecordDelete` crash:

```text
index 6  = SecureToken   ; fake auth-authority slot type 4
index 10 = DisabledUser  ; low dword 8
index 11 = DisabledUser  ; high dword 8
free(0x00000008_00000008)
```

The cleanup code frees pointer fields from every nonzero parsed slot:

```text
_odauthauthorities_free_contents
  -> _odauthauthority_free_contents(fake slot)
       -> free([fake_slot+0x10])  ; observed 0x800000008
```

## Security Impact Calibration

Proves:

```text
non-root client can trigger root opendirectoryd to free an attacker-composed
qword from a malformed AuthenticationAuthority record
```

Still needs proof:

```text
non-root creation or attacker-controlled supply of the toxic local PlistFile
record used by HasSecureToken
valid heap-pointer free or weaponizable allocator state corruption
arbitrary read/write, PC control, code execution, or Target Flag capture
```

The strongest current report wording is:

```text
Unprivileged root-daemon memory corruption: ODNodeCustomFunction
HasSecureToken reaches a DisabledTags parser OOB cleanup path and causes
root opendirectoryd to free an attacker-composed invalid pointer.
```

## Evidence Status And Remaining Gates

Satisfied evidence asks:

```text
1. full HasSecureToken .ips crash report
2. ReportCrash / malloc line for object 0x800000008
3. non-root ODNodeCustomFunction client source
4. repeated uid=501 -> free(0x800000008) report
```

Still open:

```text
1. whether any non-root path can create/modify the toxic local PlistFile
   AuthenticationAuthority used by HasSecureToken
2. whether attacker-supplied LDAP AuthenticationAuthority can reach this same
   PlistFile cleanup consumer, or another cleanup/finalizer consumer with equal
   or stronger primitive quality
3. whether any lane turns the enum-composed invalid free into a valid object,
   valid heap-pointer free, arbitrary read/write, PC control, or Target Flag
```

Next dynamic discriminators:

```text
token sweep indexes 10/11:
  DisabledUser/DisabledUser -> 0x800000008
  AppleID/AppleID           -> 0x700000007
  Kerberosv5/Kerberosv5     -> 0x300000003
  unknown/unknown           -> 0xa0000000a

placement matrix:
  toxic record precreated by root/admin, triggered by non-root
  toxic same-user record created/modified by non-root, triggered by non-root
  toxic authority supplied by dynamic LDAP path, if any read-style cleanup
  consumer reaches that node/module
```
