# Reboot Preservation Snapshot

Created before SIP-disable reboot on 2026-06-11.

This directory preserves volatile `/tmp` artifacts and fresh static evidence for the `opendirectoryd` `DisabledTags` OOB-write investigation.

## Preserved From `/tmp`

- `od_arm64e`: extracted arm64e `opendirectoryd` binary used for static disassembly.
- `evilldap/`: full malicious LDAP fixture tree from `/tmp/evilldap`, including:
  - `seed.ldif`
  - `custom.schema`
  - `slapd.conf`
  - `fg.log`
  - `fg389.log`
  - `data/dc=evil,dc=test/uid=victim.ldif`

## Generated Snapshots

- `auth_handler_block_invoke_2_disasm.txt`: bounded disassembly for `___odm_handle_api_authentication_block_invoke_2`.
- `authauthority_parse_window_disasm.txt`: bounded disassembly around `_odauthauthorities_parse` and `__authauthority_parse_authdata`.
- `dynamic_node_create_disasm.txt`: bounded disassembly for `_odnodeconfig_create_dynamic`.
- `dynamic_template_LDAPv3_plutil.txt`: plutil dump of Apple's LDAPv3 dynamic node template.
- `template_Open_Directory_Server_plutil.txt`: plutil dump of the Open Directory Server template.
- `mapping_Open_Directory_plutil.txt`: plutil dump of the Open Directory mapping.
- `writable_od_config_files_pre_reboot.txt`: writable OpenDirectory configuration files present before reboot.
- `opendirectoryd_launchctl_pre_reboot.txt`: pre-reboot launchctl state for `opendirectoryd`.
- `process_snapshot.txt`: process snapshot for `slapd`, `dscl`, and `opendirectoryd`.
- `SHA256SUMS.txt`: checksums for this preservation directory.

## Safety Note

Do not re-trigger the crash on the live host after reboot just to confirm state. This boot already had repeated `opendirectoryd` crashes and `PanicOnConsecutiveCrash` is enabled. Further exploitability work should run in a disposable VM with low-token sweeps first.

