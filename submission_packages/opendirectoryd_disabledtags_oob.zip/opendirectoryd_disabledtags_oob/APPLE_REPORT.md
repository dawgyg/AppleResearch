# Apple Security Bounty report — opendirectoryd AuthenticationAuthority DisabledTags OOB-write

## Affected Area
opendirectoryd (Directory Services) — root system daemon, sandbox-reachable Mach service
com.apple.system.opendirectoryd.api

## Title (<100)
Out-of-bounds write in root opendirectoryd parsing AuthenticationAuthority DisabledTags, reachable from a sandboxed process

## System
macOS 26.5.1 (25F80), arm64e. /usr/libexec/opendirectoryd version string opendirectoryd-966.100.2.

## Summary
opendirectoryd parses each directory record's AuthenticationAuthority attribute during any
authentication/verify request. The "DisabledTags" authority type handler
(__authauthority_parse_authdata) splits a comma-separated token list and appends each token's
32-bit enum value into a fixed 6-entry inline array inside the 0x38-byte per-authority slot,
with NO bounds check:

    0x100031c40  ldr x8, [x21]            ; count   (slot+0x18)
    0x100031c44  str w24, [x22, x8, lsl #2]; array[count] = enum   (x22 = slot+0x20)  <-- UNBOUNDED
    0x100031c48  add x8, x8, #1 ; str back ; count++  ; next comma token

The inline array (slot+0x20 .. slot+0x38) holds only 6 uint32. An AuthenticationAuthority value
of the form ";DisabledTags;<7+ comma tokens>" writes past the slot, corrupting adjacent process
memory in root opendirectoryd. (_odauthauthorities_remove_disabledtag uses #0x5/#0x6 cap math,
confirming the intended capacity is 6.) The aggregate of 10 authority slots (0x238 bytes) is a
stack buffer (sp+0x78) in the API auth path, and a heap OS_od_credential object (object+0x90) in
the credential paths.

## UPDATE — Unprivileged -> root controlled invalid-free (escalation beyond the base crash)

Further VM analysis upgraded this from a non-deterministic crash to a DETERMINISTIC, attacker-
controlled `free()` in the root daemon, reachable from a NON-ROOT process with no privilege gate.

Mechanism: set DisabledTags token index 6 = "SecureToken" (tag enum 4). The OOB write then stamps
type 4 into the first overflowed "fake" authority slot (aggregate+0x40). When opendirectoryd
enumerates SEP-credential authorities, the cleanup `_odauthauthorities_free_contents` walks all ten
fixed slots, skips only type==0, so it VISITS the fake slot and `_odauthauthority_free_contents`
frees `fakeslot+0x10` — a pointer composed from DisabledTags token indexes 10/11. With those tokens =
"DisabledUser" (enum 8), the freed pointer is the attacker-composed value 0x800000008.
VM token sweep confirms this value tracks the chosen enum at indexes 10/11:
AppleID -> 0x700000007, Kerberosv5 -> 0x300000003, LocalCachedUser -> 0x600000006,
DisabledUser -> 0x800000008.

Unprivileged trigger (public OpenDirectory API, no admin):
    ODNodeCustomFunction(/Local/Default, "HasSecureToken", {"Recordname": victim})
Run as uid 501 (non-root), this makes ROOT opendirectoryd call free(0x800000008) and abort with heap
corruption. Reproduced deterministically. The `HasSecureToken` PlistFile custom function has no
`__session_has_privilege` gate (verified static + dynamic), which removes the privilege gate that the
RecordDelete path had.

Reachability calibration for this update: the demonstrated `HasSecureToken` controlled-free trigger was
run against a toxic local PlistFile record in the VM; the non-root property applies to the trigger. The
separate dynamic LDAP result below proves non-root/sandboxed attacker supply to the base
AuthenticationAuthority parser, but it is not yet claimed to feed this exact PlistFile
`HasSecureToken` cleanup consumer.

System log (root opendirectoryd):
    opendirectoryd(PID) malloc: *** error for object 0x800000008: pointer being freed was not allocated

Crash backtrace (system .ips, SIGABRT):
    _odrequest_api_process -> odm_NodeCustomFunction -> __odm_NodeCustomFunction_block_invoke
      -> HasSecureToken (PlistFile) -> __HasSecureToken_block_invoke
      -> _plistfile_attrs_is_sepCredentialUser
      -> odauthauthorities_free_contents -> odauthauthority_free_contents
      -> free(0x800000008) -> ___BUG_IN_CLIENT_OF_LIBMALLOC_POINTER_BEING_FREED_WAS_NOT_ALLOCATED

Honest calibration: the freed value (0x800000008) is composed from tag enums (each dword in 1..0xa),
so it is an obviously-invalid address that libmalloc's safety check catches and aborts on. This is a
reproducible UNPRIVILEGED -> root controlled invalid-free / heap-corruption (attacker-controlled free
pointer), not yet a free of a valid heap allocation (UAF) or code execution. Platform: macOS only
(opendirectoryd does not exist on iOS).

Evidence: vm_dynamic_evidence/UNPRIV_CONTROLLED_FREE_HasSecureToken.md,
opendirectoryd_UNPRIV_HasSecureToken_free_0x800000008.ips, malloc_error_freed_pointer.txt,
CONTROLLED_FREE_TOKEN_SWEEP_AND_PLACEMENT.md, opendirectoryd_controlled_free_0x800000008.ips,
odtest_client.c.

## Reachability for the base parser (no admin, no local root required)
AuthenticationAuthority is in opendirectoryd's __auth_attributes default 7-item fetch set for an
ordinary verify, so it is fetched and parsed for any record an auth targets — including records
served by a directory node. /System/Library/OpenDirectory/DynamicNodeTemplates/LDAPv3.plist is a
"Dynamic LDAPv3 node" using the "Open Directory Server" template (which maps
dsAttrTypeStandard:AuthenticationAuthority -> LDAP authAuthority). A non-root / sandboxed process
(the app sandbox allows com.apple.system.opendirectoryd.api) can ODNodeCreateWithName("/LDAPv3/
<attacker-host>") WITHOUT dsconfigldap/admin; OD connects to the attacker's LDAP, fetches the
crafted authAuthority, and parses it. Verified: with no configured LDAP nodes, /LDAPv3/<host>
access is dynamic and a non-root dscl query runs without permission error.

## Reproduction (demonstrated: root opendirectoryd SIGSEGV)
1. Attacker LDAP (OpenLDAP slapd, ldif backend, port 389) serves a user record whose authAuthority =
   ";DisabledTags;<400 comma-separated ShadowHash tokens>" (objectClass apple-user/inetOrgPerson/
   posixAccount under cn=users). [Full slapd config + LDIF in LDAP_TRANSCRIPT_AND_MAPPING.md / rig.]
2. A non-root / sandboxed client triggers a verify against that record via the dynamic node:
   dscl /LDAPv3/<attacker-host> -authonly victim x
3. opendirectoryd fetches + parses the malicious authAuthority -> OOB write -> root daemon
   terminates with SIGSEGV. launchd log: "opendirectoryd [PID] exited due to SIGSEGV"
   (opendirectoryd_SIGSEGV_log_evidence.txt). A sandbox-profiled client (only the opendirectoryd.api
   Mach lookup, no network) reproduced the same root crash.
   Local variant (confirms the corruption; needs root to set the attribute):
     sudo dscl . -create /Users/p AuthenticationAuthority ";DisabledTags;<400 tokens>"
     dscl . -authonly p x   -> root opendirectoryd SIGSEGV.

## Impact (honest framing — agreed with co-researcher)
A sandboxed, non-root client can select an explicit dynamic LDAP node such as /LDAPv3/<attacker-host>.
opendirectoryd dynamically materializes the node from Apple's LDAPv3 dynamic template, fetches a
network-supplied user record, maps LDAP authAuthority to AuthenticationAuthority, and parses it in
ROOT context. A malicious ";DisabledTags;..." value triggers the OOB write in root opendirectoryd.
Demonstrated impact: memory corruption + crash of the root daemon from a sandboxed/non-root client.
VM-native crash analysis shows the overflow corrupts an adjacent authority/mechanism structure that
is later consumed as a C-string pointer by _find_mechanisms -> CFStringCreateWithCString -> strlen
(consistent crash site across all runs); the daemon dereferences a corrupted pointer in root context.

Controllability — honest, measured: the OOB write itself is deterministic (boundary is exact: 6 tokens
never crash, 8+ crash), but the *value* of the later-consumed pointer is NON-DETERMINISTIC and
heap-layout dependent. Repeating an identical input multiple times produced different fault addresses
across runs (observed: no-crash, 0x0, and 0x100000000/0x800000000) for the same token list. In some
runs attacker token bytes appear in the consumed pointer dwords (e.g. a DisabledUser token correlating
with 0x8.. in the fault address), but this does NOT reproduce reliably, so it must be treated as a
non-controlled corrupted-pointer dereference, not a reliable controlled-write/aim primitive.

NOT claimed: privilege escalation, root code execution, or reliable pointer control. Even when attacker
bytes do land, each OOB-written dword is bounded to the small auth-type tag enum (1..0xa), and the
target is not mappable from the attacker side. This is reported as a sandbox/unprivileged-reachable
heap out-of-bounds WRITE in a root daemon (memory-safety violation) with a demonstrated root-daemon
crash; exploitability grading deferred to Apple.

## Original impact note
Memory corruption (out-of-bounds write of attacker-controlled length) in a root system daemon,
reachable from a sandboxed/unprivileged process via a dynamic LDAP node with no admin step.
The written value per element is a tag enum (0-0xa); the write LENGTH is attacker-controlled.

## Evidence (attached)
- opendirectoryd_SIGSEGV_log_evidence.txt — launchd SIGSEGV terminations of root opendirectoryd.
- static_oob_analysis.txt — the uncapped store loop disassembly.
- REACHABILITY_DYNAMIC_NODE.md, LDAP_TRANSCRIPT_AND_MAPPING.md — the no-admin dynamic-node path + LDAP transcript.
- EXPLOITABILITY.md / EXPLOITABILITY_TRIAGE.md — primitive analysis (stack vs heap, value constraint).
- vm_dynamic_evidence/DYNAMIC_CRASH_ANALYSIS.md, FIND_MECHANISMS_POINTER_OFFSET_STATIC_NOTES.md,
  FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md — root-context corrupted-pointer dereference and
  non-deterministic marker-correlation correction.
Note: on the host proof, opendirectoryd has _PanicOnCrash and the launchd SIGSEGV log is the crash
record. In the disposable SIP-off VM, native .ips reports were generated and used for register-state
triage.
