# Sibling Static Hunt Notes

Date: 2026-06-12
Scope: static-only search for related `AuthenticationAuthority` /
`DisabledTags` bugs

## Bottom Line

I did not find a second identical `strsep`-style parser bug inside
`opendirectoryd`. The useful sibling lead is the exported single-tag append
helper:

```text
_odauthauthorities_add_disabledtag
```

Static disassembly shows this helper appends one enum value to a `DisabledTags`
slot without a visible capacity check against the six-entry inline list. If the
parsed list already has six non-duplicate entries, one more append can write
past the inline capacity.

This is a same-root-cause local-node mutation lead, not a proven LPE. A deeper
reachability review is in `PLISTFILE_SIBLING_REACHABILITY_STATIC_NOTES.md`; the
short version is that direct local-record mutation has visible privilege,
sandbox, and SEP-auth-authority consistency checks.

## Parser Duplicate Search

Within `opendirectoryd`, the directly relevant string-splitting parser surface
stays concentrated in:

```text
__authauthority_parse
__authauthority_parse_authdata
__authauthority_parse_shadowhash_list
```

`__authauthority_parse_shadowhash_list` uses a bitmask-style representation for
shadow hash types rather than the vulnerable `DisabledTags` append array shape.

## add_disabledtag Helper Shape

Relevant helper:

```text
_odauthauthorities_add_disabledtag
```

Static shape:

```text
entry:       0x100032110
find/create DisabledTags slot type 9
scan for duplicate requested auth type
load count from slot + 0x18
append requested enum to slot + 0x20 + count*4
increment count at slot + 0x18
```

The important store sequence:

```text
0x1000321a4  add x8, x20, x8, lsl #2
0x1000321a8  str w19, [x8, #0x20]
0x1000321ac  ldr x8, [x20, #0x18]
0x1000321b0  add x8, x8, #1
0x1000321b4  str x8, [x20, #0x18]
```

No caller-side or helper-side six-entry cap was visible in the inspected path.

## PlistFile.bundle Import And Call Sites

Static imports from
`/System/Library/OpenDirectory/Modules/PlistFile.bundle/Contents/MacOS/PlistFile`
include:

```text
_odauthauthorities_add_disabledtag
_odauthauthorities_remove_disabledtag
_odauthauthorities_add_shadowhash
_odauthauthorities_attribute_create
_odauthauthorities_disabledtag
_odauthauthorities_find
_odauthauthorities_free_contents
_odauthauthorities_get_shadowhashtypes
_odauthauthorities_localcacheduser
_odauthauthorities_parse
_odauthauthorities_remove
_odauthauthority_parse
```

`r2` xrefs for the append helper:

```text
sym.__plistfile_attrs_remove_sepCredential 0x114ac -> odauthauthorities_add_disabledtag
sym.__plistfile_attrs_remove_sepCredential 0x11510 -> odauthauthorities_add_disabledtag
```

Visible `odauthauthorities_parse` consumers in `PlistFile.bundle` include:

```text
_SecureTokenResetPassword                         0x3b0c
__verify_password                                 0x7cd0
__plistfile_attrs_is_sepCredentialUser            0x8e38
__plistfile_attrs_is_eligible_for_sepCredential   0x969c
__plistfile_verify_password_and_update_record     0xd1d0
__plistfile_verify_password_and_update_record     0xd3b8
__plistfile_verify_password_and_update_record     0xd538
__plistfile_verify_password_and_update_record     0xdb44
__create_record                                   0xfc98
_odm_NodeReplaceUserRecord                        0x10984
_odm_NodeReplaceUserRecord                        0x10b40
__plistfile_attrs_remove_sepCredential            0x113b4
__do_change_password                              0x12890
_odm_RecordSetValue                               0x13bc4
__sync_shadowhash_hash_data                       0x14854
_odm_RecordAuthenticationAllowed                  0x17cf0
__plistfile_attrs_add_sepCredential               0x1e42c
__plistfile_attrs_authenticationAllowedAdministratively 0x200cc
__plistfile_attrs_add_shadowhash                  0x216e0
__plistfile_attrs_remove_shadowhash               0x2189c
__plistfile_update_localkdc                       0x21b7c
__plistfile_attrs_update_shadowhash               0x23868
__plistfile_attrs_is_eligible_for_login_hashes    0x23e6c
```

## Candidate Scenario

Potential sibling setup:

1. A local record has an `authentication_authority` value with a
   `;DisabledTags;` list already containing six non-duplicate entries.
2. A local-node mutation path parses that record into the 0x238 aggregate.
3. `__plistfile_attrs_remove_sepCredential` removes SecureToken/OTI state and
   calls `_odauthauthorities_add_disabledtag`.
4. The append helper writes a seventh entry past the inline list and increments
   the count.

The likely values appended are:

```text
SecureToken -> 4
OTI         -> 5
```

## Reachability Gates

This lead needs VM/local authorization testing before it should be called an
LPE:

- Can an unprivileged or sandboxed user place a six-entry `DisabledTags` list
  into their own local record?
- Can that same user trigger `__plistfile_attrs_remove_sepCredential` or a
  related mutation path without admin/root privileges?
- Can `_odm_NodeReplaceUserRecord`, `_odm_RecordSetValue`, password-change, or
  SecureToken reset flows preserve attacker-controlled prefilled
  `authentication_authority` state long enough to hit the append?
- Does the seventh append crash, corrupt a later slot, or get serialized back
  out harmlessly?
- Do the visible `RecordSetValue`, `NodeReplaceUserRecord`, password-change, or
  SecureToken support guardrails reduce this to admin/root-only state
  corruption?

Until those are answered, classify this as a sibling bug/variant candidate with
uncertain attacker reachability.

## External Consumers Still Worth Auditing

Other binaries and modules contain `AuthenticationAuthority` strings or related
OpenDirectory logic, but they have not yet been proven to share the same append
bug:

```text
PasswordService
slapd
SystemCache.bundle
legacy.bundle
PAM modules
SecurityAgent/Helper
Directory Utility LDAPv3 plugin
```

Priority for further static hunting should stay on code that imports or
duplicates `odauthauthorities_*` helpers and then mutates parsed authorities.

## Additional Sibling: Legacy Compound Predicate Depth

I also found a separate indexed-stack-write candidate in the legacy compound
query predicate parser. Full notes:

```text
PREDICATE_COMPOUND_DEPTH_STACK_OOB_STATIC_NOTES.md
```

This is not the same root cause as `DisabledTags`. The parent block
`____predicate_create_compound_block_invoke` allocates a 128-qword stack vector
at `sp+0xa8` and stores the stack canary at `sp+0x4a8`, immediately after the
vector. The child parser checks current depth against cap `0x80` before
incrementing and writing `vector[new_depth]`.

Important static sequence:

```text
100014a84  cmp x8, x9                  ; current_depth vs 0x80
100014a88  b.ge more_than_128_error
...
100014bec  add x10, x10, #0x1
100014bf0  str x10, [x9, #0x18]
100014bf4  str x0, [x8, x10, lsl #3]  ; vector[new_depth]
```

Depth 127 therefore appears to pass, increment to 128, and write
`vector[128]`, which equals the saved stack guard slot. Static reachability
points at `ODQueryCreateWithNode` / `query_predicates` with match type `0x200b`.

Classify as a VM-only sibling candidate and likely DoS-class stack-cookie abort,
not an LPE primitive unless dynamic evidence shows more than canary clobber.

## Continuation Module Scan

A follow-up static-only module scan reviewed several apparent sibling shapes and
banked them as negatives or currently gated paths. Full notes:

```text
STATIC_HUNT_CONTINUATION_NOTES.md
```

Short version:

- `AppleODClientPWS.bundle` has a `strsep` token vector, but it is bounded to
  three stored pointers.
- `ActiveDirectory.bundle` CLDAP address-list storage is bounded to 32 entries.
- `ActiveDirectory.bundle` CLDAP DNS-label stack-vector storage is bounded to
  successful indexes `0..7`; see the separate negative package under
  `/Users/dawgyg/submission_packages/activedirectory_cldap_label_stack_review_negative`.
- `SystemCache.bundle` imports `_odauthauthority_parse`, but its visible call
  passes type filter `3` (`Kerberosv5`), not `DisabledTags` type `9`.

This keeps the best static follow-up on the existing `DisabledTags` second-stage
consumers, `_odcredential_set_authentication_authority`, and the
`PlistFile.bundle` append-helper authorization matrix.
