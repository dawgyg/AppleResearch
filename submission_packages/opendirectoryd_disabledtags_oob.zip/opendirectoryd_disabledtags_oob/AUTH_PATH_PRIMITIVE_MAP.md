# Authentication-Path Primitive Map

Date: 2026-06-11
Host: macOS 26.5.1 25F80
Binary: `/usr/libexec/opendirectoryd`, `opendirectoryd-966.100.2`

## Summary

The confirmed `dscl -authonly` crash path parses authentication authorities into a stack local in `___odm_handle_api_authentication_block_invoke_2`, not a heap allocation. The primitive is therefore a constrained sequential stack/object overwrite:

```text
write size:    4 bytes per comma token
write values:  small auth-type enum values, or fallback 0xa for unknown tokens
write order:   sequential, starting at DisabledTags list[0]
```

This is not an arbitrary-address write and should not be described as confirmed code execution.

Update: repeat VM testing invalidated the early p10/p11 consumed-pointer
control interpretation. The offset map below is still useful for geometry and
breakpoint placement, but do not describe indexes `10/11` as deterministic
pointer control. The supported auth-path claim is non-controlled root-context
corrupted-pointer dereference; see `FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md`.

## Stack Layout

Relevant authentication handler setup:

```text
0x100004f3c  sub sp, sp, #0x370
0x100004f60  x8 = sp + 0x2b0
0x100004f64  [sp+0x2b0] = 0
0x100004f68  [sp+0x2b8] = sp+0x2b0
0x100004f7c  x0 = sp + 0x78
0x100004f80  w1 = 0x238
0x100004f84  bzero(sp+0x78, 0x238)
0x100004fa0  x0 = sp + 0x78
0x100004fa4  _odauthauthorities_parse
```

For the first parsed `DisabledTags` authority:

```text
aggregate base:       sp + 0x78
DisabledTags list:    sp + 0xa0
aggregate end:        sp + 0x2b0
post-aggregate local: sp + 0x2b0
pointer local:        sp + 0x2b8
```

## Token Offset Map

The table below uses zero-based token indexes. A runtime test that generates
`N` comma tokens writes indexes `0..N-1`. For example, token index `6` is reached
with `7` comma tokens, and token index `132` is reached with `133` comma tokens.

```text
token   0: sp+0xa0 aggregate+0x28 slot0+0x20
token   5: sp+0xb4 aggregate+0x3c slot0+0x34
token   6: sp+0xb8 aggregate+0x40 slot1+0x0
token  19: sp+0xec aggregate+0x74 slot1+0x34
token  20: sp+0xf0 aggregate+0x78 slot2+0x0
token  33: sp+0x124 aggregate+0xac slot2+0x34
token  34: sp+0x128 aggregate+0xb0 slot3+0x0
token  47: sp+0x15c aggregate+0xe4 slot3+0x34
token  48: sp+0x160 aggregate+0xe8 slot4+0x0
token  61: sp+0x194 aggregate+0x11c slot4+0x34
token  62: sp+0x198 aggregate+0x120 slot5+0x0
token  75: sp+0x1cc aggregate+0x154 slot5+0x34
token  76: sp+0x1d0 aggregate+0x158 slot6+0x0
token  89: sp+0x204 aggregate+0x18c slot6+0x34
token  90: sp+0x208 aggregate+0x190 slot7+0x0
token 103: sp+0x23c aggregate+0x1c4 slot7+0x34
token 104: sp+0x240 aggregate+0x1c8 slot8+0x0
token 117: sp+0x274 aggregate+0x1fc slot8+0x34
token 118: sp+0x278 aggregate+0x200 slot9+0x0
token 131: sp+0x2ac aggregate+0x234 slot9+0x34
token 132: sp+0x2b0 aggregate+0x238 post-aggregate +0x0
token 133: sp+0x2b4 aggregate+0x23c post-aggregate +0x4
token 134: sp+0x2b8 aggregate+0x240 post-aggregate +0x8
token 135: sp+0x2bc aggregate+0x244 post-aggregate +0xc
token 136: sp+0x2c0 aggregate+0x248 post-aggregate +0x10
token 137: sp+0x2c4 aggregate+0x24c post-aggregate +0x14
token 138: sp+0x2c8 aggregate+0x250 post-aggregate +0x18
token 139: sp+0x2cc aggregate+0x254 post-aggregate +0x1c
token 140: sp+0x2d0 aggregate+0x258 post-aggregate +0x20
```

## Post-Aggregate Use

The local pointer at `sp+0x2b8` is read after parsing:

```text
0x100004ff0  x8 = [sp+0x2b8]
0x100004ff4  [x8+0x18] = x0
0x100005018  x8 = [sp+0x2b8]
0x10000501c  [x8+0x18] = x0
0x1000052c4  x8 = [sp+0x2b8]
0x1000052c8  x0 = [x8+0x18]
```

Tokens 134 and 135 overwrite the low/high 32-bit halves of this pointer local. Because written values are small enum constants, this is likely to produce a low or invalid pointer rather than immediately useful controlled code execution, but it is an important crash-triage target in a VM.

## In-Aggregate Fake Slot Leads

Before token 132, the overflow can create or corrupt later `odauthauthority` slots inside the aggregate.

`_odauthauthorities_find` scans all ten slots rather than a separately tracked parsed count:

```text
0x10003180c  add x0, x0, #0x8
0x100031810  mov w8, #0xa
```

`__find_mechanisms` also scans slot types and uses slot fields when it sees nonzero types. This means zero-based token indexes 6, 20, 34, 48, 62, 76, 90, 104, and 118 can potentially create fake authority-slot types. In count-based VM scripts, those are 7, 21, 35, 49, 63, 77, 91, 105, and 119 tokens.

The consumed C-string pointer for this specific consumer is at `slot+0x10`.
For the first fake slot (`slot 1`), that pointer's low/high dwords are token
indexes `10` and `11`:

```text
0x100005484  ldur w8, [x22-0x10]       ; slot type at slot+0x0
0x10000548c  ldr x1, [x22]             ; cStr at slot+0x10
0x100005498  CFStringCreateWithCString

slot  type_idx  cStr_low_idx  cStr_high_idx
1     6         10            11
2     20        24            25
3     34        38            39
4     48        52            53
5     62        66            67
6     76        80            81
7     90        94            95
8     104       108           109
9     118       122           123
```

See `FIND_MECHANISMS_POINTER_OFFSET_STATIC_NOTES.md` for the full formula and
`FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md` for the repeat-test correction.

The most promising in-aggregate follow-up candidates are:

```text
type 6: LocalCachedUser path, later code dereferences fields from the found slot
type 8: disabled-account path, useful for control-flow influence but less obviously a memory primitive
type 9: additional DisabledTags-like slot state
type 10: fallback unknown-token value, useful for nonzero fake slot typing
```

## VM-Only Next Steps

Do not continue live-host crash testing because `opendirectoryd` has `PanicOnConsecutiveCrash = true`.

Recommended VM triage:

1. Sweep boundary token counts, not hundreds of tokens. Use 7, 21, 35, 49, 63, 77, 91, 105, and 119 to hit fake-slot type indexes 6, 20, 34, 48, 62, 76, 90, 104, and 118.
2. Prefer deterministic token patterns that set fake slot types at zero-based token indexes 6, 20, 34, etc.
3. For `_find_mechanisms` corrupted-pointer diagnostics, first mark token indexes 10 and 11, then 24 and 25 if needed. Do not treat marker changes as control unless they reproduce across repeated runs.
4. Capture crash registers and fault addresses for counts 133 through 136 to cover zero-based indexes 132 through 135.
5. Identify the smallest crashing token count.
6. Only after low-count characterization, test whether type-6 fake slots drive a more useful dereference before the post-aggregate overwrite.
