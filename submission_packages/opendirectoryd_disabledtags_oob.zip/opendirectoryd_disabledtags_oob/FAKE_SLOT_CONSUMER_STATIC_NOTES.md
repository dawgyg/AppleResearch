# Fake-Slot Consumer Static Notes

Date: 2026-06-11
Binary: `/usr/libexec/opendirectoryd` arm64e, macOS 26.5.1 25F80

## Scope

Static-only notes for interpreting VM crash results from the `DisabledTags` overflow. These notes do not require running any `opendirectoryd` trigger on the host.

## Indexes vs Counts

The offset maps use zero-based token indexes. A trigger with `N` comma tokens writes token indexes `0..N-1`.

```text
zero-based index 6   -> first fake slot type write, requires 7 tokens
zero-based index 20  -> next fake slot type write, requires 21 tokens
zero-based index 132 -> first post-aggregate write, requires 133 tokens
```

The VM helper should use token counts `7, 21, 35, 49, 63, 77, 91, 105, 119` for fake-slot type boundaries, not `6, 20, 34, ...`.

## Parser Behavior

`_odauthauthorities_parse` bzeroes the whole `0x238` aggregate and parses each `AuthenticationAuthority` array element into the next real slot:

```text
aggregate + 0x0: parsed-slot count
aggregate + 0x8: slot 0
slot size:       0x38
```

The `DisabledTags` overflow can overwrite later slots inside the already-zeroed aggregate, but those fake slots are not reparsed by the original parse loop. They are consumed later by scanners, serializers, add/remove helpers, and finalizers that scan all ten slots by type.

## Important Consumers

`_odauthauthorities_find` scans all ten slot types and ignores the parsed-slot count. A fake nonzero type is therefore discoverable even if it was not parsed as a real array element.

`__find_mechanisms` also scans all ten slots. For every nonzero type, it calls `CFStringCreateWithCString` on the pointer at `slot + 0x10` without type-specific validation. For the first fake slot, that pointer's low/high dwords are zero-based token indexes `10` and `11`; see `FIND_MECHANISMS_POINTER_OFFSET_STATIC_NOTES.md`.

`__account_is_disabled` only checks for type `8` (`DisabledUser`) via `_odauthauthorities_find`. A fake type-8 slot can act as a logic toggle for "account disabled" without needing valid slot fields. That is useful for understanding behavior, but not by itself a code-execution primitive.

`__account_is_cached` looks up type `6` (`LocalCachedUser`) and then uses fields from the found slot:

```text
slot + 0x18 -> CFStringCreateWithCString
slot + 0x28 -> uuid_unparse
```

A fake type-6 slot is therefore expected to fault when the string pointer is NULL/low, unless the VM path reaches a real parsed type-6 slot.

`_odcredential_create` and `_odcredential_create_with_details` search for type `3` (`Kerberosv5`) after parsing and pass `slot + 0x20` to `CFStringCreateWithCString` if found. A fake type-3 slot can create an immediate low-pointer crash during credential creation.

`_odauthauthorities_attribute_create` serializes all ten slots. For type `9` (`DisabledTags`), it treats `slot + 0x18` as the list count and each entry at `slot + 0x20` as a 1-based token-table index. Values are not range-checked before `entry - 1` indexes the nine-entry table. Unknown tokens store fallback value `10`; serializing such an entry indexes one past the table and appears to load NULL from the adjacent table slot on this build. That is a likely serializer crash/DoS vector, not a stronger write primitive.

`_odauthauthorities_free_contents` scans all ten slot types and frees fields according to type. Fake type values combined with low enum-composed pointer fields can produce finalizer crashes. Because the overflow writes only small integers, these are expected to be low-pointer frees unless a separate heap-layout effect provides a valid adjacent pointer.

Follow-up refinement: `WHOLE_SLOT_REMOVE_FAKE_FREE_STATIC_NOTES.md` documents a
more specific selected-free lane. `_odauthauthorities_remove(type=4/5)` can
select a fake SecureToken/OTI slot made by token index `6`, then
`_odauthauthority_free_contents` frees fake pointer fields at token indexes
`10/11`, `8/9`, and `12/13`.

## VM Interpretation

Useful crash classes:

- `__find_mechanisms` at `CFStringCreateWithCString(slot+0x10)`: fake nonzero type consumed; pointer low/high dwords are marker-testable at token indexes `10` and `11` for the first fake slot.
- `__account_is_disabled`: fake type 8 reached; logic toggle rather than memory-control.
- `__account_is_cached`: fake type 6 reached; likely low-pointer in `slot+0x18`.
- `_odcredential_create` post-parse type-3 handling: fake Kerberos slot reached; likely low-pointer in `slot+0x20`.
- `_odauthauthorities_attribute_create` type-9 serialization: possible fallback-10 table OOB read/NULL string.
- `_odauthauthorities_free_contents` / `_odauthauthority_free_contents`: fake type reached finalizer; check whether the freed pointer is NULL/low or a real heap pointer.

What would upgrade exploitability:

- A non-low, attacker-influenced pointer reaches one of the string/free consumers.
- A fake slot changes control flow without immediate crash and preserves a corrupted credential object for later use.
- A heap-adjacent object/refcount effect is observed after the aggregate boundary rather than just inside fake slots.
