# OpenDirectory Strsep Sibling And Add-Helper Static Notes

Date: 2026-06-12T0312Z
Scope: static-only continuation for `strsep`/indexed-store siblings and the
`_odauthauthorities_add_disabledtag` helper boundary.

## Bottom Line

I did not find a second OpenDirectory `strsep` parser with the same unbounded
indexed-store shape as the known `DisabledTags` bug.

The useful result from this pass is narrower:

- `DisabledTags` remains the only reviewed unbounded `strsep` plus indexed
  dword-store parser in the OpenDirectory binary/module set.
- `__authauthority_parse_shadowhash_list` uses `strsep`, but converts fixed
  string names into a bitmask; it does not append into an indexed array.
- `AppleODClientPWS.bundle` has a `strsep` token vector, but it is bounded to
  three qword stores.
- `_odauthauthorities_add_disabledtag` is the same-root-cause append primitive
  in helper form: if reached with a real `DisabledTags` slot whose count is
  already six, the next append writes the next authority slot's type dword at
  `slot+0x38`.

The helper variant is still reachability-gated. It needs a path that first
creates/preserves an overfull or exactly-full type-9 slot, then calls
`_odauthauthorities_add_disabledtag` before the parser's `_find_mechanisms`
crash path wins. The currently known static path remains `PlistFile.bundle`
SEP/SecureToken/password machinery, which is authorization-sensitive.

No host OpenDirectory, LDAP, `dscl`, or VM dynamic trigger was run for this
note.

## OpenDirectory Strsep Sweep

The widened static sweep covered:

```text
/usr/libexec/opendirectoryd
/System/Library/OpenDirectory/Modules/*.bundle/Contents/MacOS/*
```

The only reviewed `strsep` plus unbounded indexed store in this set is still
the `DisabledTags` type-9 authdata branch:

```text
100031bd0  type == 9
100031bdc  zero slot+0x18 count/list
100031be4  delimiter ","
100031bf0  bl   _strsep
100031c40  ldr  x8, [x21]              ; count
100031c44  str  w24, [x22, x8, lsl #2] ; list[count] = token enum
100031c48  ldr  x8, [x21]
100031c4c  add  x8, x8, #0x1
100031c50  str  x8, [x21]              ; count++
100031c64  cbnz x0, 0x100031c10
```

The bug remains the absence of a six-entry cap before the dword store.

## ShadowHash Strsep Negative

`__authauthority_parse_shadowhash_list` also tokenizes with `strsep`, but its
consumer shape is different:

```text
100032560  bl   _strsep
100032580  compare "SMB-NT"
100032590  compare "SHA1"
1000325a0  compare "CRAM-MD5"
1000325b0  compare "SALTED-SHA1"
1000325c0  compare "RECOVERABLE"
1000325d0  compare "SALTED-SHA512"
1000325e0  compare "SALTED-SHA512-PBKDF2"
1000325f4  compare "SRP-RFC5054-4096-SHA512-PBKDF2"
10003260c  compare "DIGEST-MD5"
```

Each match ORs a fixed bit into the result mask. I did not find an indexed
array append or attacker-influenced write offset in this parser.

## AppleODClientPWS Strsep Negative

`AppleODClientPWS.bundle` has one relevant `strsep` loop in
`___pws_sasl_auth_block_invoke`, but it stores into exactly three zeroed qword
slots:

```text
c568  cbz  x22, fail
c570  strdup
c580  zero sp+0x1260
c584  zero sp+0x1258
c588  zero sp+0x1268
c594  x25 = sp+0x1258
c5a8  bl   _strsep
c5ac  str  x0, [x25, x24]
c5b4  ccmp x24, #0x10, #0x4, ne
c5b8  add  x24, x24, #0x8
c5bc  b.ne loop
```

The stores are at byte offsets `0`, `8`, and `0x10`. The `#0x10` compare is a
byte-offset bound, not a 16-entry array bound, so I am treating this as a
negative.

## Add-DisabledTag Helper Boundary

`_odauthauthorities_add_disabledtag` has the same missing-cap property as the
parser, but the primitive is reached through a mutator helper rather than the
initial authdata tokenizer.

Static shape:

```text
100032130  call __odauthauthorities_find_or_create(type=9)
100032178  count = [disabledtags_slot+0x18]
100032184  if count >= 1, scan count entries for duplicates
1000321a4  x8 = slot + count*4
1000321a8  str w19, [x8, #0x20]         ; list[count] = tag, no cap
1000321ac  reload count
1000321b0  count++
1000321b4  store count at slot+0x18
```

For a normal type-9 slot layout:

```text
slot+0x00  type
slot+0x08  authdata field / metadata
slot+0x10  string pointer field
slot+0x18  DisabledTags count
slot+0x20  list[0]
slot+0x24  list[1]
slot+0x28  list[2]
slot+0x2c  list[3]
slot+0x30  list[4]
slot+0x34  list[5]
slot+0x38  first dword of next authority slot
```

Therefore:

```text
count 0..5  append inside the intended six-entry list
count 6     append writes slot+0x38, the next authority slot's type dword
count > 6   append writes further through adjacent slots/aggregate state
```

The duplicate scan also trusts `slot+0x18`, so an overfull count can drive
reads through adjacent slot bytes before the append. The append itself is the
important corruption primitive for the PlistFile variant.

## Reachability Status

`__odauthauthorities_find_or_create` is bounded while allocating/finding
authority slots. It scans at most ten slots and is not a new OOB write by
itself:

```text
scan existing types through the 10-slot aggregate
scan empty slots through the same aggregate
write type string and type only after an in-bounds empty slot is found
```

So the helper lane needs an already-present type-9 slot with count six or
greater. The known static importer remains `PlistFile.bundle`:

```text
__plistfile_attrs_remove_sepCredential
  parse local-record authentication_authority
  remove SecureToken/OTI authority slot
  call _odauthauthorities_add_disabledtag
  serialize authentication_authority
```

That path is still subject to privilege, sandbox, and SEP/SecureToken policy
checks. Do not claim non-admin trigger from this static note alone.

## VM Work To Prioritize

If VM time is available for the helper variant, the useful gate is precise:

```text
1. Seed a throwaway local record with exactly six real DisabledTags entries.
2. Trigger a stock PlistFile path that calls _odauthauthorities_add_disabledtag.
3. Break at _odauthauthorities_add_disabledtag.
4. Record the type-9 slot pointer and [slot+0x18] before append.
5. Confirm count == 6 reaches the store at slot+0x38.
6. Capture whether the corrupted aggregate serializes or crashes.
```

Useful breakpoints/watchpoints:

```text
_odauthauthorities_add_disabledtag
_odauthauthorities_attribute_create
_odauthauthority_attribute_create
__plistfile_attrs_remove_sepCredential
__plistfile_attrs_add_sepCredential
```

Keep `_odauthauthorities_remove_disabledtag` as a separate second-stage gate:
that helper has the stronger count-derived `memmove` primitive, but it is not
the helper called by the inspected `remove_sepCredential` path.

## Impact Framing

This pass strengthens the package by ruling out several tempting siblings and
pinning the add-helper boundary exactly. It does not replace the dynamic
root-context corrupted-pointer dereference evidence as the primary bug proof.

Recommended wording:

```text
The parser bug is proven dynamically through root opendirectoryd pointer
corruption. Static review also identifies a same-root-cause mutator helper,
_odauthauthorities_add_disabledtag, whose seventh append writes the adjacent
authority slot's type dword. That helper is authorization/reachability-gated
through PlistFile SecureToken/password workflows unless VM testing proves a
lower-privilege prefill and trigger path.
```
