#include <CoreFoundation/CoreFoundation.h>
#include <stdio.h>
#include <string.h>
#include <unistd.h>
typedef CFTypeRef ODSessionRef; typedef CFTypeRef ODNodeRef; typedef CFTypeRef ODRecordRef;
extern ODSessionRef ODSessionCreate(CFAllocatorRef, CFDictionaryRef, CFErrorRef*);
extern ODNodeRef ODNodeCreateWithName(CFAllocatorRef, ODSessionRef, CFStringRef, CFErrorRef*);
extern CFTypeRef ODNodeCustomFunction(ODNodeRef, CFStringRef, CFTypeRef, CFErrorRef*);
extern ODRecordRef ODNodeCopyRecord(ODNodeRef, CFStringRef, CFStringRef, CFArrayRef, CFErrorRef*);
extern CFDictionaryRef ODRecordCopyEffectivePolicies(ODRecordRef, CFErrorRef*);

int main(int argc, char** argv){
  const char* user = argc>1?argv[1]:"_lpeprobe";
  const char* which = argc>2?argv[2]:"all";
  CFStringRef cfuser = CFStringCreateWithCString(NULL,user,kCFStringEncodingUTF8);
  CFErrorRef err=NULL;
  printf("uid=%d user=%s which=%s\n",getuid(),user,which); fflush(stdout);
  ODSessionRef s = ODSessionCreate(kCFAllocatorDefault,NULL,&err);
  ODNodeRef node = ODNodeCreateWithName(kCFAllocatorDefault,s,CFSTR("/Local/Default"),&err);
  printf("node=%p err=%p\n",node,err); fflush(stdout);
  if(!node) return 1;
  if(!strcmp(which,"hastoken")||!strcmp(which,"all")){
    CFMutableDictionaryRef p=CFDictionaryCreateMutable(NULL,0,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);
    CFDictionarySetValue(p,CFSTR("Recordname"),cfuser); err=NULL;
    CFTypeRef r=ODNodeCustomFunction(node,CFSTR("HasSecureToken"),p,&err);
    printf("HasSecureToken r=%p err=%p\n",r,err); fflush(stdout);
  }
  if(!strcmp(which,"policies")||!strcmp(which,"all")){
    err=NULL; ODRecordRef rec=ODNodeCopyRecord(node,CFSTR("dsRecTypeStandard:Users"),cfuser,NULL,&err);
    printf("CopyRecord rec=%p err=%p\n",rec,err); fflush(stdout);
    if(rec){ err=NULL; CFDictionaryRef pol=ODRecordCopyEffectivePolicies(rec,&err);
      printf("EffectivePolicies pol=%p err=%p\n",pol,err); fflush(stdout); }
  }
  if(!strcmp(which,"lockout")||!strcmp(which,"all")){
    CFMutableDictionaryRef p=CFDictionaryCreateMutable(NULL,0,&kCFTypeDictionaryKeyCallBacks,&kCFTypeDictionaryValueCallBacks);
    CFDictionarySetValue(p,CFSTR("Recordname"),cfuser); err=NULL;
    CFTypeRef r=ODNodeCustomFunction(node,CFSTR("GetSEPCredentialLockoutState"),p,&err);
    printf("GetSEPCredentialLockoutState r=%p err=%p\n",r,err); fflush(stdout);
  }
  printf("DONE\n"); return 0;
}
