# UNPRIVILEGED -> root controlled invalid-free in opendirectoryd (HasSecureToken)

Environment: macOS 26.5.1 (25F80) VM, opendirectoryd-966.100.2, system daemon, unmodified.

## Result (proven, reproducible)

A **non-root** process (uid 501) calling the public OpenDirectory API
`ODNodeCustomFunction(node, "HasSecureToken", {"Recordname": victim})` makes **root
opendirectoryd `free()` an attacker-composed pointer** and abort with heap corruption:

```
opendirectoryd malloc: *** error for object 0x800000008: pointer being freed was not allocated
```

`0x800000008` is attacker data: a `DisabledUser`(enum 8) token at DisabledTags indexes 10 and 11
composes the freed pointer (high dword 0x8, low dword 0x8).

## Full crash backtrace (system .ips, EXC_CRASH/SIGABRT)

```
_odrequest_api_process
  odm_NodeCustomFunction                 (opendirectoryd +0x9518)   <- public API, unprivileged
    __odm_NodeCustomFunction_block_invoke (opendirectoryd +0x9608)
      HasSecureToken                      (PlistFile +0x8898)        <- NO __session_has_privilege gate
        __HasSecureToken_block_invoke     (PlistFile +0x8c3c)
          _plistfile_attrs_is_sepCredentialUser (PlistFile +0x8ef8)
            odauthauthorities_free_contents     (opendirectoryd +0x322fc)
              odauthauthority_free_contents     (opendirectoryd +0x31648)
                free(0x800000008)  ->  ___BUG_IN_CLIENT_OF_LIBMALLOC_POINTER_BEING_FREED_WAS_NOT_ALLOCATED
```

## Mechanism

1. DisabledTags OOB write (base bug) overflows the 6-entry inline tag array; with token index 6 =
   `SecureToken`(enum 4), the first fake authority slot (aggregate+0x40) gets type 4.
2. `_plistfile_attrs_is_sepCredentialUser` enumerates authority slots; cleanup
   `odauthauthorities_free_contents` walks all 10 slots, skips only type==0, so it visits the fake
   type-4 slot and `odauthauthority_free_contents` frees `fakeslot+0x10` — composed from DisabledTags
   token indexes 10/11 = `0x800000008`.
3. libmalloc detects the bogus free and aborts the root daemon.

## Why this matters (vs the base filed bug

- Base bug: OOB write -> non-deterministic corrupted-pointer strlen NULL-ish crash, and the only
  proven trigger reaching the free lane was root-gated `RecordDelete`
  (`__session_has_privilege` + sandbox_check "opendirectory-user-modify").
- This: an **unprivileged** public API (`HasSecureToken` custom function) reaches the same cleanup
  and produces a **deterministic, attacker-controlled `free()` argument** in the root daemon. No
  admin, no privilege gate in the function body (confirmed static + dynamic).

## Honest ceiling

The freed value (`0x800000008`) is composed from tag enums (each dword 1..0xa), so it is an
obviously-invalid address; libmalloc's safety check catches it and `abort()`s. This is therefore a
**reproducible unprivileged -> root controlled invalid-free / heap-corruption crash**, NOT yet a
free of a valid heap allocation (UAF) or code execution — the enum value range cannot address real
heap memory. Severity is unprivileged-reachable root-daemon memory corruption with attacker-
controlled free pointer; weaponization to UAF/RCE would require a second primitive that supplies a
valid pointer (not demonstrated).

## Repro

```
# local HasSecureToken controlled-free proof:
# seed a local PlistFile record's AuthenticationAuthority (VM used local/dslocal
# write privileges for this seed step):
authentication_authority[0] = ";DisabledTags;<6x non-SecureToken>,SecureToken,<3x>,DisabledUser,DisabledUser,<pad to ~32>"

# trigger (UNPRIVILEGED, uid 501):
odtest <victim> hastoken      # ODNodeCustomFunction(/Local/Default, "HasSecureToken", {"Recordname": victim})
-> root opendirectoryd: free(0x800000008) -> SIGABRT
```

Reachability split: the separate dynamic `/LDAPv3/<attacker-host>` result proves a
non-root/sandboxed client can supply malicious `AuthenticationAuthority` to the
base authentication parser. It does not, by itself, prove that LDAP-supplied data
reaches the PlistFile-only `HasSecureToken` cleanup consumer above.

Evidence: opendirectoryd_UNPRIV_HasSecureToken_free_0x800000008.ips, malloc_error_freed_pointer.txt
Client source: odtest.c (OpenDirectory framework, ~45 lines).
