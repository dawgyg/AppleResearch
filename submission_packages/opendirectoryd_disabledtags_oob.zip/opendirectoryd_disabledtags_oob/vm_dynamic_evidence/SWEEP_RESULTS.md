# DisabledTags OOB — native crash sweep results (VM, system opendirectoryd)

All rows are a fresh crash of the **unmodified system `opendirectoryd`** (root) on macOS 26.5.1,
parsed from the per-crash `.ips`. Crash site is always:
`__odm_handle_api_authentication_block_invoke_2 -> _find_mechanisms -> CFStringCreateWithCString ->
_platform_strlen`.

## Overflow boundary (uniform ShadowHash tokens)

```
count  result
  6    NO CRASH       (== inline tag-array capacity 6)
  7    NO CRASH
  8    CRASH  far=0x0
  9    CRASH  far=0x0
>=100  CRASH  far=0x100000000
```

The crash requires overflowing past the 6-entry array; larger counts change the corrupted geometry,
but the later faulting pointer value is heap-state dependent and not reliably token-driven.

## Historical per-position observations (count=64; base ShadowHash=1; one DisabledUser=8 at zero-based position P)

```
P     far            x0            note
7     0x100000000    0x100000001   baseline (marker outside fatal fields)
8     0x0            0x0           marker forces NULL deref
9     NO CRASH                     marker suppresses crash
10    (see note)     0x100000008*  early low-dword-like sample  [*not reproducible]
11    0x800000000    0x800000001   early high-dword-like sample (cStr/x1/far) [not reproducible]
13    0x0            0x0
14-16 NO CRASH
```

Reading after re-test: different comma positions write different fields of the corrupted,
later-consumed structure, but the fault-address value is not reproducibly token-driven. The
position-11 "high dword" interpretation was an early single-sample correlation and must not be
reported as control.

## Determinism re-test — CONCLUSION: pointer value is NON-deterministic (control NOT reliable)

Identical input (`DisabledUser` at position 11, count=64) run 4×, plus varying only the position-11
token, gentle harness (no killall):

```
pos11=DisabledUser  run1   NO CRASH
pos11=DisabledUser  run2   far=0x800000000
pos11=DisabledUser  run3   far=0x0
pos11=DisabledUser  run4   far=0x800000000
pos11=ShadowHash           far=0x0          (expected 0x100000000 if token-driven — it was not)
pos11=Kerberosv5           NO CRASH
pos11=AppleID              NO CRASH
pos11=DisabledUser         NO CRASH
```

The fault address for one fixed input varies across {no-crash, 0x0, 0x800000000}, and varying the
token does NOT make the high dword track the enum. Therefore the earlier single-sample position
correlations (p10 -> x0=8, p11 -> far=0x8..) were **heap-layout coincidences, not control**. The
consumed-pointer value is heap-state dependent and NOT attacker-controllable.

### Honest bottom line
- DETERMINISTIC: the OOB write and its boundary (<=6 no crash, >=8 crash), the crash site
  (`_find_mechanisms -> CFStringCreateWithCString -> strlen`), and the fact that the corruption is
  consumed as a pointer in root context.
- NON-DETERMINISTIC: the value of that pointer. Attacker token bytes sometimes appear in it but do
  not reproduce, so this is a non-controlled corrupted-pointer dereference — a memory-safety crash,
  not a controllable write/aim primitive.

## Value-range limit

Every OOB store writes the tag enum (1..9) or unknown-token fallback 10. Even if a future,
independently repeated test found a stable consumed-field effect, the written dwords would still be
bounded to 1..10 and would not by themselves provide arbitrary address or PC control. The current
demonstrated ceiling is a non-controlled root-daemon corrupted-pointer crash, pending a separate
second-stage primitive (count-as-length, adjacent-object refcount, persistent heap field, or
finalizer effect) that escapes the enum-value limit.
