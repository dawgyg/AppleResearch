# Controlled-free value sweep + placement/reachability calibration

## Freed pointer is attacker-controlled (deterministic, tracks token enum)

HasSecureToken trigger, fake slot type set via index 6 = SecureToken, freed pointer field
(fakeslot+0x10) composed from DisabledTags token indexes 10/11. Varying that token:

```
idx10/11 = AppleID(enum 7)         -> root opendirectoryd free(0x700000007)
idx10/11 = Kerberosv5(enum 3)      -> root opendirectoryd free(0x300000003)
idx10/11 = LocalCachedUser(enum 6) -> root opendirectoryd free(0x600000006)
idx10/11 = DisabledUser(enum 8)    -> root opendirectoryd free(0x800000008)
```

=> The freed pointer value is attacker-CONTROLLED: `free(0x0E0000000E)` for chosen enum E
(each dword is the chosen tag enum, range 1..0xa). Deterministic and reproducible.

## Placement / reachability (honest)

- TRIGGER is unprivileged: a non-root (uid 501) process calling
  `ODNodeCustomFunction(/Local/Default,"HasSecureToken",{"Recordname":victim})` drives the root
  daemon free. No privilege gate (HasSecureToken is whitelisted in PlistFile.bundle Info.plist
  ODCustomFunctions and has no __session_has_privilege in its body).
- SEEDING of the toxic AuthenticationAuthority is NOT unprivileged locally:
    non-root `dscl . -create/-append /Users/<u> AuthenticationAuthority ...` -> eDSPermissionError.
  Local placement of the toxic AA needs root (dslocal write).
- The separate dynamic `/LDAPv3/<attacker-host>` result proves a non-root/sandboxed client can
  supply a malicious AuthenticationAuthority to the BASE authentication parser, but it is NOT yet
  proven that LDAP-node-supplied data reaches this PlistFile-only HasSecureToken cleanup consumer
  (LDAP records flow through a different module than PlistFile/dslocal).

## Net classification

Today: "a toxic AuthenticationAuthority record (planted with root/dslocal write, e.g. via MDM,
configuration profile, migration, or a network directory) becomes an UNPRIVILEGED -> root
controlled invalid-free": any non-root user can then make root opendirectoryd free an
attacker-chosen (enum-composed) pointer via HasSecureToken. This is a real privilege-boundary /
memory-safety issue, but it is NOT a self-contained unprivileged LPE, because (a) local seeding
needs root and the unprivileged LDAP seeding path is not yet proven to reach this consumer, and
(b) the freed value is enum-range, so libmalloc safety-aborts (controlled invalid free, not a
valid-pointer UAF / code execution).

## Remaining gates for LPE
1. Unprivileged seeding into the HasSecureToken/PlistFile cleanup consumer (LDAP-node -> PlistFile,
   or any non-root local AA-write vector).
2. Escape the enum value range to free/release a VALID heap allocation (heap grooming so the OOB
   write lands inside a real adjacent pointer, or a field/path that stores a full pointer).

## DEFINITIVE: HasSecureToken is PlistFile(/Local)-only — seeding gap is structural

Module Info.plist ODCustomFunctions survey:
- PlistFile.bundle advertises HasSecureToken + all SecureToken*/GetSEPCredentialLockoutState.
- LDAPv3.bundle advertises NO custom functions.

Therefore HasSecureToken can only target a /Local (dslocal) record. The strong controlled-free
primitive is reachable only on local records, and placing the toxic AuthenticationAuthority on a
local record requires root (non-root dscl -> eDSPermissionError). The unprivileged /LDAPv3 path
reaches only the BASE parser (non-deterministic strlen crash), NOT this PlistFile cleanup consumer.

Conclusion: this bug does NOT yield a self-contained unprivileged -> root LPE via HasSecureToken.
The deterministic controlled-free is "root-planted local toxic record + unprivileged trigger";
the unprivileged self-contained reach is only the weak base-parser crash. Full LPE/code-exec would
require BOTH (a) an unprivileged path that places/feeds a toxic AA into the PlistFile SecureToken
consumer, AND (b) escaping the enum value range to free a valid allocation. Neither is demonstrated.
