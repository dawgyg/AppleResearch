# opendirectoryd DisabledTags OOB — Dynamic crash analysis (VM, SIP off)

Environment: fresh macOS 26.5.1 (25F80) VM, `opendirectoryd-966.100.2`, arm64e, SIP disabled
for debugging only. All crashes reproduced on the **unmodified system `opendirectoryd`**
(the root daemon, not a harness).

## Reproduction (native, no debugger)

1. A local user record is created and its `authentication_authority` is written **directly into
   the dslocal plist** (`/var/db/dslocal/nodes/Default/users/<u>.plist`) as a single string:
   `;DisabledTags;<tok>,<tok>,...,<tok>` with N comma tokens.
   (Direct-plist write is used because OD's *write* path rejects the long value with
   `eServerError -14910`; the on-disk record is parsed on the *read*/auth path.)
2. `opendirectoryd` is restarted so it loads the record fresh.
3. `dscl . -authonly <u> wrongpassword` drives the authentication path.

Result: `opendirectoryd` (root) **crashes every time** — its PID changes as launchd respawns it,
and a fresh crash report is written to `/Library/Logs/DiagnosticReports/opendirectoryd-*.ips`.

This is the same primitive as the static finding: `__authauthority_parse_authdata` stores the
per-token tag enum with `str w24,[x22,x8,lsl#2]` and an **unbounded** count, overflowing the
fixed inline tag array (capacity 6).

## Crash thread (from system .ips)

```
exception : EXC_BAD_ACCESS (SIGSEGV)
subtype   : KERN_INVALID_ADDRESS at 0x0000000100000000
faulting far = 0x100000000     pc = libsystem_platform _platform_strlen

#0 libsystem_platform.dylib  _platform_strlen
#1 CoreFoundation            CFStringCreateWithCString + 0x...   (cStr arg = 0x100000000)
#2 opendirectoryd            _find_mechanisms                 (+0x549c)
#3 opendirectoryd            __odm_handle_api_authentication_block_invoke_2  (+0x4fc4)

key regs at fault:
  x0 = 0x100000001   x1 = 0x100000000   far = 0x100000000
  x19 = 0x600   x20 = 0x100000001
```

Interpretation: the DisabledTags overflow corrupts the adjacent authority/mechanism structure.
`_find_mechanisms` subsequently passes a **corrupted C-string pointer** to
`CFStringCreateWithCString`, whose `strlen` dereferences the bad pointer (`0x100000000`) → SIGSEGV.
So the OOB write does not merely walk off the end and fault during the write; it persists into the
structure and is **consumed as a pointer** by a later root-context code path.

## Controllability characterization (native sweeps)

Overflow boundary (uniform `ShadowHash` tokens, native crash + .ips per count):

```
count = 6   NO CRASH      (== inline tag array capacity; matches static cap=6)
count = 7   NO CRASH      (1 past array; corrupts a non-fatal field)
count = 8   CRASH  far=0x0            (overflow reaches the consumed pointer field)
count = 9   CRASH  far=0x0
count >=100 CRASH  far=0x100000000    (consumed pointer value changes with overflow distance)
```

So the **overflow past the 6-entry array is required** to crash. The count changes
which neighboring fields are corrupted, but later repeat testing showed the
value of the consumed pointer is heap-state dependent rather than a stable
function of token choice or position.

Historical marker sweep: base token `ShadowHash`(1) for all 64 entries, with one
`DisabledUser`(enum 8) walked across positions:

```
DisabledUser @ pos 4,6,8,12   ->  x0 = 0x100000001  (unchanged)
DisabledUser @ pos 10         ->  x0 = 0x100000008  (early low-dword-like sample; not reproducible)
DisabledUser @ pos 11         ->  x1/far = 0x800000000  (early high-dword-like sample; not reproducible)
```

Static offset mapping places zero-based token index `10` at the low dword of the
first fake authority slot's `_find_mechanisms` `slot+0x10` C-string pointer
field, and token index `11` at that pointer's high dword. That explains why
these positions were plausible diagnostic markers.

The later determinism re-test invalidated the control interpretation. Identical
input (`DisabledUser` at position `11`, count `64`) produced no crash,
`far=0x800000000`, and `far=0x0` across repeated runs. Varying only the
position-11 token also failed to make `far` track the enum: `ShadowHash` gave
`far=0x0` instead of the expected `0x100000000`, while `Kerberosv5`, `AppleID`,
and `DisabledUser` did not crash in that pass. The marker correlations were
heap-layout coincidences, not reproducible pointer control.

Codex static/frame caveat: at the `_find_mechanisms` call site, `x0` is the
allocator and `x1` is the C-string pointer. At the later `_platform_strlen` crash
frame, `x0`/`x20` can instead be the C-string pointer or CoreFoundation local
copies. The position-10 result should therefore be worded only as a historical,
non-reproducible marker observation unless a future repeated run proves a stable
call-site effect.

## Controlled invalid-free lane (RecordDelete)

Separate PlistFile testing produced a stronger, deterministic cleanup crash:

```
___BUG_IN_CLIENT_OF_LIBMALLOC_POINTER_BEING_FREED_WAS_NOT_ALLOCATED
opendirectoryd  _odauthauthority_free_contents
opendirectoryd  _odauthauthorities_free_contents
PlistFile       _plistfile_attrs_is_sepCredentialUser
PlistFile       _plistfile_last_sepCredentialUser
PlistFile       _odm_RecordDelete
opendirectoryd  _odrequest_api_process
```

The malloc application-specific information was reproduced three times:

```
opendirectoryd malloc: *** error for object 0x800000008:
pointer being freed was not allocated
```

Artifacts:

```
malloc_error_freed_pointer.txt
opendirectoryd_controlled_free_0x800000008.ips
```

Static mapping explains the value. The first fake authority slot begins after
the six-entry `DisabledTags` inline list. Token index `6` supplies the fake slot
type (`SecureToken`, enum `4`), making `_odauthauthorities_free_contents` visit
that slot during aggregate cleanup. Token indexes `10` and `11` are the low and
high dwords of fake `slot+0x10`, the first pointer freed by
`_odauthauthority_free_contents`. With `DisabledUser` (`8`) in both positions,
the free argument is:

```
0x00000008_00000008 == 0x800000008
```

Impact calibration: this proves a deterministic attacker-composed `free()`
argument in root `opendirectoryd`. It does not yet prove valid heap-pointer
free, arbitrary free, weaponized UAF, code execution, or LPE, because each
pointer dword remains constrained to the auth-tag enum range. The observed
`RecordDelete` trigger also has PlistFile privilege/sandbox gates; a separate
privilege matrix is required before using this as a non-admin escalation claim.

## Honest impact statement

Demonstrated: a sandbox-/unprivileged-reachable (dynamic LDAP node) **OOB write
in root `opendirectoryd` auth-authority parsing** that corrupts an authority
structure and causes a later **corrupted-pointer dereference** (`strlen` via
`CFStringCreateWithCString`) in the root auth path — reproducible, with full
register/stack evidence on the unmodified system daemon.

Also demonstrated: a PlistFile `RecordDelete` cleanup path that turns the same
fake-slot corruption into a deterministic, attacker-composed invalid
`free(0x800000008)` in root `opendirectoryd`.

NOT claimed: arbitrary code execution, deterministic index-10/index-11 pointer
control, a fully attacker-chosen pointer, write-what-where, arbitrary address
control, PC control, valid heap-pointer free, weaponized UAF, or RecordDelete
LPE. Attacker token bytes sometimes appear in the `_find_mechanisms` consumed
pointer, but that does not reproduce reliably. The `RecordDelete` free argument
is deterministic, but remains enum-composed and invalid under normal heap
layouts.
