# OpenDirectory Module Sibling Scan Continuation

Date: 2026-06-12T0240Z
Scope: static-only scan of OpenDirectory modules for additional
`AuthenticationAuthority` / `DisabledTags` / indexed-write siblings.

## Bottom Line

No new stronger LPE-grade sibling was found in this continuation pass. The
module scan supports keeping VM time on the existing `DisabledTags` exploitation
gates and the already-documented `PlistFile.bundle` append-helper lead.

Reviewed lanes:

- `AppleODClientPWS.bundle`: bounded stack token vector.
- `ActiveDirectory.bundle`: bounded CLDAP address-list store.
- `ActiveDirectory.bundle`: CLDAP DNS-label stack vector reviewed negative.
- `SystemCache.bundle`: `_odauthauthority_parse` call is type-filtered away
  from `DisabledTags`.
- `PlistFile.bundle`: still the meaningful sibling module because it imports
  full aggregate parse/mutate/serialize helpers.

No host OpenDirectory, LDAP bind, `dscl`, or VM dynamic trigger was run for
this note.

## AppleODClientPWS Stack Token Vector

`AppleODClientPWS.bundle` has a `strsep` loop that initially looked like a
fixed stack-vector candidate. Manual disassembly shows it only stores three
token pointers at offsets `0`, `8`, and `16`.

Relevant static shape:

```text
c5a8  bl   _strsep
c5ac  str  x0, [x25, x24]
c5b4  ccmp x24, #0x10, #0x4, ne
c5b8  add  x24, x24, #0x8
c5bc  b.ne c5a0
```

The loop exits after the `x24 == 0x10` store. I do not see an OOB write here.

## ActiveDirectory CLDAP Address List

One CLDAP site-discovery path writes 32-bit address entries through an indexed
store. The loop guard caps the index to `0..31`.

Relevant static shape:

```text
a184  str w12, [x10, x20, lsl #2]
a188  add x20, x20, #0x1
a194  cmp x20, #0x20
a198  b.lo a158
```

This is not a current sibling candidate.

## ActiveDirectory CLDAP Label Stack Vector

The CLDAP DNS-label parser looked higher-signal because it writes pointers into
an eight-qword stack vector adjacent to the stack canary:

```text
str x27, [sp, #0x50 + w24*8]
```

Manual review says the stored index is the accumulated outer output-string
count, capped to successful indexes `0..7` by the surrounding outer loop. Error
paths do not produce index `8`.

Negative review package:

```text
/Users/dawgyg/submission_packages/activedirectory_cldap_label_stack_review_negative/NEGATIVE_STATIC_REVIEW.md
```

This was banked as a negative to avoid spending VM time on it.

## SystemCache Authauthority Parse Import

`SystemCache.bundle` imports `_odauthauthority_parse` and
`_odauthauthority_free_contents`, but the visible call site passes a fixed type
filter of `3`:

```text
18c34  add x0, sp, #0x70
18c38  mov w2, #0x3
18c3c  bl  _odauthauthority_parse
```

The core helper stores that filter and uses it to select the required authority
string before calling the lower parser:

```text
100030fa8  str w2, [sp, #0x28]
100030ff4  ldr w8, [x20, #0x28]
100030ff8  sub w8, w8, #0x1
100031004  ldr x2, [table, w8, uxtw #3]
100031008  bl  __authauthority_parse
```

With `w2 == 3`, this path filters to `Kerberosv5`, not `DisabledTags` type `9`.
I do not see a route for the `DisabledTags` parser bug through this
`SystemCache.bundle` call site.

## Remaining Best VM Focus

Follow-up static narrowing: `_od_update_authenticationauthority` does not look
like the next second-stage consumer. Static review found generic record
update/search CFArray handling around `AuthenticationAuthority`, but no direct
calls to `_odauthauthorities_parse`, `add_disabledtag`, `remove_disabledtag`, or
serializers, and no OpenDirectory module imports the helper. The parser sibling
review also did not find another same-shape unbounded inline-list append inside
`__authauthority_parse_authdata`; `DisabledTags` remains the parser-side
outlier. See `OD_UPDATE_AUTHORITY_AND_PARSE_SIBLING_STATIC_NOTES.md`.

The useful follow-up work remains:

- Bank the confirmed PlistFile `RecordDelete` cleanup result in
  `RECORD_DELETE_CONTROLLED_INVALID_FREE_DYNAMIC_NOTES.md`: fake
  `SecureToken` slot at index `6` makes `_odauthauthorities_free_contents`
  visit the fake slot, and indexes `10/11` deterministically compose the first
  `free()` argument observed as `0x800000008`. Next work is privilege matrix
  and token-control sweep, not re-proving the static map.
- Use `READ_STYLE_CLEANUP_CONSUMER_STATIC_NOTES.md` for the next LPE
  reachability pass. Top probes are `HasSecureToken` and
  `ODRecordAuthenticationAllowed` / `ODRecordCopyEffectivePolicies` because
  they are read/auth-style paths into `_odauthauthorities_free_contents`, unlike
  the confirmed but gated `RecordDelete` trigger.
- Use `FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md` and
  `vm_dynamic_evidence/SWEEP_RESULTS.md` as the canonical p10/p11 interpretation.
  Do not spend VM time trying to package p10/p11 as deterministic pointer
  composition unless a new repeated test contradicts the current non-control
  result.
- Gate `_odcredential_set_authentication_authority` and confirm whether `x2` is
  the attacker-controlled `AuthenticationAuthority` array before any
  `_find_mechanisms` crash wins.
- If the heap setter gate passes, use
  `HEAP_SETTER_POST_AGGREGATE_FIELD_CONSUMERS_STATIC_NOTES.md` to classify
  indexes `132..145` as finalizer/Auth/krb5 field consumers and index `152` as
  the `credential+0x318` flag gate.
- Gate second-stage trusted-count consumers:
  `_odauthauthorities_remove_disabledtag`,
  `_odauthauthorities_attribute_create`, and
  `_odauthauthority_attribute_create`.
- For the PlistFile memmove lane, include the false-positive disabledtag gate:
  `_odauthauthorities_disabledtag` can match overflow words at index `>=6` and
  route `__plistfile_attrs_add_sepCredential` into
  `_odauthauthorities_remove_disabledtag` when caller `w2` bit 0 is set. See
  `DISABLEDTAG_FALSE_POSITIVE_LOGIC_GADGET_STATIC_NOTES.md`.
- Treat `PlistFile.bundle` `_odauthauthorities_add_disabledtag` as the only
  currently meaningful module sibling, pending an authorization matrix for
  non-admin prefill/trigger paths.
