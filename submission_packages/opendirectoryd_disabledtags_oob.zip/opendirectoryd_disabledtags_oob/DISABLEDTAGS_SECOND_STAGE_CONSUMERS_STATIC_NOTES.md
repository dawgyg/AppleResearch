# DisabledTags Second-Stage Consumer Static Notes

Date: 2026-06-12
Binary: `/usr/libexec/opendirectoryd`, `opendirectoryd-966.100.2`
Scope: static-only follow-up for consumers that trust an overfull `DisabledTags`
slot after parsing.

## Bottom line

The outer `AuthenticationAuthority` array parser has a ten-slot cap, and the
ShadowHash hash-list path is bitmask-based rather than an unbounded inline-array
write. Those two paths do not currently look like sibling OOB writes.

The useful second-stage lead is different: once the existing `DisabledTags`
parser creates a slot with `count > 6`, later helpers trust that count when
removing or serializing the slot. Those consumers can turn the overfull count
into OOB reads, table-index reads, or count-derived `memmove` lengths.

This is not yet a separately proven reachable primitive. It is a VM triage map.

## Guarded paths checked

`_odauthauthorities_parse` zeroes a 0x238 aggregate and parses array entries
through `___odauthauthorities_parse_block_invoke`.

Important guard:

```text
0x1000317c0  ldr x8, [block+0x20]      ; aggregate
0x1000317c4  ldr x9, [x8]              ; parsed count
0x1000317c8  cmp x9, 9
0x1000317cc  b.gt skip
0x1000317d8  slot = aggregate + count*0x38
0x1000317dc  slot += 8
0x1000317e8  __authauthority_parse(slot, value, 0)
0x1000317f8  count++
```

That supports exactly ten slots, indexes 0 through 9. I did not find an outer
array-count OOB in this path.

`__authauthority_parse_shadowhash_list` parses `HASHLIST:<...>` and
`BLOCKED:<...>` into a bitmask. It compares token strings and ORs bits into
`w19`; it does not append into a fixed inline array.

## Removal consumer: count-derived scan and memmove

`_odauthauthorities_remove_disabledtag` scans for a type-9 slot, then trusts
the slot's `DisabledTags` count.

Relevant instructions:

```text
0x1000321e8  ldur w9, [x19-0x20]       ; slot type
0x1000321ec  cmp w9, 9
0x100032204  ldur x8, [x19-8]          ; DisabledTags count
0x100032210  lsl x9, x8, 2             ; count * 4
0x100032214  sub x2, x9, 4             ; memmove length base
0x100032220  ldr w10, [x0]             ; scan entry
0x100032228  b.eq found
0x100032258  add x1, x0, 4
0x10003225c  memmove(x0, x0+4, x2)
0x100032268  count--
```

For a valid six-entry list this is normal removal logic. For an overfull real
`DisabledTags` slot, the scan can read past the six-entry inline list. If the
removed tag is found early, the `memmove` length is derived from the overfull
count and can copy data from beyond the inline list back into the list/adjacent
slot region.

This is only useful if a VM path reaches `remove_disabledtag` on an already
overfull slot. Important 2026-06-12 refinement: the inspected
`PlistFile.bundle` `__plistfile_attrs_remove_sepCredential` path does not call
`_odauthauthorities_remove_disabledtag`; it calls `_odauthauthorities_remove`
for whole SecureToken/OTI authority slots, then `_odauthauthorities_add_disabledtag`,
then serializes. See `SECOND_STAGE_CONSUMER_REFINEMENT_NOTES.md`.

A later static pass found a different PlistFile route that does call
`_odauthauthorities_remove_disabledtag`: `__plistfile_attrs_add_sepCredential`
in SecureToken/password-update workflows. It is documented in
`PLISTFILE_SECURETOKEN_DISABLEDTAG_CONSUMERS_STATIC_NOTES.md`; current
reachability still appears policy/credential gated.

## Serialization consumer: count and entry values are trusted

`_odauthauthority_attribute_create` type 9 (`DisabledTags`) also trusts the
slot count and list entries.

Relevant instructions:

```text
0x100031228  ldr x8, [x19+0x18]        ; DisabledTags count
0x10003122c  cmp x8, 1
0x10003123c  x23 = x19 + 0x20          ; list base
0x100031240  x24 = ODAuthAuthorityStrings
0x100031250  ldr w9, [x23, i, lsl 2]   ; entry[i]
0x100031254  sub w9, w9, 1
0x100031258  ldr x21, [x24, w9, uxtw 3]
0x100031274  strlcat(buffer, x21, ...)
0x10003128c  reload count
0x100031294  cmp i, count
0x100031298  b.lt loop
```

There is no visible `count <= 6` check and no visible `1 <= entry <= 9` check
before indexing the token string table.

Consequences for VM triage:

- An overfull count can make serialization read entries beyond the six-entry
  inline list.
- A corrupted entry value of `0` underflows `entry - 1`.
- A fallback value of `10` indexes one past the nine-token table.
- Any corrupted entry value that resolves to a bad pointer can become a C string
  pointer passed into `__strlcat_chk`.

The fallback `10` case also exists without an overfull count when the parser sees
an unknown `DisabledTags` token. That narrower validation-mismatch lead is
tracked separately in `DISABLEDTAGS_UNKNOWN_TOKEN_SERIALIZER_STATIC_NOTES.md`.

Known static xrefs to `_odauthauthorities_attribute_create` in `opendirectoryd`:

```text
___odcredential_copy_details_block_invoke 0x10003455c
__create_connection_with_options          0x100058f7c
```

Follow-up refinement: those daemon xrefs serialize heap credential aggregates
at `credential+0x90`; they are not serializer-before-`_find_mechanisms` calls
on the proven LDAP auth stack aggregate. See
`DAEMON_HEAP_SERIALIZER_GATES_STATIC_NOTES.md`.

`PlistFile.bundle` also imports `odauthauthorities_attribute_create` and calls
it in local-record mutation paths already described in
`PLISTFILE_SIBLING_REACHABILITY_STATIC_NOTES.md`.

## VM gates

VM-only breakpoints or probes that would upgrade this lead:

```text
_odauthauthorities_remove_disabledtag
_odauthauthorities_attribute_create
_odauthauthority_attribute_create
```

Useful observations:

```text
slot type is 9
slot+0x18 count is greater than 6
list entries after index 5 come from attacker-shaped overflow geometry
remove_disabledtag reaches memmove with x2 > 0x14
attribute_create reaches __strlcat_chk with x21 loaded from an out-of-range table index or OOB list entry
```

For the PlistFile path, the highest-signal safe VM test is now split from the
generic `remove_disabledtag` gate:

```text
seed throwaway local record with overfull DisabledTags containing SecureToken or OTI early
trigger __plistfile_attrs_remove_sepCredential on that record
capture whether add_disabledtag appends a seventh tag and whether serialization consumes fake slots
```

Do not expect `_odauthauthorities_remove_disabledtag` to fire from this specific
PlistFile SEP-removal path. Break on `_odauthauthorities_remove_disabledtag`
globally as a separate gate for other consumers.

For the dynamic LDAP path, check whether authentication or credential-copy
flows ever serialize the parsed malicious authority before the existing
`_find_mechanisms` crash wins.

## Do not overclaim

Safe wording:

```text
Static review found second-stage consumers that trust the corrupted
DisabledTags count during removal and serialization. These are VM upgrade leads,
not independently proven LPE primitives yet.
```

Unsafe wording until VM evidence exists:

```text
remove_disabledtag exploitation is reachable from sandboxed LDAP
serialization gives arbitrary read
second-stage memmove is confirmed live
```
