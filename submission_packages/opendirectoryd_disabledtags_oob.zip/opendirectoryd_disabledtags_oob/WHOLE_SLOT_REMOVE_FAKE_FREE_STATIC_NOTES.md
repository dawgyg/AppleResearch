# Whole-Slot Remove Fake-Slot Free Static Notes

Date: 2026-06-12T0325Z
Scope: static-only refinement of `_odauthauthorities_remove` and PlistFile
SecureToken/OTI removal paths after a `DisabledTags` fake-slot overflow.
No host OpenDirectory, ActiveDirectory, LDAP, `dscl`, lldb, or VM dynamic
trigger was run for this note.

## Bottom Line

There is a second fake-slot consumer worth VM testing:

```text
_odauthauthorities_remove(type=4/5)
  -> _odauthauthority_free_contents(fake slot)
  -> free(fake slot pointer fields)
```

If an overfull `DisabledTags` list sets the first fake slot's type dword to
`SecureToken` (`4`) or `OTI` (`5`), any path that calls whole-slot
`_odauthauthorities_remove(type=4/5)` can select that fake slot and run the
generic auth-authority finalizer on fake pointer fields.

This is not arbitrary free. The fake pointers are still composed from
`DisabledTags` enum dwords (`1..10`). It is, however, a distinct root-context
consumer from `_find_mechanisms`: an attacker-shaped fake slot can be selected
by the SecureToken/OTI whole-slot removal helper before the append helper or
serializer runs.

Dynamic update: Claude later confirmed an adjacent fake-slot free through
`RecordDelete -> _plistfile_attrs_is_sepCredentialUser ->
_odauthauthorities_free_contents`, not through whole-slot
`_odauthauthorities_remove(type=4/5)`. That cleanup path still consumes the same
fake-slot pointer fields and observed `free(0x800000008)` with `DisabledUser`
tokens at indexes `10/11`. See
`RECORD_DELETE_CONTROLLED_INVALID_FREE_DYNAMIC_NOTES.md`.

## Fake Slot Field Map

For a first parsed `DisabledTags` authority in slot 0:

```text
aggregate base        = A
slot 0 base           = A + 0x08
DisabledTags list     = A + 0x28
token index n writes  = A + 0x28 + 4*n
first fake slot base  = A + 0x40
```

First fake slot field indexes:

```text
slot+0x00 type        index 6
slot+0x08 ptr low     index 8
slot+0x0c ptr high    index 9
slot+0x10 ptr low     index 10
slot+0x14 ptr high    index 11
slot+0x18 ptr low     index 12
slot+0x1c ptr high    index 13
slot+0x20 list/count  index 14...
```

For fake-slot free testing, index `6` is the selector:

```text
index 6 = SecureToken  -> fake slot type 4
index 6 = OTI          -> fake slot type 5
```

The first pointer freed by `_odauthauthority_free_contents` is `slot+0x10`,
so indexes `10` and `11` are the most visible pointer-composition markers.

## Core Helper Behavior

`_odauthauthorities_remove` scans all ten fixed slots by type. It does not use
the parsed aggregate count as its loop bound, and it does not compact slots:

```text
0x1000318b4  _odauthauthorities_remove
0x1000318c8  w8 = 0x8                         ; first slot type offset
0x1000318cc  ldr w9, [aggregate, x8]
0x1000318d0  cmp w9, w1
0x1000318d4  b.eq found
0x1000318d8  x8 += 0x38
0x1000318dc  cmp x8, 0x238
0x1000318e0  b.ne scan
0x1000318ec  x0 = aggregate + x8
0x1000318f0  _odauthauthority_free_contents
0x1000318f8  aggregate_count--
```

`_odauthauthority_free_contents` frees generic pointer fields before the
type-specific switch:

```text
0x100031638  x19 = slot
0x10003163c  x0 = [slot+0x10]
0x100031644  free(x0) if non-null
0x100031648  x0 = [slot+0x08]
0x100031650  free(x0) if non-null
0x100031654  w8 = [slot+0x00]
```

For fake type `4` or `5`, it also reaches the generic type branch that frees
`slot+0x18` if non-null:

```text
0x100031660  if type == 1/2/3 use type-specific branches
0x100031670  type 4/5 falls through toward generic branch
0x1000316c0  x0 = [slot+0x18]
0x1000316c8  free(x0) if non-null
```

So the first fake slot can drive up to three enum-composed pointer frees:

```text
free(slot+0x10)  indexes 10/11
free(slot+0x08)  indexes 8/9
free(slot+0x18)  indexes 12/13
```

## PlistFile Routes That Call Whole-Slot Remove

`__plistfile_attrs_remove_sepCredential` calls whole-slot removal before the
`add_disabledtag` append lane:

```text
0x113b4  _odauthauthorities_parse
0x113c0  _odauthauthorities_remove(type=w26)  ; SecureToken(4) or OTI(5)
0x11454  _odauthauthorities_remove(type=4)    ; OTI secondary SecureToken remove
0x114ac  _odauthauthorities_add_disabledtag(type=w26)
0x11510  _odauthauthorities_add_disabledtag(type=4)
0x11564  _odauthauthorities_attribute_create
```

The important nuance: if there is no earlier real type-4/type-5 slot, but the
`DisabledTags` overflow creates a fake type-4/type-5 slot, this helper can find
and finalize the fake slot before the add-disabledtag append and serializer
behavior.

`__create_record` also has a whole-slot SecureToken normalization path:

```text
0xfc98   _odauthauthorities_parse(authentication_authority)
0xfca4   _odauthauthorities_find(type=4)
0xfdc4   _odauthauthorities_remove(type=4)
0xfe5c   _odauthauthorities_add(type=4)
0xfe64   _odauthauthorities_attribute_create
```

Treat `NodeCreate` as parser/serializer/whole-slot-normalization only. It is
not an `add_disabledtag`/`remove_disabledtag` helper route, but it may still be
able to select a fake type-4 slot if record creation accepts the malicious
`AuthenticationAuthority`.

## SEP User Predicate Caveat

PlistFile SEP-user predicates parse `AuthenticationAuthority` and use
`_odauthauthorities_find` on the same ten-slot aggregate:

```text
0x8e38   __plistfile_attrs_is_sepCredentialUser -> _odauthauthorities_parse
0x20b80  __plistfile_is_sepCredentialUser
0x20e38  OTI path:         _odauthauthorities_find(type=5)
0x210ac  SecureToken path: _odauthauthorities_find(type=4)
```

This means fake type-4/type-5 slots can satisfy the "auth authority exists"
portion of these predicates. There are still external checks:

```text
OTI:         _oti_helpers_user_exists(...)
SecureToken: _securetoken_helpers_has_unlockrecord(...)
```

So do not claim fake-slot type alone bypasses SecureToken policy. The VM value
is narrower: a fake slot may be enough to send execution into later
whole-slot-removal or policy code that assumes the found slot is a real parsed
authority.

## VM Test Suggestion

Use only a disposable VM snapshot.

Marker pattern for the first fake slot:

```text
index 6  = SecureToken or OTI       ; selects fake slot for remove(type=4/5)
index 10 = chosen low-dword token   ; first freed pointer low dword
index 11 = chosen high-dword token  ; first freed pointer high dword
index 8/9 and 12/13 optional secondary free markers
```

High-signal breakpoints:

```text
_odauthauthorities_remove
_odauthauthority_free_contents
free / malloc_error_break
__plistfile_attrs_remove_sepCredential
__create_record
```

At `_odauthauthorities_remove`:

```text
record x0 aggregate pointer and w1 target type
check whether returned/found slot is aggregate+0x40 for first fake slot
check [aggregate+0x40] == 4 or 5 from token index 6
```

At `_odauthauthority_free_contents`:

```text
require x0 == aggregate+0x40 for first fake slot
record [x0+0x10], [x0+0x08], [x0+0x18]
expected first freed pointer is composed from indexes 10/11
capture fresh .ips if malloc/free aborts
```

Expected honest outcome:

```text
root-context selected fake-slot free with enum-composed pointer values
```

Not yet proven:

```text
arbitrary free
valid heap-pointer free
code execution
non-admin reachability through PlistFile without policy gates
```

## Reporting Implication

This strengthens the root-daemon memory-corruption story by adding a second
consumer class:

```text
_find_mechanisms consumes fake-slot slot+0x10 as a C string pointer.
_odauthauthorities_remove can consume fake type-4/type-5 slots and free their
fake pointer fields.
```

Both are still value-limited by the token enum writes. The selected-free lane
is useful VM evidence if it can be reached through PlistFile whole-slot
normalization before the existing `_find_mechanisms` crash path wins.
