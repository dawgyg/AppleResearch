# DisabledTags Second-Stage Consumer Refinement

Date: 2026-06-12T0246Z
Scope: static-only refinement of second-stage `DisabledTags` consumers.
No host or VM OpenDirectory activity was run for this note.

## Bottom Line

`_odauthauthorities_remove_disabledtag` is stronger statically than a simple
OOB read. If it is reached with a real type-9 `DisabledTags` slot whose count is
greater than six, an early match produces a count-derived `memmove` across the
auth-authority aggregate.

For count `c` and found list index `j`, the memmove length is:

```text
length = 4 * (c - 1 - j)
```

Example: `count=64` and target tag at index `0` gives `length=252`, with
destination at `list[0]` and source at `list[1]`. The source bytes are existing
aggregate/fake-slot bytes shaped by the overflow geometry, not arbitrary
attacker-provided bytes.

Important correction: the inspected `PlistFile.bundle`
`__plistfile_attrs_remove_sepCredential` path does not call
`_odauthauthorities_remove_disabledtag`. It calls `_odauthauthorities_remove`
to remove whole SecureToken/OTI authority slots, then calls
`_odauthauthorities_add_disabledtag`, then serializes the aggregate.

Follow-up refinement: a different PlistFile helper,
`__plistfile_attrs_add_sepCredential`, does call
`_odauthauthorities_remove_disabledtag` after a parse. That SecureToken/SEP
credential add path is tracked separately in
`PLISTFILE_SECURETOKEN_DISABLEDTAG_CONSUMERS_STATIC_NOTES.md`.

## `_odauthauthorities_remove_disabledtag`

Relevant disassembly shape:

```text
0x1000321e0  add x19, x0, #0x28       ; list base for current slot
0x1000321e4  mov w8, #0xa             ; fixed ten-slot outer scan
0x1000321e8  ldur w9, [x19, #-0x20]   ; slot type
0x1000321ec  cmp w9, #0x9             ; DisabledTags
0x100032204  ldur x8, [x19, #-0x8]    ; DisabledTags count
0x100032208  cmp x8, #0x1
0x100032210  lsl x9, x8, #2
0x100032214  sub x2, x9, #4           ; memmove length base
0x100032218  mov w9, #5
0x10003221c  mov x0, x19
0x100032220  ldr w10, [x0]            ; scan entry
0x100032224  cmp w10, w1
0x100032228  b.eq found
0x10003222c  sub x2, x2, #4
0x100032230  add x0, x0, #4
0x100032234  sub x9, x9, #1
0x100032238  add x10, x8, x9
0x10003223c  cmp x10, #5
0x100032240  b.ne scan
0x100032254  cbz x9, skip_memmove
0x100032258  add x1, x0, #4
0x10003225c  memmove(x0, x0+4, x2)
0x100032268  count--
```

Interpretation:

```text
count c controls the initial memmove length base 4*c - 4
each non-matching scanned entry subtracts 4 from x2
if the removed tag is found at index j, length is 4*(c - 1 - j)
```

For valid `c=6`, the helper removes from the six-entry inline list. For
overfull `c>6`, it can scan beyond the inline list and, on an early hit,
copy bytes through later inline entries and adjacent slot fields.

This is still a reachability gate. A VM path must actually call
`_odauthauthorities_remove_disabledtag` on an already-overfull real type-9 slot
before this becomes live evidence.

## Serializer Behavior

`_odauthauthorities_attribute_create` creates a CFArray using the aggregate
count for capacity, but serializes exactly ten 0x38-byte slots.

Relevant loop shape:

```text
0x100031858  ldr x1, [x19], #0x8       ; aggregate count, capacity only
0x10003186c  mov w22, #0xa
0x100031870  mov x0, x19
0x100031874  bl _odauthauthority_attribute_create
0x100031894  add x19, x19, #0x38
0x100031898  subs x22, x22, #0x1
0x10003189c  b.ne 0x100031870
```

That matters because fake nonzero slots created by the overflow can be
serialized even if they were never counted as parsed slots.

For type 9, `_odauthauthority_attribute_create` trusts the slot count and each
entry value:

```text
0x100031228  ldr x8, [x19, #0x18]      ; DisabledTags count
0x10003122c  cmp x8, #0x1
0x10003123c  add x23, x19, #0x20       ; list base
0x100031240  x24 = ODAuthAuthorityStrings
0x100031250  ldr w9, [x23, x22, lsl #2]
0x100031254  sub w9, w9, #1
0x100031258  ldr x21, [x24, w9, uxtw #3]
0x100031274  strlcat(buffer, x21, ...)
0x10003128c  reload count
0x100031294  cmp x22, x9
0x100031298  b.lt loop
```

There is no visible `count <= 6` check and no visible entry range check before
the token-string table index.

## PlistFile Correction

The inspected `PlistFile.bundle` flow in `__plistfile_attrs_remove_sepCredential`
is:

```text
0x11360  x0 = sp; w1 = 0x238; bzero
0x1136c  _sepCredential_usingOTI
0x11378  w8 = 4
0x1137c  w26 = OTI ? 5 : 4
0x113a8  odproplist_get_array(authentication_authority)
0x113b4  _odauthauthorities_parse
0x113bc  x1 = w26; _odauthauthorities_remove
...
0x1144c  if OTI mode: x1 = 4; _odauthauthorities_remove
...
0x114a4  if x24: x1 = w26; _odauthauthorities_add_disabledtag
...
0x11508  if OTI mode: x1 = 4; _odauthauthorities_add_disabledtag
...
0x11560  _odauthauthorities_attribute_create
0x1157c  CFDictionarySetValue(authentication_authority, new_array)
```

So for this path, VM time should focus on:

```text
prefill/authorization gate for the local record
_odauthauthorities_add_disabledtag appending a seventh tag
_odauthauthorities_attribute_create serializing fake/nonzero slots
```

Do not expect a `_odauthauthorities_remove_disabledtag` breakpoint from this
specific PlistFile path.

Do expect a `_odauthauthorities_remove_disabledtag` breakpoint from the separate
PlistFile `__plistfile_attrs_add_sepCredential` path if an authorized VM
workflow reaches it with the remove-disabled flag set.

## VM Gates

Highest-signal dynamic checks:

```text
break _odauthauthorities_remove_disabledtag globally
  require slot type 9 and count > 6
  record found index j and x2 memmove length
  formula check: x2 == 4*(count - 1 - j)

break _odauthauthorities_attribute_create
break _odauthauthority_attribute_create
  check whether a path serializes before _find_mechanisms wins
  watch fake nonzero slots and type-9 count > 6

for PlistFile:
  treat _odauthauthorities_add_disabledtag and serializer behavior as the lane
  do not treat this path as remove_disabledtag reachability proof
```

Safe wording:

```text
Static review found a count-derived memmove primitive in
_odauthauthorities_remove_disabledtag if any VM path reaches it on an overfull
type-9 slot. The inspected PlistFile SEP-removal path is not that path; it is
an append-helper plus serializer route.
```
