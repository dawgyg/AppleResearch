# Refcount-UAF static recon

Date: 2026-06-12T0434Z
Scope: static-only response to the refcount-UAF LPE triage question. No host
`opendirectoryd`, `dscl`, LDAP, or lldb actions were run.

## Bottom line

The proven unprivileged `HasSecureToken` controlled-free lane is stack-backed, not
heap-backed. That exact lane is excellent report evidence, but it is not the right place
for adjacent heap-object refcount grooming.

The remaining heap candidate is still the credential aggregate embedded inside
`OS_od_credential` at `credential+0x90`. That path can corrupt finalizer-consumed fields
inside the same 0x328 object, but it is not yet proven reachable with attacker-controlled
`AuthenticationAuthority` data. The VM gate remains `_odcredential_set_authentication_authority`
with `x2` equal to the malicious array.

## HasSecureToken backing: stack

`_HasSecureToken` dispatches to `___HasSecureToken_block_invoke`, which calls:

```text
0x8c30  attrs = record attrs
0x8c34  x1 = block + 0x38
0x8c38  __plistfile_attrs_is_sepCredentialUser(attrs, ...)
```

In `__plistfile_attrs_is_sepCredentialUser`:

```text
0x8c8c  sub sp, sp, #0x280
0x8ca4  save stack guard at [x29-0x48]
0x8ca8  x0 = sp+0x8
0x8cac  w1 = 0x238
0x8cb0  bzero(sp+0x8, 0x238)
...
0x8e34  x0 = sp+0x8
0x8e38  _odauthauthorities_parse(sp+0x8, AuthenticationAuthority)
0x8e40  x0 = sp+0x8
0x8e50  __plistfile_is_sepCredentialUser(...)
0x8ef0  x0 = sp+0x8
0x8ef4  _odauthauthorities_free_contents(sp+0x8)
0x8ef8  check stack guard
```

So the aggregate Claude is hitting through `ODNodeCustomFunction("HasSecureToken")`
is a 0x238 stack local, not a heap allocation. There is no same-size heap chunk adjacent
to this aggregate to groom.

For a first-slot `;DisabledTags;...`, the token list base is `sp+0x30`
(`aggregate+0x28`). The first write beyond the 0x238 aggregate is token index 132.
In this frame, the stack guard is at `sp+0x278`, so index 146 reaches the low dword
of the saved stack guard and index 147 reaches the high dword. That is useful for
classifying overrun extent, but it is a stack-corruption evidence route, not a heap
refcount route.

## OOB loop remains unbounded

The vulnerable parser still has no capacity check in the `DisabledTags` authdata loop:

```text
0x100031bd0  type == DisabledTags
0x100031bd4  save authdata pointer
0x100031bdc  x21 = slot+0x18  ; count field
0x100031bfc  x22 = slot+0x20  ; six-entry inline list base
...
0x100031c40  count = [slot+0x18]
0x100031c44  str w24, [slot+0x20 + count*4]
0x100031c48  reload count
0x100031c4c  count++
0x100031c50  store count
0x100031c54  continue strsep loop
```

The only value written per token is the parsed authority enum dword (`1..10`), but the
write index is attacker-controlled through token count.

## Heap credential lane

`_odcredential_create` and `_odcredential_create_with_details` create 0x328-byte
`OS_od_credential` objects:

```text
0x100033610  w0 = 0x10
0x100033614  w1 = 0x328
0x100033620  _odobject_create_internal(..., size=0x328, finalizer=__odcredential_finalize)

0x1000337fc  w0 = 0x10
0x100033800  w1 = 0x328
0x10003380c  _odobject_create_internal(..., size=0x328, finalizer=__odcredential_finalize)
```

Both parse authentication authorities into `credential+0x90`:

```text
0x1000336c0  x0 = credential+0x90
0x1000336c8  _odauthauthorities_parse

0x100033938  x0 = credential+0x90
0x10003393c  _odauthauthorities_parse
```

The setter is still the best heap lead because it frees and reparses into the same
embedded aggregate without visibly rewriting the post-aggregate fields afterward:

```text
0x1000342fc  credential = block[0x20]
0x100034300  x0 = credential+0x90
0x100034304  _odauthauthorities_free_contents
0x10003430c  x1 = block[0x28]  ; new AuthenticationAuthority array
0x100034310  x0 = credential+0x90
0x100034314  _odauthauthorities_parse
```

For a first-slot `DisabledTags` inside this heap aggregate, token index mapping is:

```text
index 132 -> credential+0x2c8
index 134 -> credential+0x2d0
index 136 -> credential+0x2d8
index 138 -> credential+0x2e0
index 140 -> credential+0x2e8
index 142 -> credential+0x2f0
index 144 -> credential+0x2f8
index 150 -> credential+0x310
index 152 -> credential+0x318
```

`__odcredential_finalize` consumes those fields:

```text
0x100035c38  CFRelease([credential+0x2d0])
0x100035c48  CFRelease([credential+0x2c8])
0x100035c58  CFRelease([credential+0x310])
0x100035c68  od_release([credential+0x2e0])
0x100035c74  free([credential+0x2f8])
0x100035c84  AuthorizationFree([credential+0x2d8], 0)
0x100035c94  krb5_cc_destroy([credential+0x2f0], [credential+0x2e8])
0x100035ca8  krb5_free_context([credential+0x2f0])
```

This is stronger than pure adjacent-groom speculation because the corrupted fields are
inside the object that the finalizer later consumes. The remaining limits are:

1. The dword values are still only authority enum values (`1..10`).
2. Static reachability only shows the direct setter caller as trust-credential population.
3. The already-proven LDAP/user auth crash path reaches a stack aggregate unless VM
   breakpoints prove otherwise.

## OD object/refcount model

`_od_release` is a thin wrapper over libplatform's os_object release:

```text
0x1000257cc  cbz x0, return
0x1000257d0  __os_object_release_without_xref_dispose
```

`_odobject_create_internal` uses `__os_object_alloc`, then stores OD metadata:

```text
0x100025960  class = global class table[type]
0x100025968  __os_object_alloc(class, name)
0x100025974  [object+0x18] = type
0x100025978  [object+0x20] = name/finalizer metadata
0x10002597c  [object+0x10] = dispose callback
0x1000259a8  [object+0x28] = dispatch queue
0x1000259e0  [object+0x48] = retained/copy UUID CFData
0x100025a00  [object+0x60] / [object+0x68] = OD object list links
```

I do not see a simple in-object integer refcount field after the authority aggregate.
The os_object retain state is allocator/runtime-managed, so the currently visible
credential primitive is post-field finalizer corruption, not a clean static refcount
overwrite.

## VM gates for Claude

Prioritize these checks:

```text
1. HasSecureToken path
   Confirm aggregate address is stack in lldb. If so, deprioritize heap-adjacent
   refcount grooming for this specific lane.

2. Credential setter path
   Break _odcredential_set_authentication_authority.
   Capture backtrace, x0 credential, x2 AuthenticationAuthority array, record name/type,
   malloc_size(x0), and whether x2 is the attacker-controlled array.

3. If setter x2 is attacker-controlled
   After _odauthauthorities_parse returns, inspect credential+0x2c8..+0x318 and
   observe any normal credential release/finalization that follows. A
   CFRelease/AuthorizationFree/free crash from those fields is materially stronger
   evidence than the stack lane.

4. If setter is not hit or x2 is not attacker-controlled
   Treat the heap UAF plan as unproven for this trigger and keep the report framed as
   unprivileged root-daemon controlled invalid-free / memory corruption.
```

Do not conflate the proven `HasSecureToken` unprivileged trigger with the heap credential
setter until the VM breakpoint proves the same malicious `AuthenticationAuthority` reaches
that setter.
