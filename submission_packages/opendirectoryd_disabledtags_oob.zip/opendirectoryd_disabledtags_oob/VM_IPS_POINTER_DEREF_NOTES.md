# VM IPS Pointer-Dereference Notes

Date: 2026-06-12
Binary: `/usr/libexec/opendirectoryd`, `opendirectoryd-966.100.2`
Source: Claude-reported VM `.ips` crash evidence from `lpe-vm`

## Local Artifact Status

As of 2026-06-12, the package file
`vm_dynamic_evidence/opendirectoryd_crash_find_mechanisms.ips` is zero bytes.
This note preserves Claude-reported/user-pasted `.ips` details, but the package
needs the real crash report copied in before submission. A read-only Codex SSH
fetch attempt against the VM did not return and was terminated; do not replace
the missing artifact with host-side crash attempts.

## Summary

The VM crash result upgrades the live evidence from "root daemon crash after
OOB write" to "root daemon consumes an OOB-corrupted auth-authority slot and
passes a corrupted pointer to a string API."

This is still not proof of root code execution or Apple Security Bounty Target
Flag capture.

## Reported Crash Evidence

Claude reported a fresh VM crash report:

```text
/Library/Logs/DiagnosticReports/opendirectoryd-2026-06-11-182257.ips
```

Relevant reported state:

```text
exception: EXC_BAD_ACCESS
far:       0x100000000
pc:        0x1877c8ac4
x0:        0x100000001
x1:        0x100000000
x20:       0x100000001
```

Reported symbolicated path:

```text
__odm_handle_api_authentication_block_invoke_2  (opendirectoryd +0x4fc4)
  -> _find_mechanisms                           (opendirectoryd +0x549c)
       -> CFStringCreateWithCString(corrupted_ptr)
            -> strlen(0x100000000)
```

## Interpretation

This matches the static fake-slot consumer notes:

- `DisabledTags` overflows its six-entry inline list.
- The overflow reaches later `odauthauthority` slots inside the same 0x238
  aggregate before it reaches post-aggregate stack locals.
- `_find_mechanisms` scans all ten authority slots.
- For a nonzero fake/corrupted slot type, it passes a slot field to
  `CFStringCreateWithCString`.
- CoreFoundation then calls `strlen` on the corrupted C string pointer in root
  `opendirectoryd`.

The important upgrade is that a root-context consumer uses the corrupted slot
field, not merely that the parser writes out of bounds.

## Static Offset Correction

`__find_mechanisms` consumes the pointer at `slot+0x10`, not `slot+0x18`:

```text
0x100005484  ldur w8, [x22-0x10]       ; slot type at slot+0x0
0x10000548c  ldr x1, [x22]             ; cStr pointer at slot+0x10
0x100005498  CFStringCreateWithCString
```

For a first parsed `DisabledTags` slot, the overflow list base is
`aggregate+0x28`. The first fake slot (`slot 1`) has:

```text
type dword:       token index 6
cStr low dword:   token index 10
cStr high dword:  token index 11
```

The full table is in `FIND_MECHANISMS_POINTER_OFFSET_STATIC_NOTES.md`.

## Controllability Update

Claude's uniform-token sweep used the same crash shape with different token
names:

```text
ShadowHash  -> enum 1
Kerberosv5  -> enum 3
AppleID     -> enum 7
```

The fault address stayed `0x100000000` across those runs. Therefore the current
uniform-token evidence did not prove direct token-enum-to-pointer control.

Claude's later marker sweep reportedly placed `DisabledUser` at zero-based token
index `10` and changed the crash-path state in one sample to:

```text
mk8@10 -> x0=0x100000008
          x20=0x100000008
```

That matches the static map: index `10` is the low dword of the first fake
slot's `_find_mechanisms` `slot+0x10` pointer field. This was a plausible offset
marker, but not reproducible control.

Claude then reported the decisive high-dword marker at zero-based token index
`11`:

```text
p11 -> far=0x800000000
       x1 =0x800000000
```

Uniform `ShadowHash` tokens gave `far=0x100000000` in the earlier sample, so
this initially looked like high-dword marker influence. Repeat testing disproved
that conclusion. Identical input produced no crash, `far=0x800000000`, and
`far=0x0` across runs; changing only the position-11 token did not make the
fault address track the enum. Treat the p10/p11 observations as heap-layout
coincidences, not deterministic pointer control.

Register caveat: at the `_find_mechanisms` call site, `x0` is allocator and
`x1` is the C-string pointer passed to `CFStringCreateWithCString`. At the later
`_platform_strlen` crash frame, `x0`/`x20` can be the string pointer or
CoreFoundation local copies. Avoid over-wording the marker as allocator control
unless a call-site frame proves it.

Current best model:

- The attacker controls overflow length/count and fake-slot geometry.
- The attacker controls written values only within the small auth-type enum
  set (`1..9`) or fallback `10`.
- The observed pointer/register values are geometry plus heap state. Attacker
  token bytes sometimes appear in the consumed pointer, but the value does not
  reproduce and is not a controlled target/aim primitive.

## VM Next Gates

Recommended VM-only follow-up:

1. Sweep fake-slot boundary counts:

```text
7, 21, 35, 49, 63, 77, 91, 105, 119
```

These correspond to zero-based token indexes:

```text
6, 20, 34, 48, 62, 76, 90, 104, 118
```

2. Sweep post-aggregate boundary counts:

```text
133, 134, 135, 136
```

These correspond to zero-based token indexes:

```text
132, 133, 134, 135
```

3. For each crash, record:

```text
token count
token name/pattern
first crashing frame
far/fault address
x0/x1/x2/x8/x20 if present in the .ips
whether the first crashing count is in-aggregate or post-aggregate
```

4. Look specifically for:

- `far` or the C string pointer changing with count.
- A non-low pointer or heap pointer reaching the string/free consumers.
- A fake slot that changes auth flow without immediate crash.
- Any post-aggregate stack-local corruption that moves beyond low-pointer
  crashes.

## Do Not Overclaim Yet

Safe wording:

```text
Root opendirectoryd memory corruption is reachable from a stock sandboxed
client through an explicit dynamic LDAPv3 node. VM crash evidence shows the
overflow can corrupt an auth-authority slot that is later consumed as a C
string pointer by _find_mechanisms, causing root-context strlen on a corrupted
pointer.
```

Unsafe wording until more evidence exists:

```text
A token enum directly and reliably controls the dereferenced pointer.
Arbitrary read/write is proven.
PC control is proven.
Target Flag is captured.
```
