# Non-PlistFile Consumer And Local Placement Static Answer

Date: 2026-06-12T0430Z
Scope: answer to Claude's placement/module-survey questions. Static-only on the
host; no OpenDirectory, LDAP, dscl, lldb, or VM dynamic trigger was run.

## Direct Answer

I do not see a cheap static win that recombines the unprivileged LDAP supply path
with the deterministic PlistFile controlled-free consumer.

Current answer to Claude's two material questions:

```text
1. Non-PlistFile unprivileged cleanup/free consumer for LDAP-supplied
   AuthenticationAuthority:
   not found.

2. Non-root local vector to write/influence a PlistFile record's
   AuthenticationAuthority:
   not found.
```

That leaves the current honest ceiling for this candidate:

```text
unprivileged/sandbox -> root opendirectoryd OOB write/crash via dynamic LDAP
root/admin-seeded local toxic record -> unprivileged trigger -> deterministic
controlled invalid free in root opendirectoryd
```

It does not currently make a self-contained unprivileged LPE.

## Question 1: Non-PlistFile Cleanup Consumer

Module custom-function survey:

```text
AppleODClientLDAP.bundle:
  GetAuthenticationData
  GetRecordPrivileges

AppleODClientPWS.bundle:
  CheckNTLMv2SessionKeySupport
  GetRecordPrivileges

ldap.bundle:
  ServerDiscovery

configure.bundle:
  AddTrust
  RemoveTrust

PlistFile.bundle:
  HasSecureToken
  SecureTokenAllowed
  GetSEPCredentialLockoutState
  SecureToken*
  VerifyCredential
  VolumeHasOwners
  ...
```

Only `PlistFile.bundle` advertises `HasSecureToken`, `SecureToken*`, or
SEP-credential custom functions.

Undefined-symbol survey:

```text
PlistFile.bundle imports:
  _odauthauthorities_parse
  _odauthauthorities_free_contents
  _odauthauthorities_find
  _odauthauthorities_disabledtag
  _odauthauthorities_remove_disabledtag
  _odauthauthorities_attribute_create
  ...

AppleODClientLDAP / ldap / AppleODClientPWS / Kerberosv5 / NetLogon import:
  _kODAttributeTypeAuthenticationAuthority
  selected _odcredential_* helpers
  _odnodeconfig_copy_trustcredential
  but not the aggregate _odauthauthorities_parse/free_contents helpers
```

String survey:

```text
__plistfile_attrs_is_sepCredentialUser / SecureToken / SEP helper strings:
  PlistFile only

SystemCache and legacy contain AuthenticationAuthority-related strings. Prior
static notes found a SystemCache single-authority parse lead with a type-3
Kerberosv5 filter, but not the type-9 DisabledTags aggregate cleanup/free lane.
```

`ActiveDirectory`, `AppleODClientLDAP`, and `AppleODClientPWS` do export
`_odm_RecordAuthenticationAllowed`, but the static import table does not show
them calling `_odauthauthorities_parse` or `_odauthauthorities_free_contents`.
So the PlistFile `ODRecordAuthenticationAllowed` cleanup lead does not transfer
to LDAP/AD/PWS as a controlled-free consumer.

The non-PlistFile modules still matter for the base bug and credential leads:

```text
AppleODClientLDAP imports _odcredential_create
ldap imports _odcredential_create and _odcredential_create_with_details
AppleODClientPWS imports _odcredential_create and _odcredential_copy_details
```

That keeps the heap-credential breakpoint lane alive, but it is not the
PlistFile fake-slot free. For that lane, the useful VM gates remain:

```text
_odcredential_create / _odcredential_create_with_details:
  classify whether attacker LDAP AuthenticationAuthority reaches object+0x90
  and whether post-parse fixups overwrite the corrupted fields

_odcredential_set_authentication_authority:
  promote only if x2 is the attacker-controlled AuthenticationAuthority array
```

## Question 2: Non-Root Local AuthenticationAuthority Placement

Current dynamic fact from Claude:

```text
uid 501 dscl . -create/-append AuthenticationAuthority -> eDSPermissionError
```

Static PlistFile mutation gates agree with that:

```text
_odm_RecordSetValue:
  __fetch_and_retain_record
  __recordentry_copy_attributes
  __session_has_privilege
  __plistfile_attrs_modification_allowed_by_sandbox

_odm_RecordAddValue:
  __session_has_privilege
  __plistfile_attrs_modification_allowed_by_sandbox

_odm_RecordRemoveValue:
  __session_has_privilege
  __plistfile_attrs_modification_allowed_by_sandbox

_odm_NodeCreateRecord:
  __session_has_privilege
  creation-attribute validation

_odm_NodeReplaceUserRecord:
  parses existing and replacement AuthenticationAuthority, but has policy checks
  around preserving/removing SEP credential authorities
```

The privilege helper is not a stub:

```text
__session_has_privilege:
  odconnection_copy_credential
  odrequest_verify_access
  odcredential_copy_recordname
  __user_has_privilege

__plistfile_attrs_modification_allowed_by_sandbox:
  sandbox_check_by_audit_token("opendirectory-user-modify", ...)
```

For `AuthenticationAuthority`, `RecordSetValue` also has special SEP/OTI
consistency logic:

```text
compare requested attribute with authentication_authority
__plistfile_attrs_is_sepCredentialUser(existing_attrs)
parse proposed/new auth_authority
find OTI / SecureToken
free parsed auth authorities
```

I did not find a static uid-owned/self-service exception for
`AuthenticationAuthority`.

`/System/Library/OpenDirectory/permissions.plist` agrees with the same split for
`dsRecTypeStandard:Users` / `dsAttrTypeStandard:AuthenticationAuthority`:

```text
ordinary/self/euid-looking entries:
  readattr only

writeattr entries:
  privileged UUID entries such as ABCDEFAB-CDEF-ABCD-EFAB-CDEF00000000 and
  ABCDEFAB-CDEF-ABCD-EFAB-CDEF00000050
```

Mobile-account/cache/profile angle:

```text
PlistFile contains LocalCachedUser/mobile-account strings, and opendirectoryd
contains createmobileaccount / ODNodeReplaceUserRecord strings.
```

But I did not find a static path showing a non-root user can cause
network-supplied `AuthenticationAuthority` to be materialized into a local
PlistFile record without privilege/policy approval. Treat MDM, configuration
profile, migration, and managed mobile-account creation as root/admin or
environment-seeding stories unless VM evidence proves otherwise.

## Reporting Consequence

For Apple report language, keep the two facts separate:

```text
dynamic LDAP:
  non-root/sandbox attacker supply -> root parser OOB -> root daemon crash

HasSecureToken:
  toxic local record already present -> non-root trigger -> deterministic
  controlled invalid free in root daemon
```

Do not state that these combine into a self-contained unprivileged LPE unless
future VM evidence proves either:

```text
1. non-root local AuthenticationAuthority placement, or
2. LDAP-supplied AuthenticationAuthority reaches a cleanup/finalizer consumer
   with deterministic controlled-free or stronger behavior, or
3. credential heap parsing yields a valid object/Target Flag/arbitrary write
   primitive.
```
