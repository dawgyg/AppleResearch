# Heap Credential Path Static Notes

Date: 2026-06-11
Binary: `/usr/libexec/opendirectoryd` arm64e, macOS 26.5.1 25F80

## Scope

These notes are static-only. They are meant to guide VM exploitability triage for the `DisabledTags` OOB write without running additional `opendirectoryd` crash triggers on the host.

## DisabledTags Token Value Map

The `DisabledTags` token loop compares each comma token against a nine-entry table at arm64e `0x100081130`. Matches store `index + 1`; misses store fallback `0xa`.

```text
1  ShadowHash
2  ApplePasswordServer
3  Kerberosv5
4  SecureToken
5  OTI
6  LocalCachedUser
7  AppleID
8  DisabledUser
9  DisabledTags
10 unknown token fallback
```

This confirms that fake-slot experiments can deliberately place type `6` with `LocalCachedUser`, type `8` with `DisabledUser`, type `9` with `DisabledTags`, and fallback type `10` with any unknown token.

## Heap Object Layout

Credential creation allocates a `0x328`-byte `OS_od_credential` object:

```text
_odcredential_create:
  _odobject_create_internal(..., size = 0x328, ...)
  auth-authorities aggregate = object + 0x90

_odcredential_create_with_details:
  _odobject_create_internal(..., size = 0x328, ...)
  auth-authorities aggregate = object + 0x90

_odcredential_set_authentication_authority:
  frees then reparses into object + 0x90
```

For a first-slot `DisabledTags` value:

```text
DisabledTags list base = object + 0xb8
aggregate end          = object + 0x2c8
first post-aggregate write: zero-based token index 132
```

The offsets below use zero-based token indexes. A VM test with `N` comma tokens writes indexes `0..N-1`.

Useful token-index offsets:

```text
index 132 -> object + 0x2c8  (requires 133 tokens)
index 134 -> object + 0x2d0  (requires 135 tokens)
index 136 -> object + 0x2d8  (requires 137 tokens)
index 138 -> object + 0x2e0  (requires 139 tokens)
index 140 -> object + 0x2e8  (requires 141 tokens)
index 146 -> object + 0x300  (requires 147 tokens)
index 150 -> object + 0x310  (requires 151 tokens)
index 152 -> object + 0x318  (requires 153 tokens)
```

## Post-Parse Field Writes

`_odcredential_create` initializes some later fields before parsing:

```text
object + 0x318: flags ORed with caller flags before parse
object + 0x300: uuid_clear before parse
object + 0x310: zero before parse
object + 0x70 / +0x78 / +0x80 / +0x88: retained CF fields before parse
object + 0x2d0: copied nodename before parse on one flag path
object + 0x2e0: retained node/config pointer before parse
```

After parsing, `_odcredential_create` searches for type `3` (`Kerberosv5`) and, if found, writes a newly created `CFString` to `object + 0x2c8`.

`_odcredential_create_with_details` sets `object + 0x318` before parsing, parses into `object + 0x90`, then writes several fields after parsing:

```text
object + 0x2c8: CFString if type 3 is found
object + 0x88: retained field unless flag bit 1 path is taken
object + 0x2d0: copied nodename on flag bit 1 path
object + 0x2e0: retained node/config pointer after parse
```

This means some post-aggregate corruptions are overwritten in the `create_with_details` path after the OOB write. The `object + 0x318` flags field is not overwritten after parse, but reaching token 152 first walks through pointer-bearing fields and UUID/storage fields.

`_odcredential_set_authentication_authority` is different: it frees the aggregate contents and reparses into `object + 0x90`, then only logs parse success/failure in the inspected block. It does not immediately rewrite `object + 0x2c8`, `+0x2d0`, `+0x2e0`, or `+0x318` in the visible post-parse path. If this setter is reachable with attacker-controlled auth authority on a live credential, it is the most interesting heap path because the post-aggregate corruption may persist for later credential users/finalizers.

Reachability caveat: `HEAP_SETTER_REACHABILITY_STATIC_NOTES.md` shows the visible direct setter caller is the trust-credential population helper, which fetches `AuthenticationAuthority` for the credential object's own record name/type. Do not conflate that heap setter lead with the already-proven dynamic LDAP user-record auth path until VM breakpoints show the attacker LDAP array reaches the setter.

## Triage Implications

- Direct pointer planting is still unlikely: write values are small integers (`1..10`), not attacker-chosen addresses.
- `object + 0x318` flag corruption is plausible in `create_with_details`, but reaching it requires zero-based index 152, i.e. 153 comma tokens, and crosses pointer fields first.
- The most realistic upgrade path is not immediate PC control. Look for a second-stage effect: small scalar/flag/type corruption that changes later control flow, causes a later controlled copy/free/deref, or makes a finalizer release a low/corrupted field in a useful way.
- VM triage should distinguish faults that happen during parse, immediately after parse, in `_odcredential_create` field fixups, in later credential use, and in `__odcredential_finalize`.

## VM-Only Suggested Order

1. First reproduce low-count auth stack crashes at fake-slot boundaries. The zero-based boundary indexes are `6, 20, 34, 48, 62, 76, 90, 104, 118`; the required token counts are `7, 21, 35, 49, 63, 77, 91, 105, 119`.
2. Then capture post-aggregate stack/heap counts. Zero-based indexes `132..140` require token counts `133..141`.
3. For heap paths, prioritize `_odcredential_set_authentication_authority` breakpoints over ordinary creation paths, because creation paths overwrite some fields after parse. Confirm whether the setter's `x2` array is attacker-controlled; static evidence currently points to a trust-credential population path, not automatically the victim user-record path.
4. For fake slots, use token names that place the intended small type value at the slot type offset: `LocalCachedUser` for 6, `DisabledUser` for 8, `DisabledTags` for 9, and an unknown string for 10.
5. Capture fault address, registers, backtrace, and whether the crash occurs before or after any stack-canary failure.
