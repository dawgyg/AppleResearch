# Draft Apple Security Bounty Report

## Title

Out-of-bounds write in `opendirectoryd` `AuthenticationAuthority` `DisabledTags` parser reachable from sandboxed clients through dynamic LDAP/OpenDirectory nodes

## Summary

`opendirectoryd` parses `dsAttrTypeStandard:AuthenticationAuthority` values in root context. For type `DisabledTags`, the parser splits attacker-controlled auth data on commas and appends one 32-bit enum per token into a fixed inline list that holds six entries. The append loop has no capacity check.

A malicious value such as:

```text
;DisabledTags;ShadowHash,ShadowHash,ShadowHash,...
```

causes writes past the inline `DisabledTags` list. With enough comma tokens, the write corrupts later authority slots and then adjacent stack/object memory. On macOS 26.5.1 25F80, this was dynamically confirmed by crashing root `opendirectoryd`. VM crash analysis shows the corrupted data is later consumed as a C-string pointer by `_find_mechanisms -> CFStringCreateWithCString -> strlen`; repeat marker tests show the consumed pointer value is heap-layout dependent, not reliably token-controlled.

## Affected Version

Tested on:

```text
ProductName:    macOS
ProductVersion: 26.5.1
BuildVersion:   25F80
opendirectoryd: opendirectoryd-966.100.2
```

## Security Impact

This is memory corruption in a root daemon. The dynamic proof shows a stock, sandboxed, non-root client can trigger the crashing parser through an explicit dynamic LDAP node by calling the OpenDirectory API through `/usr/bin/dscl`.

Current impact proven by this package:

- Root `opendirectoryd` memory corruption and crash.
- Root-context corrupted-pointer consumption in `_find_mechanisms -> CFStringCreateWithCString -> strlen`.
- Non-controlled root-context corrupted-pointer dereference: repeat testing showed identical inputs can produce no crash, `far=0x0`, or `far=0x800000000`; changing only the position-11 token did not make the fault address track the token enum.
- Sandbox-reachable trigger through `com.apple.system.opendirectoryd.api`.
- Explicit `/LDAPv3/<host>` dynamic node selection; no persistent host-specific LDAP configuration was present for `/LDAPv3/127.0.0.1` on the test host.
- Network-supplied LDAP record controls the malicious `authAuthority` data.

Current impact not yet proven:

- Privilege escalation.
- Sandbox escape with code execution.
- Arbitrary read/write.
- Freely chosen pointer, reliable pointer-value control, or program-counter control.
- Apple Security Bounty Target Flag capture.

## Root Cause

In `__authauthority_parse_authdata`, when the parsed authority type is `DisabledTags` (`type == 9`), the code zeroes the count and inline list, then loops over comma-delimited tokens:

```text
0x100031bd0  type == 9 branch
0x100031bdc  x21 = slot + 0x18
0x100031bdc  zero [slot+0x18 ... slot+0x37]
0x100031bfc  x22 = slot + 0x20
0x100031c10  token loop over strsep(..., ",")
0x100031c40  count = [slot+0x18]
0x100031c44  str w24, [slot+0x20 + count*4]
0x100031c4c  count++
0x100031c50  store count
```

There is no check that `count < 6` before `str w24, [x22, x8, lsl #2]`.

One authority slot is `0x38` bytes. The `DisabledTags` count is at `slot + 0x18`, and the inline list starts at `slot + 0x20`. Only `0x18` bytes remain, so six `uint32_t` values fit. The seventh token writes beyond the slot.

The companion removal routine uses hardcoded six-entry capacity math, supporting that six entries is the intended capacity.

## Dynamic Proof

Two trigger paths were confirmed.

### Local Record Proof

A disposable local record `_oobprobe_64154` was given an `AuthenticationAuthority` containing `;DisabledTags;` plus hundreds of comma-delimited tokens. A stock authentication path caused `opendirectoryd` to crash and restart. This local setup required root to create the malicious record, so it is not by itself a privilege escalation.

### LDAP Sandbox-Reachability Proof

A local test LDAP server served a malicious user record:

```text
dn: uid=victim,cn=users,dc=evil,dc=test
objectClass: inetOrgPerson
objectClass: posixAccount
objectClass: shadowAccount
objectClass: apple-user
objectClass: extensibleObject
authAuthority: ;DisabledTags;ShadowHash,ShadowHash,...
```

A constrained sandboxed client with no network permission triggered the root daemon crash through the OpenDirectory Mach service using the explicit dynamic node path `/LDAPv3/127.0.0.1`:

```text
sandbox dscl rc=62
od before=77590 runs=11 crashes=10
od after=89292 runs=12 crashes=11 signal=Segmentation fault: 11
<dscl_cmd> DS Error: -14910 (eServerError)
Authentication for node /LDAPv3/127.0.0.1 failed. (-14910, eServerError)
```

The sandbox profile allowed:

```text
(allow process*)
(allow file-read*)
(allow file-map-executable)
(allow mach-lookup (global-name "com.apple.system.opendirectoryd.api"))
(allow sysctl-read)
(allow signal (target self))
```

It did not grant network access; the sandboxed process only reached `opendirectoryd` over the OpenDirectory Mach service.

Follow-up filesystem and static checks showed that `/LDAPv3/127.0.0.1` was not backed by a persistent host-specific LDAP configuration:

```text
/Library/Preferences/OpenDirectory/Configurations/Contacts.plist
/Library/Preferences/OpenDirectory/Configurations/Search.plist
```

The node is instead consistent with the built-in dynamic template:

```text
/System/Library/OpenDirectory/DynamicNodeTemplates/LDAPv3.plist
comment: "Dynamic LDAPv3 node"
enabled: true
template: "Open Directory Server"
```

The `Open Directory Server` template uses the `Open Directory` mapping, which maps `dsAttrTypeStandard:AuthenticationAuthority` for users to LDAP `authAuthority`.

## Reproduction Notes

Do not run this on a primary machine. `opendirectoryd` has `_PanicOnCrash` configured with `PanicOnConsecutiveCrash = true`; repeated daemon crashes may panic the machine.

Use a disposable VM. The package includes the LDAP fixture files and captured evidence. The high-level repro is:

1. Start the provided LDAP fixture serving the malicious `uid=victim,cn=users,dc=evil,dc=test` record.
2. Confirm harmless reads can resolve `/LDAPv3/127.0.0.1 /Users/victim` through the dynamic node path.
3. Run a sandboxed `dscl /LDAPv3/127.0.0.1 -authonly victim wrongpass`.
4. Observe `opendirectoryd` restart and `launchctl` reporting `last terminating signal = Segmentation fault: 11`.

## Evidence Included

- `static_oob_analysis.txt`: disassembly of the vulnerable parser loop.
- `DYNAMIC_LDAP_REACHABILITY.md` and `REACHABILITY_DYNAMIC_NODE.md`: dynamic `/LDAPv3/<host>` reachability evidence and current caveats.
- `AUTH_PATH_PRIMITIVE_MAP.md`: stack overwrite offset map and VM-only exploitability follow-up plan.
- `FIND_MECHANISMS_POINTER_OFFSET_STATIC_NOTES.md` and `FIND_MECHANISMS_POSITION10_NONCONTROL_NOTES.md`: `_find_mechanisms` consumed-pointer offset map and the non-deterministic marker-correlation correction.
- `vm_dynamic_evidence/DYNAMIC_CRASH_ANALYSIS.md`: VM-native crash and marker-sweep summary.
- `EXPLOITABILITY_TRIAGE.md`: static triage of stack/object layouts and current LPE status.
- `system_version.txt`: host and binary version.
- `opendirectoryd_SIGSEGV_log_evidence.txt`: launchd SIGSEGV lines.
- `network_ldap_sandbox_20260611T1938EDT/`: LDAP fixture, sandbox trigger output, launchctl state, and victim LDAP entry.

## Reporter Assessment

This should be treated as a root-daemon memory-corruption vulnerability with sandbox-reachable parsing through dynamic LDAP node selection. It should not yet be labeled as a confirmed privilege escalation with code execution unless additional exploitability work demonstrates control of execution, arbitrary read/write, or an Apple Security Bounty Target Flag.
