# find_mechanisms Position-10/11 Non-Control Notes

Date: 2026-06-12
Source: user/Claude-reported VM marker sweep plus later determinism re-test.

## Bottom line

The static offset map is still useful: for the first fake authority slot reached
by a `DisabledTags` overflow, zero-based token index `10` lands on the low dword
of the `_find_mechanisms` `slot+0x10` C-string pointer field, and token index
`11` lands on the high dword.

The control interpretation is invalidated. The early single-sample marker runs
looked like position-specific pointer influence:

```text
mk8@10 -> x0 = 0x100000008
          x20 = 0x100000008
p11 -> far = 0x800000000
       x1  = 0x800000000
```

Repeated runs did not reproduce that relationship. With identical input
(`DisabledUser` at position `11`, count `64`), runs produced no crash,
`far=0x800000000`, and `far=0x0`. Varying only the position-11 token also failed
to make the fault address track the token enum: `ShadowHash` produced `far=0x0`
instead of the expected `0x100000000`, while `Kerberosv5`, `AppleID`, and
`DisabledUser` produced no crash in the later pass.

Conclusion: attacker token bytes sometimes appear in the consumed pointer, but
the value is heap-layout dependent and not reproducible. This is a
non-controlled corrupted-pointer dereference in root context, not deterministic
per-position pointer control and not a controllable target/aim primitive.

## Register-frame caveat

Be careful with register names across frames.

At the `_find_mechanisms` call site:

```text
0x10000548c  ldr x1, [x22]             ; cStr pointer at slot+0x10
0x100005490  x0 = allocator
0x100005498  CFStringCreateWithCString(allocator, cStr, 0x600)
```

At the later `_platform_strlen` crash frame, `x0` can be the C-string pointer
being measured by `strlen`, and `x20` can be a callee/local copy inside
CoreFoundation. So `x0=0x100000008` in a `.ips` sample does not necessarily mean
the original `CFAllocatorRef` argument was overwritten.

## What remains solid

- The `DisabledTags` parser writes past the six-entry inline list with no bounds
  check.
- The low-count boundary is repeatable: six tokens stay in bounds; eight or more
  crashed in the VM sweep. The seventh token is already OOB but was nonfatal in
  the observed sweep.
- The crash site is consistently `_find_mechanisms -> CFStringCreateWithCString
  -> _platform_strlen`.
- The crash is a root-context dereference of a corrupted pointer after the OOB
  write is consumed by a later authority-slot scanner.
- Dynamic LDAP node reachability makes the root crash triggerable from an
  unprivileged/sandboxed client path.

## Not supported

Do not claim:

```text
deterministic index-10 or index-11 control of the consumed pointer
full low+high cStr composition in one captured crash
arbitrary address control
controllable target/aim
PC control
code execution
Target Flag write/capture
```

The remaining exploitability upgrade lane is separate: prove a persistent
second-stage effect, such as the heap `OS_od_credential` setter/finalizer path or
a trusted-count consumer reached through `PlistFile`, using repeated VM evidence.
