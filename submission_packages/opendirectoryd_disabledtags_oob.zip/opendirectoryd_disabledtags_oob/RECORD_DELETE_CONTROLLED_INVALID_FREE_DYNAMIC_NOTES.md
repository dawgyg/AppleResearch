# RecordDelete Controlled Invalid-Free Dynamic Notes

Date: 2026-06-12T0347Z
Scope: Claude-reported VM dynamic result plus Codex static mapping. Codex did not
run host OpenDirectory, LDAP, `dscl`, lldb, or VM dynamic triggers for this note.

## Bottom Line

The PlistFile `RecordDelete` lane has now produced a stronger crash class than
the earlier `_find_mechanisms` C-string dereference:

```text
___BUG_IN_CLIENT_OF_LIBMALLOC_POINTER_BEING_FREED_WAS_NOT_ALLOCATED
opendirectoryd  _odauthauthority_free_contents
opendirectoryd  _odauthauthorities_free_contents
PlistFile       _plistfile_attrs_is_sepCredentialUser
PlistFile       _plistfile_last_sepCredentialUser
PlistFile       _odm_RecordDelete
opendirectoryd  _odrequest_api_process
```

Claude's crash log reported:

```text
opendirectoryd malloc: *** error for object 0x800000008:
pointer being freed was not allocated
```

That pointer value is token-composed attacker data. A toxic authority record
with `DisabledTags` index `6 == SecureToken` creates a fake type-4 authority
slot. Setting indexes `10 == DisabledUser` and `11 == DisabledUser` composes
the first fake-slot pointer field as:

```text
slot+0x10 = 0x00000008_00000008 = 0x800000008
```

Cleanup then calls `free(0x800000008)` in root `opendirectoryd`.

This is a controlled invalid-free primitive. It is materially stronger than a
NULL/low C-string dereference, but it is not yet a weaponized UAF or arbitrary
free because each pointer dword is still limited to the small auth-tag enum
range.

Evidence artifacts currently banked in this package:

```text
vm_dynamic_evidence/malloc_error_freed_pointer.txt
vm_dynamic_evidence/opendirectoryd_controlled_free_0x800000008.ips
```

## Why This Lane Fires

The relevant `PlistFile.bundle` predicate parses the record's
`AuthenticationAuthority` into a stack aggregate, calls SEP-user policy logic,
and then always frees the aggregate:

```text
0x8c70  __plistfile_attrs_is_sepCredentialUser
0x8ca8    bzero(sp+0x8, 0x238)
0x8e34    x0 = sp+0x8
0x8e38    _odauthauthorities_parse(...)
0x8e40    x0 = sp+0x8
0x8e50    __plistfile_is_sepCredentialUser(...)
0x8ef0    x0 = sp+0x8
0x8ef4    _odauthauthorities_free_contents(...)
```

`_odauthauthorities_free_contents` iterates all ten fixed slots in the
`0x238`-byte aggregate. It skips only slots whose type dword is zero:

```text
0x1000322d4  _odauthauthorities_free_contents
0x1000322e4    x19 = aggregate
0x1000322e8    x20 = 0x8
0x1000322ec    w8 = [aggregate+x20]
0x1000322f0    if w8 == 0 skip
0x1000322f4    x0 = aggregate+x20
0x1000322f8    _odauthauthority_free_contents(slot)
0x1000322fc    x20 += 0x38
0x100032300    loop until x20 == 0x238
```

So the fake slot does not need `_odauthauthorities_remove(type=4)` to select it.
It only needs a nonzero fake-slot type. In the confirmed crash, index `6`
provided `SecureToken` (`4`), which is also enough to satisfy the relevant
SEP-user type search before cleanup.

`_odauthauthority_free_contents` frees the generic pointer fields:

```text
0x10003163c  x0 = [slot+0x10]
0x100031644  free(x0) if non-null
0x100031648  x0 = [slot+0x08]
0x100031650  free(x0) if non-null
0x100031654  w8 = [slot+0x00]
...
0x1000316c0  x0 = [slot+0x18]
0x1000316c8  free(x0) for generic type branch if non-null
```

The first observed abort is the `slot+0x10` free, controlled by token indexes
`10` and `11`.

## Fake Slot Map

For a first parsed `DisabledTags` authority in slot 0:

```text
aggregate base        = A
slot 0 base           = A + 0x08
DisabledTags list     = A + 0x28
token index n writes  = A + 0x28 + 4*n
first fake slot base  = A + 0x40
```

First fake slot fields:

```text
index 6       -> fake slot type dword
index 8/9     -> fake slot+0x08 pointer low/high dwords
index 10/11   -> fake slot+0x10 pointer low/high dwords
index 12/13   -> fake slot+0x18 pointer low/high dwords
```

Observed controlled-free pattern:

```text
index 6  = SecureToken   ; fake type 4
index 10 = DisabledUser  ; low dword 8
index 11 = DisabledUser  ; high dword 8
free(0x800000008)
```

Additional deterministic classification tests:

```text
Change indexes 10/11 to other valid tags and confirm malloc reports:
  0x0000000H_0000000L

Set index 10/11 to Unknown tokens and confirm:
  0x0000000a_0000000a

Set index 10 or 11 to omitted/zero if possible and confirm whether cleanup
falls through to the next fake pointer field at indexes 8/9 or 12/13.
```

## Trigger And Privilege Notes

The confirmed stack is `RecordDelete`, not the earlier speculative `passwd`
classification:

```text
0x164ec  _odm_RecordDelete
0x165b8    __session_has_privilege(...)
0x16698    _securetoken_helpers_context_is_valid(...)
0x166a8    __plistfile_last_sepCredentialUser(...)
```

The static gate shows `RecordDelete` has privilege and sandbox checks before
the operation proceeds:

```text
0x165b8  __session_has_privilege
0x16664  continue only if privilege gate permits
0x166f8  sandbox_check_by_audit_token("opendirectory-user-modify")
```

Therefore the `RecordDelete` dynamic result proves root-daemon controlled
invalid free, not non-admin LPE by itself. The reachability tier has now been
upgraded by the separate `HasSecureToken` result:

```text
uid=501 (non-root)
  -> ODNodeCustomFunction("HasSecureToken", { "Recordname": victim })
  -> root opendirectoryd free(0x800000008)
```

That proves non-root trigger of the same cleanup/free consumer for an
already-toxic local record. The remaining LPE question is whether a non-root
attacker can place or supply the toxic `AuthenticationAuthority` record, and
whether the enum-composed invalid free can be converted into a valid heap
corruption/code-execution primitive.

The tier still depends on proof showing either:

```text
1. an unprivileged client can create/prefill a toxic local record and invoke a
   read-style cleanup path such as `HasSecureToken`, or
2. the same cleanup consumer is reachable through the already-proven
   unprivileged dynamic LDAP/OpenDirectory node path, or
3. a second-stage allocator effect turns the enum-composed invalid free into a
   valid free/UAF or code-execution primitive.
```

## Exploitability Calibration

Safe current claim:

```text
A malicious AuthenticationAuthority value can create a fake auth-authority
slot. During PlistFile RecordDelete SEP-user evaluation, root opendirectoryd
frees a pointer field from that fake slot. The freed pointer value is
attacker-composed from DisabledTags token enum dwords; the VM observed a
deterministic free(0x800000008).
```

Do not yet claim:

```text
valid heap-pointer free
arbitrary free
weaponized UAF
code execution
privilege escalation through RecordDelete
Target Flag capture
```

The honest limitation is value range. Current parser writes are chosen from
small auth-token enum values, generally `1..10`. That is enough to prove control
of the freed qword and root-context heap corruption, but not enough by itself to
free a normal heap allocation address on arm64e macOS.

## Immediate VM Asks

Already banked:

```text
full .ips crash report for the controlled-free crash
three ReportCrash malloc lines showing free(0x800000008)
```

If rerunning, additionally capture:

```text
crashed-thread backtrace with image offsets
register state at abort/free if present
exact triggering command and whether it was sudo/root/non-root
exact toxic token sequence
```

Then test only in disposable VM snapshots:

```text
1. Token-control sweep over indexes 10/11 to show the malloc bad object tracks
   the chosen enum dwords.
2. Privilege matrix for local-node prefill plus RecordDelete:
   root, admin, same unprivileged user, sandboxed same user.
3. Search for a non-delete PlistFile path that calls
   _odauthauthorities_free_contents on attacker-authored authority data after
   only unprivileged operations.
4. Re-check dynamic LDAP path for any cleanup frame that reaches
   _odauthauthorities_free_contents before _find_mechanisms crashes.
```

Static follow-up found concrete read/auth-style probes for item 3:

```text
ODNodeCustomFunction("HasSecureToken", {"Recordname": toxic_user})
ODRecordAuthenticationAllowed(toxic_user_record)
ODRecordCopyEffectivePolicies(toxic_user_record)
```

See `READ_STYLE_CLEANUP_CONSUMER_STATIC_NOTES.md`.

## Relationship To Earlier Static Notes

This dynamic result is adjacent to, but distinct from,
`WHOLE_SLOT_REMOVE_FAKE_FREE_STATIC_NOTES.md`.

The earlier whole-slot note covers:

```text
_odauthauthorities_remove(type=4/5)
  -> _odauthauthority_free_contents(fake selected slot)
```

The confirmed `RecordDelete` result covers:

```text
_plistfile_attrs_is_sepCredentialUser
  -> _odauthauthorities_free_contents(all nonzero slots)
  -> _odauthauthority_free_contents(fake nonzero slot)
```

Both consume the same fake-slot pointer fields, but the confirmed path is the
aggregate cleanup path after SEP-user predicate evaluation.
