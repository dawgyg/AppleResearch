# Reachability upgrade: dynamic LDAPv3 node => NO admin precondition

CONFIRMED (static + safe dynamic, no crash):
- /System/Library/OpenDirectory/DynamicNodeTemplates/LDAPv3.plist = "Dynamic LDAPv3 node",
  template "Open Directory Server" (which maps dsAttrTypeStandard:AuthenticationAuthority -> LDAP authAuthority).
- At test time there were NO configured LDAP nodes (/Library/Preferences/OpenDirectory/Configurations/LDAPv3/ empty),
  so the /LDAPv3/127.0.0.1 access used by the proven crashes was a DYNAMIC node, created without dsconfigldap/admin.
- Non-root `dscl /LDAPv3/127.0.0.1 -read /Users/victim` (as user dawgyg) ran WITHOUT eDSPermissionError
  (empty result = server mapping gap, not an auth/privilege denial). Dynamic-node connection is permitted for non-root.

IMPLICATION:
- An unprivileged / sandboxed process (sandbox allows com.apple.system.opendirectoryd.api) can do
  ODNodeCreateWithName("/LDAPv3/<attacker-host>") and OD connects to the attacker's LDAP with the
  Open Directory Server template, fetches the record's authAuthority, and parses it (-authonly / verify),
  reaching __authauthority_parse_authdata with NO admin binding and NO local root.
- => pure unprivileged/sandbox -> root memory corruption (the admin precondition is removed).

REMAINING TO FULLY NAIL (non-crashing, needs the rig's server mapping):
- Confirm a non-root client RESOLVES victim via the dynamic node end-to-end (server must serve the
  ou=macosxodconfig mapping + apple-user record per Codex's LDAP_TRANSCRIPT_AND_MAPPING.md).
- Then (VM-only, panic-safe) classify the auth-path crash and second-stage
  consumers. Repeat testing did not prove register/PC control; current upgrade
  gates are heap setter reachability, heap setter post-aggregate field
  consumers, trusted-count consumers, PlistFile helper lanes, selected fake-slot
  finalization, and the disabledtag false-positive gate documented in
  `DISABLEDTAG_FALSE_POSITIVE_LOGIC_GADGET_STATIC_NOTES.md`.
- Separate VM work has now confirmed a PlistFile `RecordDelete` cleanup lane:
  `_plistfile_attrs_is_sepCredentialUser` reaches
  `_odauthauthorities_free_contents`, which frees an enum-composed fake-slot
  pointer (`0x800000008` with DisabledUser at indexes 10/11). This is stronger
  heap-corruption evidence, but its demonstrated trigger has RecordDelete
  privilege/sandbox gates and is not yet the unprivileged dynamic LDAP path.
