# Dynamic LDAP Reachability Notes

Date: 2026-06-11
Host: macOS 26.5.1 25F80

## Bottom Line

The explicit node path `/LDAPv3/<host>` is not limited to persistently configured LDAP nodes. On this host, `/LDAPv3/127.0.0.1` was reachable without a host-specific LDAP configuration file, consistent with `opendirectoryd` dynamically creating the node from Apple's built-in dynamic LDAPv3 template.

This removes the earlier "admin must configure the malicious LDAP node" caveat for the explicit-node trigger path.

## Filesystem State

No host-specific LDAP configuration was present in the writable configuration locations:

```text
$ find /Library/OpenDirectory/Configurations /Library/Preferences/OpenDirectory/Configurations -maxdepth 4 -type f -print 2>/dev/null | sort
/Library/Preferences/OpenDirectory/Configurations/Contacts.plist
/Library/Preferences/OpenDirectory/Configurations/Search.plist
```

The system configuration and dynamic template files are present:

```text
/System/Library/OpenDirectory/Configurations/LDAPv3.plist
/System/Library/OpenDirectory/DynamicNodeTemplates/LDAPv3.plist
```

## Dynamic Template

`/System/Library/OpenDirectory/DynamicNodeTemplates/LDAPv3.plist`:

```text
comment: "Dynamic LDAPv3 node"
enabled: true
locked: true
template: "Open Directory Server"
module options:
  AppleODClient:
    Server Mappings: true
```

`/System/Library/OpenDirectory/Templates/Open Directory Server.plist`:

```text
description: "Open Directory Server Node"
mappings:
  template: "Open Directory"
modules:
  authentication:
    AppleODClientLDAP
    AppleODClientPWS
  default:
    ldap
  discovery:
    AppleODClientLDAP
    AppleODClientPWS
```

`/System/Library/OpenDirectory/Mappings/Open Directory.plist` maps users' standard authentication authority to LDAP `authAuthority`:

```text
recordtypes:
  dsRecTypeStandard:Users:
    attributetypes:
      dsAttrTypeStandard:AuthenticationAuthority:
        native: "authAuthority"
    info:
      Search Base: "cn=users, %!"
```

## Static Daemon Path

Relevant strings in `/usr/libexec/opendirectoryd`:

```text
ODNodeCreateWithName
ODNodeCreateWithNameAndOptions
Using dynamic node for lookup of '%{public}@'
/System/Library/OpenDirectory/DynamicNodeTemplates/
/System/Library/OpenDirectory/Templates/%@.plist
/Library/OpenDirectory/Templates/%@.plist
```

`_odnodeconfig_create_dynamic` constructs a path under `/System/Library/OpenDirectory/DynamicNodeTemplates/`, falls back to `/Library/OpenDirectory/Configurations/`, and then loads/clones a node configuration:

```text
0x10003d260  "/System/Library/OpenDirectory/DynamicNodeTemplates/"
0x10003d2cc  _od_cstr_from_cfstring
0x10003d2d4  _lstat
0x10003d2e8  _odnodeconfig_create
0x10003d324  __odnodeconfig_load_if_necessary
0x10003d368  _odnodeconfig_create_clone
0x10003d410  _odnodeconfig_apply_moduleconfigs
```

No Authorization framework calls are visible in this dynamic creation path. By contrast, persistent configuration writes expose the expected configure-right surface:

```text
system.services.directory.configure
AuthorizationCreateFromExternalForm
AuthorizationCopyRights
/Configure
```

## Reachability Claim

Precise claim for the report:

An unprivileged/sandboxed client can select an explicit dynamic LDAP node name such as `/LDAPv3/127.0.0.1`. `opendirectoryd` dynamically materializes that node using the system LDAPv3 dynamic template and Open Directory mapping, then fetches/parses `authAuthority` from the network-supplied user record during authentication.

This proves a sandbox/unprivileged client can feed attacker-controlled `AuthenticationAuthority` data into root `opendirectoryd` without first installing a persistent LDAP configuration.

