# DisabledTags Unknown-Token Serializer Static Notes

Date: 2026-06-12
Binary: `/usr/libexec/opendirectoryd`, `opendirectoryd-966.100.2`
Scope: static-only follow-up for a `DisabledTags` parser/serializer validation
mismatch that does not require an overfull token count.

## Bottom line

The `DisabledTags` parser accepts an unknown token by storing fallback enum value
`10`. The type-9 serializer later assumes every stored value is in the valid
range `1..9`, subtracts one, and indexes the nine-entry
`ODAuthAuthorityStrings` table.

For a single unknown token, `10 - 1 == 9`, so the serializer reads one entry past
the nine-token table. The next table slot is NULL in the inspected binary, so
the expected effect is a NULL C-string pointer passed to `__strlcat_chk` if a VM
path serializes the parsed authority.

This is a separate static lead from the overfull-count OOB write. It needs VM
reachability evidence before it should be described as a live bug.

## Parser accepts and stores fallback 10

In the type-9 `DisabledTags` path inside `__authauthority_parse_authdata`, each
comma-delimited token starts with fallback value `0xa`. The code compares the
input token against nine known auth strings; if none matches, `w24` remains
`0xa` and is still stored in the inline list.

Relevant instructions:

```text
0x100031c1c  mov w24, 0xa              ; fallback for unknown token
0x100031c20  ldr x0, [x23, x25, lsl 3] ; known-token table
0x100031c28  strcmp(known, token)
0x100031c2c  add x25, x25, 1
0x100031c34  csel w24, w25, w24, eq    ; known match -> 1..9
0x100031c38  cmp x25, 9
0x100031c3c  b.ne loop
0x100031c40  ldr x8, [x21]             ; count
0x100031c44  str w24, [x22, x8, lsl 2] ; stores 10 if no match
0x100031c4c  add x8, x8, 1
0x100031c50  str x8, [x21]
```

So an authority such as:

```text
;DisabledTags;NotARealAuthType
```

should parse to a valid type-9 slot with `count == 1` and `list[0] == 10`.

## Serializer assumes entries are 1..9

The type-9 branch in `_odauthauthority_attribute_create` checks that count is
at least one, but it does not validate each stored entry value before indexing
the string table.

Relevant instructions:

```text
0x100031228  ldr x8, [x19+0x18]        ; count
0x10003122c  cmp x8, 1
0x10003123c  x23 = x19 + 0x20          ; list base
0x100031240  x24 = ODAuthAuthorityStrings
0x100031250  ldr w9, [x23, i, lsl 2]   ; entry
0x100031254  sub w9, w9, 1
0x100031258  ldr x21, [x24, w9, uxtw 3]
0x100031274  strlcat(buffer, x21, ...)
```

The table has nine known auth-token entries followed by NULL:

```text
0x100081130  ShadowHash
0x100081138  ApplePasswordServer
0x100081140  Kerberosv5
0x100081148  SecureToken
0x100081150  OTI
0x100081158  LocalCachedUser
0x100081160  AppleID
0x100081168  DisabledUser
0x100081170  DisabledTags
0x100081178  NULL
```

For stored value `10`, the serializer indexes entry `9`, loads NULL into `x21`,
and passes it as the source C string to `__strlcat_chk`.

## Static xrefs

Known static xrefs to `_odauthauthorities_attribute_create` in
`opendirectoryd`:

```text
___odcredential_copy_details_block_invoke 0x10003455c
__create_connection_with_options          0x100058f7c
```

`PlistFile.bundle` also imports `odauthauthorities_attribute_create` for local
record paths.

## VM gates

VM-only validation target:

```text
AuthenticationAuthority: ;DisabledTags;NotARealAuthType
```

Useful observations:

```text
slot type is 9
slot+0x18 count is 1
list[0] is 10
_odauthauthority_attribute_create reaches 0x100031258
w9 after subtract is 9
x21 loaded from table entry 9 is NULL
__strlcat_chk is reached with x1 == NULL
```

This can be tested independently from the overfull-count crash. Any VM proof
should still use stock client reachability and should avoid host-side
OpenDirectory triggers.

## Do not overclaim

Safe wording:

```text
Static review found a DisabledTags parser/serializer validation mismatch:
unknown tokens are accepted as value 10, while serialization assumes entries are
1..9 and can pass NULL to strlcat if serialization is reachable.
```

Unsafe wording until VM evidence exists:

```text
unknown DisabledTags token is a proven sandboxed crash
unknown token gives LPE
unknown token reaches odcredential_copy_details from LDAP
```
