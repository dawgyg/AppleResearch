#include <errno.h>
#include <mach/mach.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

enum {
    MAX_MESSAGE_SIZE = 4096,
    DEFAULT_QUEUE_LIMIT = 1024,
};

static unsigned long
parse_unsigned(const char *text, const char *name)
{
    char *end = NULL;
    unsigned long value;

    errno = 0;
    value = strtoul(text, &end, 0);
    if (errno != 0 || text[0] == '\0' || end == NULL || *end != '\0') {
        fprintf(stderr, "invalid %s: %s\n", name, text);
        exit(2);
    }
    return value;
}

static int
file_contains(const char *path, const char *needle)
{
    char line[1024];
    FILE *file = fopen(path, "r");

    if (file == NULL) {
        return 0;
    }
    while (fgets(line, sizeof(line), file) != NULL) {
        if (strstr(line, needle) != NULL) {
            fclose(file);
            return 1;
        }
    }
    fclose(file);
    return 0;
}

int
main(int argc, char **argv)
{
    unsigned long message_size = argc > 1 ?
        parse_unsigned(argv[1], "message size") : 128;
    unsigned long count = argc > 2 ?
        parse_unsigned(argv[2], "message count") : 64;
    unsigned long delay_us = argc > 3 ?
        parse_unsigned(argv[3], "delay") : 0;
    unsigned long hold_ms = argc > 4 ?
        parse_unsigned(argv[4], "hold time") : 1000;
    unsigned long marker = argc > 5 ?
        parse_unsigned(argv[5], "marker") : 0x434f4445UL;
    const char *wait_path = argc > 6 ? argv[6] : NULL;
    const char *wait_marker = argc > 7 ? argv[7] : "crypt_begin";
    mach_port_limits_t limits = {
        .mpl_qlimit = DEFAULT_QUEUE_LIMIT,
    };
    mach_port_t port = MACH_PORT_NULL;
    uint8_t *message;
    mach_msg_header_t *header;
    kern_return_t kr;
    unsigned long sent = 0;

    if (message_size < sizeof(*header) ||
        message_size > MAX_MESSAGE_SIZE ||
        count == 0 || count > DEFAULT_QUEUE_LIMIT ||
        delay_us > 10000000UL || hold_ms > 60000UL) {
        fprintf(stderr, "arguments out of range\n");
        return 2;
    }

    message = calloc(1, message_size);
    if (message == NULL) {
        perror("calloc");
        return 1;
    }
    for (size_t offset = sizeof(*header);
        offset + sizeof(uint32_t) <= message_size;
        offset += sizeof(uint32_t)) {
        uint32_t word = (uint32_t)marker ^
            (uint32_t)(offset - sizeof(*header));
        memcpy(message + offset, &word, sizeof(word));
    }

    kr = mach_port_allocate(mach_task_self(), MACH_PORT_RIGHT_RECEIVE,
        &port);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "mach_port_allocate: %s\n",
            mach_error_string(kr));
        free(message);
        return 1;
    }
    kr = mach_port_insert_right(mach_task_self(), port, port,
        MACH_MSG_TYPE_MAKE_SEND);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "mach_port_insert_right: %s\n",
            mach_error_string(kr));
        mach_port_destruct(mach_task_self(), port, 0, 0);
        free(message);
        return 1;
    }
    kr = mach_port_set_attributes(mach_task_self(), port,
        MACH_PORT_LIMITS_INFO, (mach_port_info_t)&limits,
        MACH_PORT_LIMITS_INFO_COUNT);
    if (kr != KERN_SUCCESS) {
        fprintf(stderr, "mach_port_set_attributes: %s\n",
            mach_error_string(kr));
        mach_port_destruct(mach_task_self(), port, 0, 0);
        free(message);
        return 1;
    }

    header = (mach_msg_header_t *)message;
    header->msgh_bits = MACH_MSGH_BITS(MACH_MSG_TYPE_COPY_SEND, 0);
    header->msgh_size = (mach_msg_size_t)message_size;
    header->msgh_remote_port = port;
    header->msgh_local_port = MACH_PORT_NULL;
    header->msgh_voucher_port = MACH_PORT_NULL;

    if (wait_path != NULL) {
        unsigned long polls;

        for (polls = 0; polls < 120000UL; polls++) {
            if (file_contains(wait_path, wait_marker)) {
                break;
            }
            usleep(500);
        }
        if (polls == 120000UL) {
            fprintf(stderr, "timed out waiting for %s in %s\n",
                wait_marker, wait_path);
            mach_port_destruct(mach_task_self(), port, 0, 0);
            free(message);
            return 1;
        }
    }
    if (delay_us != 0) {
        usleep((useconds_t)delay_us);
    }
    for (unsigned long i = 0; i < count; i++) {
        header->msgh_id = (mach_msg_id_t)(marker + i);
        kr = mach_msg(header, MACH_SEND_MSG | MACH_SEND_TIMEOUT,
            header->msgh_size, 0, MACH_PORT_NULL, 0, MACH_PORT_NULL);
        if (kr != MACH_MSG_SUCCESS) {
            fprintf(stderr, "mach_msg[%lu]: %s\n", i,
                mach_error_string(kr));
            break;
        }
        sent++;
    }

    printf("port=%u message_size=%lu sent=%lu marker=0x%08lx\n",
        port, message_size, sent, marker & UINT32_MAX);
    fflush(stdout);
    if (hold_ms != 0) {
        usleep((useconds_t)(hold_ms * 1000UL));
    }
    mach_port_destruct(mach_task_self(), port, 0, 0);
    free(message);
    return sent == count ? 0 : 1;
}
