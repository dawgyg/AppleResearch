#!/usr/sbin/dtrace -s

#pragma D option quiet

dtrace:::BEGIN
{
	printf("%llu trace_begin\n", (uint64_t)walltimestamp);
}

fbt:*:gss_krb5_destroy_context:entry
{
	printf("%llu destroy_enter tid=%d old=%p\n",
	    (uint64_t)walltimestamp, tid, arg0);
}

fbt:*:gss_krb5_destroy_context:return
{
	printf("%llu destroy_return tid=%d\n",
	    (uint64_t)walltimestamp, tid);
}

fbt:*:gss_krb5_make_context:entry
{
	printf("%llu make_enter tid=%d lucid=%p len=%u\n",
	    (uint64_t)walltimestamp, tid, arg0, (uint32_t)arg1);
}

fbt:*:gss_krb5_make_context:return
{
	printf("%llu make_return tid=%d new=%p\n",
	    (uint64_t)walltimestamp, tid, arg1);
}

fbt:*:cc_key_schedule_create:entry
{
	printf("%llu crypto_use tid=%d cctx=%p\n",
	    (uint64_t)walltimestamp, tid, arg0);
}

fbt:*:krb5_crypt_mbuf:entry
{
	printf("%llu crypt_mbuf tid=%d cctx=%p len=%llu encrypt=%d\n",
	    (uint64_t)walltimestamp, tid, arg0, (uint64_t)arg2,
	    (int)arg3);
}
