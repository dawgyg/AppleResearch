#!/usr/sbin/dtrace -s

#pragma D option quiet
#pragma D option dynvarsize=32m
#pragma D option switchrate=1ms

dtrace:::BEGIN
{
	freed_schedule_1 = 0;
	freed_schedule_2 = 0;
	schedule_state_1 = 0;
	schedule_state_2 = 0;
	token_size_1 = 0;
	token_size_2 = 0;
	active_schedule_1 = 0;
	active_schedule_2 = 0;
	crypt_seen_schedule = 0;
	crypt_calls = 0;
	last_crypt_time = 0;
	printf("%llu trace_begin\n", (uint64_t)walltimestamp);
}

fbt:*:gss_crypto_ctx_free:entry
{
	self->in_crypto_free = 1;
}

fbt:mach_kernel:kfree_ext:entry
/self->in_crypto_free && arg2 == 244/
{
	if (freed_schedule_1 == 0 || freed_schedule_1 == arg1) {
		freed_schedule_1 = arg1;
		schedule_state_1 = 1;
		schedule_free_time_1 = walltimestamp;
	} else {
		freed_schedule_2 = arg1;
		schedule_state_2 = 1;
		schedule_free_time_2 = walltimestamp;
	}
	printf("%llu schedule_free tid=%d ptr=%p active=%d\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    arg1 == active_schedule_1 || arg1 == active_schedule_2);
	if (arg1 == crypt_seen_schedule) {
		printf("%llu schedule_free_timing ptr=%p calls=%llu since_last_ns=%llu\n",
		    (uint64_t)walltimestamp, arg1, (uint64_t)crypt_calls,
		    (uint64_t)(walltimestamp - last_crypt_time));
	}
}

fbt:*:gss_crypto_ctx_free:return
/self->in_crypto_free/
{
	self->in_crypto_free = 0;
}

fbt:mach_kernel:kfree_ext:entry
/((arg1 == freed_schedule_1 && arg2 == token_size_1) ||
   (arg1 == freed_schedule_2 && arg2 == token_size_2)) &&
  ((arg1 == freed_schedule_1 &&
    (schedule_state_1 == 2 || schedule_state_1 == 3)) ||
   (arg1 == freed_schedule_2 &&
    (schedule_state_2 == 2 || schedule_state_2 == 3)))/
{
	if (arg1 == freed_schedule_1) {
		schedule_state_1 = 4;
	} else {
		schedule_state_2 = 4;
	}
	printf("%llu token_free tid=%d ptr=%p active=%d\n",
	    (uint64_t)walltimestamp, tid, arg1,
	    arg1 == active_schedule_1 || arg1 == active_schedule_2);
}

fbt:*:ipc_kmsg_alloc:entry
/(freed_schedule_1 != 0 || freed_schedule_2 != 0) &&
  execname == "mach_kmsg_spray"/
{
	self->in_kmsg_alloc = 1;
}

fbt:*:nfs_gss_svc_ctx_init:entry
{
	self->in_nfs_svc_init = 1;
}

fbt:mach_kernel:kalloc_ext:entry
/freed_schedule_1 != 0 && arg1 > 128 && arg1 <= 256/
{
	self->tracked_allocation = 1;
	self->allocation_size = arg1;
	self->allocation_caller = caller;
	self->allocation_is_kmsg = self->in_kmsg_alloc;
	self->allocation_is_nfs_token = self->in_nfs_svc_init &&
	    arg1 >= 220 && arg1 <= 240;
}

fbt:mach_kernel:kalloc_ext:return
/self->tracked_allocation &&
  (arg1 == freed_schedule_1 || arg1 == freed_schedule_2)/
{
	this->old_state = arg1 == freed_schedule_1 ?
	    schedule_state_1 : schedule_state_2;
	this->active = arg1 == active_schedule_1 ||
	    arg1 == active_schedule_2;
	if (self->allocation_is_nfs_token &&
	    (this->old_state == 1 || this->old_state == 4)) {
		if (arg1 == freed_schedule_1) {
			schedule_state_1 = 2;
			token_size_1 = self->allocation_size;
		} else {
			schedule_state_2 = 2;
			token_size_2 = self->allocation_size;
		}
		printf("%llu token_reclaim tid=%d ptr=%p size=%llu old_state=%d active=%d\n",
		    (uint64_t)walltimestamp, tid, arg1,
		    (uint64_t)self->allocation_size, this->old_state,
		    this->active);
	} else if ((this->old_state == 1 || this->old_state == 4) &&
	    execname == "mach_kmsg_spray" && self->allocation_is_kmsg) {
		if (arg1 == freed_schedule_1) {
			schedule_state_1 = 5;
		} else {
			schedule_state_2 = 5;
		}
		printf("%llu controlled_kmsg_reclaim tid=%d ptr=%p size=%llu old_state=%d active=%d caller=%a\n",
		    (uint64_t)walltimestamp, tid, arg1,
		    (uint64_t)self->allocation_size, this->old_state,
		    this->active, self->allocation_caller);
	} else {
		if (arg1 == freed_schedule_1) {
			schedule_state_1 = 0;
			freed_schedule_1 = 0;
		} else {
			schedule_state_2 = 0;
			freed_schedule_2 = 0;
		}
		printf("%llu schedule_overwrite tid=%d exec=%s ptr=%p size=%llu old_state=%d active=%d caller=%a\n",
		    (uint64_t)walltimestamp, tid, execname, arg1,
		    (uint64_t)self->allocation_size, this->old_state,
		    this->active, self->allocation_caller);
	}
}

fbt:mach_kernel:kalloc_ext:return
/self->tracked_allocation/
{
	self->tracked_allocation = 0;
	self->allocation_caller = 0;
	self->allocation_is_kmsg = 0;
	self->allocation_is_nfs_token = 0;
}

fbt:*:ipc_kmsg_alloc:return
/self->in_kmsg_alloc/
{
	self->in_kmsg_alloc = 0;
}

fbt:*:nfs_gss_svc_ctx_init:return
/self->in_nfs_svc_init/
{
	self->in_nfs_svc_init = 0;
}

fbt:*:nfs_gss_mach_vmcopyout:entry
/((arg2 == freed_schedule_1 && schedule_state_1 == 2) ||
   (arg2 == freed_schedule_2 && schedule_state_2 == 2))/
{
	self->token_fill = arg2;
}

fbt:*:nfs_gss_mach_vmcopyout:return
/self->token_fill/
{
	if (self->token_fill == freed_schedule_1 &&
	    schedule_state_1 == 2) {
		schedule_state_1 = 3;
	} else if (self->token_fill == freed_schedule_2 &&
	    schedule_state_2 == 2) {
		schedule_state_2 = 3;
	}
	printf("%llu token_fill_return tid=%d ptr=%p error=%d active=%d q0=%016llx q1=%016llx q2=%016llx q3=%016llx q4=%016llx q5=%016llx q6=%016llx q7=%016llx\n",
	    (uint64_t)walltimestamp, tid, self->token_fill, (int)arg1,
	    self->token_fill == active_schedule_1 ||
	    self->token_fill == active_schedule_2,
	    *(uint64_t *)(self->token_fill + 0),
	    *(uint64_t *)(self->token_fill + 8),
	    *(uint64_t *)(self->token_fill + 16),
	    *(uint64_t *)(self->token_fill + 24),
	    *(uint64_t *)(self->token_fill + 32),
	    *(uint64_t *)(self->token_fill + 40),
	    *(uint64_t *)(self->token_fill + 48),
	    *(uint64_t *)(self->token_fill + 56));
	self->token_fill = 0;
}

fbt:*:do_crypt:entry
{
	self->active_schedule = *(uintptr_t *)(arg0 + 16);
	if (active_schedule_1 == 0 ||
	    active_schedule_1 == self->active_schedule) {
		active_schedule_1 = self->active_schedule;
	} else {
		active_schedule_2 = self->active_schedule;
	}
	if (crypt_seen_schedule != self->active_schedule) {
		crypt_seen_schedule = self->active_schedule;
		crypt_calls = 0;
		last_crypt_time = 0;
		printf("%llu crypt_begin tid=%d schedule=%p\n",
		    (uint64_t)walltimestamp, tid, self->active_schedule);
	}
}

fbt:*:do_crypt:entry
/(*(uintptr_t *)(arg0 + 16) == freed_schedule_1 &&
   schedule_state_1 == 5) ||
  (*(uintptr_t *)(arg0 + 16) == freed_schedule_2 &&
   schedule_state_2 == 5)/
{
	this->schedule = *(uintptr_t *)(arg0 + 16);
	printf("%llu controlled_schedule_use tid=%d schedule=%p data=%p len=%llu q0=%016llx q1=%016llx q2=%016llx q3=%016llx q4=%016llx q5=%016llx q6=%016llx q7=%016llx\n",
	    (uint64_t)walltimestamp, tid, this->schedule, arg1, (uint64_t)arg2,
	    *(uint64_t *)(this->schedule + 0),
	    *(uint64_t *)(this->schedule + 8),
	    *(uint64_t *)(this->schedule + 16),
	    *(uint64_t *)(this->schedule + 24),
	    *(uint64_t *)(this->schedule + 32),
	    *(uint64_t *)(this->schedule + 40),
	    *(uint64_t *)(this->schedule + 48),
	    *(uint64_t *)(this->schedule + 56));
}

fbt:*:do_crypt:entry
/(*(uintptr_t *)(arg0 + 16) == freed_schedule_1 &&
   (schedule_state_1 == 2 || schedule_state_1 == 3)) ||
  (*(uintptr_t *)(arg0 + 16) == freed_schedule_2 &&
   (schedule_state_2 == 2 || schedule_state_2 == 3))/
{
	this->schedule = *(uintptr_t *)(arg0 + 16);
	this->state = this->schedule == freed_schedule_1 ?
	    schedule_state_1 : schedule_state_2;
	printf("%llu token_schedule_use tid=%d schedule=%p state=%d data=%p len=%llu q0=%016llx q1=%016llx q2=%016llx q3=%016llx q4=%016llx q5=%016llx q6=%016llx q7=%016llx\n",
	    (uint64_t)walltimestamp, tid, this->schedule, this->state,
	    arg1, (uint64_t)arg2,
	    *(uint64_t *)(this->schedule + 0),
	    *(uint64_t *)(this->schedule + 8),
	    *(uint64_t *)(this->schedule + 16),
	    *(uint64_t *)(this->schedule + 24),
	    *(uint64_t *)(this->schedule + 32),
	    *(uint64_t *)(this->schedule + 40),
	    *(uint64_t *)(this->schedule + 48),
	    *(uint64_t *)(this->schedule + 56));
}

fbt:*:do_crypt:return
/self->active_schedule &&
  ((self->active_schedule == freed_schedule_1 &&
    (schedule_state_1 == 2 || schedule_state_1 == 3)) ||
   (self->active_schedule == freed_schedule_2 &&
    (schedule_state_2 == 2 || schedule_state_2 == 3)))/
{
	printf("%llu token_schedule_return tid=%d schedule=%p result=%d state=%d\n",
	    (uint64_t)walltimestamp, tid, self->active_schedule, (int)arg1,
	    self->active_schedule == freed_schedule_1 ?
	    schedule_state_1 : schedule_state_2);
}

fbt:*:do_crypt:return
/self->active_schedule/
{
	crypt_calls++;
	last_crypt_time = walltimestamp;
	if (active_schedule_1 == self->active_schedule) {
		active_schedule_1 = 0;
	}
	if (active_schedule_2 == self->active_schedule) {
		active_schedule_2 = 0;
	}
	self->active_schedule = 0;
}
